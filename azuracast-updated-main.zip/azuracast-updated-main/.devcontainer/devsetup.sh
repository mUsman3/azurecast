#!/usr/bin/env bash

make install-cloud-ide
make frontend-build

make up
