<template>
    <section class="card" role="region" id="profile-backend">
        <div class="card-header bg-primary-dark">
            <h3 class="card-title" key="lang_backend_none_title" v-translate>AutoDJ Disabled</h3>
        </div>
        <div class="card-body">
            <p key="lang_backend_none_desc" v-translate>AutoDJ has been disabled for this station. No music will automatically be played when a source is not live.</p>
        </div>
    </section>
</template>

<script>
export default {
    inheritAttrs: false,
}
</script>
