import initBase
  from '~/base.js';

import '~/vendor/bootstrapVue.js';
import '~/vendor/fancybox.js';

import AdminBranding
  from '~/components/Admin/Branding.vue';

export default initBase(AdminBranding);
