import initBase from '~/base.js';

import '~/vendor/bootstrapVue.js';

import AdminShoutcast from '~/components/Admin/Shoutcast.vue';

export default initBase(AdminShoutcast);
