import initBase from '~/base.js';

import '~/vendor/bootstrapVue.js';

import AdminSettings from '~/components/Admin/Settings.vue';

export default initBase(AdminSettings);
