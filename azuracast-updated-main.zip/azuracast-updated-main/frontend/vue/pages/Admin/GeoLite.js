import initBase from '~/base.js';

import '~/vendor/bootstrapVue.js';

import AdminGeoLite from '~/components/Admin/GeoLite.vue';

export default initBase(AdminGeoLite);
