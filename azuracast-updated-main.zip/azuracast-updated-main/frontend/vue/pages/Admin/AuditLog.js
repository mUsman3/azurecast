import initBase
  from '~/base.js';

import '~/vendor/bootstrapVue.js';
import '~/vendor/luxon.js';

import AuditLog
  from '~/components/Admin/AuditLog.vue';

export default initBase(AuditLog);
