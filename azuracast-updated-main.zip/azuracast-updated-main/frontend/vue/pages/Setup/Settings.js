import initBase from '~/base.js';

import '~/vendor/bootstrapVue.js';

import SetupSettings from '~/components/Setup/Settings.vue';

export default initBase(SetupSettings);
