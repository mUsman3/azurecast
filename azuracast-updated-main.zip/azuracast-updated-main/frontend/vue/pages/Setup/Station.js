import initBase from '~/base.js';

import '~/vendor/bootstrapVue.js';

import SetupStation from '~/components/Setup/Station.vue';

export default initBase(SetupStation);
