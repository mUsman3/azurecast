import initBase from '~/base.js';

import '~/vendor/bootstrapVue.js';

import SftpUsers from "~/components/Stations/SftpUsers";

export default initBase(SftpUsers);
