import initBase
  from '~/base.js';

import '~/vendor/bootstrapVue.js';

import Webhooks
  from '~/components/Stations/Webhooks';

export default initBase(Webhooks);
