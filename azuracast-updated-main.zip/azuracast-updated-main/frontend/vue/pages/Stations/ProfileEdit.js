import initBase from '~/base.js';

import '~/vendor/bootstrapVue.js';

import ProfileEdit from '~/components/Stations/ProfileEdit.vue';

export default initBase(ProfileEdit);
