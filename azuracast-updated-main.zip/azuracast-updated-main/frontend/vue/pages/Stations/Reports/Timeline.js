import initBase
  from '~/base.js';

import '~/vendor/bootstrapVue.js';
import '~/vendor/luxon.js';

import Timeline
  from '~/components/Stations/Reports/Timeline.vue';

export default initBase(Timeline);
