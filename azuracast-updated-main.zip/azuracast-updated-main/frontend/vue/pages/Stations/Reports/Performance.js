import initBase
  from '~/base.js';

import '~/vendor/bootstrapVue.js';

import Performance
  from '~/components/Stations/Reports/Performance.vue';

export default initBase(Performance);
