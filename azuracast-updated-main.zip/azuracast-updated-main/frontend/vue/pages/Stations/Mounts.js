import initBase
  from '~/base.js';
import '~/vendor/bootstrapVue.js';

import Mounts
  from '~/components/Stations/Mounts.vue';

export default initBase(Mounts);
