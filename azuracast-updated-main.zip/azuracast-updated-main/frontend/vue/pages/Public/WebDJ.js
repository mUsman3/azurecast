import initBase
  from '~/base.js';

import '~/vendor/bootstrapVue.js';

import WebDJ
  from '~/components/Public/WebDJ.vue';

export default initBase(WebDJ);
