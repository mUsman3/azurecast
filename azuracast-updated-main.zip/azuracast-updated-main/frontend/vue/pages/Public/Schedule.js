import initBase
  from '~/base.js';

import '~/vendor/bootstrapVue.js';
import '~/vendor/luxon.js';

import Schedule
  from '~/components/Public/Schedule.vue';

export default initBase(Schedule);
