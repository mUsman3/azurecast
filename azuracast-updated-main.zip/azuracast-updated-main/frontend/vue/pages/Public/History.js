import initBase
  from '~/base.js';

import '~/vendor/luxon.js';

import History
  from '~/components/Public/History.vue';

export default initBase(History);
