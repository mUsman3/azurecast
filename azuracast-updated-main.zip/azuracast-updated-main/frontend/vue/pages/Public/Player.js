import initBase
  from '~/base.js';

import '~/store.js';

import Player
  from '~/components/Public/Player.vue';

export default initBase(Player);
