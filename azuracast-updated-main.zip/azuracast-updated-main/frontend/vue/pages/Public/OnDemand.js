import initBase
  from '~/base.js';

import '~/vendor/bootstrapVue.js';

import OnDemand
  from '~/components/Public/OnDemand.vue';

export default initBase(OnDemand);
