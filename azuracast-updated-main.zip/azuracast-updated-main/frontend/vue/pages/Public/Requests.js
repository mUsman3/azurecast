import initBase
  from '~/base.js';

import '~/vendor/bootstrapVue.js';

import Requests
  from '~/components/Public/Requests.vue';

export default initBase(Requests);
