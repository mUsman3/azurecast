<?php return array (
  'domain' => NULL,
  'plural-forms' => 'nplurals=4; plural=(n==1) ? 0 : (n>=2 && n<=4) ? 1 : 3;',
  'messages' => 
  array (
    '' => 
    array (
      '' => 
      array (
        0 => 'Project-Id-Version: azuracast
Report-Msgid-Bugs-To: 
Last-Translator: 
Language-Team: Czech
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
POT-Creation-Date: 2021-10-27T06:14:10+00:00
PO-Revision-Date: 2021-10-27 07:09
Language: cs_CZ
Plural-Forms: nplurals=4; plural=(n==1) ? 0 : (n>=2 && n<=4) ? 1 : 3;
X-Crowdin-Project: azuracast
X-Crowdin-Project-ID: 217396
X-Crowdin-Language: cs
X-Crowdin-File: /main/resources/locale/default.pot
X-Crowdin-File-ID: 4
',
      ),
      'Avatars are retrieved based on your e-mail address from the %{service} service. Click to manage your %{service} settings.' => 
      array (
        0 => '',
      ),
      'Drag file(s) here to upload or' => 
      array (
        0 => '',
      ),
      'Select File' => 
      array (
        0 => 'Zvolte soubor',
      ),
      'Today' => 
      array (
        0 => '',
      ),
      'Yesterday' => 
      array (
        0 => '',
      ),
      'Last 7 Days' => 
      array (
        0 => '',
      ),
      'Last 14 Days' => 
      array (
        0 => 'Posledních 14 dní',
      ),
      'Last 30 Days' => 
      array (
        0 => 'Posledních 30 dní',
      ),
      'This Month' => 
      array (
        0 => '',
      ),
      'Last Month' => 
      array (
        0 => '',
      ),
      'Volume' => 
      array (
        0 => 'Hlasitost',
      ),
      'Waveform Zoom' => 
      array (
        0 => '',
      ),
      'Mute' => 
      array (
        0 => 'Umlčet',
      ),
      'Full Volume' => 
      array (
        0 => 'Plná hlasitost',
      ),
      'Edit Record' => 
      array (
        0 => '',
      ),
      'Add Record' => 
      array (
        0 => '',
      ),
      'Copy to Clipboard' => 
      array (
        0 => '',
      ),
      'Close' => 
      array (
        0 => '',
      ),
      'Save Changes' => 
      array (
        0 => 'Uložit změny',
      ),
      'Refresh rows' => 
      array (
        0 => '',
      ),
      'Rows per page' => 
      array (
        0 => '',
      ),
      'Select displayed fields' => 
      array (
        0 => '',
      ),
      'Select all visible rows' => 
      array (
        0 => '',
      ),
      'Select' => 
      array (
        0 => '',
      ),
      'Deselect' => 
      array (
        0 => '',
      ),
      'Search' => 
      array (
        0 => '',
      ),
      'No records to display.' => 
      array (
        0 => '',
      ),
      'Loading...' => 
      array (
        0 => '',
      ),
      'Stop' => 
      array (
        0 => '',
      ),
      'Play' => 
      array (
        0 => 'Hrát',
      ),
      'Listeners' => 
      array (
        0 => 'Posluchači',
      ),
      'Log View' => 
      array (
        0 => '',
      ),
      'Average Listeners' => 
      array (
        0 => '',
      ),
      'Unique Listeners' => 
      array (
        0 => '',
      ),
      'Hide Charts' => 
      array (
        0 => '',
      ),
      'Show Charts' => 
      array (
        0 => '',
      ),
      'My Account' => 
      array (
        0 => '',
      ),
      'Administration' => 
      array (
        0 => '',
      ),
      'Listeners Per Station' => 
      array (
        0 => '',
      ),
      'Station Overview' => 
      array (
        0 => '',
      ),
      'Manage Stations' => 
      array (
        0 => '',
      ),
      'Station Name' => 
      array (
        0 => '',
      ),
      'Now Playing' => 
      array (
        0 => '',
      ),
      'Public Page' => 
      array (
        0 => 'Veřejná stránka',
      ),
      'Manage' => 
      array (
        0 => '',
      ),
      'Username' => 
      array (
        0 => '',
      ),
      'New Password' => 
      array (
        0 => 'Nové heslo',
      ),
      'Password' => 
      array (
        0 => 'Heslo',
      ),
      'Leave blank to use the current password.' => 
      array (
        0 => '',
      ),
      'SSH Public Keys' => 
      array (
        0 => '',
      ),
      'Optionally supply SSH public keys this user can use to connect instead of a password. Enter one key per line.' => 
      array (
        0 => '',
      ),
      'Edit SFTP User' => 
      array (
        0 => 'Upravit SFTP uživatele',
      ),
      'Add SFTP User' => 
      array (
        0 => 'Přidat SFTP uživatele',
      ),
      'Reorder Playlist' => 
      array (
        0 => '',
      ),
      'Down' => 
      array (
        0 => '',
      ),
      'Up' => 
      array (
        0 => '',
      ),
      'Playlist order set.' => 
      array (
        0 => '',
      ),
      'Title' => 
      array (
        0 => 'Název',
      ),
      'Artist' => 
      array (
        0 => 'Interpret',
      ),
      'Album' => 
      array (
        0 => 'Album',
      ),
      'Actions' => 
      array (
        0 => 'Akce',
      ),
      'Advanced' => 
      array (
        0 => 'Pokročilé',
      ),
      'Warning' => 
      array (
        0 => '',
      ),
      'If any of these options are enabled, this playlist will be managed directly via Liquidsoap instead of via AzuraCast. This can have unintended effects and should only be used when you are comfortable with the results.' => 
      array (
        0 => '',
      ),
      'Advanced Manual AutoDJ Scheduling Options' => 
      array (
        0 => '',
      ),
      'Control how this playlist is handled by the AutoDJ software.' => 
      array (
        0 => 'Ovládejte, jak bude tento playlist přehrávat software AutoDJ.',
      ),
      'Interrupt other songs to play at scheduled time.' => 
      array (
        0 => 'Přerušit přehrávání ostatních skladeb v naplánovaném čase.',
      ),
      'Only loop through playlist once.' => 
      array (
        0 => 'Přehrát playlist pouze jednou.',
      ),
      'Only play one track at scheduled time.' => 
      array (
        0 => 'V naplánovaném čase přehrát pouze jednu skladbu.',
      ),
      'Merge playlist to play as a single track.' => 
      array (
        0 => 'Sloučit playlist pro přehrání jako jednu skladbu.',
      ),
      'Low' => 
      array (
        0 => 'Nižší',
      ),
      'Default' => 
      array (
        0 => 'Výchozí',
      ),
      'High' => 
      array (
        0 => 'Vyšší',
      ),
      'Basic Info' => 
      array (
        0 => '',
      ),
      'Playlist Name' => 
      array (
        0 => 'Název playlistu',
      ),
      'Playlist Weight' => 
      array (
        0 => 'Váha playlistu',
      ),
      'Higher weight playlists are played more frequently compared to other lower-weight playlists.' => 
      array (
        0 => 'Playlisty s vyšší váhou se přehrávají častěji než ostatní playlisty s nižší váhou.',
      ),
      'Is Enabled' => 
      array (
        0 => '',
      ),
      'If disabled, the playlist will not be included in radio playback, but can still be managed.' => 
      array (
        0 => '',
      ),
      'Avoid Duplicate Artists/Titles' => 
      array (
        0 => '',
      ),
      'Whether the AutoDJ should attempt to avoid duplicate artists and track titles when playing media from this playlist.' => 
      array (
        0 => '',
      ),
      'Include in On-Demand Player' => 
      array (
        0 => '',
      ),
      'If this station has on-demand streaming and downloading enabled, only songs that are in playlists with this setting enabled will be visible.' => 
      array (
        0 => '',
      ),
      'Playlist Type' => 
      array (
        0 => '',
      ),
      'General Rotation' => 
      array (
        0 => 'Obecná rotace',
      ),
      'Standard playlist, shuffles with other standard playlists based on weight.' => 
      array (
        0 => '',
      ),
      'Once per x Songs' => 
      array (
        0 => 'Jednou za x skladeb',
      ),
      'Play exactly once every $x songs.' => 
      array (
        0 => '',
      ),
      'Once per x Minutes' => 
      array (
        0 => '',
      ),
      'Play exactly once every $x minutes.' => 
      array (
        0 => '',
      ),
      'Once per Hour' => 
      array (
        0 => 'Jednou za hodinu',
      ),
      'Play once per hour at the specified minute.' => 
      array (
        0 => 'Hraje jednou za hodinu ve stanovené minutě.',
      ),
      'Manually define how this playlist is used in Liquidsoap configuration.' => 
      array (
        0 => '',
      ),
      'Learn about Advanced Playlists' => 
      array (
        0 => '',
      ),
      'Include in Automated Assignment' => 
      array (
        0 => 'Zahrnout do automatizovaného přiřazení',
      ),
      'If auto-assignment is enabled, use this playlist as one of the targets for songs to be redistributed into. This will overwrite the existing contents of this playlist.' => 
      array (
        0 => 'Pokud je povoleno automatizované přiřazení, použije se tento playlist jako jeden z cílů pro distribuci skladeb. Tím dojde k přepsání existujícího obsahu tohoto playlistu.',
      ),
      'Number of Songs Between Plays' => 
      array (
        0 => 'Počet skladeb mezi přehráním',
      ),
      'This playlist will play every $x songs, where $x is specified below.' => 
      array (
        0 => 'Tento playlist bude hrát každých $x skladeb, kde $x je uvedeno výše.',
      ),
      'Number of Minutes Between Plays' => 
      array (
        0 => 'Počet minut mezi přehráním',
      ),
      'This playlist will play every $x minutes, where $x is specified below.' => 
      array (
        0 => 'Tento playlist bude hrát každých $x minut, kde $x je uvedeno výše.',
      ),
      'Minute of Hour to Play' => 
      array (
        0 => 'Minuta hodiny pro přehrání',
      ),
      'Specify the minute of every hour that this playlist should play.' => 
      array (
        0 => 'Zvolte minutu každé hodiny, kterou by měl hrát tento playlist.',
      ),
      'Monday' => 
      array (
        0 => 'Pondělí',
      ),
      'Tuesday' => 
      array (
        0 => 'Úterý',
      ),
      'Wednesday' => 
      array (
        0 => 'Středa',
      ),
      'Thursday' => 
      array (
        0 => 'Čtvrtek',
      ),
      'Friday' => 
      array (
        0 => 'Pátek',
      ),
      'Saturday' => 
      array (
        0 => 'Sobota',
      ),
      'Sunday' => 
      array (
        0 => 'Neděle',
      ),
      'Schedule' => 
      array (
        0 => '',
      ),
      'Not Scheduled' => 
      array (
        0 => '',
      ),
      'This playlist currently has no scheduled times. It will play at all times. To add a new scheduled time, click the button below.' => 
      array (
        0 => '',
      ),
      'Scheduled Time #%{num}' => 
      array (
        0 => '',
      ),
      'Remove' => 
      array (
        0 => '',
      ),
      'Start Time' => 
      array (
        0 => 'Čas zahájení',
      ),
      'To play once per day, set the start and end times to the same value.' => 
      array (
        0 => 'Chcete-li hrát jednou za den, nastavte začátek a konec času na stejnou hodnotu.',
      ),
      'End Time' => 
      array (
        0 => 'Čas ukončení',
      ),
      'If the end time is before the start time, the playlist will play overnight.' => 
      array (
        0 => 'Pokud je čas ukončení před časem zahájení, bude playlist hrát přes noc.',
      ),
      'Station Time Zone' => 
      array (
        0 => 'Časové pásmo stanice',
      ),
      'This station\'s time zone is currently %{tz}.' => 
      array (
        0 => '',
      ),
      'Start Date' => 
      array (
        0 => '',
      ),
      'To set this schedule to run only within a certain date range, specify a start and end date.' => 
      array (
        0 => '',
      ),
      'Start/end date cannot be used on playlists with advanced settings!' => 
      array (
        0 => '',
      ),
      'End Date' => 
      array (
        0 => '',
      ),
      'Loop Once' => 
      array (
        0 => '',
      ),
      'Scheduled Play Days of Week' => 
      array (
        0 => 'Plánované dny v týdnu',
      ),
      'Leave blank to play on every day of the week.' => 
      array (
        0 => 'Nechte prázdné, aby playlist hrál každý den v týdnu.',
      ),
      'Add Schedule Item' => 
      array (
        0 => '',
      ),
      'Source' => 
      array (
        0 => 'Zdroj',
      ),
      'Song-Based Playlist' => 
      array (
        0 => 'Playlist založený na skladbách',
      ),
      'A playlist containing media files hosted on this server.' => 
      array (
        0 => 'Playlist obsahující mediální soubory hostované na tomto serveru.',
      ),
      'Remote URL Playlist' => 
      array (
        0 => 'Vzdálený playlist',
      ),
      'A playlist that instructs the station to play from a remote URL.' => 
      array (
        0 => 'Seznam stop, který instruuje stanici, aby hrála ze vzdálené URL adresy.',
      ),
      'Song Playback Order' => 
      array (
        0 => 'Pořadí přehrávání skladeb',
      ),
      'Shuffled' => 
      array (
        0 => 'Zamíchané',
      ),
      'The full playlist is shuffled and then played through in the shuffled order.' => 
      array (
        0 => '',
      ),
      'Random' => 
      array (
        0 => 'Náhodné',
      ),
      'A completely random track is picked for playback every time the queue is populated.' => 
      array (
        0 => '',
      ),
      'Sequential' => 
      array (
        0 => 'Postupné',
      ),
      'The order of the playlist is manually specified and followed by the AutoDJ.' => 
      array (
        0 => '',
      ),
      'If requests are enabled for your station, users will be able to request media that is on this playlist.' => 
      array (
        0 => 'Pokud jsou pro vaši stanici povoleny žádosti, uživatelé budou moci požádat o skladby, které jsou v tomto playlistu.',
      ),
      'Allow Requests from This Playlist' => 
      array (
        0 => 'Povolit žádosti o skladby z tohoto playlistu',
      ),
      'Enable this setting to prevent metadata from being sent to the AutoDJ for files in this playlist. This is useful if the playlist contains jingles or bumpers.' => 
      array (
        0 => 'Povolte toto nastavení, abyste pro soubory v tomto playlistu zabránili odesílání metadat do AutoDJe. To je užitečné v případě, že playlist obsahuje znělky, reklamy a podobně.',
      ),
      'Hide Metadata from Listeners ("Jingle Mode")' => 
      array (
        0 => 'Skrýt posluchačům metadata ("Jingle mód")',
      ),
      'Remote URL' => 
      array (
        0 => 'Vzdálené URL',
      ),
      'Remote URL Type' => 
      array (
        0 => 'Typ vzdáleného URL',
      ),
      'Direct Stream URL' => 
      array (
        0 => 'URL přímého streamu',
      ),
      'Playlist (M3U/PLS) URL' => 
      array (
        0 => 'URL playlistu (M3U/PLS)',
      ),
      'Remote Playback Buffer (Seconds)' => 
      array (
        0 => 'Vzdálená vyrovnávací paměť (sekundy)',
      ),
      'The length of playback time that Liquidsoap should buffer when playing this remote playlist. Shorter times may lead to intermittent playback on unstable connections.' => 
      array (
        0 => 'Délka přehrávání, kterou by měl Liquidsoap při použití tohoto vzdáleného playlistu přednačítat. Kratší časy mohou vést k přerušovanému přehrávání na nestabilních připojeních.',
      ),
      'Import from PLS/M3U' => 
      array (
        0 => '',
      ),
      'Select PLS/M3U File to Import' => 
      array (
        0 => '',
      ),
      'AzuraCast will scan the uploaded file for matches in this station\'s music library. Media should already be uploaded before running this step. You can re-run this tool as many times as needed.' => 
      array (
        0 => '',
      ),
      'Duplicate Playlist' => 
      array (
        0 => '',
      ),
      '%{name} - Copy' => 
      array (
        0 => '',
      ),
      'New Playlist Name' => 
      array (
        0 => '',
      ),
      'Customize Copy' => 
      array (
        0 => '',
      ),
      'Copy associated media and folders.' => 
      array (
        0 => '',
      ),
      'Copy scheduled playback times.' => 
      array (
        0 => '',
      ),
      'Playback Queue' => 
      array (
        0 => '',
      ),
      'Playlist queue cleared.' => 
      array (
        0 => 'Fronta playlistu vymazána.',
      ),
      'This queue contains the remaining tracks in the order they will be queued by the AzuraCast AutoDJ (if the tracks are eligible to be played).' => 
      array (
        0 => '',
      ),
      'Clear Queue' => 
      array (
        0 => '',
      ),
      'Edit Playlist' => 
      array (
        0 => '',
      ),
      'Add Playlist' => 
      array (
        0 => '',
      ),
      'Edit Station Profile' => 
      array (
        0 => '',
      ),
      'Song Title' => 
      array (
        0 => 'Název skladby',
      ),
      'Cued On' => 
      array (
        0 => '',
      ),
      'Delete Queue Item?' => 
      array (
        0 => '',
      ),
      'Clear Upcoming Song Queue?' => 
      array (
        0 => '',
      ),
      'Clear' => 
      array (
        0 => '',
      ),
      'Upcoming Song Queue' => 
      array (
        0 => 'Nadcházející fronta skladeb',
      ),
      'Clear Upcoming Song Queue' => 
      array (
        0 => '',
      ),
      'Logs' => 
      array (
        0 => '',
      ),
      'Delete' => 
      array (
        0 => 'Odstranit',
      ),
      'Listener Request' => 
      array (
        0 => '',
      ),
      'Playlist:' => 
      array (
        0 => '',
      ),
      'Remote Station Type' => 
      array (
        0 => 'Typ vzdálené stanice',
      ),
      'Display Name' => 
      array (
        0 => 'Zobrazovaný název',
      ),
      'The display name assigned to this relay when viewing it on administrative or public pages. Leave blank to automatically generate one.' => 
      array (
        0 => 'Zobrazovaný název přiřazený tomuto vzdálenému připojení při zobrazení na administrativních nebo veřejných stránkách. Nechte prázdné pro automatické vygenerování.',
      ),
      'Remote Station Listening URL' => 
      array (
        0 => 'URL adresa pro vzdálenou stanici',
      ),
      'Example: if the remote radio URL is http://station.example.com:8000/radio.mp3, enter "http://station.example.com:8000".' => 
      array (
        0 => '',
      ),
      'Remote Station Listening Mountpoint/SID' => 
      array (
        0 => 'Přípojný bod/SID vzdálené stanice',
      ),
      'Specify a mountpoint (i.e. "/radio.mp3") or a Shoutcast SID (i.e. "2") to specify a specific stream to use for statistics or broadcasting.' => 
      array (
        0 => '',
      ),
      'Remote Station Administrator Password' => 
      array (
        0 => '',
      ),
      'To retrieve detailed unique listeners and client details, an administrator password is often required.' => 
      array (
        0 => '',
      ),
      'Show on Public Pages' => 
      array (
        0 => 'Zobrazit na veřejných stránkách',
      ),
      'Enable to allow listeners to select this relay on this station\'s public pages.' => 
      array (
        0 => 'Umožněte posluchačům vybrat toto vzdálené připojení na veřejných stránkách této stanice.',
      ),
      'AutoDJ' => 
      array (
        0 => '',
      ),
      'Broadcast AutoDJ to Remote Station' => 
      array (
        0 => 'Vysílání AutoDJ do vzdálené stanice',
      ),
      'If enabled, the AutoDJ on this installation will automatically play music to this mount point.' => 
      array (
        0 => 'Pokud je povoleno, funkce AutoDJ této instalace bude do tohoto přípojného bodu automaticky přehrávat playlisty.',
      ),
      'AutoDJ Format' => 
      array (
        0 => 'Formát funkce AutoDJ',
      ),
      'AutoDJ Bitrate (kbps)' => 
      array (
        0 => 'Přenosová rychlost funkce AutoDJ (kbps)',
      ),
      'Remote Station Source Port' => 
      array (
        0 => 'Zdrojový port vzdálené stanice',
      ),
      'If the port you broadcast to is different from the one you listed in the URL above, specify the source port here.' => 
      array (
        0 => 'Pokud se port, na který se vysílá, liší od portu uvedeného výše, určete zdrojový port zde.',
      ),
      'Remote Station Source Mountpoint/SID' => 
      array (
        0 => 'Přípojný bod/SID vzdálené stanice',
      ),
      'If the mountpoint (i.e. /radio.mp3) or Shoutcast SID (i.e. 2) you broadcast to is different from the one listed above, specify the source mount point here.' => 
      array (
        0 => '',
      ),
      'Remote Station Source Username' => 
      array (
        0 => 'Zdrojové uživatelské jméno vzdálené stanice',
      ),
      'If you are broadcasting using AutoDJ, enter the source username here. This may be blank.' => 
      array (
        0 => 'Pokud se vysílá pomocí funkce AutoDJ, zadejte zde zdrojové uživatelské jméno. Může být prázdné.',
      ),
      'Remote Station Source Password' => 
      array (
        0 => 'Zdrojové heslo vzdálené stanice',
      ),
      'If you are broadcasting using AutoDJ, enter the source password here.' => 
      array (
        0 => 'Pokud se vysílá pomocí funkce AutoDJ, zadejte zde zdrojové heslo.',
      ),
      'Publish to "Yellow Pages" Directories' => 
      array (
        0 => 'Publikovat do adresářů "Zlaté stránky"',
      ),
      'Enable to advertise this relay on "Yellow Pages" public radio directories.' => 
      array (
        0 => '',
      ),
      'Edit Remote Relay' => 
      array (
        0 => '',
      ),
      'Add Remote Relay' => 
      array (
        0 => '',
      ),
      'Playlist' => 
      array (
        0 => 'Playlist',
      ),
      'Scheduling' => 
      array (
        0 => 'Plánování',
      ),
      '# Songs' => 
      array (
        0 => '',
      ),
      'All Playlists' => 
      array (
        0 => '',
      ),
      'Schedule View' => 
      array (
        0 => '',
      ),
      'More' => 
      array (
        0 => '',
      ),
      'Reorder' => 
      array (
        0 => '',
      ),
      'Reshuffle' => 
      array (
        0 => '',
      ),
      'Duplicate' => 
      array (
        0 => '',
      ),
      'Disable' => 
      array (
        0 => 'Zakázáno',
      ),
      'Enable' => 
      array (
        0 => 'Povoleno',
      ),
      'Disabled' => 
      array (
        0 => 'Zakázáno',
      ),
      'Weight' => 
      array (
        0 => '',
      ),
      'Once per %{songs} Songs' => 
      array (
        0 => '',
      ),
      'Once per %{minutes} Minutes' => 
      array (
        0 => '',
      ),
      'Once per Hour (at %{minute})' => 
      array (
        0 => '',
      ),
      'Custom' => 
      array (
        0 => '',
      ),
      'Delete Playlist?' => 
      array (
        0 => '',
      ),
      'Playlists' => 
      array (
        0 => '',
      ),
      'Edit' => 
      array (
        0 => '',
      ),
      'Export %{format}' => 
      array (
        0 => '',
      ),
      'Song-based' => 
      array (
        0 => '',
      ),
      'Jingle Mode' => 
      array (
        0 => '',
      ),
      'On-Demand' => 
      array (
        0 => '',
      ),
      'Auto-Assigned' => 
      array (
        0 => '',
      ),
      'Name' => 
      array (
        0 => 'Název',
      ),
      'Delete Remote Relay?' => 
      array (
        0 => '',
      ),
      'Remote Relays' => 
      array (
        0 => 'Vzdálená připojení',
      ),
      'Remote relays let you work with broadcasting software outside this server. Any relay you include here will be included in your station\'s statistics. You can also broadcast from this server to remote relays.' => 
      array (
        0 => '',
      ),
      'Enabled' => 
      array (
        0 => 'Povoleno',
      ),
      'Mount Point URL' => 
      array (
        0 => 'URL přípojného bodu',
      ),
      'You can set a custom URL for this stream that AzuraCast will use when referring to it. Leave empty to use the default value.' => 
      array (
        0 => 'Pro tento stream můžete nastavit vlastní adresu URL, kterou bude služba AzuraCast používat, když na ni bude odkazováno. Chcete-li použít výchozí hodnotu, ponechte prázdné.',
      ),
      'Custom Frontend Configuration' => 
      array (
        0 => 'Vlastní konfigurace frontendu',
      ),
      'You can include any special mount point settings here, in either JSON { key: \'value\' } format or XML <key>value</key>' => 
      array (
        0 => '',
      ),
      'This name should always begin with a slash (/), and must be a valid URL, such as /autodj.mp3' => 
      array (
        0 => 'Tento řetězec by měl vždy začínat lomítkem (/) a musí být platnou adresou URL, například /autodj.mp3',
      ),
      'The display name assigned to this mount point when viewing it on administrative or public pages. Leave blank to automatically generate one.' => 
      array (
        0 => 'Zobrazovaný název přiřazený tomuto přípojnému bodu při zobrazení na administrativních nebo veřejných stránkách. Nechte prázdné pro automatické vygenerování.',
      ),
      'Enable to allow listeners to select this mount point on this station\'s public pages.' => 
      array (
        0 => 'Umožněte posluchačům vybrat tento přípojný bod na veřejných stránkách této stanice.',
      ),
      'Set as Default Mount Point' => 
      array (
        0 => 'Nastavit jako výchozí přípojný bod',
      ),
      'If this mount is the default, it will be played on the radio preview and the public radio page in this system.' => 
      array (
        0 => 'Pokud je toto připojení výchozí, bude přehráno v náhledu rádia a na veřejné stránce rádia.',
      ),
      'Relay Stream URL' => 
      array (
        0 => 'URL jiného streamu',
      ),
      'Enter the full URL of another stream to relay its broadcast through this mount point.' => 
      array (
        0 => 'Zadejte úplnou adresu URL jiného streamu, aby bylo možné přenášet vysílání prostřednictvím tohoto bodu připojení.',
      ),
      'Enable to advertise this mount point on "Yellow Pages" public radio directories.' => 
      array (
        0 => 'Povolit publikování tohoto přípojného bodu do veřejných adresářů rádiových stanic typu "Zlaté stránky".',
      ),
      'Max Listener Duration' => 
      array (
        0 => '',
      ),
      'Set the length of time (seconds) a listener will stay connected to the stream. If set to 0, listeners can stay connected infinitely.' => 
      array (
        0 => '',
      ),
      'YP Directory Authorization Hash' => 
      array (
        0 => 'Autorizační hash adresáře YP',
      ),
      'Fallback Mount' => 
      array (
        0 => 'Nouzový přípojný bod',
      ),
      'If this mount point is not playing audio, listeners will automatically be redirected to this mount point. The default is /error.mp3, a repeating error message.' => 
      array (
        0 => 'Pokud tento přípojný bod nepřehrává zvuk, posluchači budou automaticky přesměrováni na tento přípojný bod. Výchozí hodnota je /error.mp3, opakující se chybová zpráva.',
      ),
      'Enable AutoDJ' => 
      array (
        0 => 'Povolit funkci AutoDJ',
      ),
      'If enabled, the AutoDJ will automatically play music to this mount point.' => 
      array (
        0 => 'Pokud je povoleno, funkce AutoDJ bude do tohoto přípojného bodu automaticky přehrávat playlisty.',
      ),
      'Intro' => 
      array (
        0 => '',
      ),
      'Select Intro File' => 
      array (
        0 => '',
      ),
      'This introduction file should exactly match the bitrate and format of the mount point itself.' => 
      array (
        0 => '',
      ),
      'Current Intro File' => 
      array (
        0 => '',
      ),
      'Download' => 
      array (
        0 => '',
      ),
      'Clear File' => 
      array (
        0 => '',
      ),
      'There is no existing intro file associated with this mount point.' => 
      array (
        0 => '',
      ),
      'Edit Mount Point' => 
      array (
        0 => '',
      ),
      'Add Mount Point' => 
      array (
        0 => '',
      ),
      'Delete SFTP User?' => 
      array (
        0 => '',
      ),
      'SFTP Users' => 
      array (
        0 => 'SFTP Uživatelé',
      ),
      'Connection Information' => 
      array (
        0 => '',
      ),
      'Server:' => 
      array (
        0 => '',
      ),
      'You may need to connect directly to your IP address:' => 
      array (
        0 => '',
      ),
      'Port:' => 
      array (
        0 => '',
      ),
      'Web Hook Details' => 
      array (
        0 => '',
      ),
      'Web hooks automatically send a HTTP POST request to the URL you specify to notify it any time one of the triggers you specify occurs on your station.' => 
      array (
        0 => '',
      ),
      'The body of the POST message is the exact same as the NowPlaying API response for your station.' => 
      array (
        0 => '',
      ),
      'NowPlaying API Response' => 
      array (
        0 => '',
      ),
      'In order to process quickly, web hooks have a short timeout, so the responding service should be optimized to handle the request in under 2 seconds.' => 
      array (
        0 => '',
      ),
      'Web Hook URL' => 
      array (
        0 => '',
      ),
      'The URL that will receive the POST messages any time an event is triggered.' => 
      array (
        0 => '',
      ),
      'Optional: HTTP Basic Authentication Username' => 
      array (
        0 => '',
      ),
      'If your web hook requires HTTP basic authentication, provide the username here.' => 
      array (
        0 => '',
      ),
      'Optional: HTTP Basic Authentication Password' => 
      array (
        0 => '',
      ),
      'If your web hook requires HTTP basic authentication, provide the password here.' => 
      array (
        0 => '',
      ),
      'Matomo Installation Base URL' => 
      array (
        0 => '',
      ),
      'The full base URL of your Matomo installation.' => 
      array (
        0 => '',
      ),
      'Matomo Site ID' => 
      array (
        0 => '',
      ),
      'The numeric site ID for this site.' => 
      array (
        0 => '',
      ),
      'Matomo API Token' => 
      array (
        0 => '',
      ),
      'Optionally supply an API token to allow IP address overriding.' => 
      array (
        0 => '',
      ),
      'Discord Web Hook URL' => 
      array (
        0 => '',
      ),
      'This URL is provided within the Discord application.' => 
      array (
        0 => '',
      ),
      'Main Message Content' => 
      array (
        0 => '',
      ),
      'Description' => 
      array (
        0 => '',
      ),
      'URL' => 
      array (
        0 => '',
      ),
      'Author Name' => 
      array (
        0 => '',
      ),
      'Thumbnail Image URL' => 
      array (
        0 => '',
      ),
      'Footer Text' => 
      array (
        0 => '',
      ),
      'Web Hook Name' => 
      array (
        0 => '',
      ),
      'Choose a name for this webhook that will help you distinguish it from others. This will only be shown on the administration page.' => 
      array (
        0 => '',
      ),
      'Web Hook Triggers' => 
      array (
        0 => '',
      ),
      'This web hook will only run when the selected event(s) occur on this specific station.' => 
      array (
        0 => '',
      ),
      'Message Customization Tips' => 
      array (
        0 => '',
      ),
      'Variables are in the form of:' => 
      array (
        0 => '',
      ),
      'All values in the NowPlaying API response are available for use. Any empty fields are ignored.' => 
      array (
        0 => '',
      ),
      'TuneIn Station ID' => 
      array (
        0 => '',
      ),
      'The station ID will be a numeric string that starts with the letter S.' => 
      array (
        0 => '',
      ),
      'TuneIn Partner ID' => 
      array (
        0 => '',
      ),
      'TuneIn Partner Key' => 
      array (
        0 => '',
      ),
      'Markdown' => 
      array (
        0 => '',
      ),
      'HTML' => 
      array (
        0 => '',
      ),
      'Bot Token' => 
      array (
        0 => '',
      ),
      'See the Telegram Documentation for more details.' => 
      array (
        0 => '',
      ),
      'Chat ID' => 
      array (
        0 => '',
      ),
      'Unique identifier for the target chat or username of the target channel (in the format @channelusername).' => 
      array (
        0 => '',
      ),
      'Custom API Base URL' => 
      array (
        0 => '',
      ),
      'Leave blank to use the default Telegram API URL (recommended).' => 
      array (
        0 => '',
      ),
      'Message parsing mode' => 
      array (
        0 => '',
      ),
      'See the Telegram documentation for more details.' => 
      array (
        0 => '',
      ),
      'GA Property Tracking ID' => 
      array (
        0 => '',
      ),
      'The property ID used to track live listeners.' => 
      array (
        0 => '',
      ),
      'Message Recipient(s)' => 
      array (
        0 => '',
      ),
      'E-mail addresses can be separated by commas.' => 
      array (
        0 => '',
      ),
      'Message Subject' => 
      array (
        0 => '',
      ),
      'Message Body' => 
      array (
        0 => '',
      ),
      'Select Web Hook Type' => 
      array (
        0 => '',
      ),
      '%{ seconds } seconds' => 
      array (
        0 => '',
      ),
      '%{ minutes } minutes' => 
      array (
        0 => '',
      ),
      'No Limit' => 
      array (
        0 => '',
      ),
      'Twitter Account Details' => 
      array (
        0 => '',
      ),
      'Steps for configuring a Twitter application:' => 
      array (
        0 => '',
      ),
      'Create a new app on the Twitter Applications site. Use this installation\'s base URL as the application URL.' => 
      array (
        0 => '',
      ),
      'Twitter Applications' => 
      array (
        0 => '',
      ),
      'In the newly created application, click the "Keys and Access Tokens" tab.' => 
      array (
        0 => '',
      ),
      'At the bottom of the page, click "Create my access token".' => 
      array (
        0 => '',
      ),
      'Once these steps are completed, enter the information from the "Keys and Access Tokens" page into the fields below.' => 
      array (
        0 => '',
      ),
      'Consumer Key (API Key)' => 
      array (
        0 => '',
      ),
      'Consumer Secret (API Secret)' => 
      array (
        0 => '',
      ),
      'Access Token' => 
      array (
        0 => '',
      ),
      'Access Token Secret' => 
      array (
        0 => '',
      ),
      'Only Send One Tweet Every...' => 
      array (
        0 => '',
      ),
      'Edit Web Hook' => 
      array (
        0 => 'Upravit webhook',
      ),
      'Add Web Hook' => 
      array (
        0 => 'Přidat webhook',
      ),
      'Powered by AzuraCast' => 
      array (
        0 => '',
      ),
      'Now playing on %{ station }:' => 
      array (
        0 => '',
      ),
      'Now playing on %{ station }: %{ title } by %{ artist }! Tune in now.' => 
      array (
        0 => '',
      ),
      'Now playing on %{ station }: %{ title } by %{ artist }! Tune in now: %{ url }' => 
      array (
        0 => '',
      ),
      'Disable song requests?' => 
      array (
        0 => 'Zakázat požadavky na skladby?',
      ),
      'Enable song requests?' => 
      array (
        0 => 'Povolit požadavky na skladby?',
      ),
      'Song Requests' => 
      array (
        0 => 'Žádosti o skladby',
      ),
      'View' => 
      array (
        0 => 'Zobrazit',
      ),
      'Streams' => 
      array (
        0 => '',
      ),
      'Local Streams' => 
      array (
        0 => '',
      ),
      'Unique' => 
      array (
        0 => '',
      ),
      'Download PLS' => 
      array (
        0 => '',
      ),
      'Download M3U' => 
      array (
        0 => '',
      ),
      '%{listeners} Listener' => 
      array (
        0 => '',
      ),
      'On the Air' => 
      array (
        0 => '',
      ),
      'Playing Next' => 
      array (
        0 => '',
      ),
      'Live' => 
      array (
        0 => '',
      ),
      'Skip Song' => 
      array (
        0 => '',
      ),
      'Disconnect Streamer' => 
      array (
        0 => '',
      ),
      'Disable streamers?' => 
      array (
        0 => '',
      ),
      'Enable streamers?' => 
      array (
        0 => '',
      ),
      'Streamers/DJs' => 
      array (
        0 => '',
      ),
      'Edit Profile' => 
      array (
        0 => 'Upravit profil',
      ),
      'Disable public pages?' => 
      array (
        0 => '',
      ),
      'Enable public pages?' => 
      array (
        0 => '',
      ),
      'Public Pages' => 
      array (
        0 => '',
      ),
      'Web DJ' => 
      array (
        0 => 'Web DJ',
      ),
      'On-Demand Media' => 
      array (
        0 => 'Média na vyžádání',
      ),
      'Podcasts' => 
      array (
        0 => 'Podcasty',
      ),
      'Embed Widgets' => 
      array (
        0 => '',
      ),
      'Broadcasting Service' => 
      array (
        0 => '',
      ),
      'Administration URL' => 
      array (
        0 => '',
      ),
      'Administrator Password' => 
      array (
        0 => '',
      ),
      'Source Password' => 
      array (
        0 => '',
      ),
      'Relay Password' => 
      array (
        0 => '',
      ),
      'Restart' => 
      array (
        0 => '',
      ),
      'Start' => 
      array (
        0 => '',
      ),
      'Radio Player' => 
      array (
        0 => '',
      ),
      'History' => 
      array (
        0 => '',
      ),
      'Requests' => 
      array (
        0 => '',
      ),
      'Light' => 
      array (
        0 => 'Světlé',
      ),
      'Dark' => 
      array (
        0 => 'Tmavé',
      ),
      'Widget Type' => 
      array (
        0 => '',
      ),
      'Theme' => 
      array (
        0 => '',
      ),
      'Customize' => 
      array (
        0 => '',
      ),
      'Embed Code' => 
      array (
        0 => '',
      ),
      'Preview' => 
      array (
        0 => '',
      ),
      'Scheduled' => 
      array (
        0 => 'Rozvrh',
      ),
      'Streamer/DJ' => 
      array (
        0 => '',
      ),
      'Now' => 
      array (
        0 => '',
      ),
      'AutoDJ Disabled' => 
      array (
        0 => '',
      ),
      'AutoDJ has been disabled for this station. No music will automatically be played when a source is not live.' => 
      array (
        0 => '',
      ),
      '%{numSongs} uploaded song' => 
      array (
        0 => '',
      ),
      '%{numPlaylists} playlist' => 
      array (
        0 => '',
      ),
      'LiquidSoap is currently shuffling from %{songs} and %{playlists}.' => 
      array (
        0 => '',
      ),
      'AutoDJ Service' => 
      array (
        0 => '',
      ),
      'Running' => 
      array (
        0 => '',
      ),
      'Not Running' => 
      array (
        0 => '',
      ),
      'Delete Mount Point?' => 
      array (
        0 => '',
      ),
      'Mount Points' => 
      array (
        0 => 'Přípojné body',
      ),
      'Mount points are how listeners connect and listen to your station. Each mount point can be a different audio format or quality. Using mount points, you can set up a high-quality stream for broadband listeners and a mobile stream for phone users.' => 
      array (
        0 => '',
      ),
      'Default Mount' => 
      array (
        0 => '',
      ),
      'Genre' => 
      array (
        0 => 'Žánr',
      ),
      'Length' => 
      array (
        0 => 'Délka',
      ),
      'Size' => 
      array (
        0 => '',
      ),
      'Modified' => 
      array (
        0 => '',
      ),
      'Album Art' => 
      array (
        0 => 'Obal alba',
      ),
      'Rename' => 
      array (
        0 => '',
      ),
      'View tracks in playlist' => 
      array (
        0 => '',
      ),
      '%{spaceUsed} of %{spaceTotal} Used (%{filesCount} Files)' => 
      array (
        0 => '',
      ),
      '%{spaceUsed} Used (%{filesCount} Files)' => 
      array (
        0 => '',
      ),
      'Music Files' => 
      array (
        0 => '',
      ),
      'You can also upload files in bulk via SFTP.' => 
      array (
        0 => '',
      ),
      'Manage SFTP Accounts' => 
      array (
        0 => '',
      ),
      'Directory' => 
      array (
        0 => 'Adresář',
      ),
      'Move %{ num } File(s) to' => 
      array (
        0 => '',
      ),
      'Files moved:' => 
      array (
        0 => '',
      ),
      'Back' => 
      array (
        0 => '',
      ),
      'Move to Directory' => 
      array (
        0 => '',
      ),
      'Home' => 
      array (
        0 => '',
      ),
      'Basic Information' => 
      array (
        0 => 'Základní Informace',
      ),
      'File Name' => 
      array (
        0 => 'Jméno souboru',
      ),
      'The relative path of the file in the station\'s media directory.' => 
      array (
        0 => 'Relativní cesta souboru v mediálním adresáři stanice.',
      ),
      'Song Artist' => 
      array (
        0 => 'Interpret skladby',
      ),
      'Song Genre' => 
      array (
        0 => '',
      ),
      'Song Album' => 
      array (
        0 => 'Album skladby',
      ),
      'Song Lyrics' => 
      array (
        0 => 'Texty skladby',
      ),
      'ISRC' => 
      array (
        0 => 'ISRC',
      ),
      'International Standard Recording Code, used for licensing reports.' => 
      array (
        0 => 'Mezinárodní standardní kód záznamů, který se používá pro zprávy o licencích.',
      ),
      'Visual Cue Editor' => 
      array (
        0 => '',
      ),
      'Set cue and fade points using the visual editor. The timestamps will be saved to the corresponding fields in the advanced playback settings.' => 
      array (
        0 => '',
      ),
      'Set Cue In' => 
      array (
        0 => '',
      ),
      'Set Cue Out' => 
      array (
        0 => '',
      ),
      'Set Overlap' => 
      array (
        0 => '',
      ),
      'Set Fade In' => 
      array (
        0 => '',
      ),
      'Set Fade Out' => 
      array (
        0 => '',
      ),
      'Custom Fields' => 
      array (
        0 => 'Vlastní pole',
      ),
      'Delete Album Art' => 
      array (
        0 => '',
      ),
      'Replace Album Cover Art' => 
      array (
        0 => 'Vyměnit přebal alba',
      ),
      'Song Length' => 
      array (
        0 => '',
      ),
      'Amplify: Amplification (dB)' => 
      array (
        0 => '',
      ),
      'The volume in decibels to amplify the track with. Leave blank to use the system default.' => 
      array (
        0 => '',
      ),
      'Custom Fading: Overlap Time (seconds)' => 
      array (
        0 => 'Vlastní přechod: doba překrytí (v sekundách)',
      ),
      'The time that this song should overlap its surrounding songs when fading. Leave blank to use the system default.' => 
      array (
        0 => 'Doba, po kterou by se tato skladba měla při přechodu překrývat se sousedními. Chcete-li použít výchozí nastavení systému, ponechte prázdné.',
      ),
      'Custom Fading: Fade-In Time (seconds)' => 
      array (
        0 => 'Vlastní přechod: zesilování zvuku (v sekundách)',
      ),
      'The time period that the song should fade in. Leave blank to use the system default.' => 
      array (
        0 => 'Časová sekvence, ve které by se měla skladba překrývat na začátku. Chcete-li použít výchozí nastavení systému, ponechte prázdné.',
      ),
      'Custom Fading: Fade-Out Time (seconds)' => 
      array (
        0 => 'Vlastní přechod: zeslabování zvuku (v sekundách)',
      ),
      'The time period that the song should fade out. Leave blank to use the system default.' => 
      array (
        0 => 'Časová sekvence, ve které by se měla skladba překrývat na konci. Chcete-li použít výchozí nastavení systému, ponechte prázdné.',
      ),
      'Custom Cues: Cue-In Point (seconds)' => 
      array (
        0 => 'Vlastní střih: místo nástupu (v sekundách)',
      ),
      'Seconds from the start of the song that the AutoDJ should start playing.' => 
      array (
        0 => 'Počet sekund od začátku skladby, kde má AutoDJ začít přehrávat.',
      ),
      'Custom Cues: Cue-Out Point (seconds)' => 
      array (
        0 => 'Vlastní střih: místo ukončení (v sekundách)',
      ),
      'Seconds from the start of the song that the AutoDJ should stop playing.' => 
      array (
        0 => 'Počet sekund od začátku skladby, kde má AutoDJ přestat přehrávat.',
      ),
      'Rename File/Directory' => 
      array (
        0 => 'Přejmenování souboru/adresáře',
      ),
      'New File Name' => 
      array (
        0 => '',
      ),
      'Set or clear playlists from the selected media' => 
      array (
        0 => '',
      ),
      'New Playlist' => 
      array (
        0 => '',
      ),
      'Queue the selected media to play next' => 
      array (
        0 => '',
      ),
      'Analyze and reprocess the selected media' => 
      array (
        0 => '',
      ),
      'The request could not be processed.' => 
      array (
        0 => '',
      ),
      'Files queued for playback:' => 
      array (
        0 => '',
      ),
      'Files marked for reprocessing:' => 
      array (
        0 => '',
      ),
      'Delete %{ num } media files?' => 
      array (
        0 => '',
      ),
      'Files removed:' => 
      array (
        0 => '',
      ),
      'Playlists updated for selected files:' => 
      array (
        0 => '',
      ),
      'Playlists cleared for selected files:' => 
      array (
        0 => '',
      ),
      'No files selected.' => 
      array (
        0 => '',
      ),
      'Save' => 
      array (
        0 => '',
      ),
      'Move' => 
      array (
        0 => '',
      ),
      'Queue' => 
      array (
        0 => '',
      ),
      'Reprocess' => 
      array (
        0 => '',
      ),
      'New Folder' => 
      array (
        0 => '',
      ),
      'Edit Media' => 
      array (
        0 => '',
      ),
      'New Directory' => 
      array (
        0 => '',
      ),
      'New directory created.' => 
      array (
        0 => '',
      ),
      'Directory Name' => 
      array (
        0 => '',
      ),
      'Create Directory' => 
      array (
        0 => '',
      ),
      'Artwork' => 
      array (
        0 => '',
      ),
      'Select PNG/JPG artwork file' => 
      array (
        0 => '',
      ),
      'Artwork must be a minimum size of 1400 x 1400 pixels and a maximum size of 3000 x 3000 pixels for Apple Podcasts.' => 
      array (
        0 => '',
      ),
      'Clear Artwork' => 
      array (
        0 => '',
      ),
      'Edit Episode' => 
      array (
        0 => '',
      ),
      'Add Episode' => 
      array (
        0 => '',
      ),
      'Edit Podcast' => 
      array (
        0 => '',
      ),
      'Add Podcast' => 
      array (
        0 => '',
      ),
      'Podcast Title' => 
      array (
        0 => '',
      ),
      'Website' => 
      array (
        0 => '',
      ),
      'Typically the home page of a podcast.' => 
      array (
        0 => '',
      ),
      'The description of your podcast. The typical maximum amount of text allowed for this is 4000 characters.' => 
      array (
        0 => '',
      ),
      'Language' => 
      array (
        0 => 'Jazyk',
      ),
      'The language spoken on the podcast.' => 
      array (
        0 => '',
      ),
      'Author' => 
      array (
        0 => '',
      ),
      'The contact person of the podcast. May be required in order to list the podcast on services like Apple Podcasts, Spotify, Google Podcasts, etc.' => 
      array (
        0 => '',
      ),
      'E-Mail' => 
      array (
        0 => '',
      ),
      'The email of the podcast contact. May be required in order to list the podcast on services like Apple Podcasts, Spotify, Google Podcasts, etc.' => 
      array (
        0 => '',
      ),
      'Categories' => 
      array (
        0 => '',
      ),
      'Select the category/categories that best reflects the content of your podcast.' => 
      array (
        0 => '',
      ),
      'Art' => 
      array (
        0 => '',
      ),
      'Podcast' => 
      array (
        0 => '',
      ),
      '# Episodes' => 
      array (
        0 => '',
      ),
      'All Podcasts' => 
      array (
        0 => '',
      ),
      'Delete Podcast?' => 
      array (
        0 => '',
      ),
      'RSS Feed' => 
      array (
        0 => '',
      ),
      'Episodes' => 
      array (
        0 => '',
      ),
      'Episode' => 
      array (
        0 => '',
      ),
      'File' => 
      array (
        0 => '',
      ),
      'Explicit' => 
      array (
        0 => '',
      ),
      'Delete Episode?' => 
      array (
        0 => '',
      ),
      'Typically a website with content about the episode.' => 
      array (
        0 => '',
      ),
      'The description of the episode. The typical maximum amount of text allowed for this is 4000 characters.' => 
      array (
        0 => '',
      ),
      'Publish Date' => 
      array (
        0 => '',
      ),
      'The date when the episode should be published.' => 
      array (
        0 => '',
      ),
      'Publish Time' => 
      array (
        0 => '',
      ),
      'The time when the episode should be published (according to the stations timezone).' => 
      array (
        0 => '',
      ),
      'Contains explicit content' => 
      array (
        0 => '',
      ),
      'Indicates the presence of explicit content (explicit language or adult content). Apple Podcasts displays an Explicit parental advisory graphic for your episode if turned on. Episodes containing explicit material aren’t available in some Apple Podcasts territories.' => 
      array (
        0 => '',
      ),
      'Media' => 
      array (
        0 => 'Média',
      ),
      'Select Media File' => 
      array (
        0 => '',
      ),
      'Podcast media should be in the MP3 or M4A (AAC) format for the greatest compatibility.' => 
      array (
        0 => '',
      ),
      'Current Podcast Media' => 
      array (
        0 => '',
      ),
      'Clear Media' => 
      array (
        0 => '',
      ),
      'There is no existing media associated with this episode.' => 
      array (
        0 => '',
      ),
      'Notes' => 
      array (
        0 => '',
      ),
      'Account List' => 
      array (
        0 => '',
      ),
      'Delete Streamer?' => 
      array (
        0 => '',
      ),
      'Streamer/DJ Accounts' => 
      array (
        0 => 'Stream/DJ účty',
      ),
      'Add Streamer' => 
      array (
        0 => '',
      ),
      'Broadcasts' => 
      array (
        0 => '',
      ),
      'Icecast Clients' => 
      array (
        0 => '',
      ),
      'You may need to connect directly via your IP address:' => 
      array (
        0 => '',
      ),
      'Mount Name:' => 
      array (
        0 => '',
      ),
      'SHOUTcast Clients' => 
      array (
        0 => '',
      ),
      'For some clients, use port:' => 
      array (
        0 => '',
      ),
      'Password:' => 
      array (
        0 => '',
      ),
      'or' => 
      array (
        0 => '',
      ),
      'Setup instructions for broadcasting software are available on the AzuraCast wiki.' => 
      array (
        0 => '',
      ),
      'AzuraCast Wiki' => 
      array (
        0 => '',
      ),
      'Streamer Username' => 
      array (
        0 => '',
      ),
      'The streamer will use this username to connect to the radio server.' => 
      array (
        0 => '',
      ),
      'Streamer password' => 
      array (
        0 => '',
      ),
      'The streamer will use this password to connect to the radio server.' => 
      array (
        0 => '',
      ),
      'Streamer Display Name' => 
      array (
        0 => '',
      ),
      'This is the informal display name that will be shown in API responses if the streamer/DJ is live.' => 
      array (
        0 => '',
      ),
      'Comments' => 
      array (
        0 => 'Poznámky',
      ),
      'Internal notes or comments about the user, visible only on this control panel.' => 
      array (
        0 => '',
      ),
      'Account is Active' => 
      array (
        0 => '',
      ),
      'Enable to allow this account to log in and stream.' => 
      array (
        0 => '',
      ),
      'Enforce Schedule Times' => 
      array (
        0 => '',
      ),
      'If enabled, this streamer will only be able to connect during their scheduled broadcast times.' => 
      array (
        0 => '',
      ),
      'This streamer is not scheduled to play at any times.' => 
      array (
        0 => '',
      ),
      'If the end time is before the start time, the schedule entry will continue overnight.' => 
      array (
        0 => '',
      ),
      'Streamer Broadcasts' => 
      array (
        0 => '',
      ),
      'Play/Pause' => 
      array (
        0 => '',
      ),
      'Delete Broadcast?' => 
      array (
        0 => '',
      ),
      'Edit Streamer' => 
      array (
        0 => '',
      ),
      'Hour' => 
      array (
        0 => '',
      ),
      'IP' => 
      array (
        0 => '',
      ),
      'Time' => 
      array (
        0 => '',
      ),
      'Time (sec)' => 
      array (
        0 => '',
      ),
      'User Agent' => 
      array (
        0 => '',
      ),
      'Stream' => 
      array (
        0 => '',
      ),
      'Location' => 
      array (
        0 => '',
      ),
      'Live Listeners' => 
      array (
        0 => '',
      ),
      'Download CSV' => 
      array (
        0 => '',
      ),
      'for selected period' => 
      array (
        0 => '',
      ),
      'Total Listener Hours' => 
      array (
        0 => '',
      ),
      'Mobile Device' => 
      array (
        0 => '',
      ),
      'Desktop Device' => 
      array (
        0 => '',
      ),
      'Unknown' => 
      array (
        0 => '',
      ),
      'Local' => 
      array (
        0 => '',
      ),
      'Remote' => 
      array (
        0 => '',
      ),
      'Filename' => 
      array (
        0 => '',
      ),
      'Length Text' => 
      array (
        0 => '',
      ),
      'Playlist(s)' => 
      array (
        0 => '',
      ),
      'Joins' => 
      array (
        0 => '',
      ),
      'Losses' => 
      array (
        0 => '',
      ),
      'Total' => 
      array (
        0 => '',
      ),
      'Num Plays' => 
      array (
        0 => '',
      ),
      'Play %' => 
      array (
        0 => '',
      ),
      'Ratio' => 
      array (
        0 => '',
      ),
      'Song Listener Impact' => 
      array (
        0 => 'Dopad na posluchače',
      ),
      'Date Requested' => 
      array (
        0 => 'Datum žádosti',
      ),
      'Date Played' => 
      array (
        0 => 'Datum odehrání',
      ),
      'Requester IP' => 
      array (
        0 => 'IP žadatele',
      ),
      'Delete Request?' => 
      array (
        0 => '',
      ),
      'Clear All Pending Requests?' => 
      array (
        0 => '',
      ),
      'Clear Pending Requests' => 
      array (
        0 => '',
      ),
      'Not Played' => 
      array (
        0 => 'Nehráno',
      ),
      'Listeners by Day' => 
      array (
        0 => 'Posluchači podle dne',
      ),
      'Listeners by Day of Week' => 
      array (
        0 => 'Posluchači podle dne v týdnu',
      ),
      'Listeners by Hour' => 
      array (
        0 => 'Posluchači podle hodiny',
      ),
      'Best Performing Songs' => 
      array (
        0 => '',
      ),
      'in the last 48 hours' => 
      array (
        0 => '',
      ),
      'Change' => 
      array (
        0 => '',
      ),
      'Song' => 
      array (
        0 => '',
      ),
      'Worst Performing Songs' => 
      array (
        0 => '',
      ),
      'Most Played Songs' => 
      array (
        0 => '',
      ),
      'in the last month' => 
      array (
        0 => '',
      ),
      'Plays' => 
      array (
        0 => '',
      ),
      'Date/Time' => 
      array (
        0 => '',
      ),
      'Song Playback Timeline' => 
      array (
        0 => 'Časová osa přehrávání skladeb',
      ),
      'Live Streamer:' => 
      array (
        0 => '',
      ),
      'Name/Type' => 
      array (
        0 => '',
      ),
      'Triggers' => 
      array (
        0 => '',
      ),
      'Delete Web Hook?' => 
      array (
        0 => '',
      ),
      'Web Hooks' => 
      array (
        0 => 'Webhooky',
      ),
      'Web hooks let you connect to external web services and broadcast changes to your station to them.' => 
      array (
        0 => '',
      ),
      'Test' => 
      array (
        0 => '',
      ),
      'Song History' => 
      array (
        0 => 'Historie skladeb',
      ),
      'Request Song' => 
      array (
        0 => 'Na přání',
      ),
      'Request a Song' => 
      array (
        0 => 'Žádost o skladbu na přání',
      ),
      'Microphone' => 
      array (
        0 => '',
      ),
      'Cue' => 
      array (
        0 => '',
      ),
      'Microphone Source' => 
      array (
        0 => '',
      ),
      'Stop Streaming' => 
      array (
        0 => '',
      ),
      'Start Streaming' => 
      array (
        0 => '',
      ),
      'Metadata updated!' => 
      array (
        0 => '',
      ),
      'Settings' => 
      array (
        0 => 'Nastavení',
      ),
      'Metadata' => 
      array (
        0 => '',
      ),
      'Encoder' => 
      array (
        0 => '',
      ),
      'MP3' => 
      array (
        0 => '',
      ),
      'Raw' => 
      array (
        0 => '',
      ),
      'Sample Rate' => 
      array (
        0 => '',
      ),
      'Bit Rate' => 
      array (
        0 => '',
      ),
      'DJ Credentials' => 
      array (
        0 => '',
      ),
      'Use Asynchronous Worker' => 
      array (
        0 => '',
      ),
      'Update Metadata' => 
      array (
        0 => '',
      ),
      'Mixer' => 
      array (
        0 => '',
      ),
      'Playlist 1' => 
      array (
        0 => '',
      ),
      'Playlist 2' => 
      array (
        0 => '',
      ),
      'Unknown Title' => 
      array (
        0 => 'Neznámý název',
      ),
      'Unknown Artist' => 
      array (
        0 => 'Neznámý interpret',
      ),
      'Add Files to Playlist' => 
      array (
        0 => '',
      ),
      'Continuous Play' => 
      array (
        0 => '',
      ),
      'Repeat Playlist' => 
      array (
        0 => '',
      ),
      'Request' => 
      array (
        0 => 'Žádost',
      ),
      'This field is required.' => 
      array (
        0 => '',
      ),
      'This field must have at least %{ min } letters.' => 
      array (
        0 => '',
      ),
      'This field must have at most %{ max } letters.' => 
      array (
        0 => '',
      ),
      'This field must be between %{ min } and %{ max }.' => 
      array (
        0 => '',
      ),
      'This field must only contain alphabetic characters.' => 
      array (
        0 => '',
      ),
      'This field must only contain alphanumeric characters.' => 
      array (
        0 => '',
      ),
      'This field must only contain numeric characters.' => 
      array (
        0 => '',
      ),
      'This field must be a valid integer.' => 
      array (
        0 => '',
      ),
      'This field must be a valid decimal number.' => 
      array (
        0 => '',
      ),
      'This field must be a valid e-mail address.' => 
      array (
        0 => '',
      ),
      'This field must be a valid IP address.' => 
      array (
        0 => '',
      ),
      'This field must be a valid URL.' => 
      array (
        0 => '',
      ),
      'This password is too common or insecure.' => 
      array (
        0 => '',
      ),
      'Global Permissions' => 
      array (
        0 => '',
      ),
      'Role Name' => 
      array (
        0 => 'Název role',
      ),
      'Users with this role will have these permissions across the entire installation.' => 
      array (
        0 => '',
      ),
      'Station Permissions' => 
      array (
        0 => '',
      ),
      'Users with this role will have these permissions for this single station.' => 
      array (
        0 => '',
      ),
      'Add Station' => 
      array (
        0 => '',
      ),
      'Edit Role' => 
      array (
        0 => '',
      ),
      'Add Role' => 
      array (
        0 => '',
      ),
      'User' => 
      array (
        0 => 'Uživatel',
      ),
      'Operation' => 
      array (
        0 => '',
      ),
      'Identifier' => 
      array (
        0 => '',
      ),
      'Target' => 
      array (
        0 => '',
      ),
      'Insert' => 
      array (
        0 => '',
      ),
      'Update' => 
      array (
        0 => '',
      ),
      'Audit Log' => 
      array (
        0 => '',
      ),
      'N/A' => 
      array (
        0 => '',
      ),
      'Changes' => 
      array (
        0 => '',
      ),
      'Field' => 
      array (
        0 => '',
      ),
      'Previous' => 
      array (
        0 => '',
      ),
      'Updated' => 
      array (
        0 => '',
      ),
      'Broadcasting' => 
      array (
        0 => 'Vysílání',
      ),
      'Only connect to a remote server.' => 
      array (
        0 => '',
      ),
      'Use Icecast 2.4 on this server.' => 
      array (
        0 => '',
      ),
      'Use SHOUTcast DNAS 2 on this server.' => 
      array (
        0 => '',
      ),
      'This software delivers your broadcast to the listening audience.' => 
      array (
        0 => '',
      ),
      'SHOUTcast License ID' => 
      array (
        0 => '',
      ),
      'SHOUTcast User ID' => 
      array (
        0 => '',
      ),
      'Customize Source Password' => 
      array (
        0 => '',
      ),
      'Leave blank to automatically generate a new password.' => 
      array (
        0 => '',
      ),
      'Customize Administrator Password' => 
      array (
        0 => '',
      ),
      'Customize Broadcasting Port' => 
      array (
        0 => '',
      ),
      'No other program can be using this port. Leave blank to automatically assign a port.' => 
      array (
        0 => '',
      ),
      'Maximum Listeners' => 
      array (
        0 => '',
      ),
      'Maximum number of total listeners across all streams. Leave blank to use the default.' => 
      array (
        0 => '',
      ),
      'Banned IP Addresses' => 
      array (
        0 => '',
      ),
      'List one IP address or group (in CIDR format) per line.' => 
      array (
        0 => '',
      ),
      'Allowed IP Addresses' => 
      array (
        0 => '',
      ),
      'Banned Countries' => 
      array (
        0 => '',
      ),
      'Select the countries that are not allowed to connect to the streams.' => 
      array (
        0 => '',
      ),
      'Clear List' => 
      array (
        0 => '',
      ),
      'Custom Configuration' => 
      array (
        0 => '',
      ),
      'This code will be included in the frontend configuration. Allowed formats are:' => 
      array (
        0 => '',
      ),
      'Station Profile' => 
      array (
        0 => '',
      ),
      'Web Site URL' => 
      array (
        0 => '',
      ),
      'Note: This should be the public-facing homepage of the radio station, not the AzuraCast URL. It will be included in broadcast details.' => 
      array (
        0 => '',
      ),
      'Time Zone' => 
      array (
        0 => '',
      ),
      'Scheduled playlists and other timed items will be controlled by this time zone.' => 
      array (
        0 => '',
      ),
      'Default Album Art URL' => 
      array (
        0 => 'URL adresa výchozího obrázku alba',
      ),
      'If a song has no album art, this URL will be listed instead. Leave blank to use the standard placeholder art.' => 
      array (
        0 => 'Pokud skladba nemá žádný obrázek alba, bude zobrazen obrázek z této URL adresy. Chcete-li použít standardní zástupný obrázek, ponechte prázdné.',
      ),
      'URL Stub' => 
      array (
        0 => '',
      ),
      'Optionally specify a short URL-friendly name, such as "my_station_name", that will be used in this station\'s URLs. Leave this field blank to automatically create one based on the station name.' => 
      array (
        0 => '',
      ),
      'Number of Visible Recent Songs' => 
      array (
        0 => '',
      ),
      'Customize the number of songs that will appear in the "Song History" section for this station and in all public APIs.' => 
      array (
        0 => '',
      ),
      'Enable Public Pages' => 
      array (
        0 => '',
      ),
      'Show the station in public pages and general API results.' => 
      array (
        0 => '',
      ),
      'On-Demand Streaming' => 
      array (
        0 => '',
      ),
      'Enable On-Demand Streaming' => 
      array (
        0 => '',
      ),
      'If enabled, music from playlists with on-demand streaming enabled will be available to stream via a specialized public page.' => 
      array (
        0 => '',
      ),
      'Enable Downloads on On-Demand Page' => 
      array (
        0 => '',
      ),
      'If enabled, a download button will also be present on the public "On-Demand" page.' => 
      array (
        0 => '',
      ),
      'Use Liquidsoap on this server.' => 
      array (
        0 => '',
      ),
      'Do not use an AutoDJ service.' => 
      array (
        0 => '',
      ),
      'Smart Mode' => 
      array (
        0 => '',
      ),
      'Normal Mode' => 
      array (
        0 => '',
      ),
      'Disable Crossfading' => 
      array (
        0 => '',
      ),
      'This software shuffles from playlists of music constantly and plays when no other radio source is available.' => 
      array (
        0 => '',
      ),
      'Crossfade Method' => 
      array (
        0 => '',
      ),
      'Choose a method to use when transitioning from one song to another. Smart Mode considers the volume of the two tracks when fading for a smoother effect, but requires more CPU resources.' => 
      array (
        0 => '',
      ),
      'Crossfade Duration (Seconds)' => 
      array (
        0 => '',
      ),
      'Number of seconds to overlap songs.' => 
      array (
        0 => '',
      ),
      'Apply Compression and Normalization' => 
      array (
        0 => '',
      ),
      'Compress and normalize your station\'s audio, producing a more uniform and "full" sound.' => 
      array (
        0 => '',
      ),
      'Some stream licensing providers may have specific rules regarding song requests. Check your local regulations for more information.' => 
      array (
        0 => '',
      ),
      'Allow Song Requests' => 
      array (
        0 => '',
      ),
      'Enable listeners to request a song for play on your station. Only songs that are already in your playlists are requestable.' => 
      array (
        0 => '',
      ),
      'Request Minimum Delay (Minutes)' => 
      array (
        0 => '',
      ),
      'If requests are enabled, this specifies the minimum delay (in minutes) between a request being submitted and being played. If set to zero, a minor delay of 15 seconds is applied to prevent request floods.' => 
      array (
        0 => '',
      ),
      'Request Last Played Threshold (Minutes)' => 
      array (
        0 => '',
      ),
      'This specifies the minimum time (in minutes) between a song playing on the radio and being available to request again. Set to 0 for no threshold.' => 
      array (
        0 => '',
      ),
      'Streamers / DJs' => 
      array (
        0 => '',
      ),
      'Allow Streamers / DJs' => 
      array (
        0 => '',
      ),
      'If enabled, streamers (or DJs) will be able to connect directly to your stream and broadcast live music that interrupts the AutoDJ stream.' => 
      array (
        0 => '',
      ),
      'Record Live Broadcasts' => 
      array (
        0 => '',
      ),
      'If enabled, AzuraCast will automatically record any live broadcasts made to this station to per-broadcast recordings.' => 
      array (
        0 => '',
      ),
      'Live Broadcast Recording Format' => 
      array (
        0 => '',
      ),
      'Live Broadcast Recording Bitrate (kbps)' => 
      array (
        0 => '',
      ),
      'Deactivate Streamer on Disconnect (Seconds)' => 
      array (
        0 => '',
      ),
      'This is the number of seconds until a streamer who has been manually disconnected can reconnect to the stream. Set to 0 to allow the streamer to immediately reconnect.' => 
      array (
        0 => '',
      ),
      'Customize DJ/Streamer Port' => 
      array (
        0 => '',
      ),
      'Note: the port after this one will automatically be used for legacy connections.' => 
      array (
        0 => '',
      ),
      'DJ/Streamer Buffer Time (Seconds)' => 
      array (
        0 => '',
      ),
      'The number of seconds of signal to store in case of interruption. Set to the lowest value that your DJs can use without stream interruptions.' => 
      array (
        0 => '',
      ),
      'Customize DJ/Streamer Mount Point' => 
      array (
        0 => '',
      ),
      'If your streaming software requires a specific mount point path, specify it here. Otherwise, use the default.' => 
      array (
        0 => '',
      ),
      'Advanced Configuration' => 
      array (
        0 => '',
      ),
      'Customize Internal Request Processing Port' => 
      array (
        0 => '',
      ),
      'This port is not used by any external process. Only modify this port if the assigned port is in use. Leave blank to automatically assign a port.' => 
      array (
        0 => '',
      ),
      'Use Replaygain Metadata' => 
      array (
        0 => '',
      ),
      'Instruct Liquidsoap to use any replaygain metadata associated with a song to control its volume level.' => 
      array (
        0 => '',
      ),
      'AutoDJ Queue Length' => 
      array (
        0 => '',
      ),
      'This determines how many songs in advance the AutoDJ will automatically fill the queue.' => 
      array (
        0 => '',
      ),
      'Manual AutoDJ Mode' => 
      array (
        0 => '',
      ),
      'This mode disables AzuraCast\'s AutoDJ management, using Liquidsoap itself to manage song playback. "Next Song" and some other features will not be available.' => 
      array (
        0 => '',
      ),
      'Character Set Encoding' => 
      array (
        0 => '',
      ),
      'For most cases, use the default UTF-8 encoding. The older ISO-8859-1 encoding can be used if accepting connections from SHOUTcast 1 DJs or using other legacy software.' => 
      array (
        0 => '',
      ),
      'Duplicate Prevention Time Range (Minutes)' => 
      array (
        0 => '',
      ),
      'This specifies the time range (in minutes) of the song history that the duplicate song prevention algorithm should take into account.' => 
      array (
        0 => '',
      ),
      'Enable Broadcasting' => 
      array (
        0 => '',
      ),
      'If disabled, the station will not broadcast or shuffle its AutoDJ.' => 
      array (
        0 => '',
      ),
      'Base Station Directory' => 
      array (
        0 => '',
      ),
      'The parent directory where station playlist and configuration files are stored. Leave blank to use default directory.' => 
      array (
        0 => '',
      ),
      'Media Storage Location' => 
      array (
        0 => '',
      ),
      'Live Recordings Storage Location' => 
      array (
        0 => '',
      ),
      'Podcasts Storage Location' => 
      array (
        0 => '',
      ),
      'Clone Station' => 
      array (
        0 => '',
      ),
      '%{station} - Copy' => 
      array (
        0 => '',
      ),
      'Edit Station' => 
      array (
        0 => 'Upravit stanici',
      ),
      'Share Media Storage Location' => 
      array (
        0 => '',
      ),
      'Share Recordings Storage Location' => 
      array (
        0 => '',
      ),
      'Share Podcasts Storage Location' => 
      array (
        0 => '',
      ),
      'User Permissions' => 
      array (
        0 => '',
      ),
      'New Station Name' => 
      array (
        0 => '',
      ),
      'New Station Description' => 
      array (
        0 => '',
      ),
      'Copy to New Station' => 
      array (
        0 => '',
      ),
      'Permissions' => 
      array (
        0 => 'Oprávnění',
      ),
      'Delete Role?' => 
      array (
        0 => '',
      ),
      'Roles & Permissions' => 
      array (
        0 => '',
      ),
      'AzuraCast uses a role-based access control system. Roles are given permissions to certain sections of the site, then users are assigned into those roles.' => 
      array (
        0 => '',
      ),
      'Global' => 
      array (
        0 => '',
      ),
      'Storage Adapter' => 
      array (
        0 => '',
      ),
      'Local Filesystem' => 
      array (
        0 => '',
      ),
      'Remote: S3 Compatible' => 
      array (
        0 => '',
      ),
      'Remote: Dropbox' => 
      array (
        0 => '',
      ),
      'Path/Suffix' => 
      array (
        0 => '',
      ),
      'For local filesystems, this is the base path of the directory. For remote filesystems, this is the folder prefix.' => 
      array (
        0 => '',
      ),
      'Storage Quota' => 
      array (
        0 => '',
      ),
      'Set a maximum disk space that this storage location can use. Specify the size with unit, i.e. "8 GB". Units are measured in 1024 bytes. Leave blank to default to the available space on the disk.' => 
      array (
        0 => '',
      ),
      'Access Key ID' => 
      array (
        0 => '',
      ),
      'Secret Key' => 
      array (
        0 => '',
      ),
      'Endpoint' => 
      array (
        0 => '',
      ),
      'Bucket Name' => 
      array (
        0 => '',
      ),
      'Region' => 
      array (
        0 => '',
      ),
      'API Version' => 
      array (
        0 => '',
      ),
      'Dropbox Generated Access Token' => 
      array (
        0 => '',
      ),
      'Learn More about Dropbox Auth Tokens' => 
      array (
        0 => '',
      ),
      'Edit Storage Location' => 
      array (
        0 => '',
      ),
      'Add Storage Location' => 
      array (
        0 => '',
      ),
      'GeoLite version "%{ version }" is currently installed.' => 
      array (
        0 => '',
      ),
      'Install GeoLite IP Database' => 
      array (
        0 => '',
      ),
      'IP Geolocation is used to guess the approximate location of your listeners based on the IP address they connect with. Use the free built-in IP Geolocation library or enter a license key on this page to use MaxMind GeoLite.' => 
      array (
        0 => '',
      ),
      'Instructions' => 
      array (
        0 => '',
      ),
      'AzuraCast ships with a built-in free IP geolocation database. You may prefer to use the MaxMind GeoLite service instead to achieve more accurate results. Using MaxMind GeoLite requires a license key, but once the key is provided, we will automatically keep the database updated.' => 
      array (
        0 => '',
      ),
      'To download the GeoLite database:' => 
      array (
        0 => '',
      ),
      'Create an account on the MaxMind developer site.' => 
      array (
        0 => '',
      ),
      'MaxMind Developer Site' => 
      array (
        0 => '',
      ),
      'Visit the "My License Key" page under the "Services" section.' => 
      array (
        0 => '',
      ),
      'Click "Generate new license key".' => 
      array (
        0 => '',
      ),
      'Paste the generated license key into the field on this page.' => 
      array (
        0 => '',
      ),
      'Current Installed Version' => 
      array (
        0 => 'Aktuálně nainstalovaná verze',
      ),
      'GeoLite is not currently installed on this installation.' => 
      array (
        0 => '',
      ),
      'MaxMind License Key' => 
      array (
        0 => '',
      ),
      'Remove Key' => 
      array (
        0 => '',
      ),
      'Delete Station?' => 
      array (
        0 => '',
      ),
      'Stations' => 
      array (
        0 => 'Stanice',
      ),
      'Clone' => 
      array (
        0 => '',
      ),
      'Field Name' => 
      array (
        0 => 'Název pole',
      ),
      'This will be used as the label when editing individual songs, and will show in API results.' => 
      array (
        0 => 'Toto bude použito jako popisek při úpravách jednotlivých skladeb a bude zobrazeno ve výsledcích API.',
      ),
      'Programmatic Name' => 
      array (
        0 => 'Systémový název',
      ),
      'Optionally specify an API-friendly name, such as "field_name". Leave this field blank to automatically create one based on the name.' => 
      array (
        0 => '',
      ),
      'Automatically Set from ID3v2 Value' => 
      array (
        0 => '',
      ),
      'Optionally select an ID3v2 metadata field that, if present, will be used to set this field\'s value.' => 
      array (
        0 => '',
      ),
      'Edit Custom Field' => 
      array (
        0 => '',
      ),
      'Add Custom Field' => 
      array (
        0 => '',
      ),
      'Adapter' => 
      array (
        0 => '',
      ),
      'Station(s)' => 
      array (
        0 => '',
      ),
      'Station Media' => 
      array (
        0 => '',
      ),
      'Station Recordings' => 
      array (
        0 => '',
      ),
      'Station Podcasts' => 
      array (
        0 => '',
      ),
      'Backups' => 
      array (
        0 => 'Zálohy',
      ),
      'Applying changes...' => 
      array (
        0 => '',
      ),
      'Delete Storage Location?' => 
      array (
        0 => '',
      ),
      'Storage Locations' => 
      array (
        0 => '',
      ),
      'SHOUTcast version "%{ version }" is currently installed.' => 
      array (
        0 => '',
      ),
      'Install SHOUTcast 2 DNAS' => 
      array (
        0 => '',
      ),
      'SHOUTcast 2 DNAS is not free software, and its restrictive license does not allow AzuraCast to distribute the SHOUTcast binary.' => 
      array (
        0 => '',
      ),
      'In order to install SHOUTcast:' => 
      array (
        0 => '',
      ),
      'Download the Linux x64 binary from the SHOUTcast Radio Manager:' => 
      array (
        0 => '',
      ),
      'SHOUTcast Radio Manager' => 
      array (
        0 => '',
      ),
      'The file name should look like:' => 
      array (
        0 => '',
      ),
      'Upload the file on this page to automatically extract it into the proper directory.' => 
      array (
        0 => '',
      ),
      'SHOUTcast 2 DNAS is not currently installed on this installation.' => 
      array (
        0 => '',
      ),
      'Services' => 
      array (
        0 => '',
      ),
      'Stable' => 
      array (
        0 => '',
      ),
      'Rolling Release' => 
      array (
        0 => '',
      ),
      'AzuraCast Update Checks' => 
      array (
        0 => '',
      ),
      'Current Release Channel' => 
      array (
        0 => '',
      ),
      'Learn more about release channels in the AzuraCast docs.' => 
      array (
        0 => '',
      ),
      'Show Update Announcements' => 
      array (
        0 => '',
      ),
      'Show new releases within your update channel on the AzuraCast homepage.' => 
      array (
        0 => '',
      ),
      'E-mail Delivery Service' => 
      array (
        0 => '',
      ),
      'Used for "Forgot Password" functionality, web hooks and other functions.' => 
      array (
        0 => '',
      ),
      'Enable Mail Delivery' => 
      array (
        0 => '',
      ),
      'Sender Name' => 
      array (
        0 => '',
      ),
      'Sender E-mail Address' => 
      array (
        0 => '',
      ),
      'SMTP Host' => 
      array (
        0 => '',
      ),
      'SMTP Port' => 
      array (
        0 => '',
      ),
      'Use Secure (TLS) SMTP Connection' => 
      array (
        0 => '',
      ),
      'Usually enabled for port 465, disabled for ports 587 or 25.' => 
      array (
        0 => '',
      ),
      'SMTP Username' => 
      array (
        0 => '',
      ),
      'SMTP Password' => 
      array (
        0 => '',
      ),
      'Avatar Services' => 
      array (
        0 => '',
      ),
      'Avatar Service' => 
      array (
        0 => '',
      ),
      'Default Avatar URL' => 
      array (
        0 => '',
      ),
      'Album Art Services' => 
      array (
        0 => '',
      ),
      'Check Web Services for Album Art for "Now Playing" Tracks' => 
      array (
        0 => '',
      ),
      'Check Web Services for Album Art When Uploading Media' => 
      array (
        0 => '',
      ),
      'Last.fm API Key' => 
      array (
        0 => '',
      ),
      'This service can provide album art for tracks where none is available locally.' => 
      array (
        0 => '',
      ),
      'Apply for an API key at Last.fm' => 
      array (
        0 => '',
      ),
      'Last 60 Days' => 
      array (
        0 => 'Posledních 60 dní',
      ),
      'Last Year' => 
      array (
        0 => 'Poslední rok',
      ),
      'Last 2 Years' => 
      array (
        0 => 'Poslední dva roky',
      ),
      'Indefinitely' => 
      array (
        0 => 'Na neurčito',
      ),
      'Site Base URL' => 
      array (
        0 => 'Základní URL webu',
      ),
      'The base URL where this service is located. Use either the external IP address or fully-qualified domain name (if one exists) pointing to this server.' => 
      array (
        0 => 'Základní URL adresa, na které se tato služba nachází. Použijte externí adresu IP nebo úplný název domény (pokud existuje) směřující na tento server.',
      ),
      'AzuraCast Instance Name' => 
      array (
        0 => 'Název instance AzuraCast',
      ),
      'This name will appear as a sub-header next to the AzuraCast logo, to help identify this server.' => 
      array (
        0 => 'Tento název se zobrazí jako dílčí záhlaví vedle loga AzuraCast, aby bylo možné tento server identifikovat.',
      ),
      'Prefer Browser URL (If Available)' => 
      array (
        0 => 'Preferovat URL adresu prohlížeče (je-li k dispozici)',
      ),
      'If this setting is set to "Yes", the browser URL will be used instead of the base URL when it\'s available. Set to "No" to always use the base URL.' => 
      array (
        0 => 'Pokud je nastaveno na hodnotu „Ano“, bude URL adresa prohlížeče použita místo základní URL adresy, pokud je k dispozici. Chcete-li vždy použít základní URL adresu, nastavte hodnotu „Ne“.',
      ),
      'Use Web Proxy for Radio' => 
      array (
        0 => 'Použít pro rádio web proxy',
      ),
      'By default, radio stations broadcast on their own ports (i.e. 8000). If you\'re using a service like CloudFlare or accessing your radio station by SSL, you should enable this feature, which routes all radio through the web ports (80 and 443).' => 
      array (
        0 => 'Standardně rozhlasové stanice vysílají na svých vlastních portech (tj. 8000). Pokud používáte službu jako CloudFlare nebo přistupujete k vaší rozhlasové stanici pomocí protokolu SSL, měli byste tuto funkci povolit, aby rádio směrovalo přes webové porty (80 a 443).',
      ),
      'Days of Playback History to Keep' => 
      array (
        0 => 'Doba udržování historie přehrávání',
      ),
      'Set longer to preserve more playback history and listener metadata for stations. Set shorter to save disk space.' => 
      array (
        0 => '',
      ),
      'Use WebSockets for Now Playing Updates' => 
      array (
        0 => '',
      ),
      'Enables or disables the use of the newer and faster WebSocket-based system for receiving live updates on public players. You may need to disable this if you encounter problems with it.' => 
      array (
        0 => '',
      ),
      'Enable Advanced Features' => 
      array (
        0 => '',
      ),
      'Enable certain advanced features in the web interface, including advanced playlist configuration, station port assignment, changing base media directories and other functionality that should only be used by users who are comfortable with advanced functionality.' => 
      array (
        0 => '',
      ),
      'Security & Privacy' => 
      array (
        0 => '',
      ),
      'Privacy' => 
      array (
        0 => '',
      ),
      'Listener Analytics Collection' => 
      array (
        0 => 'Analytický sběr nad posluchači',
      ),
      'Aggregate listener statistics are used to show station reports across the system. IP-based listener statistics are used to view live listener tracking and may be required for royalty reports.' => 
      array (
        0 => 'Agregované statistiky posluchačů se používají k zobrazení zpráv o stanicích v systému. Statistiky posluchačů založené na protokolu IP slouží k zobrazení aktivních posluchačů a mohou být vyžadovány pro zprávy o licenčních poplatcích.',
      ),
      'Full:' => 
      array (
        0 => '',
      ),
      'Collect aggregate listener statistics and IP-based listener statistics' => 
      array (
        0 => '',
      ),
      'Limited:' => 
      array (
        0 => '',
      ),
      'Only collect aggregate listener statistics' => 
      array (
        0 => '',
      ),
      'None:' => 
      array (
        0 => '',
      ),
      'Do not collect any listener analytics' => 
      array (
        0 => '',
      ),
      'Security' => 
      array (
        0 => '',
      ),
      'Always Use HTTPS' => 
      array (
        0 => 'Vždy používat HTTPS',
      ),
      'Set to "Yes" to always use "https://" secure URLs, and to automatically redirect to the secure URL when an insecure URL is visited.' => 
      array (
        0 => 'Chcete-li vždy používat zabezpečené URL adresy „https: //“, nastavte možnost „Ano“ a při navštívení nezabezpečené URL adresy automaticky přesměrujete na zabezpečenou URL adresu.',
      ),
      'API "Access-Control-Allow-Origin" Header' => 
      array (
        0 => '',
      ),
      'Set to * to allow all sources, or specify a list of origins separated by a comma (,).' => 
      array (
        0 => '',
      ),
      'Learn more about this header.' => 
      array (
        0 => '',
      ),
      'Auto-Assign Value' => 
      array (
        0 => '',
      ),
      'None' => 
      array (
        0 => 'Nic',
      ),
      'Delete Custom Field?' => 
      array (
        0 => '',
      ),
      'Create custom fields to store extra metadata about each media file uploaded to your station libraries.' => 
      array (
        0 => '',
      ),
      'Changes saved.' => 
      array (
        0 => 'Změny byly uloženy.',
      ),
      'System Settings' => 
      array (
        0 => 'Systémová nastavení',
      ),
      'Browser Icon' => 
      array (
        0 => '',
      ),
      'Public Page Background' => 
      array (
        0 => '',
      ),
      'Default Album Art' => 
      array (
        0 => '',
      ),
      'Custom Branding' => 
      array (
        0 => '',
      ),
      'Upload Custom Assets' => 
      array (
        0 => '',
      ),
      'Clear Image' => 
      array (
        0 => '',
      ),
      'Prefer System Default' => 
      array (
        0 => '',
      ),
      'Branding Settings' => 
      array (
        0 => '',
      ),
      'Base Theme for Public Pages' => 
      array (
        0 => 'Základní téma pro veřejné stránky',
      ),
      'Select a theme to use as a base for station public pages and the login page.' => 
      array (
        0 => 'Vyberte téma, které se použije jako základní pro veřejné stránky stanice a přihlašovací stránku.',
      ),
      'Hide Album Art on Public Pages' => 
      array (
        0 => 'Skrýt obal alba na veřejných stránkách',
      ),
      'If selected, album art will not display on public-facing radio pages.' => 
      array (
        0 => 'Pokud je vybráno, nebude se obal alba zobrazovat na veřejně přístupných stránkách.',
      ),
      'Hide AzuraCast Branding on Public Pages' => 
      array (
        0 => 'Skrýt AzuraCast značku na veřejných stránkách',
      ),
      'If selected, this will remove the AzuraCast branding from public-facing pages.' => 
      array (
        0 => 'Pokud je tato možnost vybrána, odstraní se značka AzuraCast ze stránek, které jsou veřejně přístupné.',
      ),
      'Homepage Redirect URL' => 
      array (
        0 => 'URL adresa přesměrování z úvodní stránky',
      ),
      'If a visitor is not signed in and visits the AzuraCast homepage, you can automatically redirect them to the URL specified here. Leave blank to redirect them to the login screen by default.' => 
      array (
        0 => 'Pokud není návštěvník přihlášen a navštíví domovskou stránku AzuraCast, můžete ho automaticky přesměrovat na zde uvedenou URL adresu. Chcete-li ho přesměrovat na výchozí přihlašovací obrazovku, ponechte prázdné.',
      ),
      'Custom CSS for Public Pages' => 
      array (
        0 => 'Vlastní CSS pro veřejné stránky',
      ),
      'This CSS will be applied to the station public pages and login page.' => 
      array (
        0 => 'Tento CSS bude aplikován na veřejné stránky stanice a na přihlašovací stránku.',
      ),
      'Custom JS for Public Pages' => 
      array (
        0 => 'Vlastní JS pro veřejné stránky',
      ),
      'This javascript code will be applied to the station public pages and login page.' => 
      array (
        0 => 'Tento javascript bude aplikován na veřejné stránky stanice a na přihlašovací stránku.',
      ),
      'Custom CSS for Internal Pages' => 
      array (
        0 => 'Vlastní CSS pro interní stránky',
      ),
      'This CSS will be applied to the main management pages, like this one.' => 
      array (
        0 => 'Tento CSS bude aplikován na hlavní správcovské stránky, jako je tato.',
      ),
      'Seek' => 
      array (
        0 => '',
      ),
      'Create Account' => 
      array (
        0 => 'Vytvořit účet',
      ),
      'Create Station' => 
      array (
        0 => '',
      ),
      'AzuraCast First-Time Setup' => 
      array (
        0 => '',
      ),
      'Welcome to AzuraCast!' => 
      array (
        0 => '',
      ),
      'Let\'s get started by creating your Super Administrator account.' => 
      array (
        0 => '',
      ),
      'This account will have full access to the system, and you\'ll automatically be logged in to it for the rest of setup.' => 
      array (
        0 => '',
      ),
      'E-mail Address' => 
      array (
        0 => 'Emailová adresa',
      ),
      'Create a New Radio Station' => 
      array (
        0 => '',
      ),
      'Continue the setup process by creating your first radio station below. You can edit any of these details later.' => 
      array (
        0 => '',
      ),
      'Create and Continue' => 
      array (
        0 => '',
      ),
      'Customize AzuraCast Settings' => 
      array (
        0 => '',
      ),
      'Complete the setup process by providing some information about your broadcast environment. These settings can be changed later from the administration panel.' => 
      array (
        0 => '',
      ),
      'Save and Continue' => 
      array (
        0 => '',
      ),
      'An error occurred and your request could not be completed.' => 
      array (
        0 => '',
      ),
      'Error' => 
      array (
        0 => '',
      ),
      'Success' => 
      array (
        0 => '',
      ),
      'Please wait...' => 
      array (
        0 => '',
      ),
      'Delete Record?' => 
      array (
        0 => '',
      ),
      'The locale to use for CLI commands.' => 
      array (
        0 => 'Lokální prostředí pro příkazy CLI.',
      ),
      'The application environment.' => 
      array (
        0 => 'Aplikační prostředí.',
      ),
      'Manually modify the logging level.' => 
      array (
        0 => 'Ručně upravit úroveň protokolování.',
      ),
      'This allows you to log debug-level errors temporarily (for problem-solving) or reduce the volume of logs that are produced by your installation, without needing to modify whether your installation is a production or development instance.' => 
      array (
        0 => 'To vám umožní dočasně zaznamenávat chyby na úrovni ladění (kvůli řešení problémů) nebo snížit objem logů, které jsou vytvořeny vaší instalací, aniž by bylo nutné upravit, zda je vaše instalace prdukční nebo vývojářskou instancí.',
      ),
      'Composer Plugin Mode' => 
      array (
        0 => 'Režim pluginu Composer',
      ),
      'Enable the composer "merge" functionality to combine the main application\'s composer.json file with any plugin composer files. This can have performance implications, so you should only use it if you use one or more plugins with their own Composer dependencies.' => 
      array (
        0 => 'Povolte funkci composer "merge" pro kombinování composer.json souboru hlavní aplikace s jakýmkoli plugin composer souborem. Toto může mít vliv na výkon, takže byste jej měli použít pouze v případě, že používáte jeden nebo více pluginů s jejich vlastní závislostí na Composeru.',
      ),
      'Minimum Port for Station Port Assignment' => 
      array (
        0 => 'Minimální port pro přidělení portu stanice',
      ),
      'Modify this if your stations are listening on nonstandard ports.' => 
      array (
        0 => 'Upravte, pokud vaše stanice poslouchají na nestandardních portech.',
      ),
      'Maximum Port for Station Port Assignment' => 
      array (
        0 => 'Minimální port pro přidělení portu stanice',
      ),
      'MariaDB Host' => 
      array (
        0 => 'MariaDB Hostitel',
      ),
      'Do not modify this after installation.' => 
      array (
        0 => 'Po instalaci neupravujte.',
      ),
      'MariaDB Port' => 
      array (
        0 => '',
      ),
      'MariaDB Username' => 
      array (
        0 => '',
      ),
      'MariaDB Password' => 
      array (
        0 => '',
      ),
      'MariaDB Database Name' => 
      array (
        0 => '',
      ),
      'Auto-generate Random MariaDB Root Password' => 
      array (
        0 => '',
      ),
      'MariaDB Root Password' => 
      array (
        0 => '',
      ),
      'Enable MariaDB Slow Query Log' => 
      array (
        0 => '',
      ),
      'Log slower queries to diagnose possible database issues. Only turn this on if needed.' => 
      array (
        0 => '',
      ),
      'MariaDB Maximum Connections' => 
      array (
        0 => '',
      ),
      'Set the amount of allowed connections to the database. This value should be increased if you are seeing the "Too many connections" error in the logs.' => 
      array (
        0 => '',
      ),
      'Enable Redis' => 
      array (
        0 => '',
      ),
      'Disable to use a flatfile cache instead of Redis.' => 
      array (
        0 => '',
      ),
      'Redis Host' => 
      array (
        0 => '',
      ),
      'Redis Port' => 
      array (
        0 => '',
      ),
      'Redis Database Index' => 
      array (
        0 => '',
      ),
      'PHP Maximum POST File Size' => 
      array (
        0 => '',
      ),
      'PHP Memory Limit' => 
      array (
        0 => '',
      ),
      'PHP Script Maximum Execution Time' => 
      array (
        0 => '',
      ),
      '(in seconds)' => 
      array (
        0 => '',
      ),
      'Short Sync Task Execution Time' => 
      array (
        0 => '',
      ),
      'The maximum execution time (and lock timeout) for the 15-second, 1-minute and 5-minute synchronization tasks.' => 
      array (
        0 => '',
      ),
      'Long Sync Task Execution Time' => 
      array (
        0 => '',
      ),
      'The maximum execution time (and lock timeout) for the 1-hour synchronization task.' => 
      array (
        0 => '',
      ),
      'Maximum PHP-FPM Worker Processes' => 
      array (
        0 => '',
      ),
      'Enable Performance Profiling Extension' => 
      array (
        0 => '',
      ),
      'Profiling data can be viewed by visiting %s.' => 
      array (
        0 => '',
      ),
      'Profile Performance on All Requests' => 
      array (
        0 => '',
      ),
      'This will have a significant performance impact on your installation.' => 
      array (
        0 => '',
      ),
      'Profiling Extension HTTP Key' => 
      array (
        0 => '',
      ),
      'The value for the "SPX_KEY" parameter for viewing profiling pages.' => 
      array (
        0 => '',
      ),
      'Profiling Extension IP Allow List' => 
      array (
        0 => '',
      ),
      '(Docker Compose) All Docker containers are prefixed by this name. Do not change this after installation.' => 
      array (
        0 => '',
      ),
      '(Docker Compose) The amount of time to wait before a Docker Compose operation fails. Increase this on lower performance computers.' => 
      array (
        0 => '',
      ),
      'AzuraCast Release Channel' => 
      array (
        0 => '',
      ),
      'HTTP Port' => 
      array (
        0 => '',
      ),
      'The main port AzuraCast listens to for insecure HTTP connections.' => 
      array (
        0 => '',
      ),
      'HTTPS Port' => 
      array (
        0 => '',
      ),
      'The main port AzuraCast listens to for secure HTTPS connections.' => 
      array (
        0 => '',
      ),
      'SFTP Port' => 
      array (
        0 => '',
      ),
      'The port AzuraCast listens to for SFTP file management connections.' => 
      array (
        0 => '',
      ),
      'Station Ports' => 
      array (
        0 => '',
      ),
      'The ports AzuraCast should listen to for station broadcasts and incoming DJ connections.' => 
      array (
        0 => '',
      ),
      'Docker User UID' => 
      array (
        0 => '',
      ),
      'Set the UID of the user running inside the Docker containers. Matching this with your host UID can fix permission issues.' => 
      array (
        0 => '',
      ),
      'Docker User GID' => 
      array (
        0 => 'GID uživatele Dockeru',
      ),
      'Set the GID of the user running inside the Docker containers. Matching this with your host GID can fix permission issues.' => 
      array (
        0 => 'Nastavte GID uživatele běžícího v kontejnerech v Dockeru. Toto nastavení může opravit problémy s oprávněním hostitele.',
      ),
      'Advanced: Use Privileged Docker Settings' => 
      array (
        0 => 'Pokročilé: Použít privilegované nastavení Dockeru',
      ),
      'LetsEncrypt Domain Name(s)' => 
      array (
        0 => 'LetsEncrypt doménové jméno',
      ),
      'Domain name (example.com) or names (example.com,foo.bar) to use with LetsEncrypt.' => 
      array (
        0 => 'Jméno domény (example.com) nebo jména (example.com, foo.bar) pro použití s LetsEncrypt.',
      ),
      'LetsEncrypt E-mail Address' => 
      array (
        0 => 'LetsEncrypt e-mailová adresa',
      ),
      'Optionally provide an e-mail address for updates from LetsEncrypt.' => 
      array (
        0 => 'Volitelně zadejte e-mailovou adresu pro aktualizace z LetsEncrypt.',
      ),
      'This file was automatically generated by AzuraCast.' => 
      array (
        0 => '',
      ),
      'You can modify it as necessary. To apply changes, restart the Docker containers.' => 
      array (
        0 => '',
      ),
      'Remove the leading "#" symbol from lines to uncomment them.' => 
      array (
        0 => '',
      ),
      'Valid options: %s' => 
      array (
        0 => '',
      ),
      'Default: %s' => 
      array (
        0 => '',
      ),
      'Additional Environment Variables' => 
      array (
        0 => '',
      ),
      'AzuraCast Installer' => 
      array (
        0 => 'Instalátor AzuraCast',
      ),
      'Welcome to AzuraCast! Complete the initial server setup by answering a few questions.' => 
      array (
        0 => 'Vítejte na AzuraCast! Dokončete počáteční nastavení serveru zodpovězením několika otázek.',
      ),
      'AzuraCast Updater' => 
      array (
        0 => 'Aktualizace AzuraCast',
      ),
      'Change installation settings?' => 
      array (
        0 => 'Změnit nastavení instalace?',
      ),
      'AzuraCast is currently configured to listen on the following ports:' => 
      array (
        0 => 'AzuraCast je v nakonfigurován pro poslouchání na následujících portech:',
      ),
      'HTTP Port: %d' => 
      array (
        0 => 'HTTP port: %d',
      ),
      'HTTPS Port: %d' => 
      array (
        0 => 'HTTPS port: %d',
      ),
      'SFTP Port: %d' => 
      array (
        0 => 'SFTP port: %d',
      ),
      'Radio Ports: %s' => 
      array (
        0 => 'Rádiové porty: %s',
      ),
      'Customize ports used for AzuraCast?' => 
      array (
        0 => 'Přizpůsobit porty používané pro AzuraCast?',
      ),
      'Set up LetsEncrypt?' => 
      array (
        0 => 'Nastavit LetsEncrypt?',
      ),
      'Writing configuration files...' => 
      array (
        0 => 'Zapisování konfiguračních souborů...',
      ),
      'Server configuration complete!' => 
      array (
        0 => 'Konfigurace serveru dokončena!',
      ),
      'This product includes GeoLite2 data created by MaxMind, available from %s.' => 
      array (
        0 => 'Tento produkt obsahuje GeoLite2 data vytvořená MaxMindem, dostupná na %s.',
      ),
      'IP Geolocation by DB-IP' => 
      array (
        0 => 'IP Geolokace od DB-IP',
      ),
      'GeoLite database not configured for this installation. See System Administration for instructions.' => 
      array (
        0 => 'Databáze GeoLite není pro tuto instalaci nakonfigurována. Instrukce viz Správa systému.',
      ),
      'Welcome to the AzuraCast Liquidsoap configuration editor.' => 
      array (
        0 => 'Vítejte v konfiguračním editoru AzuraCast Liquidsoap.',
      ),
      'Using this page, you can customize several sections of the Liquidsoap configuration.' => 
      array (
        0 => 'Pomocí této stránky můžete upravit několik sekcí konfigurace Liquidsoap.',
      ),
      'The non-editable sections are automatically generated by AzuraCast.' => 
      array (
        0 => 'Neupravitelné sekce jsou automaticky generovány AzuraCast.',
      ),
      '%s is not recognized as a service.' => 
      array (
        0 => '%s není rozpoznán jako služba.',
      ),
      'It may not be registered with Supervisor yet. Restarting broadcasting may help.' => 
      array (
        0 => 'Zatím nemusí být registrováno u Supervisora. Restartování vysílání může pomoci.',
      ),
      '%s cannot start' => 
      array (
        0 => '%s nelze spustit',
      ),
      'It is already running.' => 
      array (
        0 => 'Již běží.',
      ),
      '%s cannot stop' => 
      array (
        0 => '%s nelze zastavit',
      ),
      'It is not running.' => 
      array (
        0 => 'Neběží.',
      ),
      '%s encountered an error' => 
      array (
        0 => '%s došlo k chybě',
      ),
      'Check the log for details.' => 
      array (
        0 => 'Podrobnosti naleznete v protokolu.',
      ),
      'Select...' => 
      array (
        0 => 'Vybrat...',
      ),
      'This feature is not currently supported on this station.' => 
      array (
        0 => 'Tato funkce není v současné době na této stanici podporována.',
      ),
      'Now Playing Data' => 
      array (
        0 => 'Právě přehrávaná data',
      ),
      '1-Minute Sync' => 
      array (
        0 => '1-minutové synchro',
      ),
      'Song Requests Queue' => 
      array (
        0 => 'Fronta požadavků',
      ),
      '5-Minute Sync' => 
      array (
        0 => '5-minutové synchro',
      ),
      'Check Media Folders' => 
      array (
        0 => 'Kontrola složky médií',
      ),
      '1-Hour Sync' => 
      array (
        0 => '1-hodinové synchro',
      ),
      'Analytics/Statistics' => 
      array (
        0 => 'Analytiky/Statistiky',
      ),
      'Cleanup' => 
      array (
        0 => 'Čištění',
      ),
      'Installation Not Recently Backed Up' => 
      array (
        0 => 'Instalace není dlouho zálohována',
      ),
      'This installation has not been backed up in the last two weeks.' => 
      array (
        0 => 'Tato instalace nebyla v posledních dvou týdnech zálohována.',
      ),
      'Update Instructions' => 
      array (
        0 => 'Pokyny k aktualizaci',
      ),
      'AzuraCast <a href="%s" target="_blank">version %s</a> is now available.' => 
      array (
        0 => 'AzuraCast <a href="%s" target="_blank">verze %s</a> je nyní k dispozici.',
      ),
      'You are currently running version %s. Updating is highly recommended.' => 
      array (
        0 => 'Momentálně používáte verzi %s. Důrazně doporučujeme aktualizovat.',
      ),
      'New AzuraCast Release Version Available' => 
      array (
        0 => 'Nová verze AzuraCast je k dispozici',
      ),
      'Your installation is currently %d update(s) behind the latest version.' => 
      array (
        0 => 'Vaše instalace je v současné době %d aktualizací za nejnovější verzí.',
      ),
      'View the changelog for full details.' => 
      array (
        0 => 'Zobrazte si seznam změn pro všechny detaily.',
      ),
      'You should update to take advantage of bug and security fixes.' => 
      array (
        0 => 'Měli byste aktualizovat, abyste využili opravy chyb a zabezpečení.',
      ),
      'New AzuraCast Updates Available' => 
      array (
        0 => 'Nové aktualizace AzuraCast jsou k dispozici',
      ),
      'Synchronized Task Not Recently Run' => 
      array (
        0 => 'Synchronizovaný úkol nebyl nedávno spuštěn',
      ),
      'The "%s" synchronization task has not run recently. This may indicate an error with your installation.' => 
      array (
        0 => 'Synchronizační úkol "%s" nebyl delší dobu spuštěn. To může naznačovat chybu s vaší instalací.',
      ),
      'Manually Run Task' => 
      array (
        0 => 'Ručně spustit úkol',
      ),
      'The performance profiling extension is currently enabled on this installation.' => 
      array (
        0 => 'Rozšíření profilování výkonu je v současné době povoleno.',
      ),
      'You can track the execution time and memory usage of any AzuraCast page or application from the profiler page.' => 
      array (
        0 => 'Můžete sledovat čas provádění a využití paměti jakékoli stránky AzuraCast nebo aplikace z profileru stránky.',
      ),
      'Profiler Control Panel' => 
      array (
        0 => 'Ovládací panel Profileru',
      ),
      'Performance profiling is currently enabled for all requests.' => 
      array (
        0 => 'Pro všechny požadavky je nyní povoleno profilování výkonu.',
      ),
      'This can have an adverse impact on system performance. You should disable this when possible.' => 
      array (
        0 => 'To může mít nepříznivý dopad na výkon systému. Pokud je to možné, měli byste to zakázat.',
      ),
      'You should update your <code>docker-compose.yml</code> file to reflect the newest changes.' => 
      array (
        0 => 'Měli byste aktualizovat soubor <code>docker-compose.yml</code> tak, aby obsahoval nejnovější změny.',
      ),
      'If you manually maintain this file, review the <a href="%s" target="_blank">latest version of the file</a> and make any changes needed.' => 
      array (
        0 => 'Pokud ručně spravujete tento soubor, zkontrolujte <a href="%s" target="_blank">nejnovější verzi souboru</a> a proveďte potřebné změny.',
      ),
      'Otherwise, update your installation and answer "Y" when prompted to update the file.' => 
      array (
        0 => 'V opačném případě aktualizujte instalaci a odpovězte "Y", pokud budete vyzváni k aktualizaci souboru.',
      ),
      'Your <code>docker-compose.yml</code> file is out of date!' => 
      array (
        0 => 'Soubor <code>docker-compose.yml</code> je zastaralý!',
      ),
      'You must be logged in to access this page.' => 
      array (
        0 => 'Pro přístup na tuto stránku musíte být přihlášeni.',
      ),
      'You do not have permission to access this portion of the site.' => 
      array (
        0 => 'Nemáte oprávnění pro přístup k této části webu.',
      ),
      'All Permissions' => 
      array (
        0 => 'Všechna oprávnění',
      ),
      'View Administration Page' => 
      array (
        0 => 'Zobrazit administrační stránku',
      ),
      'View System Logs' => 
      array (
        0 => 'Zobrazení systémových protokolů',
      ),
      'Administer Settings' => 
      array (
        0 => 'Nastavení administrace',
      ),
      'Administer API Keys' => 
      array (
        0 => 'Nastavení API klíčů',
      ),
      'Administer Stations' => 
      array (
        0 => 'Nastavení Stanic',
      ),
      'Administer Custom Fields' => 
      array (
        0 => 'Nastavení Vlastních Polí',
      ),
      'Administer Backups' => 
      array (
        0 => 'Nastavení Záloh',
      ),
      'Administer Storage Locations' => 
      array (
        0 => 'Nastavení Lokace Úložiště',
      ),
      'View Station Page' => 
      array (
        0 => 'Zobrazit stránku stanice',
      ),
      'View Station Reports' => 
      array (
        0 => 'Zobrazit přehledy stanice',
      ),
      'View Station Logs' => 
      array (
        0 => 'Zobrazit protokoly stanice',
      ),
      'Manage Station Profile' => 
      array (
        0 => 'Nastavení Profilu Stanice',
      ),
      'Manage Station Broadcasting' => 
      array (
        0 => 'Nastavení Vysílání Stanice',
      ),
      'Manage Station Streamers' => 
      array (
        0 => 'Spravovat Streamery Stanice',
      ),
      'Manage Station Mount Points' => 
      array (
        0 => 'Spravovat přípojné body stanice',
      ),
      'Manage Station Remote Relays' => 
      array (
        0 => 'Správa vzdálených relays stanice',
      ),
      'Manage Station Media' => 
      array (
        0 => 'Správa médií stanice',
      ),
      'Manage Station Automation' => 
      array (
        0 => 'Správa automatizace stanice',
      ),
      'Manage Station Web Hooks' => 
      array (
        0 => 'Spravovat webhooks stanice',
      ),
      'Manage Station Podcasts' => 
      array (
        0 => 'Spravovat podcasty stanice',
      ),
      'Imported locale: %s' => 
      array (
        0 => '',
      ),
      'The account associated with e-mail address "%s" has been set as an administrator' => 
      array (
        0 => 'Účet spojený s e-mailovou adresou "%s" byl nastaven jako správce',
      ),
      'Account not found.' => 
      array (
        0 => 'Účet nenalezen.',
      ),
      'Fixtures loaded.' => 
      array (
        0 => '',
      ),
      'Configuration successfully written.' => 
      array (
        0 => '',
      ),
      'AzuraCast Backup' => 
      array (
        0 => '',
      ),
      'Please wait while a backup is generated...' => 
      array (
        0 => '',
      ),
      'Creating temporary directories...' => 
      array (
        0 => '',
      ),
      'Directory "%s" was not created' => 
      array (
        0 => '',
      ),
      'Backing up MariaDB...' => 
      array (
        0 => '',
      ),
      'Creating backup archive...' => 
      array (
        0 => '',
      ),
      'Cleaning up temporary files...' => 
      array (
        0 => '',
      ),
      'Backup complete in %.2f seconds.' => 
      array (
        0 => '',
      ),
      'Backup path %s not found!' => 
      array (
        0 => '',
      ),
      'AzuraCast Setup' => 
      array (
        0 => '',
      ),
      'Welcome to AzuraCast. Please wait while some key dependencies of AzuraCast are set up...' => 
      array (
        0 => '',
      ),
      'Installing Data Fixtures' => 
      array (
        0 => '',
      ),
      'Refreshing All Stations' => 
      array (
        0 => '',
      ),
      'AzuraCast is now updated to the latest version!' => 
      array (
        0 => '',
      ),
      'AzuraCast installation complete!' => 
      array (
        0 => '',
      ),
      'Visit %s to complete setup.' => 
      array (
        0 => '',
      ),
      'Initialize AzuraCast' => 
      array (
        0 => '',
      ),
      'Initializing essential settings...' => 
      array (
        0 => '',
      ),
      'Environment: %s' => 
      array (
        0 => '',
      ),
      'Installation Method: %s' => 
      array (
        0 => '',
      ),
      'Running Database Migrations' => 
      array (
        0 => '',
      ),
      'Generating Database Proxy Classes' => 
      array (
        0 => '',
      ),
      'Reload System Data' => 
      array (
        0 => '',
      ),
      'AzuraCast is now initialized.' => 
      array (
        0 => '',
      ),
      'AzuraCast Settings' => 
      array (
        0 => '',
      ),
      'Setting Key' => 
      array (
        0 => '',
      ),
      'Setting Value' => 
      array (
        0 => '',
      ),
      'The port %s is in use by another station.' => 
      array (
        0 => 'Port %s je používán jinou stanicí.',
      ),
      'This value is already used.' => 
      array (
        0 => 'Tato hodnota je již použita.',
      ),
      'Storage location %s could not be validated: %s' => 
      array (
        0 => 'Cestu k uložišti %s nelze ověřit: %s',
      ),
      'Storage location %s already exists.' => 
      array (
        0 => 'Umístění úložiště %s již existuje.',
      ),
      'Search engine crawlers are not permitted to use this feature.' => 
      array (
        0 => 'Vyhledávač nemá povoleno používat tuto funkci.',
      ),
      'This station does not accept requests currently.' => 
      array (
        0 => 'Tato stanice v současné době nepřijímá požadavky.',
      ),
      'The song ID you specified could not be found in the station.' => 
      array (
        0 => 'Zadané ID skladby nebylo ve stanici nalezeno.',
      ),
      'The song ID you specified cannot be requested for this station.' => 
      array (
        0 => 'Zadané ID skladby nemůže být vyžádáno pro tuto stanici.',
      ),
      'You have submitted a request too recently! Please wait before submitting another one.' => 
      array (
        0 => 'Skladbu na přání jste žádali nedávno, před další žádostí je potřeba nějakou dobu počkat.',
      ),
      'Duplicate request: this song was already requested and will play soon.' => 
      array (
        0 => 'Duplicitní požadavek: tato skladba již byla vyžádána a bude brzy přehrána.',
      ),
      'This song or artist has been played too recently. Wait a while before requesting it again.' => 
      array (
        0 => 'Tato skladba nebo umělce byla přehrána příliš nedávno. Počkejte, než o ni znovu požádáte.',
      ),
      'Changes saved successfully.' => 
      array (
        0 => '',
      ),
      'Record created successfully.' => 
      array (
        0 => '',
      ),
      'Record updated successfully.' => 
      array (
        0 => '',
      ),
      'Record deleted successfully.' => 
      array (
        0 => '',
      ),
      'Record not found' => 
      array (
        0 => 'Záznam nebyl nalezen',
      ),
      'The uploaded file exceeds the upload_max_filesize directive in php.ini.' => 
      array (
        0 => 'Nahraný soubor překračuje hodnotu upload_max_filesize v php.ini.',
      ),
      'The uploaded file exceeds the MAX_FILE_SIZE directive from the HTML form.' => 
      array (
        0 => 'Nahraný soubor překračuje hodnotu MAX_FILE_SIZE z HTML formuláře.',
      ),
      'The uploaded file was only partially uploaded.' => 
      array (
        0 => 'Nahraný soubor byl nahrán pouze částečně.',
      ),
      'No file was uploaded.' => 
      array (
        0 => 'Nebyl nahrán žádný soubor.',
      ),
      'No temporary directory is available.' => 
      array (
        0 => '',
      ),
      'Could not write to filesystem.' => 
      array (
        0 => '',
      ),
      'Upload halted by a PHP extension.' => 
      array (
        0 => '',
      ),
      'Unspecified error.' => 
      array (
        0 => '',
      ),
      'Playlist: %s' => 
      array (
        0 => '',
      ),
      'Streamer: %s' => 
      array (
        0 => '',
      ),
      'Edit Liquidsoap Configuration' => 
      array (
        0 => '',
      ),
      'Streamers enabled!' => 
      array (
        0 => 'Streameři povoleni!',
      ),
      'You can now set up streamer (DJ) accounts.' => 
      array (
        0 => 'Nyní můžete nastavit účty streamerů (DJ).',
      ),
      'Record not found.' => 
      array (
        0 => '',
      ),
      'Profile' => 
      array (
        0 => 'Profil',
      ),
      'Automated assignment complete!' => 
      array (
        0 => 'Automatizované přiřazení dokončeno!',
      ),
      'Automated assignment error' => 
      array (
        0 => 'Chyba automatizovaného přiřazení',
      ),
      'Statistics Overview' => 
      array (
        0 => 'Přehled statistik',
      ),
      'SoundExchange Report' => 
      array (
        0 => 'SoundExchange report',
      ),
      'No episodes found.' => 
      array (
        0 => '',
      ),
      'Episode not found.' => 
      array (
        0 => '',
      ),
      'Logged in successfully.' => 
      array (
        0 => 'Přihlášení proběhlo úspěšně.',
      ),
      'Login unsuccessful' => 
      array (
        0 => 'Přihlášení bylo neúspěšné',
      ),
      'Your credentials could not be verified.' => 
      array (
        0 => 'Vaše oprávnění nebylo možné ověřit.',
      ),
      'Too many forgot password attempts' => 
      array (
        0 => '',
      ),
      'You have attempted to reset your password too many times. Please wait 30 seconds and try again.' => 
      array (
        0 => '',
      ),
      'Account Recovery Link' => 
      array (
        0 => '',
      ),
      'Account recovery e-mail sent.' => 
      array (
        0 => '',
      ),
      'If the e-mail address you provided is in the system, check your inbox for a password reset message.' => 
      array (
        0 => '',
      ),
      'Invalid token specified.' => 
      array (
        0 => '',
      ),
      'Logged in using account recovery token' => 
      array (
        0 => '',
      ),
      'Your password has been updated.' => 
      array (
        0 => '',
      ),
      'Too many login attempts' => 
      array (
        0 => 'Příliš mnoho pokusů o přihlášení',
      ),
      'You have attempted to log in too many times. Please wait 30 seconds and try again.' => 
      array (
        0 => 'Snažili jste se přihlásit příliš často, prosím, počkejte 30 sekund a zkuste to znovu.',
      ),
      'Complete the setup process to get started.' => 
      array (
        0 => '',
      ),
      'API Key not found.' => 
      array (
        0 => '',
      ),
      'API Key updated.' => 
      array (
        0 => 'API klíč upraven.',
      ),
      'Edit API Key' => 
      array (
        0 => 'Upravit API klíč',
      ),
      'Add API Key' => 
      array (
        0 => '',
      ),
      'API Key deleted.' => 
      array (
        0 => 'API klíč smazán.',
      ),
      'Profile saved!' => 
      array (
        0 => 'Profil uložen!',
      ),
      'The token you supplied is invalid. Please try again.' => 
      array (
        0 => 'Tento token není platný, zkuste to prosím znovu.',
      ),
      'Two-factor authentication enabled.' => 
      array (
        0 => 'Dvoufaktorové ověřování povoleno.',
      ),
      'Two-factor authentication disabled.' => 
      array (
        0 => 'Dvoufaktorové ověřování zakázáno.',
      ),
      'Set Up AzuraCast' => 
      array (
        0 => '',
      ),
      'Setup has already been completed!' => 
      array (
        0 => 'Nastavení již bylo dokončeno!',
      ),
      'Dashboard' => 
      array (
        0 => '',
      ),
      'AzuraCast User' => 
      array (
        0 => '',
      ),
      'This station does not support on-demand streaming.' => 
      array (
        0 => 'Tato stanice nepodporuje vysílání na vyžádání.',
      ),
      'Playlist successfully imported; %d of %d files were successfully matched.' => 
      array (
        0 => 'Playlist byl úspěšně importován; %d z %d souborů bylo úspěšně porovnáno.',
      ),
      'This playlist is not a sequential playlist.' => 
      array (
        0 => 'Tento playlist není sekvenční playlist.',
      ),
      'Playlist reshuffled.' => 
      array (
        0 => 'Playlist byl zamíchán.',
      ),
      'Playlist not found.' => 
      array (
        0 => 'Playlist nebyl nalezen.',
      ),
      'Playlist enabled.' => 
      array (
        0 => 'Playlist povolen.',
      ),
      'Playlist disabled.' => 
      array (
        0 => 'Playlist zakázán.',
      ),
      'This station is out of available storage space.' => 
      array (
        0 => 'Tato stanice je mimo dostupný úložný prostor.',
      ),
      'No directory specified' => 
      array (
        0 => 'Nebyl zadán žádný adresář',
      ),
      'File not specified.' => 
      array (
        0 => 'Nespecifikovaný soubor.',
      ),
      'New path not specified.' => 
      array (
        0 => 'Nespecifikována nová cesta.',
      ),
      'File Not Processed: %s' => 
      array (
        0 => 'Soubor není zpracován: %s',
      ),
      'File Processing' => 
      array (
        0 => 'Zpracování souborů',
      ),
      'Station restarted.' => 
      array (
        0 => 'Stanice restartována.',
      ),
      'Frontend stopped.' => 
      array (
        0 => 'Frontend byl zastaven.',
      ),
      'Frontend started.' => 
      array (
        0 => 'Frontend byl spuštěn.',
      ),
      'Frontend restarted.' => 
      array (
        0 => 'Frontend restartován.',
      ),
      'Song skipped.' => 
      array (
        0 => 'Skladba přeskočena.',
      ),
      'Streamer disconnected.' => 
      array (
        0 => 'Streamer odpojen.',
      ),
      'Backend stopped.' => 
      array (
        0 => 'Backend zastaven.',
      ),
      'Backend started.' => 
      array (
        0 => 'Backend spuštěn.',
      ),
      'Backend restarted.' => 
      array (
        0 => 'Backend restartován.',
      ),
      'Web hook not found.' => 
      array (
        0 => '',
      ),
      'Web hook enabled.' => 
      array (
        0 => 'Webhook povolen.',
      ),
      'Web hook disabled.' => 
      array (
        0 => '',
      ),
      'Podcast not found!' => 
      array (
        0 => 'Podcast nebyl nalezen!',
      ),
      'No recording available.' => 
      array (
        0 => 'Není k dispozici žádný záznam.',
      ),
      'All Stations' => 
      array (
        0 => 'Všechny stanice',
      ),
      'You cannot remove yourself.' => 
      array (
        0 => 'Nemůžete odstranit sami sebe.',
      ),
      'Create a new storage location based on the base directory.' => 
      array (
        0 => 'Vytvořit nové úložiště založené na základním adresáři.',
      ),
      'Liquidsoap Log' => 
      array (
        0 => 'Liquidsoap protokol',
      ),
      'Liquidsoap Configuration' => 
      array (
        0 => 'Liquidsoap konfigurace',
      ),
      'Icecast Access Log' => 
      array (
        0 => 'Přístupový protokol Icecast',
      ),
      'Icecast Error Log' => 
      array (
        0 => 'Chybový protokol Icecast',
      ),
      'Icecast Configuration' => 
      array (
        0 => 'Icecast konfigurace',
      ),
      'SHOUTcast Log' => 
      array (
        0 => 'SHOUTcast protokol',
      ),
      'SHOUTcast Configuration' => 
      array (
        0 => 'SHOUTcast konfigurace',
      ),
      'User updated.' => 
      array (
        0 => 'Uživatel upraven.',
      ),
      'User added.' => 
      array (
        0 => 'Uživatel přidán.',
      ),
      'Another user already exists with this e-mail address. Please update the e-mail address.' => 
      array (
        0 => 'S touto e-mailovou adresou již existuje jiný uživatel, prosím, použijte jinou.',
      ),
      'Edit User' => 
      array (
        0 => 'Upravit uživatele',
      ),
      'Add User' => 
      array (
        0 => 'Přidat uživatele',
      ),
      'You cannot delete your own account.' => 
      array (
        0 => 'Vlastní účet nelze odstranit.',
      ),
      'User deleted.' => 
      array (
        0 => 'Uživatel smazán.',
      ),
      'User not found.' => 
      array (
        0 => 'Uživatel nenalezen.',
      ),
      'AzuraCast Application Log' => 
      array (
        0 => 'Protokol aplikace AzuraCast',
      ),
      'Nginx Access Log' => 
      array (
        0 => 'Přístupový protokol Nginx',
      ),
      'Nginx Error Log' => 
      array (
        0 => 'Chybový protokol Nginx',
      ),
      'PHP Application Log' => 
      array (
        0 => 'PHP aplikační protokol',
      ),
      'Supervisord Log' => 
      array (
        0 => 'Supervisorský protokol',
      ),
      'Album Artist Sort Order' => 
      array (
        0 => 'Seřadit pořadí interpreta alba',
      ),
      'Album Sort Order' => 
      array (
        0 => 'Řazení alba',
      ),
      'Band' => 
      array (
        0 => 'Skupina',
      ),
      'Bpm' => 
      array (
        0 => 'Bpm',
      ),
      'Comment' => 
      array (
        0 => 'Komentář',
      ),
      'Commercial Information' => 
      array (
        0 => 'Obchodní informace',
      ),
      'Composer' => 
      array (
        0 => 'Skladatel',
      ),
      'Composer Sort Order' => 
      array (
        0 => 'Řazení skladatelů',
      ),
      'Conductor' => 
      array (
        0 => 'Vedení',
      ),
      'Content Group Description' => 
      array (
        0 => 'Popis skupiny obsahu',
      ),
      'Copyright' => 
      array (
        0 => 'Autorská práva',
      ),
      'Copyright Message' => 
      array (
        0 => 'Copyright zpráva',
      ),
      'Encoded By' => 
      array (
        0 => 'Kódováno',
      ),
      'Encoder Settings' => 
      array (
        0 => 'Nastavení enkódování',
      ),
      'Encoding Time' => 
      array (
        0 => 'Čas kódování',
      ),
      'File Owner' => 
      array (
        0 => 'Vlastník souboru',
      ),
      'File Type' => 
      array (
        0 => 'Typ souboru',
      ),
      'Initial Key' => 
      array (
        0 => 'Počáteční klíč',
      ),
      'Internet Radio Station Name' => 
      array (
        0 => 'Název internetové rozhlasové stanice',
      ),
      'Internet Radio Station Owner' => 
      array (
        0 => 'Majitel internetové rozhlasové stanice',
      ),
      'Involved People List' => 
      array (
        0 => 'Seznam zapojených lidí',
      ),
      'Linked Information' => 
      array (
        0 => 'Propojené informace',
      ),
      'Lyricist' => 
      array (
        0 => 'Textař',
      ),
      'Media Type' => 
      array (
        0 => 'Typ média',
      ),
      'Mood' => 
      array (
        0 => 'Nálada',
      ),
      'Music CD Identifier' => 
      array (
        0 => 'Identifikátor hudebního CD ',
      ),
      'Musician Credits List' => 
      array (
        0 => 'Seznam hudebníků',
      ),
      'Original Album' => 
      array (
        0 => 'Původní album',
      ),
      'Original Artist' => 
      array (
        0 => 'Původní interpret',
      ),
      'Original Filename' => 
      array (
        0 => 'Původní název souboru',
      ),
      'Original Lyricist' => 
      array (
        0 => 'Původní texty',
      ),
      'Original Release Time' => 
      array (
        0 => 'Původní čas vydání',
      ),
      'Original Year' => 
      array (
        0 => 'Původní rok',
      ),
      'Part Of A Compilation' => 
      array (
        0 => 'Část kompilace',
      ),
      'Part Of A Set' => 
      array (
        0 => 'Část setu',
      ),
      'Performer Sort Order' => 
      array (
        0 => 'Pořadí Performerů',
      ),
      'Playlist Delay' => 
      array (
        0 => 'Zpoždění playlistu',
      ),
      'Produced Notice' => 
      array (
        0 => 'Oznámení o produkci',
      ),
      'Publisher' => 
      array (
        0 => 'Vydavatel',
      ),
      'Recording Time' => 
      array (
        0 => 'Čas nahrávání',
      ),
      'Release Time' => 
      array (
        0 => 'Čas vydání',
      ),
      'Remixer' => 
      array (
        0 => 'Remixer',
      ),
      'Set Subtitle' => 
      array (
        0 => 'Nastavit titulek',
      ),
      'Subtitle' => 
      array (
        0 => 'Titulek',
      ),
      'Tagging Time' => 
      array (
        0 => 'Čas označení',
      ),
      'Terms Of Use' => 
      array (
        0 => 'Podmínky užití',
      ),
      'Title Sort Order' => 
      array (
        0 => 'Pořadí podle názvu',
      ),
      'Track Number' => 
      array (
        0 => '',
      ),
      'Unsynchronised Lyric' => 
      array (
        0 => '',
      ),
      'URL Artist' => 
      array (
        0 => '',
      ),
      'URL File' => 
      array (
        0 => '',
      ),
      'URL Payment' => 
      array (
        0 => '',
      ),
      'URL Publisher' => 
      array (
        0 => '',
      ),
      'URL Source' => 
      array (
        0 => '',
      ),
      'URL Station' => 
      array (
        0 => '',
      ),
      'URL User' => 
      array (
        0 => '',
      ),
      'Year' => 
      array (
        0 => '',
      ),
      'Run Synchronized Task' => 
      array (
        0 => '',
      ),
      'Debug Output' => 
      array (
        0 => '',
      ),
      'Configure Backups' => 
      array (
        0 => 'Nastavení záloh',
      ),
      'Run Manual Backup' => 
      array (
        0 => 'Spustit ruční zálohu',
      ),
      'Backup deleted.' => 
      array (
        0 => '',
      ),
      'Backup not found.' => 
      array (
        0 => '',
      ),
      'Are you sure?' => 
      array (
        0 => '',
      ),
      'Enter a password to continue.' => 
      array (
        0 => '',
      ),
      'No problems detected.' => 
      array (
        0 => '',
      ),
      'Generate the translation locale file.' => 
      array (
        0 => '',
      ),
      'Convert translated locale files into PHP arrays.' => 
      array (
        0 => '',
      ),
      'Ensure key settings are initialized within AzuraCast.' => 
      array (
        0 => '',
      ),
      'Migrate existing configuration to new INI format if any exists.' => 
      array (
        0 => '',
      ),
      'Install fixtures for demo / local development.' => 
      array (
        0 => '',
      ),
      'Run all general AzuraCast setup steps.' => 
      array (
        0 => '',
      ),
      'Run one or more scheduled synchronization tasks.' => 
      array (
        0 => '',
      ),
      'Process the message queue.' => 
      array (
        0 => 'Zpracování fronty zpráv.',
      ),
      'Clear the contents of the message queue.' => 
      array (
        0 => 'Vymazat obsah fronty zpráv.',
      ),
      'List all settings in the AzuraCast settings database.' => 
      array (
        0 => 'Seznam všech nastavení v databázi nastavení AzuraCast.',
      ),
      'Back up the AzuraCast database and statistics (and optionally media).' => 
      array (
        0 => 'Zálohujte databázi a statistiky AzuraCast (a volitelně média).',
      ),
      'System Maintenance' => 
      array (
        0 => 'Údržba systému',
      ),
      'System Logs' => 
      array (
        0 => 'Systémové logy',
      ),
      'System Debugger' => 
      array (
        0 => 'Systémový Debugger',
      ),
      'Users' => 
      array (
        0 => 'Uživatelé',
      ),
      'User Accounts' => 
      array (
        0 => 'Uživatelské účty',
      ),
      'API Keys' => 
      array (
        0 => 'API klíče',
      ),
      'Connected AzuraRelays' => 
      array (
        0 => 'Připojené AzuraRelays',
      ),
      'Install SHOUTcast' => 
      array (
        0 => 'Instalovat SHOUTcast',
      ),
      'Start Station' => 
      array (
        0 => 'Spustit stanici',
      ),
      'Ready to start broadcasting? Click to start your station.' => 
      array (
        0 => 'Jste připraveni začít vysílat? Klikněte pro spuštění stanice.',
      ),
      'Restart broadcasting? This will disconnect any current listeners.' => 
      array (
        0 => 'Restartovat vysílání? Toto odpojí všechny současné posluchače.',
      ),
      'Restart to Apply Changes' => 
      array (
        0 => 'Restartovat pro aplikaci změn',
      ),
      'Click to restart your station and apply configuration changes.' => 
      array (
        0 => 'Klepnutím restartujete stanici a aplikujte změny konfigurace.',
      ),
      'Podcasts (Beta)' => 
      array (
        0 => 'Podcasty (Beta)',
      ),
      'Reports' => 
      array (
        0 => 'Reporty',
      ),
      'Duplicate Songs' => 
      array (
        0 => 'Duplicitní skladby',
      ),
      'Unprocessable Files' => 
      array (
        0 => 'Nezpracovatelné soubory',
      ),
      'SoundExchange Royalties' => 
      array (
        0 => 'SoundExchange Royalties',
      ),
      'Utilities' => 
      array (
        0 => 'Nástroje',
      ),
      'Automated Assignment' => 
      array (
        0 => 'Automatizované přiřazení',
      ),
      'Log Viewer' => 
      array (
        0 => 'Prohlížeč protokolů',
      ),
      'Restart Broadcasting' => 
      array (
        0 => 'Restartovat vysílání',
      ),
      'Enable Automated Assignment' => 
      array (
        0 => 'Povolit automatizované přiřazení',
      ),
      'Allow the system to periodically automatically assign songs to playlists based on their performance. This process will run in the background, and will only run if this option is set to "Enabled" and at least one playlist is set to "Include in Automated Assignment".' => 
      array (
        0 => 'Tento proces bude spuštěn na pozadí, a to pouze tehdy, pokud se tato volba nastaví na "Povoleno" a alespoň jeden playlist je nastaven na "Zahrnout do automatizovaného přiřazení".',
      ),
      'Days Between Automated Assignments' => 
      array (
        0 => 'Dny mezi automatizovaným přiřazením',
      ),
      'Based on this setting, the system will automatically reassign songs every (this) days using data from the previous (this) days.' => 
      array (
        0 => 'Na základě tohoto nastavení systém automaticky znovu vyhodnotí skladby každých (těchto) dnů za použití dat z předchozích (těchto) dní.',
      ),
      '%d days' => 
      array (
        0 => '%d dní',
      ),
      'Use Browser Default' => 
      array (
        0 => 'Automaticky podle prohlížeče',
      ),
      'Reset Password' => 
      array (
        0 => 'Obnovit heslo',
      ),
      'Leave these fields blank to continue using your current password.' => 
      array (
        0 => 'Ponechte tato pole prázdná k pokračování v používání aktuálního hesla.',
      ),
      'Current Password' => 
      array (
        0 => 'Stávající heslo',
      ),
      'Confirm New Password' => 
      array (
        0 => 'Potvrzení nového hesla',
      ),
      'Customization' => 
      array (
        0 => 'Přizpůsobení',
      ),
      'Site Theme' => 
      array (
        0 => 'Motiv webu',
      ),
      'Describe the use-case for this API key for future reference.' => 
      array (
        0 => 'Popište způsob využití tohoto API klíče pro případ pozdější potřeby.',
      ),
      'Storage Location' => 
      array (
        0 => '',
      ),
      'Backup Filename' => 
      array (
        0 => 'Název souboru zálohy',
      ),
      'This will be the file name for your backup, include the file type (.zip or .rar) you wish to use.' => 
      array (
        0 => '',
      ),
      'Exclude Media from Backup' => 
      array (
        0 => 'Vyloučit média ze záloh',
      ),
      'This will produce a significantly smaller backup, but you should make sure to back up your media elsewhere. Note that only locally stored media will be backed up.' => 
      array (
        0 => '',
      ),
      'Yes' => 
      array (
        0 => 'Ano',
      ),
      'No' => 
      array (
        0 => 'Ne',
      ),
      'Run Automatic Nightly Backups' => 
      array (
        0 => 'Spustit automatické noční zálohování',
      ),
      'Enable to have AzuraCast automatically run nightly backups at the time specified.' => 
      array (
        0 => 'Povolit, aby AzuraCast v určeném čase automaticky spouštěla noční zálohování.',
      ),
      'Scheduled Backup Time' => 
      array (
        0 => 'Plánovaný čas zálohování',
      ),
      'The time (in UTC) to run the automated backup, if enabled.' => 
      array (
        0 => 'Čas (v UTC) pro spuštění automatického zálohování, pokud je povoleno.',
      ),
      'Exclude Media from Backups' => 
      array (
        0 => 'Vyloučit média ze záloh',
      ),
      'Excluding media from automated backups will save space, but you should make sure to back up your media elsewhere. Note that only locally stored media will be backed up.' => 
      array (
        0 => '',
      ),
      'Number of Backup Copies to Keep' => 
      array (
        0 => 'Počet záložních kopií pro uchování',
      ),
      'Copies older than the specified number of days will automatically be deleted. Set to zero to disable automatic deletion.' => 
      array (
        0 => 'Kopie starší než stanovený počet dní budou automaticky smazány.',
      ),
      'Attempt to Automatically Retrieve ISRC When Missing' => 
      array (
        0 => '',
      ),
      'If enabled, AzuraCast will connect to the MusicBrainz database to attempt to find an ISRC for any files where one is missing. Disabling this may improve performance.' => 
      array (
        0 => '',
      ),
      'Roles' => 
      array (
        0 => '',
      ),
      'Code from Authenticator App' => 
      array (
        0 => 'Kód z autentizační aplikace',
      ),
      'Enter the current code provided by your authenticator app to verify that it\'s working correctly.' => 
      array (
        0 => 'Zadejte aktuální kód poskytnutý autentizační aplikací, abyste ověřili, zda funguje správně.',
      ),
      'Verify Authenticator' => 
      array (
        0 => 'Ověření autentizační app',
      ),
      'Any time the currently playing song changes' => 
      array (
        0 => '',
      ),
      'Any time the listener count increases' => 
      array (
        0 => '',
      ),
      'Any time the listener count decreases' => 
      array (
        0 => '',
      ),
      'Any time a live streamer/DJ connects to the stream' => 
      array (
        0 => '',
      ),
      'Any time a live streamer/DJ disconnects from the stream' => 
      array (
        0 => '',
      ),
      'When the station broadcast goes offline.' => 
      array (
        0 => '',
      ),
      'When the station broadcast comes online.' => 
      array (
        0 => '',
      ),
      'Generic Web Hook' => 
      array (
        0 => '',
      ),
      'Automatically send a message to any URL when your station data changes.' => 
      array (
        0 => '',
      ),
      'Send E-mail' => 
      array (
        0 => '',
      ),
      'Send an e-mail to specified address(es).' => 
      array (
        0 => '',
      ),
      'TuneIn AIR' => 
      array (
        0 => '',
      ),
      'Send song metadata changes to TuneIn.' => 
      array (
        0 => '',
      ),
      'Discord Webhook' => 
      array (
        0 => '',
      ),
      'Automatically send a customized message to your Discord server.' => 
      array (
        0 => '',
      ),
      'Telegram Chat Message' => 
      array (
        0 => '',
      ),
      'Use the Telegram Bot API to send a message to a channel.' => 
      array (
        0 => '',
      ),
      'Twitter Post' => 
      array (
        0 => '',
      ),
      'Automatically send a tweet.' => 
      array (
        0 => '',
      ),
      'Google Analytics Integration' => 
      array (
        0 => '',
      ),
      'Send stream listener details to Google Analytics.' => 
      array (
        0 => '',
      ),
      'Matomo Analytics Integration' => 
      array (
        0 => '',
      ),
      'Send stream listener details to Matomo Analytics.' => 
      array (
        0 => '',
      ),
      'Account Recovery' => 
      array (
        0 => '',
      ),
      'An account recovery link has been requested for your account on "%s".' => 
      array (
        0 => '',
      ),
      'Click the link below to log in to your account.' => 
      array (
        0 => '',
      ),
      'Skip to main content' => 
      array (
        0 => '',
      ),
      'Toggle Sidebar' => 
      array (
        0 => '',
      ),
      'Toggle Menu' => 
      array (
        0 => '',
      ),
      'System Administration' => 
      array (
        0 => '',
      ),
      'Switch Theme' => 
      array (
        0 => '',
      ),
      'My API Keys' => 
      array (
        0 => '',
      ),
      'Help' => 
      array (
        0 => '',
      ),
      'End Session' => 
      array (
        0 => '',
      ),
      'Sign Out' => 
      array (
        0 => '',
      ),
      'Powered by %s' => 
      array (
        0 => '',
      ),
      'Like our software? <a href="%s" target="_blank">Donate to support AzuraCast!</a>' => 
      array (
        0 => '',
      ),
      'Errors were encountered when trying to save changes:' => 
      array (
        0 => '',
      ),
      'General' => 
      array (
        0 => '',
      ),
      'Details' => 
      array (
        0 => '',
      ),
      'Server Status' => 
      array (
        0 => '',
      ),
      'CPU Load' => 
      array (
        0 => '',
      ),
      'Current' => 
      array (
        0 => '',
      ),
      '15-Minute Average' => 
      array (
        0 => '',
      ),
      'Memory' => 
      array (
        0 => '',
      ),
      '%s of %s Used' => 
      array (
        0 => '',
      ),
      'Disk Space' => 
      array (
        0 => '',
      ),
      'Synchronization Tasks' => 
      array (
        0 => '',
      ),
      'Last run: %s' => 
      array (
        0 => '',
      ),
      'Run Task' => 
      array (
        0 => '',
      ),
      'API Key' => 
      array (
        0 => 'API klíč',
      ),
      'Owner' => 
      array (
        0 => '',
      ),
      'Revoke' => 
      array (
        0 => '',
      ),
      'Clear Cache' => 
      array (
        0 => '',
      ),
      'Clearing the application cache may log you out of your session.' => 
      array (
        0 => '',
      ),
      'Clear All Message Queues' => 
      array (
        0 => '',
      ),
      'This will clear any pending unprocessed messages in all message queues.' => 
      array (
        0 => '',
      ),
      'Message Queues' => 
      array (
        0 => '',
      ),
      '%d queued messages' => 
      array (
        0 => '',
      ),
      'Station-Specific Debugging' => 
      array (
        0 => '',
      ),
      'Rebuild AutoDJ Queue' => 
      array (
        0 => '',
      ),
      'Run Test' => 
      array (
        0 => '',
      ),
      'Send Liquidsoap Telnet Command' => 
      array (
        0 => '',
      ),
      'Command' => 
      array (
        0 => '',
      ),
      'Execute Command' => 
      array (
        0 => '',
      ),
      'Run Synchronization Task' => 
      array (
        0 => '',
      ),
      'Debug Home' => 
      array (
        0 => '',
      ),
      'The synchronization task is running in the background. The log below will update automatically.' => 
      array (
        0 => '',
      ),
      'Log In' => 
      array (
        0 => '',
      ),
      'Delete user "%s"?' => 
      array (
        0 => '',
      ),
      '(You)' => 
      array (
        0 => '',
      ),
      'Because you are running Docker, some system logs can only be accessed from a shell session on the host computer. You can run <code>%s</code> to access container logs from the terminal.' => 
      array (
        0 => '',
      ),
      'Logs by Station' => 
      array (
        0 => '',
      ),
      'Relay' => 
      array (
        0 => '',
      ),
      'Is Public' => 
      array (
        0 => '',
      ),
      'First Connected' => 
      array (
        0 => '',
      ),
      'Latest Update' => 
      array (
        0 => '',
      ),
      'Backups Home' => 
      array (
        0 => '',
      ),
      'The backup process is running in the background. The log below will update automatically.' => 
      array (
        0 => '',
      ),
      'Automatic Backups' => 
      array (
        0 => '',
      ),
      'Never run' => 
      array (
        0 => '',
      ),
      'Configure' => 
      array (
        0 => '',
      ),
      'Most Recent Backup Log' => 
      array (
        0 => '',
      ),
      'Restoring Backups' => 
      array (
        0 => '',
      ),
      'To restore a backup from your host computer, run:' => 
      array (
        0 => '',
      ),
      'Note that restoring a backup will clear your existing database. Never restore backup files from untrusted users.' => 
      array (
        0 => '',
      ),
      'Backup' => 
      array (
        0 => 'Záloha',
      ),
      'Last Modified' => 
      array (
        0 => '',
      ),
      'Delete backup "%s"?' => 
      array (
        0 => '',
      ),
      'Report Not Available' => 
      array (
        0 => '',
      ),
      'This report is not available for this station, because the system administrator has chosen not to collect detailed IP-based listener information.' => 
      array (
        0 => '',
      ),
      'Station Broadcasting Disabled' => 
      array (
        0 => '',
      ),
      'Your station is currently not enabled for broadcasting. You can still manage media, playlists, and other station settings. To re-enable broadcasting, <a href="%s">edit your station profile</a>.' => 
      array (
        0 => '',
      ),
      'Available Logs' => 
      array (
        0 => '',
      ),
      'Station Time' => 
      array (
        0 => '',
      ),
      'Automated Playlist Assignment' => 
      array (
        0 => '',
      ),
      'Based on the previous performance of your station\'s songs, %s can automatically distribute songs evenly among your playlists, placing the highest performing songs in the highest-weighted playlists.' => 
      array (
        0 => '',
      ),
      'Once you have configured automated assignment, click the button below to run the automated assignment process. This process will not run at all unless you have selected "Enable" below.' => 
      array (
        0 => '',
      ),
      'Run Automated Assignment' => 
      array (
        0 => '',
      ),
      'Configure Automated Assignment' => 
      array (
        0 => '',
      ),
      'Streamer accounts are currently disabled for this station. To enable streamer accounts, click the button below.' => 
      array (
        0 => '',
      ),
      'Enable Streaming' => 
      array (
        0 => '',
      ),
      'Two-Factor Authentication' => 
      array (
        0 => '',
      ),
      'Two-factor authentication improves the security of your account by requiring a second one-time access code in addition to your password when you log in.' => 
      array (
        0 => '',
      ),
      'Disable Two-Factor' => 
      array (
        0 => '',
      ),
      'Enable Two-Factor' => 
      array (
        0 => '',
      ),
      'Enable Two-Factor Authentication' => 
      array (
        0 => '',
      ),
      'Step 1: Scan QR Code' => 
      array (
        0 => '',
      ),
      'From your smartphone, scan the code to the right using an authentication app of your choice (FreeOTP, Authy, etc).' => 
      array (
        0 => '',
      ),
      'Step 2: Verify Generated Code' => 
      array (
        0 => '',
      ),
      'To verify that the code was set up correctly, enter the 6-digit code the app shows you.' => 
      array (
        0 => '',
      ),
      'QR-Code' => 
      array (
        0 => '',
      ),
      'No entries found.' => 
      array (
        0 => '',
      ),
      'View Details' => 
      array (
        0 => '',
      ),
      'New Key Generated' => 
      array (
        0 => '',
      ),
      '<b>Important: copy the key below before continuing!</b> You will not be able to retrieve it again.' => 
      array (
        0 => '',
      ),
      'Your full API key is below:' => 
      array (
        0 => '',
      ),
      'When making API calls, you can pass this value in the "X-API-Key" header to authenticate as yourself. You can only perform the actions your user account is allowed to perform.' => 
      array (
        0 => '',
      ),
      'Continue' => 
      array (
        0 => '',
      ),
      'API keys can be used to access some system functionality without needing to log in. All of the keys
            you create share your permissions in the system. For more information, see the <a href="%s">API documentation</a>.' => 
      array (
        0 => '',
      ),
      'Key Identifier' => 
      array (
        0 => '',
      ),
      'Enter Two-Factor Code' => 
      array (
        0 => '',
      ),
      'Your account uses a two-factor security code. Enter the code your device is currently showing below.' => 
      array (
        0 => '',
      ),
      'Security Code' => 
      array (
        0 => '',
      ),
      'Sign in' => 
      array (
        0 => '',
      ),
      'Forgot Password' => 
      array (
        0 => '',
      ),
      'name@example.com' => 
      array (
        0 => '',
      ),
      'Send Recovery E-mail' => 
      array (
        0 => '',
      ),
      'Welcome!' => 
      array (
        0 => '',
      ),
      'Welcome to %s!' => 
      array (
        0 => '',
      ),
      'Enter your password' => 
      array (
        0 => '',
      ),
      'Remember me' => 
      array (
        0 => '',
      ),
      'Please log in to continue.' => 
      array (
        0 => '',
      ),
      'Forgot your password?' => 
      array (
        0 => '',
      ),
      'This installation\'s administrator has not configured this functionality.' => 
      array (
        0 => '',
      ),
      'Contact an administrator to reset your password following the instructions in our documentation:' => 
      array (
        0 => '',
      ),
      'Password Reset Instructions' => 
      array (
        0 => '',
      ),
      'Recover Account' => 
      array (
        0 => '',
      ),
      'Choose a new password for your account.' => 
      array (
        0 => '',
      ),
      'Automatically scroll to the bottom of the log' => 
      array (
        0 => '',
      ),
      'Need Help?' => 
      array (
        0 => '',
      ),
      'You can find answers for many common questions in our <a href="%s" target="_blank">support documents</a>.' => 
      array (
        0 => '',
      ),
      'If you\'re experiencing a bug or error, you can submit a GitHub issue using the link below.' => 
      array (
        0 => '',
      ),
      'Your current installation type is <b>%s</b>. Be sure to include this when creating a new issue.' => 
      array (
        0 => '',
      ),
      'Add New GitHub Issue' => 
      array (
        0 => '',
      ),
    ),
  ),
);