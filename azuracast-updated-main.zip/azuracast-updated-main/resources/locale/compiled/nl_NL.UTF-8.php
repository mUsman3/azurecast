<?php return array (
  'domain' => NULL,
  'plural-forms' => 'nplurals=2; plural=(n != 1);',
  'messages' => 
  array (
    '' => 
    array (
      '' => 
      array (
        0 => 'Project-Id-Version: azuracast
Report-Msgid-Bugs-To: 
Last-Translator: 
Language-Team: Dutch
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
POT-Creation-Date: 2021-10-27T06:14:10+00:00
PO-Revision-Date: 2021-10-27 07:09
Language: nl_NL
Plural-Forms: nplurals=2; plural=(n != 1);
X-Crowdin-Project: azuracast
X-Crowdin-Project-ID: 217396
X-Crowdin-Language: nl
X-Crowdin-File: /main/resources/locale/default.pot
X-Crowdin-File-ID: 4
',
      ),
      'Avatars are retrieved based on your e-mail address from the %{service} service. Click to manage your %{service} settings.' => 
      array (
        0 => 'Avatars worden opgehaald op basis van je e-mailadres van de %{service} service. Klik om je %{service} instellingen te beheren.',
      ),
      'Drag file(s) here to upload or' => 
      array (
        0 => 'Bestand(en) hierheen slepen om te uploaden of',
      ),
      'Select File' => 
      array (
        0 => 'Selecteer bestand',
      ),
      'Today' => 
      array (
        0 => 'Vandaag',
      ),
      'Yesterday' => 
      array (
        0 => 'Gisteren',
      ),
      'Last 7 Days' => 
      array (
        0 => 'Laatste 7 dagen',
      ),
      'Last 14 Days' => 
      array (
        0 => 'Laatste 14 dagen',
      ),
      'Last 30 Days' => 
      array (
        0 => 'Laatste 30 dagen',
      ),
      'This Month' => 
      array (
        0 => 'Deze maand',
      ),
      'Last Month' => 
      array (
        0 => 'Laatste maand',
      ),
      'Volume' => 
      array (
        0 => 'Volume',
      ),
      'Waveform Zoom' => 
      array (
        0 => 'Waveform Zoom',
      ),
      'Mute' => 
      array (
        0 => 'Geluid dempen',
      ),
      'Full Volume' => 
      array (
        0 => 'Volledige volume',
      ),
      'Edit Record' => 
      array (
        0 => 'Record bewerken',
      ),
      'Add Record' => 
      array (
        0 => 'Record toevoegen',
      ),
      'Copy to Clipboard' => 
      array (
        0 => 'Kopiëren naar klembord',
      ),
      'Close' => 
      array (
        0 => 'Sluit',
      ),
      'Save Changes' => 
      array (
        0 => 'Instellingen Opslaan',
      ),
      'Refresh rows' => 
      array (
        0 => 'Ververs rijen',
      ),
      'Rows per page' => 
      array (
        0 => 'Rijen per pagina',
      ),
      'Select displayed fields' => 
      array (
        0 => 'Selecteer weer te geven velden',
      ),
      'Select all visible rows' => 
      array (
        0 => 'Selecteer alle zichtbare rijen',
      ),
      'Select' => 
      array (
        0 => 'Selecteer',
      ),
      'Deselect' => 
      array (
        0 => 'Deselecteer',
      ),
      'Search' => 
      array (
        0 => 'Zoeken',
      ),
      'No records to display.' => 
      array (
        0 => 'Geen archief om te laten zien.',
      ),
      'Loading...' => 
      array (
        0 => 'Laden...',
      ),
      'Stop' => 
      array (
        0 => 'Stop',
      ),
      'Play' => 
      array (
        0 => 'Speel',
      ),
      'Listeners' => 
      array (
        0 => 'Aantal luisteraars',
      ),
      'Log View' => 
      array (
        0 => 'Log weergave',
      ),
      'Average Listeners' => 
      array (
        0 => 'Gemiddeld aantal luisteraars',
      ),
      'Unique Listeners' => 
      array (
        0 => 'Unieke luisteraars',
      ),
      'Hide Charts' => 
      array (
        0 => '',
      ),
      'Show Charts' => 
      array (
        0 => 'Toon grafieken',
      ),
      'My Account' => 
      array (
        0 => 'Mijn account',
      ),
      'Administration' => 
      array (
        0 => 'Administratie',
      ),
      'Listeners Per Station' => 
      array (
        0 => 'Luisteraars per station',
      ),
      'Station Overview' => 
      array (
        0 => 'Overzicht van station',
      ),
      'Manage Stations' => 
      array (
        0 => 'Stations Beheren',
      ),
      'Station Name' => 
      array (
        0 => 'Stations Naam',
      ),
      'Now Playing' => 
      array (
        0 => 'Huidig nummer',
      ),
      'Public Page' => 
      array (
        0 => 'Publieke pagina',
      ),
      'Manage' => 
      array (
        0 => 'Beheer',
      ),
      'Username' => 
      array (
        0 => 'Gebruikersnaam',
      ),
      'New Password' => 
      array (
        0 => 'Nieuw wachtwoord',
      ),
      'Password' => 
      array (
        0 => 'Wachtwoord',
      ),
      'Leave blank to use the current password.' => 
      array (
        0 => 'Laat leeg om het huidige wachtword te gebruiken.',
      ),
      'SSH Public Keys' => 
      array (
        0 => 'Openbare SSH sleutels',
      ),
      'Optionally supply SSH public keys this user can use to connect instead of a password. Enter one key per line.' => 
      array (
        0 => 'Geef optioneel publieke SSH sleutels in die deze gebruiker kan gebruiken om verbinding te maken in plaats van een wachtwoord. Voer één sleutel per regel in.',
      ),
      'Edit SFTP User' => 
      array (
        0 => 'SFTP-gebruiker bewerken',
      ),
      'Add SFTP User' => 
      array (
        0 => 'SFTP-gebruiker toevoegen',
      ),
      'Reorder Playlist' => 
      array (
        0 => 'Afspeellijst herschikken',
      ),
      'Down' => 
      array (
        0 => 'Omlaag',
      ),
      'Up' => 
      array (
        0 => 'Omhoog',
      ),
      'Playlist order set.' => 
      array (
        0 => 'Afspeellijst volgorde ingesteld.',
      ),
      'Title' => 
      array (
        0 => 'Titel',
      ),
      'Artist' => 
      array (
        0 => 'Artiest',
      ),
      'Album' => 
      array (
        0 => 'Album',
      ),
      'Actions' => 
      array (
        0 => 'Acties',
      ),
      'Advanced' => 
      array (
        0 => 'Geavanceerd',
      ),
      'Warning' => 
      array (
        0 => 'Waarschuwing',
      ),
      'If any of these options are enabled, this playlist will be managed directly via Liquidsoap instead of via AzuraCast. This can have unintended effects and should only be used when you are comfortable with the results.' => 
      array (
        0 => 'Als een van deze opties ingeschakeld zijn, zal de afspeellijst direct via Liquidsoap beheert worden in plaats dat dit via AzuraCast gebeurt.',
      ),
      'Advanced Manual AutoDJ Scheduling Options' => 
      array (
        0 => 'Geavanceerde handmatige AutoDJ planning instellingen',
      ),
      'Control how this playlist is handled by the AutoDJ software.' => 
      array (
        0 => 'Bepaal hoe deze afspeellijst wordt behandeld door de AutoDJ software.',
      ),
      'Interrupt other songs to play at scheduled time.' => 
      array (
        0 => 'Onderbreek andere nummers om af te spelen op het geplande tijdstip.',
      ),
      'Only loop through playlist once.' => 
      array (
        0 => 'Afspeellijst maar eenmaal afspelen.',
      ),
      'Only play one track at scheduled time.' => 
      array (
        0 => 'Slechts één track afspelen op geplande tijd.',
      ),
      'Merge playlist to play as a single track.' => 
      array (
        0 => 'Voeg afspeellijst samen om af te spelen als één nummer.',
      ),
      'Low' => 
      array (
        0 => 'Laag',
      ),
      'Default' => 
      array (
        0 => 'Standaard',
      ),
      'High' => 
      array (
        0 => 'Hoog',
      ),
      'Basic Info' => 
      array (
        0 => 'Algemene informatie',
      ),
      'Playlist Name' => 
      array (
        0 => 'Naam van afspeellijst',
      ),
      'Playlist Weight' => 
      array (
        0 => 'Gewicht van afspeellijst',
      ),
      'Higher weight playlists are played more frequently compared to other lower-weight playlists.' => 
      array (
        0 => 'Afspeellijsten met een hoger gewicht worden vaker afgespeeld dan afspeellijsten met een lager gewicht.',
      ),
      'Is Enabled' => 
      array (
        0 => 'Is ingeschakeld',
      ),
      'If disabled, the playlist will not be included in radio playback, but can still be managed.' => 
      array (
        0 => 'Wanneer gekozen voor "Nee", zal de afspeellijst niet worden afgespeeld op de stream. De afspeellijst kan nog steeds worden beheert.',
      ),
      'Avoid Duplicate Artists/Titles' => 
      array (
        0 => 'Voorkom dubbele artiesten/titels',
      ),
      'Whether the AutoDJ should attempt to avoid duplicate artists and track titles when playing media from this playlist.' => 
      array (
        0 => 'Of de AutoDJ moet proberen dubbele artiesten en titels te vermijden gedurende het afspelen van media uit deze afspeellijst.',
      ),
      'Include in On-Demand Player' => 
      array (
        0 => 'Opnemen in On-Demand speler',
      ),
      'If this station has on-demand streaming and downloading enabled, only songs that are in playlists with this setting enabled will be visible.' => 
      array (
        0 => 'Als dit station on-demand streamen en downloaden heeft ingeschakeld, zullen alleen nummers die in afspeellijsten staan met deze instelling ingeschakeld zichtbaar zijn.',
      ),
      'Playlist Type' => 
      array (
        0 => 'Afspeellijst type',
      ),
      'General Rotation' => 
      array (
        0 => 'Algemene Rotatie',
      ),
      'Standard playlist, shuffles with other standard playlists based on weight.' => 
      array (
        0 => 'Standaard afspeellijst, shuffles met andere standaard afspeellijsten gebaseerd op gewicht.',
      ),
      'Once per x Songs' => 
      array (
        0 => 'Eenmaal per x nummers',
      ),
      'Play exactly once every $x songs.' => 
      array (
        0 => 'Speel precies eenmaal elke <i>x</i> nummers.',
      ),
      'Once per x Minutes' => 
      array (
        0 => 'Eens in de x minuten',
      ),
      'Play exactly once every $x minutes.' => 
      array (
        0 => 'Speel precies één keer per <i>x</i> minuten.',
      ),
      'Once per Hour' => 
      array (
        0 => 'Eenmaal per uur',
      ),
      'Play once per hour at the specified minute.' => 
      array (
        0 => 'Speel één keer per uur op de aangeven tijd.',
      ),
      'Manually define how this playlist is used in Liquidsoap configuration.' => 
      array (
        0 => 'Handmatig definiëren hoe deze afspeellijst wordt gebruikt in de Liquidsoap configuratie.',
      ),
      'Learn about Advanced Playlists' => 
      array (
        0 => 'Meer informatie over geavanceerde afspeellijsten',
      ),
      'Include in Automated Assignment' => 
      array (
        0 => 'Automatische toewijzing inschakelen',
      ),
      'If auto-assignment is enabled, use this playlist as one of the targets for songs to be redistributed into. This will overwrite the existing contents of this playlist.' => 
      array (
        0 => 'Wanneer automatische toewijzig is ingeschakeld, gebruik dan deze afspeellijst als een bron van herverdeelbare nummers. Hiermee wordt de bestaande inhoud van deze afspeellijst overschreven.',
      ),
      'Number of Songs Between Plays' => 
      array (
        0 => 'Aantal nummers tussen spelen',
      ),
      'This playlist will play every $x songs, where $x is specified below.' => 
      array (
        0 => 'Deze afspeellijst zal om $x nummers worden afgespeeld, waar $x hieronder is opgegeven.',
      ),
      'Number of Minutes Between Plays' => 
      array (
        0 => 'Aantal minuten tussen het afspelen',
      ),
      'This playlist will play every $x minutes, where $x is specified below.' => 
      array (
        0 => 'Deze afspeellijst zal elke $x minuten spelen, waar $x hieronder is opgegeven.',
      ),
      'Minute of Hour to Play' => 
      array (
        0 => 'Minuten van het uur om te spelen',
      ),
      'Specify the minute of every hour that this playlist should play.' => 
      array (
        0 => 'Specificeer de minuut van elk uur dat deze afspeellijst moet spelen.',
      ),
      'Monday' => 
      array (
        0 => 'Maandag',
      ),
      'Tuesday' => 
      array (
        0 => 'Dinsdag',
      ),
      'Wednesday' => 
      array (
        0 => 'Woensdag',
      ),
      'Thursday' => 
      array (
        0 => 'Donderdag',
      ),
      'Friday' => 
      array (
        0 => 'Vrijdag',
      ),
      'Saturday' => 
      array (
        0 => 'Zaterdag',
      ),
      'Sunday' => 
      array (
        0 => 'Zondag',
      ),
      'Schedule' => 
      array (
        0 => 'Schema planning',
      ),
      'Not Scheduled' => 
      array (
        0 => 'Niet gepland',
      ),
      'This playlist currently has no scheduled times. It will play at all times. To add a new scheduled time, click the button below.' => 
      array (
        0 => 'De afspeellijst heeft momenteel geen geplande tijden. Hij zal te allen tijde afspelen. Klik op de knop hieronder om een nieuwe geplande tijd toe te voegen.',
      ),
      'Scheduled Time #%{num}' => 
      array (
        0 => 'Geplande Tijd #%{num}',
      ),
      'Remove' => 
      array (
        0 => 'Verwijderen',
      ),
      'Start Time' => 
      array (
        0 => 'Starttijd',
      ),
      'To play once per day, set the start and end times to the same value.' => 
      array (
        0 => 'Stel de start- en eindtijd in op dezelfde waarde om één keer per dag te spelen.',
      ),
      'End Time' => 
      array (
        0 => 'Eind Tijd',
      ),
      'If the end time is before the start time, the playlist will play overnight.' => 
      array (
        0 => 'Als de eindtijd voor de begintijd is, zal de afspeellijst van de ene op de andere dag afspelen.',
      ),
      'Station Time Zone' => 
      array (
        0 => 'Tijdzone',
      ),
      'This station\'s time zone is currently %{tz}.' => 
      array (
        0 => 'De tijdzone van dit station is momenteel %{tz}.',
      ),
      'Start Date' => 
      array (
        0 => 'Start Datum',
      ),
      'To set this schedule to run only within a certain date range, specify a start and end date.' => 
      array (
        0 => 'Om dit schema alleen binnen een bepaald datumbereik uit te voeren, geef je een start- en einddatum op.',
      ),
      'Start/end date cannot be used on playlists with advanced settings!' => 
      array (
        0 => 'Start-/einddatum kan niet worden gebruikt in afspeellijsten met geavanceerde instellingen!',
      ),
      'End Date' => 
      array (
        0 => 'Eind Datum',
      ),
      'Loop Once' => 
      array (
        0 => 'Eenmalig herhalen',
      ),
      'Scheduled Play Days of Week' => 
      array (
        0 => 'Schema voor afspelen dagelijks en wekelijks',
      ),
      'Leave blank to play on every day of the week.' => 
      array (
        0 => 'Laat leeg om elke dag van de week af te laten spelen',
      ),
      'Add Schedule Item' => 
      array (
        0 => 'Voeg item toe aan schema',
      ),
      'Source' => 
      array (
        0 => 'Bron',
      ),
      'Song-Based Playlist' => 
      array (
        0 => 'Op lied gebaseerde afspeellijst',
      ),
      'A playlist containing media files hosted on this server.' => 
      array (
        0 => 'Een afspeellijst met mediabestanden gehost op deze server.',
      ),
      'Remote URL Playlist' => 
      array (
        0 => 'Afspeellijst vanaf externe URL',
      ),
      'A playlist that instructs the station to play from a remote URL.' => 
      array (
        0 => 'Een afspeellijst afspelen vanaf een andere server (Externe URL)',
      ),
      'Song Playback Order' => 
      array (
        0 => 'Volgorde van afspelen',
      ),
      'Shuffled' => 
      array (
        0 => 'Shuffled',
      ),
      'The full playlist is shuffled and then played through in the shuffled order.' => 
      array (
        0 => 'De volledige afspeellijst is geschuffeld, en zal worden afgespeeld in de geschuffelde volgorde.',
      ),
      'Random' => 
      array (
        0 => 'Willekeurig',
      ),
      'A completely random track is picked for playback every time the queue is populated.' => 
      array (
        0 => 'Elke keer dat de wachtrij wordt gevuld, wordt een volledig willekeurige track gekozen om af te spelen.',
      ),
      'Sequential' => 
      array (
        0 => 'Opeenvolgend',
      ),
      'The order of the playlist is manually specified and followed by the AutoDJ.' => 
      array (
        0 => 'De volgorde van de afspeellijst is handmatig opgegeven en gevolgd door de AutoDJ.',
      ),
      'If requests are enabled for your station, users will be able to request media that is on this playlist.' => 
      array (
        0 => 'Als requests zijn ingeschakeld voor uw station zullen luisteraars de mogelijkheid hebben om nummers binnen deze afspeellijst aan te vragen.',
      ),
      'Allow Requests from This Playlist' => 
      array (
        0 => 'Sta liedjes verzoeken toe van deze afspeellijst',
      ),
      'Enable this setting to prevent metadata from being sent to the AutoDJ for files in this playlist. This is useful if the playlist contains jingles or bumpers.' => 
      array (
        0 => 'Schakel deze instelling in om te voorkomen dat metadata naar de AutoDJ wordt verzonden voor bestanden binnen deze afspeellijst. Dit is handig wanneer de afspeellijst jingles of reclames bevat.',
      ),
      'Hide Metadata from Listeners ("Jingle Mode")' => 
      array (
        0 => 'Verberg metadata voor luisteraars (Jingel Modus)',
      ),
      'Remote URL' => 
      array (
        0 => 'Externe URL',
      ),
      'Remote URL Type' => 
      array (
        0 => 'Externe URL type',
      ),
      'Direct Stream URL' => 
      array (
        0 => 'Directe stream URL',
      ),
      'Playlist (M3U/PLS) URL' => 
      array (
        0 => 'Speellijst (M3U/PLS) URL',
      ),
      'Remote Playback Buffer (Seconds)' => 
      array (
        0 => 'Externe afspeelbuffer (seconden)',
      ),
      'The length of playback time that Liquidsoap should buffer when playing this remote playlist. Shorter times may lead to intermittent playback on unstable connections.' => 
      array (
        0 => 'De lengte van afspeeltijd dat Liquidsoap moet bufferen wanneer deze externe playlist wordt afgespeeld. Te korte buffers kunnen lijden tot onderbrekingen en instabiele verbindingen. ',
      ),
      'Import from PLS/M3U' => 
      array (
        0 => 'Importeren uit PLS/M3U',
      ),
      'Select PLS/M3U File to Import' => 
      array (
        0 => 'Selecteer PLS/M3U bestand om te importeren',
      ),
      'AzuraCast will scan the uploaded file for matches in this station\'s music library. Media should already be uploaded before running this step. You can re-run this tool as many times as needed.' => 
      array (
        0 => 'AzuraCast zal het geüploade bestand scannen voor overeenkomsten in de muziekbibliotheek van dit station. Media dient geüpload te zijn voor deze stap wordt uitgevoerd. Je kunt deze tool opnieuw uitvoeren, zo vaak als nodig is.',
      ),
      'Duplicate Playlist' => 
      array (
        0 => 'Afspeellijst dupliceren',
      ),
      '%{name} - Copy' => 
      array (
        0 => '%{name} - Kopiëren',
      ),
      'New Playlist Name' => 
      array (
        0 => 'Nieuwe afspeellijst naam',
      ),
      'Customize Copy' => 
      array (
        0 => 'Kopie aanpassen',
      ),
      'Copy associated media and folders.' => 
      array (
        0 => 'Kopieer bijbehorende media en mappen.',
      ),
      'Copy scheduled playback times.' => 
      array (
        0 => 'Kopieer geplande afspeeltijden.',
      ),
      'Playback Queue' => 
      array (
        0 => 'Wachtrij afspelen',
      ),
      'Playlist queue cleared.' => 
      array (
        0 => 'Afspeellijst wachtrij gewist.',
      ),
      'This queue contains the remaining tracks in the order they will be queued by the AzuraCast AutoDJ (if the tracks are eligible to be played).' => 
      array (
        0 => '',
      ),
      'Clear Queue' => 
      array (
        0 => 'Wachtrij legen',
      ),
      'Edit Playlist' => 
      array (
        0 => 'Afspeellijst bewerken',
      ),
      'Add Playlist' => 
      array (
        0 => 'Afspeellijst toevoegen',
      ),
      'Edit Station Profile' => 
      array (
        0 => 'Wijzig stationsprofiel',
      ),
      'Song Title' => 
      array (
        0 => 'Titel',
      ),
      'Cued On' => 
      array (
        0 => 'Gekozen op',
      ),
      'Delete Queue Item?' => 
      array (
        0 => 'Item in de wachtrij verwijderen?',
      ),
      'Clear Upcoming Song Queue?' => 
      array (
        0 => 'Wis de aanstaande muziek in wachtrij lijst',
      ),
      'Clear' => 
      array (
        0 => 'Leegmaken',
      ),
      'Upcoming Song Queue' => 
      array (
        0 => 'Aankomende nummers in wachtrij',
      ),
      'Clear Upcoming Song Queue' => 
      array (
        0 => 'Wis de aanstaande muziek in wachtrij lijst',
      ),
      'Logs' => 
      array (
        0 => 'Logs',
      ),
      'Delete' => 
      array (
        0 => 'Verwijderen',
      ),
      'Listener Request' => 
      array (
        0 => 'Luisteraar request',
      ),
      'Playlist:' => 
      array (
        0 => 'Afspeellijst:',
      ),
      'Remote Station Type' => 
      array (
        0 => 'Extern station type',
      ),
      'Display Name' => 
      array (
        0 => 'Weergavenaam',
      ),
      'The display name assigned to this relay when viewing it on administrative or public pages. Leave blank to automatically generate one.' => 
      array (
        0 => 'De naam die aan dit mountpoint is gekoppeld en wordt weergegeven op administratieve- en publieke pagina\'s. Laat leeg om automatisch te laten genereren.',
      ),
      'Remote Station Listening URL' => 
      array (
        0 => 'Luister URL van extern station',
      ),
      'Example: if the remote radio URL is http://station.example.com:8000/radio.mp3, enter "http://station.example.com:8000".' => 
      array (
        0 => '',
      ),
      'Remote Station Listening Mountpoint/SID' => 
      array (
        0 => 'Mountpoint/SID van extern station',
      ),
      'Specify a mountpoint (i.e. "/radio.mp3") or a Shoutcast SID (i.e. "2") to specify a specific stream to use for statistics or broadcasting.' => 
      array (
        0 => 'Specificeer een mountpoint (bijv. "/radio.mp3") of een Shoutcast SID (bijv. "2") om een specifieke stream op te geven voor statistieken of uitzendingen.',
      ),
      'Remote Station Administrator Password' => 
      array (
        0 => 'Wachtwoord van extern station',
      ),
      'To retrieve detailed unique listeners and client details, an administrator password is often required.' => 
      array (
        0 => 'Om gedetailleerde unieke luisteraar- en clientgegevens op te halen, is een beheerders wachtwoord vaak vereist.',
      ),
      'Show on Public Pages' => 
      array (
        0 => 'Toon op openbare pagina\'s',
      ),
      'Enable to allow listeners to select this relay on this station\'s public pages.' => 
      array (
        0 => 'Inschakelen om luisteraars toe te staan dit mount point te selecteren op de publieke pagina van het station.',
      ),
      'AutoDJ' => 
      array (
        0 => 'AutoDJ',
      ),
      'Broadcast AutoDJ to Remote Station' => 
      array (
        0 => 'Zend AutoDJ uit naar het station',
      ),
      'If enabled, the AutoDJ on this installation will automatically play music to this mount point.' => 
      array (
        0 => 'Indien ingeschakeld, zal de AutoDJ op deze installatie automatisch muziek afspelen naar dit mount punt.',
      ),
      'AutoDJ Format' => 
      array (
        0 => 'AutoDJ formaat',
      ),
      'AutoDJ Bitrate (kbps)' => 
      array (
        0 => 'AutoDJ bitrate (kbps)',
      ),
      'Remote Station Source Port' => 
      array (
        0 => 'Externe Station bron poort',
      ),
      'If the port you broadcast to is different from the one you listed in the URL above, specify the source port here.' => 
      array (
        0 => 'Als de poort die u uitzendt anders is dan de poort die u hierboven hebt aangegeven, geef dan hier de bronpoort op.',
      ),
      'Remote Station Source Mountpoint/SID' => 
      array (
        0 => 'Externe station bron mountpoint/SID',
      ),
      'If the mountpoint (i.e. /radio.mp3) or Shoutcast SID (i.e. 2) you broadcast to is different from the one listed above, specify the source mount point here.' => 
      array (
        0 => '',
      ),
      'Remote Station Source Username' => 
      array (
        0 => 'Bron gebruikersnaam van extern station',
      ),
      'If you are broadcasting using AutoDJ, enter the source username here. This may be blank.' => 
      array (
        0 => 'Als u met AutoDJ uitzendt, voer hier de brongebruikersnaam in. Dit kan leeg zijn.',
      ),
      'Remote Station Source Password' => 
      array (
        0 => 'Bronwachtwoord van extern station',
      ),
      'If you are broadcasting using AutoDJ, enter the source password here.' => 
      array (
        0 => 'Als u met AutoDJ uitzendt, voer hier het bronwachtwoord in.',
      ),
      'Publish to "Yellow Pages" Directories' => 
      array (
        0 => 'Publiceren naar "Yellow Pages" gids',
      ),
      'Enable to advertise this relay on "Yellow Pages" public radio directories.' => 
      array (
        0 => '',
      ),
      'Edit Remote Relay' => 
      array (
        0 => 'Bewerk externe relais',
      ),
      'Add Remote Relay' => 
      array (
        0 => 'Externe relay toevoegen',
      ),
      'Playlist' => 
      array (
        0 => 'Afspeellijst',
      ),
      'Scheduling' => 
      array (
        0 => 'Schema planning',
      ),
      '# Songs' => 
      array (
        0 => 'Liedjes',
      ),
      'All Playlists' => 
      array (
        0 => 'Alle afspeellijsten',
      ),
      'Schedule View' => 
      array (
        0 => 'Schema Bekijken',
      ),
      'More' => 
      array (
        0 => 'Meer',
      ),
      'Reorder' => 
      array (
        0 => 'Herschikken',
      ),
      'Reshuffle' => 
      array (
        0 => 'Opnieuw shufflen',
      ),
      'Duplicate' => 
      array (
        0 => 'Dupliceren',
      ),
      'Disable' => 
      array (
        0 => 'Schakel uit',
      ),
      'Enable' => 
      array (
        0 => 'Schakel in',
      ),
      'Disabled' => 
      array (
        0 => 'Uitgeschakeld',
      ),
      'Weight' => 
      array (
        0 => 'Gewicht',
      ),
      'Once per %{songs} Songs' => 
      array (
        0 => 'Eens per %{songs} nummers',
      ),
      'Once per %{minutes} Minutes' => 
      array (
        0 => 'Eens per %{minutes} minuten',
      ),
      'Once per Hour (at %{minute})' => 
      array (
        0 => 'Eens per uur (om %{minute})',
      ),
      'Custom' => 
      array (
        0 => 'Op maat aanpassen',
      ),
      'Delete Playlist?' => 
      array (
        0 => 'Afspeellijst verwijderen?',
      ),
      'Playlists' => 
      array (
        0 => 'Afspeellijsten',
      ),
      'Edit' => 
      array (
        0 => 'Wijzig',
      ),
      'Export %{format}' => 
      array (
        0 => 'Exporteren Formaat',
      ),
      'Song-based' => 
      array (
        0 => 'Nummergebaseerd',
      ),
      'Jingle Mode' => 
      array (
        0 => 'Jingle modus',
      ),
      'On-Demand' => 
      array (
        0 => 'On-Demand',
      ),
      'Auto-Assigned' => 
      array (
        0 => 'Automatisch toegewezen',
      ),
      'Name' => 
      array (
        0 => 'Naam',
      ),
      'Delete Remote Relay?' => 
      array (
        0 => 'Externe relay verwijderen?',
      ),
      'Remote Relays' => 
      array (
        0 => 'Externe relays',
      ),
      'Remote relays let you work with broadcasting software outside this server. Any relay you include here will be included in your station\'s statistics. You can also broadcast from this server to remote relays.' => 
      array (
        0 => 'Externe relays laten u werken met uitzendsoftware buiten deze server. Elk relay die u hier toevoegt zal worden opgenomen in de statistieken van uw station. U kunt ook vanuit deze server naar externe relays uitzenden.',
      ),
      'Enabled' => 
      array (
        0 => 'Ingeschakeld',
      ),
      'Mount Point URL' => 
      array (
        0 => 'Mount point URL',
      ),
      'You can set a custom URL for this stream that AzuraCast will use when referring to it. Leave empty to use the default value.' => 
      array (
        0 => 'U kunt een aangepaste URL instellen voor de stream die door AzuraCast wordt gebruikt. Laat leeg om de standaardwaarde te gebruiken.',
      ),
      'Custom Frontend Configuration' => 
      array (
        0 => 'Aangepaste front-end configuratie',
      ),
      'You can include any special mount point settings here, in either JSON { key: \'value\' } format or XML <key>value</key>' => 
      array (
        0 => '',
      ),
      'This name should always begin with a slash (/), and must be a valid URL, such as /autodj.mp3' => 
      array (
        0 => 'De naam dient te beginnen met een schuine streep (/), en een geldige URL te bevatten. Bijv: /autodj.mp3',
      ),
      'The display name assigned to this mount point when viewing it on administrative or public pages. Leave blank to automatically generate one.' => 
      array (
        0 => 'De weergave naam die aan dit mountpoint is gekoppeld en wordt weergegeven op administratieve- en publieke pagina\'s. Laat leeg om automatisch te laten genereren.',
      ),
      'Enable to allow listeners to select this mount point on this station\'s public pages.' => 
      array (
        0 => 'Inschakelen om luisteraars toe te staan dit mount point te selecteren op de publieke pagina van dit station.',
      ),
      'Set as Default Mount Point' => 
      array (
        0 => 'Instellen als standaard mount point',
      ),
      'If this mount is the default, it will be played on the radio preview and the public radio page in this system.' => 
      array (
        0 => 'Als dit mount point standaard is, zal deze gebruikt worden binnen de radiospeler op de publieke radio pagina van dit systeem.',
      ),
      'Relay Stream URL' => 
      array (
        0 => 'Relay stream URL',
      ),
      'Enter the full URL of another stream to relay its broadcast through this mount point.' => 
      array (
        0 => 'Voer de volledige URL in van een andere stream om deze opnieuw uit te zenden via dit mount punt.',
      ),
      'Enable to advertise this mount point on "Yellow Pages" public radio directories.' => 
      array (
        0 => 'Schakel in om dit mountpoint binnen de publieke "Yellow Pages" weer te geven.',
      ),
      'Max Listener Duration' => 
      array (
        0 => '',
      ),
      'Set the length of time (seconds) a listener will stay connected to the stream. If set to 0, listeners can stay connected infinitely.' => 
      array (
        0 => 'Stel maximaal aantal seconden in hoe lang een luisteraar mag luisteren naar de stream, zet op 0 voor oneindig.',
      ),
      'YP Directory Authorization Hash' => 
      array (
        0 => 'YP Directory Autorisatie Hash',
      ),
      'Fallback Mount' => 
      array (
        0 => 'Back-up mount point',
      ),
      'If this mount point is not playing audio, listeners will automatically be redirected to this mount point. The default is /error.mp3, a repeating error message.' => 
      array (
        0 => 'Wanneer dit mount point geen audio speelt, zullen luisteraars doorverwezen worden naar dit mount punt. De standaard is /error.mp3, welke herhaaldelijk een foutmelding laat horen.',
      ),
      'Enable AutoDJ' => 
      array (
        0 => 'AutoDJ inschakelen',
      ),
      'If enabled, the AutoDJ will automatically play music to this mount point.' => 
      array (
        0 => 'Indien ingeschakeld, zal de AutoDJ automatisch muziek afspelen op dit mount punt.',
      ),
      'Intro' => 
      array (
        0 => 'Intro',
      ),
      'Select Intro File' => 
      array (
        0 => 'Selecteer Intro Bestand',
      ),
      'This introduction file should exactly match the bitrate and format of the mount point itself.' => 
      array (
        0 => '',
      ),
      'Current Intro File' => 
      array (
        0 => 'Huidige Intro Bestand',
      ),
      'Download' => 
      array (
        0 => 'Download',
      ),
      'Clear File' => 
      array (
        0 => 'Bestand wissen',
      ),
      'There is no existing intro file associated with this mount point.' => 
      array (
        0 => '',
      ),
      'Edit Mount Point' => 
      array (
        0 => 'Mount point bewerken',
      ),
      'Add Mount Point' => 
      array (
        0 => 'Mount point toevoegen',
      ),
      'Delete SFTP User?' => 
      array (
        0 => '',
      ),
      'SFTP Users' => 
      array (
        0 => 'SFTP gebruikers',
      ),
      'Connection Information' => 
      array (
        0 => 'Connectie informatie',
      ),
      'Server:' => 
      array (
        0 => 'Server:',
      ),
      'You may need to connect directly to your IP address:' => 
      array (
        0 => '',
      ),
      'Port:' => 
      array (
        0 => 'Poort:',
      ),
      'Web Hook Details' => 
      array (
        0 => 'Webhook details',
      ),
      'Web hooks automatically send a HTTP POST request to the URL you specify to notify it any time one of the triggers you specify occurs on your station.' => 
      array (
        0 => '',
      ),
      'The body of the POST message is the exact same as the NowPlaying API response for your station.' => 
      array (
        0 => 'De inhoud van het POST bericht is exact hetzelfde als de Nu Speelt API reactie voor uw station.',
      ),
      'NowPlaying API Response' => 
      array (
        0 => 'Nu Speelt API Response',
      ),
      'In order to process quickly, web hooks have a short timeout, so the responding service should be optimized to handle the request in under 2 seconds.' => 
      array (
        0 => '',
      ),
      'Web Hook URL' => 
      array (
        0 => 'Webhook URL',
      ),
      'The URL that will receive the POST messages any time an event is triggered.' => 
      array (
        0 => 'De URL dat POST berichten zal ontvangen telkens wanneer er een Event wordt aangeroepen.',
      ),
      'Optional: HTTP Basic Authentication Username' => 
      array (
        0 => 'Optioneel: HTTP standaard authenticatie gebruikersnaam',
      ),
      'If your web hook requires HTTP basic authentication, provide the username here.' => 
      array (
        0 => 'Als je web hook HTTP basis authenticate vereist, geef dan hier de gebruikersnaam op.',
      ),
      'Optional: HTTP Basic Authentication Password' => 
      array (
        0 => 'Optioneel: HTTP standaard authenticatie wachtwoord',
      ),
      'If your web hook requires HTTP basic authentication, provide the password here.' => 
      array (
        0 => 'Als je web hook HTTP basis authenticate vereist, geef dan hier het wachtwoord op.',
      ),
      'Matomo Installation Base URL' => 
      array (
        0 => 'Basis URL van de Matomo installatie',
      ),
      'The full base URL of your Matomo installation.' => 
      array (
        0 => 'De volledige basis-URL van uw Matomo installatie.',
      ),
      'Matomo Site ID' => 
      array (
        0 => 'Matomo Site ID',
      ),
      'The numeric site ID for this site.' => 
      array (
        0 => 'Het numerieke site-ID voor deze site.',
      ),
      'Matomo API Token' => 
      array (
        0 => 'Matomo API Token',
      ),
      'Optionally supply an API token to allow IP address overriding.' => 
      array (
        0 => 'Optioneel Geef een API-sleutel op om het IP-adres te kunnen overschrijven.',
      ),
      'Discord Web Hook URL' => 
      array (
        0 => 'Discord Web Hook URL',
      ),
      'This URL is provided within the Discord application.' => 
      array (
        0 => 'Deze URL is verstrekt binnen de Discord-applicatie.',
      ),
      'Main Message Content' => 
      array (
        0 => 'Inhoud hoofdbericht',
      ),
      'Description' => 
      array (
        0 => 'Omschrijving',
      ),
      'URL' => 
      array (
        0 => 'URL',
      ),
      'Author Name' => 
      array (
        0 => 'Naam van de auteur',
      ),
      'Thumbnail Image URL' => 
      array (
        0 => 'Thumbnail afbeelding URL',
      ),
      'Footer Text' => 
      array (
        0 => 'Voettekst',
      ),
      'Web Hook Name' => 
      array (
        0 => 'Webhook naam',
      ),
      'Choose a name for this webhook that will help you distinguish it from others. This will only be shown on the administration page.' => 
      array (
        0 => 'Kies een naam voor deze webhook die u helpt om het van anderen te onderscheiden. Dit wordt alleen getoond op de beheerpagina.',
      ),
      'Web Hook Triggers' => 
      array (
        0 => 'Webhook Triggers',
      ),
      'This web hook will only run when the selected event(s) occur on this specific station.' => 
      array (
        0 => '',
      ),
      'Message Customization Tips' => 
      array (
        0 => '',
      ),
      'Variables are in the form of:' => 
      array (
        0 => '',
      ),
      'All values in the NowPlaying API response are available for use. Any empty fields are ignored.' => 
      array (
        0 => 'Alle waarden in het Nu Speelt API-antwoord zijn beschikbaar voor gebruik. Eventuele lege velden worden genegeerd.',
      ),
      'TuneIn Station ID' => 
      array (
        0 => 'TuneIn Station ID',
      ),
      'The station ID will be a numeric string that starts with the letter S.' => 
      array (
        0 => 'Het station ID zal een numerieke reeks zijn die begint met de letter S.',
      ),
      'TuneIn Partner ID' => 
      array (
        0 => 'TuneIn partner-ID',
      ),
      'TuneIn Partner Key' => 
      array (
        0 => 'TuneIn partner sleutel',
      ),
      'Markdown' => 
      array (
        0 => '',
      ),
      'HTML' => 
      array (
        0 => '',
      ),
      'Bot Token' => 
      array (
        0 => 'Bot Token',
      ),
      'See the Telegram Documentation for more details.' => 
      array (
        0 => 'Zie de Telegram-documentatie voor meer informatie.',
      ),
      'Chat ID' => 
      array (
        0 => 'Chat ID',
      ),
      'Unique identifier for the target chat or username of the target channel (in the format @channelusername).' => 
      array (
        0 => 'Unieke id voor de doelchat of gebruikersnaam van het doelkanaal (in het formaat @channelgebruikersnaam).',
      ),
      'Custom API Base URL' => 
      array (
        0 => 'Aangepaste API basis URL',
      ),
      'Leave blank to use the default Telegram API URL (recommended).' => 
      array (
        0 => '',
      ),
      'Message parsing mode' => 
      array (
        0 => 'Berichtverwerking modus',
      ),
      'See the Telegram documentation for more details.' => 
      array (
        0 => 'Zie de Telegram-documentatie voor meer informatie.',
      ),
      'GA Property Tracking ID' => 
      array (
        0 => '',
      ),
      'The property ID used to track live listeners.' => 
      array (
        0 => '',
      ),
      'Message Recipient(s)' => 
      array (
        0 => 'Bericht geadresseerde(n)',
      ),
      'E-mail addresses can be separated by commas.' => 
      array (
        0 => 'E-mailadressen kunnen gescheiden worden door komma\'s.',
      ),
      'Message Subject' => 
      array (
        0 => 'Bericht onderwerp',
      ),
      'Message Body' => 
      array (
        0 => 'Berichtinhoud',
      ),
      'Select Web Hook Type' => 
      array (
        0 => 'Selecteer Web Hook Type',
      ),
      '%{ seconds } seconds' => 
      array (
        0 => '%{ seconds } seconden',
      ),
      '%{ minutes } minutes' => 
      array (
        0 => '%{ minutes } minuten',
      ),
      'No Limit' => 
      array (
        0 => 'Geen limiet',
      ),
      'Twitter Account Details' => 
      array (
        0 => 'Twitter accountgegevens',
      ),
      'Steps for configuring a Twitter application:' => 
      array (
        0 => 'Stappen voor het configureren van een Twitter-applicatie:',
      ),
      'Create a new app on the Twitter Applications site. Use this installation\'s base URL as the application URL.' => 
      array (
        0 => 'Maak een nieuwe app op de Twitter Applicatie-site. Gebruik de basis-URL van deze installatie als de applicatie-URL.',
      ),
      'Twitter Applications' => 
      array (
        0 => '',
      ),
      'In the newly created application, click the "Keys and Access Tokens" tab.' => 
      array (
        0 => '',
      ),
      'At the bottom of the page, click "Create my access token".' => 
      array (
        0 => 'Klik onderaan de pagina op "Creëer mijn toegangstoken".',
      ),
      'Once these steps are completed, enter the information from the "Keys and Access Tokens" page into the fields below.' => 
      array (
        0 => 'Zodra deze stappen zijn voltooid, voer de informatie van de "Sleutels en Toegangstokens" pagina\'s in de onderstaande velden in.',
      ),
      'Consumer Key (API Key)' => 
      array (
        0 => 'Consumentensleutel (API-sleutel)',
      ),
      'Consumer Secret (API Secret)' => 
      array (
        0 => 'Consumentengeheim (API-geheim)',
      ),
      'Access Token' => 
      array (
        0 => 'Toegangstoken',
      ),
      'Access Token Secret' => 
      array (
        0 => 'Geheime toegangstoken',
      ),
      'Only Send One Tweet Every...' => 
      array (
        0 => 'Stuur slechts één Tweet elke...',
      ),
      'Edit Web Hook' => 
      array (
        0 => 'Web hook bewerken',
      ),
      'Add Web Hook' => 
      array (
        0 => 'Web hook toevoegen',
      ),
      'Powered by AzuraCast' => 
      array (
        0 => 'Mogelijk gemaakt door AzuraCast',
      ),
      'Now playing on %{ station }:' => 
      array (
        0 => '',
      ),
      'Now playing on %{ station }: %{ title } by %{ artist }! Tune in now.' => 
      array (
        0 => '',
      ),
      'Now playing on %{ station }: %{ title } by %{ artist }! Tune in now: %{ url }' => 
      array (
        0 => '',
      ),
      'Disable song requests?' => 
      array (
        0 => 'Verzoeknummers uitschakelen?',
      ),
      'Enable song requests?' => 
      array (
        0 => 'Verzoeknummers inschakelen?',
      ),
      'Song Requests' => 
      array (
        0 => 'Verzoeknummer',
      ),
      'View' => 
      array (
        0 => 'Bekijk',
      ),
      'Streams' => 
      array (
        0 => 'Streams',
      ),
      'Local Streams' => 
      array (
        0 => 'Lokale streams',
      ),
      'Unique' => 
      array (
        0 => 'Uniek',
      ),
      'Download PLS' => 
      array (
        0 => 'PLS downloaden',
      ),
      'Download M3U' => 
      array (
        0 => 'M3U downloaden',
      ),
      '%{listeners} Listener' => 
      array (
        0 => '%{listeners} luisteraars',
        1 => '%{listeners} luisteraars',
      ),
      'On the Air' => 
      array (
        0 => 'On the Air',
      ),
      'Playing Next' => 
      array (
        0 => 'Speelt hierna',
      ),
      'Live' => 
      array (
        0 => 'Live',
      ),
      'Skip Song' => 
      array (
        0 => 'Nummer overslaan',
      ),
      'Disconnect Streamer' => 
      array (
        0 => 'Verbreek verbinding met streamer',
      ),
      'Disable streamers?' => 
      array (
        0 => 'Streamers uitschakelen?',
      ),
      'Enable streamers?' => 
      array (
        0 => 'Streamers inschakelen?',
      ),
      'Streamers/DJs' => 
      array (
        0 => 'Streamers / DJ\'s',
      ),
      'Edit Profile' => 
      array (
        0 => 'Wijzig profiel',
      ),
      'Disable public pages?' => 
      array (
        0 => 'Publieke pagina\'s uitschakelen?',
      ),
      'Enable public pages?' => 
      array (
        0 => 'Openbare pagina\'s inschakelen?',
      ),
      'Public Pages' => 
      array (
        0 => 'Publieke pagina\'s',
      ),
      'Web DJ' => 
      array (
        0 => 'Web DJ',
      ),
      'On-Demand Media' => 
      array (
        0 => 'On-Demand Media',
      ),
      'Podcasts' => 
      array (
        0 => 'Podcasts',
      ),
      'Embed Widgets' => 
      array (
        0 => '',
      ),
      'Broadcasting Service' => 
      array (
        0 => 'Uitzend-service',
      ),
      'Administration URL' => 
      array (
        0 => 'Administratie URL',
      ),
      'Administrator Password' => 
      array (
        0 => 'Administrator wachtwoord',
      ),
      'Source Password' => 
      array (
        0 => 'Source wachtwoord',
      ),
      'Relay Password' => 
      array (
        0 => 'Relay wachtwoord',
      ),
      'Restart' => 
      array (
        0 => 'Herstart',
      ),
      'Start' => 
      array (
        0 => 'Start',
      ),
      'Radio Player' => 
      array (
        0 => 'Radio Speler',
      ),
      'History' => 
      array (
        0 => '',
      ),
      'Requests' => 
      array (
        0 => 'Verzoek',
      ),
      'Light' => 
      array (
        0 => 'Licht',
      ),
      'Dark' => 
      array (
        0 => 'Donker',
      ),
      'Widget Type' => 
      array (
        0 => 'Widget type',
      ),
      'Theme' => 
      array (
        0 => '',
      ),
      'Customize' => 
      array (
        0 => 'Aanpassen',
      ),
      'Embed Code' => 
      array (
        0 => '',
      ),
      'Preview' => 
      array (
        0 => 'Voorbeeld',
      ),
      'Scheduled' => 
      array (
        0 => 'Gepland',
      ),
      'Streamer/DJ' => 
      array (
        0 => 'Streamer/DJ',
      ),
      'Now' => 
      array (
        0 => 'Nu',
      ),
      'AutoDJ Disabled' => 
      array (
        0 => 'AutoDJ uitgeschakeld',
      ),
      'AutoDJ has been disabled for this station. No music will automatically be played when a source is not live.' => 
      array (
        0 => 'AutoDJ is uitgeschakeld. Er zal geen muziek worden afgespeeld wanneer er niet live wordt uitgezonden.',
      ),
      '%{numSongs} uploaded song' => 
      array (
        0 => '%{numSongs} geüploade nummer',
        1 => '%{numSongs} geüploade nummers',
      ),
      '%{numPlaylists} playlist' => 
      array (
        0 => '%{numPlaylists} afspeellijst',
        1 => '%{numPlaylists} afspeellijsten',
      ),
      'LiquidSoap is currently shuffling from %{songs} and %{playlists}.' => 
      array (
        0 => 'LiquidSoap wordt momenteel geschuffeld van %{songs} en %{playlists}.',
      ),
      'AutoDJ Service' => 
      array (
        0 => 'AutoDJ-service',
      ),
      'Running' => 
      array (
        0 => 'Wordt uitgevoerd',
      ),
      'Not Running' => 
      array (
        0 => 'Wordt niet uitgevoerd',
      ),
      'Delete Mount Point?' => 
      array (
        0 => 'Mount point verwijderen?',
      ),
      'Mount Points' => 
      array (
        0 => 'Mount points',
      ),
      'Mount points are how listeners connect and listen to your station. Each mount point can be a different audio format or quality. Using mount points, you can set up a high-quality stream for broadband listeners and a mobile stream for phone users.' => 
      array (
        0 => 'Mount points zijn hoe luisteraars verbinding maken met uw station. Elk mount point kan een ander audio formaat of andere kwaliteit zijn. Door gebruik te maken van mount points is het mogelijk een stream met een hoge kwaliteit aan te bieden voor luisteraars met een snelle internetverbinding en een stream met een lage kwaliteit voor mobiele luisteraars.',
      ),
      'Default Mount' => 
      array (
        0 => 'Standaard mount point',
      ),
      'Genre' => 
      array (
        0 => 'Genre',
      ),
      'Length' => 
      array (
        0 => 'Lengte',
      ),
      'Size' => 
      array (
        0 => 'Grootte',
      ),
      'Modified' => 
      array (
        0 => 'Gewijzigd',
      ),
      'Album Art' => 
      array (
        0 => 'Albumhoes',
      ),
      'Rename' => 
      array (
        0 => 'Hernoemen',
      ),
      'View tracks in playlist' => 
      array (
        0 => 'Bekijk nummers in afspeellijst',
      ),
      '%{spaceUsed} of %{spaceTotal} Used (%{filesCount} Files)' => 
      array (
        0 => '%{spaceUsed} van %{spaceTotal} gebruikt (%{filesCount} bestanden)',
      ),
      '%{spaceUsed} Used (%{filesCount} Files)' => 
      array (
        0 => '%{spaceUsed} Gebruikt (%{filesCount} bestanden)',
      ),
      'Music Files' => 
      array (
        0 => 'Mediabestanden',
      ),
      'You can also upload files in bulk via SFTP.' => 
      array (
        0 => 'U kunt ook bestanden in bulk uploaden via SFTP.',
      ),
      'Manage SFTP Accounts' => 
      array (
        0 => 'SFTP accounts beheren',
      ),
      'Directory' => 
      array (
        0 => 'Map',
      ),
      'Move %{ num } File(s) to' => 
      array (
        0 => 'Verplaats %{ num } bestand(en) naar',
      ),
      'Files moved:' => 
      array (
        0 => 'Bestanden verplaatsen',
      ),
      'Back' => 
      array (
        0 => 'Terug',
      ),
      'Move to Directory' => 
      array (
        0 => 'Verplaats naar map',
      ),
      'Home' => 
      array (
        0 => 'Startpagina',
      ),
      'Basic Information' => 
      array (
        0 => 'Algemene Informatie',
      ),
      'File Name' => 
      array (
        0 => 'Bestandsnaam',
      ),
      'The relative path of the file in the station\'s media directory.' => 
      array (
        0 => 'Het relatieve pad naar het bestand in de media map van het station.',
      ),
      'Song Artist' => 
      array (
        0 => 'Artiest',
      ),
      'Song Genre' => 
      array (
        0 => 'Track Genre',
      ),
      'Song Album' => 
      array (
        0 => 'Album',
      ),
      'Song Lyrics' => 
      array (
        0 => 'Songtekst Lied',
      ),
      'ISRC' => 
      array (
        0 => 'ISRC',
      ),
      'International Standard Recording Code, used for licensing reports.' => 
      array (
        0 => 'Internationale standaardcode voor het opnemen van licenties.',
      ),
      'Visual Cue Editor' => 
      array (
        0 => 'Visuele Cue Editor',
      ),
      'Set cue and fade points using the visual editor. The timestamps will be saved to the corresponding fields in the advanced playback settings.' => 
      array (
        0 => 'Stel cue en fade-punten in met behulp van de visuele editor. De tijdstempels worden opgeslagen in de overeenkomstige velden in de geavanceerde instellingen voor afspelen.',
      ),
      'Set Cue In' => 
      array (
        0 => 'Cue In instellen',
      ),
      'Set Cue Out' => 
      array (
        0 => 'Cue Out instellen',
      ),
      'Set Overlap' => 
      array (
        0 => 'Overlap instellen',
      ),
      'Set Fade In' => 
      array (
        0 => 'Fade In instellen',
      ),
      'Set Fade Out' => 
      array (
        0 => 'Fade Out instellen',
      ),
      'Custom Fields' => 
      array (
        0 => 'Aangepaste velden',
      ),
      'Delete Album Art' => 
      array (
        0 => 'Verwijder Albumhoezen',
      ),
      'Replace Album Cover Art' => 
      array (
        0 => 'Vervang albumhoes',
      ),
      'Song Length' => 
      array (
        0 => 'Lengte Lied',
      ),
      'Amplify: Amplification (dB)' => 
      array (
        0 => 'Versterk: Versterking (dB)',
      ),
      'The volume in decibels to amplify the track with. Leave blank to use the system default.' => 
      array (
        0 => 'Het volume in decibels om het nummer mee te versterken. Laat leeg om de systeemstandaard te gebruiken.',
      ),
      'Custom Fading: Overlap Time (seconds)' => 
      array (
        0 => 'Op maat gemaakte overgang van muziek in (seconden)',
      ),
      'The time that this song should overlap its surrounding songs when fading. Leave blank to use the system default.' => 
      array (
        0 => 'De tijd dat dit nummer moet overlappen met de nummers om te faden. Laat leeg om de standaard nummer te gebruiken.',
      ),
      'Custom Fading: Fade-In Time (seconds)' => 
      array (
        0 => 'Op maat gemaakte Fade in (seconden)',
      ),
      'The time period that the song should fade in. Leave blank to use the system default.' => 
      array (
        0 => 'De periode waarin het liedje moet infaden. Leeg laten om de systeemstandaard te gebruiken.',
      ),
      'Custom Fading: Fade-Out Time (seconds)' => 
      array (
        0 => 'Op maat gemaakte Fade out (seconden)',
      ),
      'The time period that the song should fade out. Leave blank to use the system default.' => 
      array (
        0 => 'De periode waarin het nummer moet uitfaden. Leeg laten om de systeemstandaard te gebruiken.',
      ),
      'Custom Cues: Cue-In Point (seconds)' => 
      array (
        0 => 'Op maat gemaakte Cues: In rij staan (seconden)',
      ),
      'Seconds from the start of the song that the AutoDJ should start playing.' => 
      array (
        0 => 'Aantal seconden vanaf de start van het nummer waarop de AutoDJ moet beginnen met spelen.',
      ),
      'Custom Cues: Cue-Out Point (seconds)' => 
      array (
        0 => 'Op maat gemaakte Cues: In rij staan (seconden)',
      ),
      'Seconds from the start of the song that the AutoDJ should stop playing.' => 
      array (
        0 => 'Aantal seconden vanaf de start van het nummer waarop de AutoDJ moet stoppen met spelen.',
      ),
      'Rename File/Directory' => 
      array (
        0 => 'Wijzig bestand/map',
      ),
      'New File Name' => 
      array (
        0 => 'Nieuwe bestandsnaam',
      ),
      'Set or clear playlists from the selected media' => 
      array (
        0 => 'Afspeellijsten van geselecteerde media instellen of legen',
      ),
      'New Playlist' => 
      array (
        0 => 'Nieuwe afspeellijst',
      ),
      'Queue the selected media to play next' => 
      array (
        0 => 'Voeg de geselecteerde media toe aan de wachtrij om hierna af te spelen',
      ),
      'Analyze and reprocess the selected media' => 
      array (
        0 => 'Analyseer en verwerk de geselecteerde media',
      ),
      'The request could not be processed.' => 
      array (
        0 => 'Het verzoek kon niet worden verwerkt.',
      ),
      'Files queued for playback:' => 
      array (
        0 => 'Bestanden in de afspeelwachtrij:',
      ),
      'Files marked for reprocessing:' => 
      array (
        0 => '',
      ),
      'Delete %{ num } media files?' => 
      array (
        0 => '%{ num } mediabestanden verwijderen?',
      ),
      'Files removed:' => 
      array (
        0 => 'Bestanden verwijderd:',
      ),
      'Playlists updated for selected files:' => 
      array (
        0 => 'Afspeellijsten bijgewerkt voor geselecteerde bestanden:',
      ),
      'Playlists cleared for selected files:' => 
      array (
        0 => 'Afspeellijsten geleegd voor geselecteerde bestanden:',
      ),
      'No files selected.' => 
      array (
        0 => 'Geen bestanden geselecteerd.',
      ),
      'Save' => 
      array (
        0 => 'Opslaan',
      ),
      'Move' => 
      array (
        0 => 'Verplaats',
      ),
      'Queue' => 
      array (
        0 => 'Wachtrij',
      ),
      'Reprocess' => 
      array (
        0 => 'Opnieuw verwerken',
      ),
      'New Folder' => 
      array (
        0 => 'Nieuwe map',
      ),
      'Edit Media' => 
      array (
        0 => 'Media gegevens aanpassen',
      ),
      'New Directory' => 
      array (
        0 => 'Nieuwe map',
      ),
      'New directory created.' => 
      array (
        0 => 'Nieuwe map aangemaakt.',
      ),
      'Directory Name' => 
      array (
        0 => 'Directorynaam',
      ),
      'Create Directory' => 
      array (
        0 => 'Maak map',
      ),
      'Artwork' => 
      array (
        0 => 'Kunstwerk',
      ),
      'Select PNG/JPG artwork file' => 
      array (
        0 => 'Selecteer PNG/JPG illustratie bestand',
      ),
      'Artwork must be a minimum size of 1400 x 1400 pixels and a maximum size of 3000 x 3000 pixels for Apple Podcasts.' => 
      array (
        0 => 'Illustraties moeten een minimale grootte hebben van 1400 x 1400 pixels en een maximale grootte van 3000 x 3000 pixels voor Apple Podcasts.',
      ),
      'Clear Artwork' => 
      array (
        0 => 'Verwijder Illustratie',
      ),
      'Edit Episode' => 
      array (
        0 => 'Aflevering bewerken',
      ),
      'Add Episode' => 
      array (
        0 => 'Aflevering toevoegen',
      ),
      'Edit Podcast' => 
      array (
        0 => 'Podcast bewerken',
      ),
      'Add Podcast' => 
      array (
        0 => 'Podcast toevoegen',
      ),
      'Podcast Title' => 
      array (
        0 => 'Podcast Titel',
      ),
      'Website' => 
      array (
        0 => 'Website',
      ),
      'Typically the home page of a podcast.' => 
      array (
        0 => '',
      ),
      'The description of your podcast. The typical maximum amount of text allowed for this is 4000 characters.' => 
      array (
        0 => 'De beschrijving van je podcast. De gebruikelijke maximale teksthoeveelheid is 4000 tekens.',
      ),
      'Language' => 
      array (
        0 => 'Taal',
      ),
      'The language spoken on the podcast.' => 
      array (
        0 => '',
      ),
      'Author' => 
      array (
        0 => 'Auteur',
      ),
      'The contact person of the podcast. May be required in order to list the podcast on services like Apple Podcasts, Spotify, Google Podcasts, etc.' => 
      array (
        0 => 'De contactpersoon van de podcast. Kan vereist zijn om podcast te tonen op diensten zoals Apple Podcasts, Spotify, Google Podcasts, etc.',
      ),
      'E-Mail' => 
      array (
        0 => 'E-Mail',
      ),
      'The email of the podcast contact. May be required in order to list the podcast on services like Apple Podcasts, Spotify, Google Podcasts, etc.' => 
      array (
        0 => '',
      ),
      'Categories' => 
      array (
        0 => 'Categorieën',
      ),
      'Select the category/categories that best reflects the content of your podcast.' => 
      array (
        0 => 'Selecteer de categorie/categorieën die het beste bij de inhoud van uw podcast past.',
      ),
      'Art' => 
      array (
        0 => 'Albumhoes',
      ),
      'Podcast' => 
      array (
        0 => 'Podcast',
      ),
      '# Episodes' => 
      array (
        0 => 'Afleveringen',
      ),
      'All Podcasts' => 
      array (
        0 => 'Alle Podcasts',
      ),
      'Delete Podcast?' => 
      array (
        0 => 'Podcast verwijderen?',
      ),
      'RSS Feed' => 
      array (
        0 => 'RSS-Feed',
      ),
      'Episodes' => 
      array (
        0 => 'Afleveringen',
      ),
      'Episode' => 
      array (
        0 => '',
      ),
      'File' => 
      array (
        0 => '',
      ),
      'Explicit' => 
      array (
        0 => 'Expliciet',
      ),
      'Delete Episode?' => 
      array (
        0 => 'Aflevering verwijderen?',
      ),
      'Typically a website with content about the episode.' => 
      array (
        0 => 'Meestal een website met inhoud over de aflevering.',
      ),
      'The description of the episode. The typical maximum amount of text allowed for this is 4000 characters.' => 
      array (
        0 => 'De beschrijving van de aflevering. De gebruikelijke maximale teksthoeveelheid voor dit is 4000 tekens.',
      ),
      'Publish Date' => 
      array (
        0 => 'Publicatiedatum',
      ),
      'The date when the episode should be published.' => 
      array (
        0 => 'De datum waarop de aflevering moet worden gepubliceerd.',
      ),
      'Publish Time' => 
      array (
        0 => 'Publicatietijd',
      ),
      'The time when the episode should be published (according to the stations timezone).' => 
      array (
        0 => '',
      ),
      'Contains explicit content' => 
      array (
        0 => 'Bevat expliciete inhoud',
      ),
      'Indicates the presence of explicit content (explicit language or adult content). Apple Podcasts displays an Explicit parental advisory graphic for your episode if turned on. Episodes containing explicit material aren’t available in some Apple Podcasts territories.' => 
      array (
        0 => '',
      ),
      'Media' => 
      array (
        0 => 'Media',
      ),
      'Select Media File' => 
      array (
        0 => 'Selecteer een bestand',
      ),
      'Podcast media should be in the MP3 or M4A (AAC) format for the greatest compatibility.' => 
      array (
        0 => 'Podcast media moeten MP3 of M4A (AAC) formaat hebben voor de beste compatibiliteit.',
      ),
      'Current Podcast Media' => 
      array (
        0 => 'Huidige Podcast Media',
      ),
      'Clear Media' => 
      array (
        0 => 'Media wissen',
      ),
      'There is no existing media associated with this episode.' => 
      array (
        0 => '',
      ),
      'Notes' => 
      array (
        0 => 'Notities',
      ),
      'Account List' => 
      array (
        0 => 'Accountoverzicht',
      ),
      'Delete Streamer?' => 
      array (
        0 => 'Streamer verwijderen?',
      ),
      'Streamer/DJ Accounts' => 
      array (
        0 => 'Streamer/DJ accounts',
      ),
      'Add Streamer' => 
      array (
        0 => 'Streamer toevoegen',
      ),
      'Broadcasts' => 
      array (
        0 => 'Uitzendingen',
      ),
      'Icecast Clients' => 
      array (
        0 => '',
      ),
      'You may need to connect directly via your IP address:' => 
      array (
        0 => '',
      ),
      'Mount Name:' => 
      array (
        0 => '',
      ),
      'SHOUTcast Clients' => 
      array (
        0 => 'SHOUTcast Clients',
      ),
      'For some clients, use port:' => 
      array (
        0 => '',
      ),
      'Password:' => 
      array (
        0 => 'Wachtwoord: ',
      ),
      'or' => 
      array (
        0 => 'of',
      ),
      'Setup instructions for broadcasting software are available on the AzuraCast wiki.' => 
      array (
        0 => 'Instructies voor het instellen van uitzendingssoftware zijn beschikbaar op de AzuraCast wiki.',
      ),
      'AzuraCast Wiki' => 
      array (
        0 => 'AzuraCast Wiki',
      ),
      'Streamer Username' => 
      array (
        0 => 'Streamer gebruikersnaam',
      ),
      'The streamer will use this username to connect to the radio server.' => 
      array (
        0 => 'De streamer dient de gebruikersnaam te gebruiken om met de radio server te verbinden.',
      ),
      'Streamer password' => 
      array (
        0 => 'Wachtwoord streamer',
      ),
      'The streamer will use this password to connect to the radio server.' => 
      array (
        0 => 'De streamer zal dit wachtwoord gebruiken om verbinding te maken met de radioserver.',
      ),
      'Streamer Display Name' => 
      array (
        0 => 'Streamer weergavenaam',
      ),
      'This is the informal display name that will be shown in API responses if the streamer/DJ is live.' => 
      array (
        0 => 'Dit is de informele weergavenaam die zal worden weergegeven in API-antwoorden als de streamer/DJ live is.',
      ),
      'Comments' => 
      array (
        0 => 'Opmerkingen',
      ),
      'Internal notes or comments about the user, visible only on this control panel.' => 
      array (
        0 => 'Interne notities of commentaar over de gebruiker, alleen zichtbaar vanuit dit controle paneel.',
      ),
      'Account is Active' => 
      array (
        0 => 'Account is actief',
      ),
      'Enable to allow this account to log in and stream.' => 
      array (
        0 => 'Stel in op “Ja” om dit account toegang te geven om in te loggen en te streamen.',
      ),
      'Enforce Schedule Times' => 
      array (
        0 => 'Geplande uitzendtijden afdwingen',
      ),
      'If enabled, this streamer will only be able to connect during their scheduled broadcast times.' => 
      array (
        0 => 'Indien ingeschakeld, zal deze streamer enkel de mogelijkheid hebben om te verbinden gedurende de geplande uitzendtijden.',
      ),
      'This streamer is not scheduled to play at any times.' => 
      array (
        0 => 'Deze streamer is nog niet opgenomen in de planning.',
      ),
      'If the end time is before the start time, the schedule entry will continue overnight.' => 
      array (
        0 => 'Als de eindtijd voor de begintijd is, zal het geplande item in de nacht doorgaan.',
      ),
      'Streamer Broadcasts' => 
      array (
        0 => 'Streamer uitzendingen',
      ),
      'Play/Pause' => 
      array (
        0 => 'Afspelen/Pauzeren',
      ),
      'Delete Broadcast?' => 
      array (
        0 => 'Uitzending verwijderen?',
      ),
      'Edit Streamer' => 
      array (
        0 => 'Wijzig streamer',
      ),
      'Hour' => 
      array (
        0 => 'Uur',
      ),
      'IP' => 
      array (
        0 => 'IP-adres',
      ),
      'Time' => 
      array (
        0 => 'Tijd',
      ),
      'Time (sec)' => 
      array (
        0 => 'Tijd (seconden)',
      ),
      'User Agent' => 
      array (
        0 => 'Browser',
      ),
      'Stream' => 
      array (
        0 => 'Stream',
      ),
      'Location' => 
      array (
        0 => 'Locatie',
      ),
      'Live Listeners' => 
      array (
        0 => 'Live luisteraars',
      ),
      'Download CSV' => 
      array (
        0 => 'Download CSV',
      ),
      'for selected period' => 
      array (
        0 => 'voor geselecteerde periode',
      ),
      'Total Listener Hours' => 
      array (
        0 => 'Totaal aantal luisteruren',
      ),
      'Mobile Device' => 
      array (
        0 => 'Mobiel apparaat',
      ),
      'Desktop Device' => 
      array (
        0 => 'Desktop apparaat',
      ),
      'Unknown' => 
      array (
        0 => 'Onbekend',
      ),
      'Local' => 
      array (
        0 => 'Lokaal',
      ),
      'Remote' => 
      array (
        0 => 'Extern',
      ),
      'Filename' => 
      array (
        0 => 'Bestandsnaam',
      ),
      'Length Text' => 
      array (
        0 => 'Lengte van tekst',
      ),
      'Playlist(s)' => 
      array (
        0 => 'Afspeellijst(en)',
      ),
      'Joins' => 
      array (
        0 => 'Ingeschakeld',
      ),
      'Losses' => 
      array (
        0 => 'Verliest',
      ),
      'Total' => 
      array (
        0 => 'Totaal',
      ),
      'Num Plays' => 
      array (
        0 => 'Num Plays',
      ),
      'Play %' => 
      array (
        0 => 'Speel %',
      ),
      'Ratio' => 
      array (
        0 => 'Verhouding',
      ),
      'Song Listener Impact' => 
      array (
        0 => 'Impact van nummer op luisteraar',
      ),
      'Date Requested' => 
      array (
        0 => 'Datum aangevraagd',
      ),
      'Date Played' => 
      array (
        0 => 'Datum afgespeeld',
      ),
      'Requester IP' => 
      array (
        0 => 'IP van aanvrager',
      ),
      'Delete Request?' => 
      array (
        0 => 'Verzoek verwijderen?',
      ),
      'Clear All Pending Requests?' => 
      array (
        0 => 'Alle verzoeknummer in de wachtrij verwijderen?',
      ),
      'Clear Pending Requests' => 
      array (
        0 => 'Verwijder verzoeknummer uit de wachtrij',
      ),
      'Not Played' => 
      array (
        0 => 'Niet afgespeeld',
      ),
      'Listeners by Day' => 
      array (
        0 => 'Aantal luisteraars per dag',
      ),
      'Listeners by Day of Week' => 
      array (
        0 => 'Aantal luisteraars per dag van de week',
      ),
      'Listeners by Hour' => 
      array (
        0 => 'Aantal luisteraars per uur',
      ),
      'Best Performing Songs' => 
      array (
        0 => 'Best presterende nummers',
      ),
      'in the last 48 hours' => 
      array (
        0 => 'in de laatste 48 uur',
      ),
      'Change' => 
      array (
        0 => 'Wijzig',
      ),
      'Song' => 
      array (
        0 => 'Nummer',
      ),
      'Worst Performing Songs' => 
      array (
        0 => 'Slecht presterende nummers',
      ),
      'Most Played Songs' => 
      array (
        0 => 'Meest gedraaide nummers',
      ),
      'in the last month' => 
      array (
        0 => 'in de laatste maand',
      ),
      'Plays' => 
      array (
        0 => 'Aantal keer gespeeld',
      ),
      'Date/Time' => 
      array (
        0 => 'Datum/Tijd',
      ),
      'Song Playback Timeline' => 
      array (
        0 => 'Nummer Afspeeltijdlijn',
      ),
      'Live Streamer:' => 
      array (
        0 => 'Live Streamer:',
      ),
      'Name/Type' => 
      array (
        0 => '',
      ),
      'Triggers' => 
      array (
        0 => 'Triggers',
      ),
      'Delete Web Hook?' => 
      array (
        0 => 'Web hook verwijderen?',
      ),
      'Web Hooks' => 
      array (
        0 => 'Webhooks',
      ),
      'Web hooks let you connect to external web services and broadcast changes to your station to them.' => 
      array (
        0 => 'Webhooks laat u verbinding maken met externe webdiensten om informatie door te sturen bij veranderingen binnen uw station.',
      ),
      'Test' => 
      array (
        0 => 'Test',
      ),
      'Song History' => 
      array (
        0 => 'Afspeelgeschiedenis',
      ),
      'Request Song' => 
      array (
        0 => 'Nummer aanvragen',
      ),
      'Request a Song' => 
      array (
        0 => 'Nummer aanvragen',
      ),
      'Microphone' => 
      array (
        0 => 'Microfoon',
      ),
      'Cue' => 
      array (
        0 => 'Stop (in cue mode)',
      ),
      'Microphone Source' => 
      array (
        0 => 'Microfoon bron',
      ),
      'Stop Streaming' => 
      array (
        0 => 'Stoppen met streamen',
      ),
      'Start Streaming' => 
      array (
        0 => 'Start streamen',
      ),
      'Metadata updated!' => 
      array (
        0 => 'Metadata bijgewerkt!',
      ),
      'Settings' => 
      array (
        0 => 'Instellingen',
      ),
      'Metadata' => 
      array (
        0 => 'Metagegevens',
      ),
      'Encoder' => 
      array (
        0 => 'Encoder',
      ),
      'MP3' => 
      array (
        0 => 'MP3',
      ),
      'Raw' => 
      array (
        0 => 'Raw',
      ),
      'Sample Rate' => 
      array (
        0 => 'Sample snelheid',
      ),
      'Bit Rate' => 
      array (
        0 => 'Bit Rate',
      ),
      'DJ Credentials' => 
      array (
        0 => 'DJ inloggegevens',
      ),
      'Use Asynchronous Worker' => 
      array (
        0 => 'Gebruik asynchrone streamer',
      ),
      'Update Metadata' => 
      array (
        0 => 'Metadata bijwerken',
      ),
      'Mixer' => 
      array (
        0 => 'Mixen',
      ),
      'Playlist 1' => 
      array (
        0 => 'Afspeellijst 1',
      ),
      'Playlist 2' => 
      array (
        0 => 'Afspeellijst 2',
      ),
      'Unknown Title' => 
      array (
        0 => 'Onbekende titel',
      ),
      'Unknown Artist' => 
      array (
        0 => 'Onbekende artiest',
      ),
      'Add Files to Playlist' => 
      array (
        0 => 'Bestanden toevoegen aan afspeellijst',
      ),
      'Continuous Play' => 
      array (
        0 => 'Continu spelen',
      ),
      'Repeat Playlist' => 
      array (
        0 => 'Herhaal afspeellijst',
      ),
      'Request' => 
      array (
        0 => 'Aanvragen',
      ),
      'This field is required.' => 
      array (
        0 => 'Dit veld is verplicht.',
      ),
      'This field must have at least %{ min } letters.' => 
      array (
        0 => '',
      ),
      'This field must have at most %{ max } letters.' => 
      array (
        0 => '',
      ),
      'This field must be between %{ min } and %{ max }.' => 
      array (
        0 => '',
      ),
      'This field must only contain alphabetic characters.' => 
      array (
        0 => '',
      ),
      'This field must only contain alphanumeric characters.' => 
      array (
        0 => 'Dit veld mag alleen alfanumerieke tekens bevatten.',
      ),
      'This field must only contain numeric characters.' => 
      array (
        0 => 'Dit veld mag alleen numerieke tekens bevatten.',
      ),
      'This field must be a valid integer.' => 
      array (
        0 => '',
      ),
      'This field must be a valid decimal number.' => 
      array (
        0 => '',
      ),
      'This field must be a valid e-mail address.' => 
      array (
        0 => '',
      ),
      'This field must be a valid IP address.' => 
      array (
        0 => '',
      ),
      'This field must be a valid URL.' => 
      array (
        0 => '',
      ),
      'This password is too common or insecure.' => 
      array (
        0 => '',
      ),
      'Global Permissions' => 
      array (
        0 => '',
      ),
      'Role Name' => 
      array (
        0 => 'Rol naam',
      ),
      'Users with this role will have these permissions across the entire installation.' => 
      array (
        0 => '',
      ),
      'Station Permissions' => 
      array (
        0 => 'Permissies per station',
      ),
      'Users with this role will have these permissions for this single station.' => 
      array (
        0 => '',
      ),
      'Add Station' => 
      array (
        0 => 'Station toevoegen',
      ),
      'Edit Role' => 
      array (
        0 => 'Rol bewerken',
      ),
      'Add Role' => 
      array (
        0 => 'Rol toevoegen',
      ),
      'User' => 
      array (
        0 => 'Gebruiker',
      ),
      'Operation' => 
      array (
        0 => 'Operatie',
      ),
      'Identifier' => 
      array (
        0 => 'Identificatiecode',
      ),
      'Target' => 
      array (
        0 => 'Doel',
      ),
      'Insert' => 
      array (
        0 => 'Toevoegen',
      ),
      'Update' => 
      array (
        0 => 'Update',
      ),
      'Audit Log' => 
      array (
        0 => 'Controle logboek',
      ),
      'N/A' => 
      array (
        0 => 'NB',
      ),
      'Changes' => 
      array (
        0 => 'Wijzigingen',
      ),
      'Field' => 
      array (
        0 => 'Veld',
      ),
      'Previous' => 
      array (
        0 => 'Vorige',
      ),
      'Updated' => 
      array (
        0 => 'Bijgewerkt',
      ),
      'Broadcasting' => 
      array (
        0 => 'Uitzenden',
      ),
      'Only connect to a remote server.' => 
      array (
        0 => '',
      ),
      'Use Icecast 2.4 on this server.' => 
      array (
        0 => '',
      ),
      'Use SHOUTcast DNAS 2 on this server.' => 
      array (
        0 => '',
      ),
      'This software delivers your broadcast to the listening audience.' => 
      array (
        0 => 'Deze software verstuurt je radiouitzending naar het publiek.',
      ),
      'SHOUTcast License ID' => 
      array (
        0 => '',
      ),
      'SHOUTcast User ID' => 
      array (
        0 => '',
      ),
      'Customize Source Password' => 
      array (
        0 => 'Bronwachtwoord aanpassen',
      ),
      'Leave blank to automatically generate a new password.' => 
      array (
        0 => 'Laat leeg om automatisch een wachtwoord te genereren.',
      ),
      'Customize Administrator Password' => 
      array (
        0 => 'Beheerderswachtwoord aanpassen',
      ),
      'Customize Broadcasting Port' => 
      array (
        0 => 'Uitzendpoort aanpassen',
      ),
      'No other program can be using this port. Leave blank to automatically assign a port.' => 
      array (
        0 => 'Deze poort kan niet door een ander programma gebruikt worden. Laat dit veld leeg om automatisch een poort toe te laten kennen.',
      ),
      'Maximum Listeners' => 
      array (
        0 => 'Maximaal aantal luisteraars',
      ),
      'Maximum number of total listeners across all streams. Leave blank to use the default.' => 
      array (
        0 => '',
      ),
      'Banned IP Addresses' => 
      array (
        0 => 'Geblokkeerde e-mailadressen',
      ),
      'List one IP address or group (in CIDR format) per line.' => 
      array (
        0 => 'Geef één IP-adres of groep (in CIDR formaat) per regel aan.',
      ),
      'Allowed IP Addresses' => 
      array (
        0 => 'Toegestane IP-adressen',
      ),
      'Banned Countries' => 
      array (
        0 => 'Geblokkeerde landen',
      ),
      'Select the countries that are not allowed to connect to the streams.' => 
      array (
        0 => 'Selecteer de landen die geen verbinding met de streams mogen maken.',
      ),
      'Clear List' => 
      array (
        0 => '',
      ),
      'Custom Configuration' => 
      array (
        0 => 'Aangepaste configuratie',
      ),
      'This code will be included in the frontend configuration. Allowed formats are:' => 
      array (
        0 => '',
      ),
      'Station Profile' => 
      array (
        0 => 'Stationsprofiel',
      ),
      'Web Site URL' => 
      array (
        0 => 'Website URL',
      ),
      'Note: This should be the public-facing homepage of the radio station, not the AzuraCast URL. It will be included in broadcast details.' => 
      array (
        0 => 'Opmerking: Dit moet de publieke startpagina van het radiostation zijn, niet de AzuraCast pagina. Deze website zal worden opgenomen in de uitzendgegevens.',
      ),
      'Time Zone' => 
      array (
        0 => 'Tijdzone',
      ),
      'Scheduled playlists and other timed items will be controlled by this time zone.' => 
      array (
        0 => 'Onder andere geplande afspeellijsten zijn afhankelijk van de ingestelde tijdzone.',
      ),
      'Default Album Art URL' => 
      array (
        0 => 'URL van standaard albumhoes',
      ),
      'If a song has no album art, this URL will be listed instead. Leave blank to use the standard placeholder art.' => 
      array (
        0 => 'Als een nummer geen albumhoes heeft, zal deze URL in plaats daarvan worden weergegeven. Laat leeg om de standaard hoes te gebruiken.',
      ),
      'URL Stub' => 
      array (
        0 => 'URL-vriendelijke naam',
      ),
      'Optionally specify a short URL-friendly name, such as "my_station_name", that will be used in this station\'s URLs. Leave this field blank to automatically create one based on the station name.' => 
      array (
        0 => '',
      ),
      'Number of Visible Recent Songs' => 
      array (
        0 => '',
      ),
      'Customize the number of songs that will appear in the "Song History" section for this station and in all public APIs.' => 
      array (
        0 => 'Pas het aantal nummers aan die worden getoond in de "Afspeelgeschiedenis" sectie voor dit station en in alle openbare API\'s.',
      ),
      'Enable Public Pages' => 
      array (
        0 => '',
      ),
      'Show the station in public pages and general API results.' => 
      array (
        0 => 'Toon het station in openbare pagina\'s en algemene API-resultaten.',
      ),
      'On-Demand Streaming' => 
      array (
        0 => '',
      ),
      'Enable On-Demand Streaming' => 
      array (
        0 => 'Schakel On-Demand Streaming in',
      ),
      'If enabled, music from playlists with on-demand streaming enabled will be available to stream via a specialized public page.' => 
      array (
        0 => '',
      ),
      'Enable Downloads on On-Demand Page' => 
      array (
        0 => 'Downloads inschakelen op On-Demand pagina',
      ),
      'If enabled, a download button will also be present on the public "On-Demand" page.' => 
      array (
        0 => '',
      ),
      'Use Liquidsoap on this server.' => 
      array (
        0 => '',
      ),
      'Do not use an AutoDJ service.' => 
      array (
        0 => '',
      ),
      'Smart Mode' => 
      array (
        0 => 'Slimme modus',
      ),
      'Normal Mode' => 
      array (
        0 => 'Normale modus',
      ),
      'Disable Crossfading' => 
      array (
        0 => 'Crossfading uitschakelen',
      ),
      'This software shuffles from playlists of music constantly and plays when no other radio source is available.' => 
      array (
        0 => 'Deze software kiest willekeurige muziek uit afspeellijsten en speelt wanneer er geen audiobron beschikbaar is.',
      ),
      'Crossfade Method' => 
      array (
        0 => 'Crossfade methode',
      ),
      'Choose a method to use when transitioning from one song to another. Smart Mode considers the volume of the two tracks when fading for a smoother effect, but requires more CPU resources.' => 
      array (
        0 => 'Kies een methode om te gebruiken tijdens de overgang van het ene nummer naar het andere. Slimme modus bekijkt het volume van beide nummers voor een vloeiende overgang, dit belast de CPU echter meer.',
      ),
      'Crossfade Duration (Seconds)' => 
      array (
        0 => 'Lengte van crossfade (seconden)',
      ),
      'Number of seconds to overlap songs.' => 
      array (
        0 => 'Aantal seconden om nummers te overlappen.',
      ),
      'Apply Compression and Normalization' => 
      array (
        0 => 'Compressie en normalisatie toepassen',
      ),
      'Compress and normalize your station\'s audio, producing a more uniform and "full" sound.' => 
      array (
        0 => 'Comprimeer en normaliseer de audio van uw station, met een meer uniform en "volledig" geluid.',
      ),
      'Some stream licensing providers may have specific rules regarding song requests. Check your local regulations for more information.' => 
      array (
        0 => '',
      ),
      'Allow Song Requests' => 
      array (
        0 => 'Accepteer verzoeknummers',
      ),
      'Enable listeners to request a song for play on your station. Only songs that are already in your playlists are requestable.' => 
      array (
        0 => 'Schakel in om luisteraars requests aan te laten vragen, om afspeelt te worden op je station. Alleen nummers welke in je afspeellijsten staan zijn aan te vragen.',
      ),
      'Request Minimum Delay (Minutes)' => 
      array (
        0 => 'Minimale vertraging van verzoeknummers (minuten)',
      ),
      'If requests are enabled, this specifies the minimum delay (in minutes) between a request being submitted and being played. If set to zero, a minor delay of 15 seconds is applied to prevent request floods.' => 
      array (
        0 => '',
      ),
      'Request Last Played Threshold (Minutes)' => 
      array (
        0 => 'Tijdsverschil ter verzoeken met afgespeelde nummers (in minuten)',
      ),
      'This specifies the minimum time (in minutes) between a song playing on the radio and being available to request again. Set to 0 for no threshold.' => 
      array (
        0 => '',
      ),
      'Streamers / DJs' => 
      array (
        0 => '',
      ),
      'Allow Streamers / DJs' => 
      array (
        0 => 'Streamers / DJ\'s toestaan',
      ),
      'If enabled, streamers (or DJs) will be able to connect directly to your stream and broadcast live music that interrupts the AutoDJ stream.' => 
      array (
        0 => 'Indien ingeschakeld, zullen streamers (of DJs) rechtstreeks verbinding kunnen maken met uw stream en live muziek kunnen uitzenden die de AutoDJ stream onderbreekt.',
      ),
      'Record Live Broadcasts' => 
      array (
        0 => 'Neem Live Uitzendingen op',
      ),
      'If enabled, AzuraCast will automatically record any live broadcasts made to this station to per-broadcast recordings.' => 
      array (
        0 => 'Indien ingeschakeld, zal AzuraCast automatisch alle live uitzendingen opnemen die op dit station hoorbaar zijn geweest.',
      ),
      'Live Broadcast Recording Format' => 
      array (
        0 => 'Formaat voor live uitzending opnames',
      ),
      'Live Broadcast Recording Bitrate (kbps)' => 
      array (
        0 => 'Bitrate (kbps) voor live uitzending opnames',
      ),
      'Deactivate Streamer on Disconnect (Seconds)' => 
      array (
        0 => 'Streamer uitschakelen bij verbreken van verbinding (aantal seconden)',
      ),
      'This is the number of seconds until a streamer who has been manually disconnected can reconnect to the stream. Set to 0 to allow the streamer to immediately reconnect.' => 
      array (
        0 => '',
      ),
      'Customize DJ/Streamer Port' => 
      array (
        0 => 'DJ/Streamer poort aanpassen',
      ),
      'Note: the port after this one will automatically be used for legacy connections.' => 
      array (
        0 => '',
      ),
      'DJ/Streamer Buffer Time (Seconds)' => 
      array (
        0 => 'DJ/Streamer buffer tijd (seconden)',
      ),
      'The number of seconds of signal to store in case of interruption. Set to the lowest value that your DJs can use without stream interruptions.' => 
      array (
        0 => 'Het aantal seconden van het signaal dat opgeslagen moet worden in geval van een onderbreking.',
      ),
      'Customize DJ/Streamer Mount Point' => 
      array (
        0 => 'DJ/Streamer Mount Point aanpassen',
      ),
      'If your streaming software requires a specific mount point path, specify it here. Otherwise, use the default.' => 
      array (
        0 => 'Als je streaming software een specifiek pad voor het mount point vereist, geef deze dan hier op. Gebruik anders de standaard.',
      ),
      'Advanced Configuration' => 
      array (
        0 => 'Geavanceerde configuratie',
      ),
      'Customize Internal Request Processing Port' => 
      array (
        0 => 'Interne request verwerkingspoort aanpassen',
      ),
      'This port is not used by any external process. Only modify this port if the assigned port is in use. Leave blank to automatically assign a port.' => 
      array (
        0 => 'Deze poort wordt niet gebruikt door een extern proces. Pas deze poort aan als de toegewezen poort in gebruik is. Laat leeg om automatisch een poort toe te wijzen.',
      ),
      'Use Replaygain Metadata' => 
      array (
        0 => 'Gebruik Replaygain Metadata',
      ),
      'Instruct Liquidsoap to use any replaygain metadata associated with a song to control its volume level.' => 
      array (
        0 => 'Geef Liquidsoap de instructie om replaygain metadata te gebruiken, die gekoppeld zijn aan een nummer, om het volume niveau te controleren.',
      ),
      'AutoDJ Queue Length' => 
      array (
        0 => 'AutoDJ wachtrij lengte',
      ),
      'This determines how many songs in advance the AutoDJ will automatically fill the queue.' => 
      array (
        0 => '',
      ),
      'Manual AutoDJ Mode' => 
      array (
        0 => 'Handmatige AutoDJ Modus',
      ),
      'This mode disables AzuraCast\'s AutoDJ management, using Liquidsoap itself to manage song playback. "Next Song" and some other features will not be available.' => 
      array (
        0 => 'Deze modus schakelt de beheermogelijkheden van AzuraCasts AutoDJ uit, in plaats daarvan wordt Liquidsoap zelf gebruik om het afspelen van nummers te beheren. Hierdoor zal onder andere de functie voor het weergeven van het volgende nummer niet beschikbaar zijn.',
      ),
      'Character Set Encoding' => 
      array (
        0 => 'Karaktercodering',
      ),
      'For most cases, use the default UTF-8 encoding. The older ISO-8859-1 encoding can be used if accepting connections from SHOUTcast 1 DJs or using other legacy software.' => 
      array (
        0 => 'In de meeste gevallen dient de standaard UTF-8 codering gebruikt te worden. De oudere ISO-8859-1 codering kan gebruikt worden wanneer connecties van SHOUTcast 1 DJs of andere oude software toegestaan dienen te worden.',
      ),
      'Duplicate Prevention Time Range (Minutes)' => 
      array (
        0 => 'Dubbele artiesten check die gedraaid worden (in minuten)',
      ),
      'This specifies the time range (in minutes) of the song history that the duplicate song prevention algorithm should take into account.' => 
      array (
        0 => 'Dit geeft het tijdsbereik (in minuten) van de geschiedenis van het nummer aan dat het dubbele lied en/of artiest preventie algoritme in aanmerking moet nemen.',
      ),
      'Enable Broadcasting' => 
      array (
        0 => 'Uitzending inschakelen',
      ),
      'If disabled, the station will not broadcast or shuffle its AutoDJ.' => 
      array (
        0 => 'Indien uitgeschakeld, zal het station zijn AutoDJ niet uitzenden.',
      ),
      'Base Station Directory' => 
      array (
        0 => 'Station basis directory',
      ),
      'The parent directory where station playlist and configuration files are stored. Leave blank to use default directory.' => 
      array (
        0 => 'De bovenliggende map waar de afspeellijst en configuratiebestanden worden opgeslagen. Laat leeg om de standaard map te gebruiken.',
      ),
      'Media Storage Location' => 
      array (
        0 => 'Opslaglocatie voor media',
      ),
      'Live Recordings Storage Location' => 
      array (
        0 => 'Opslaglocatie voor live-opnamen',
      ),
      'Podcasts Storage Location' => 
      array (
        0 => 'Opslaglocatie voor podcasts',
      ),
      'Clone Station' => 
      array (
        0 => '',
      ),
      '%{station} - Copy' => 
      array (
        0 => '',
      ),
      'Edit Station' => 
      array (
        0 => 'Wijzig station',
      ),
      'Share Media Storage Location' => 
      array (
        0 => 'Deel opslaglocatie van media',
      ),
      'Share Recordings Storage Location' => 
      array (
        0 => 'Deel opslaglocatie van live-opnamen',
      ),
      'Share Podcasts Storage Location' => 
      array (
        0 => 'Deel opslaglocatie van podcasts',
      ),
      'User Permissions' => 
      array (
        0 => 'Gebruikersrechten',
      ),
      'New Station Name' => 
      array (
        0 => 'Nieuwe stationsnaam',
      ),
      'New Station Description' => 
      array (
        0 => 'Nieuwe station beschrijving',
      ),
      'Copy to New Station' => 
      array (
        0 => '',
      ),
      'Permissions' => 
      array (
        0 => 'Machtigingen',
      ),
      'Delete Role?' => 
      array (
        0 => 'Deze rol verwijderen?',
      ),
      'Roles & Permissions' => 
      array (
        0 => 'Rollen & Permissies',
      ),
      'AzuraCast uses a role-based access control system. Roles are given permissions to certain sections of the site, then users are assigned into those roles.' => 
      array (
        0 => 'AzuraCast gebruikt een op rol gebaseerd toegangscontrolesysteem. Rollen krijgen machtigingen voor bepaalde delen van de site, waarna gebruikers worden toegewezen aan deze rollen.',
      ),
      'Global' => 
      array (
        0 => 'Globaal',
      ),
      'Storage Adapter' => 
      array (
        0 => 'Opslag Adapter',
      ),
      'Local Filesystem' => 
      array (
        0 => 'Lokaal bestandssysteem',
      ),
      'Remote: S3 Compatible' => 
      array (
        0 => 'Extern: S3 Compatibel',
      ),
      'Remote: Dropbox' => 
      array (
        0 => 'Extern: Dropbox',
      ),
      'Path/Suffix' => 
      array (
        0 => 'Pad/achtervoegsel',
      ),
      'For local filesystems, this is the base path of the directory. For remote filesystems, this is the folder prefix.' => 
      array (
        0 => 'Voor lokale bestandssystemen is dit het basispad van de map. Voor externe bestandssystemen is dit het voorvoegsel van de map.',
      ),
      'Storage Quota' => 
      array (
        0 => 'Opslagruimte',
      ),
      'Set a maximum disk space that this storage location can use. Specify the size with unit, i.e. "8 GB". Units are measured in 1024 bytes. Leave blank to default to the available space on the disk.' => 
      array (
        0 => 'Stel de maximale schijfruimte in die deze opslaglocatie mag gebruiken. Geef een grootte op met eenheid, d.w.z. "8 GB". Eenheden worden gemeten per 1024 bytes. Laat leeg om de standaard beschikbare ruimte op de schijf te gebruiken.',
      ),
      'Access Key ID' => 
      array (
        0 => 'Access Key ID',
      ),
      'Secret Key' => 
      array (
        0 => 'Geheime sleutel',
      ),
      'Endpoint' => 
      array (
        0 => 'Eindpunt',
      ),
      'Bucket Name' => 
      array (
        0 => 'Bucket Naam',
      ),
      'Region' => 
      array (
        0 => 'Regio',
      ),
      'API Version' => 
      array (
        0 => 'API versie',
      ),
      'Dropbox Generated Access Token' => 
      array (
        0 => 'Dropbox heeft een Toegangstoken gegenereerd',
      ),
      'Learn More about Dropbox Auth Tokens' => 
      array (
        0 => 'Meer informatie over Dropbox Auth Tokens',
      ),
      'Edit Storage Location' => 
      array (
        0 => 'Bewerk opslaglocatie',
      ),
      'Add Storage Location' => 
      array (
        0 => 'Voeg opslaglocatie toe',
      ),
      'GeoLite version "%{ version }" is currently installed.' => 
      array (
        0 => '',
      ),
      'Install GeoLite IP Database' => 
      array (
        0 => 'GeoLite IP-database installeren',
      ),
      'IP Geolocation is used to guess the approximate location of your listeners based on the IP address they connect with. Use the free built-in IP Geolocation library or enter a license key on this page to use MaxMind GeoLite.' => 
      array (
        0 => '',
      ),
      'Instructions' => 
      array (
        0 => 'Instructies',
      ),
      'AzuraCast ships with a built-in free IP geolocation database. You may prefer to use the MaxMind GeoLite service instead to achieve more accurate results. Using MaxMind GeoLite requires a license key, but once the key is provided, we will automatically keep the database updated.' => 
      array (
        0 => '',
      ),
      'To download the GeoLite database:' => 
      array (
        0 => '',
      ),
      'Create an account on the MaxMind developer site.' => 
      array (
        0 => '',
      ),
      'MaxMind Developer Site' => 
      array (
        0 => '',
      ),
      'Visit the "My License Key" page under the "Services" section.' => 
      array (
        0 => 'Bezoek de "Mijn Licentiesleutel" pagina onder de sectie "Diensten".',
      ),
      'Click "Generate new license key".' => 
      array (
        0 => 'Klik op "Genereer nieuwe licentiesleutel".',
      ),
      'Paste the generated license key into the field on this page.' => 
      array (
        0 => 'Plak de gegenereerde licentiesleutel in het veld op deze pagina.',
      ),
      'Current Installed Version' => 
      array (
        0 => 'Huidige geïnstalleerde versie',
      ),
      'GeoLite is not currently installed on this installation.' => 
      array (
        0 => 'GeoLite is momenteel niet geïnstalleerd.',
      ),
      'MaxMind License Key' => 
      array (
        0 => 'MaxMind licentiesleutel',
      ),
      'Remove Key' => 
      array (
        0 => '',
      ),
      'Delete Station?' => 
      array (
        0 => '',
      ),
      'Stations' => 
      array (
        0 => 'Stations',
      ),
      'Clone' => 
      array (
        0 => 'Kloon',
      ),
      'Field Name' => 
      array (
        0 => 'Veldnaam',
      ),
      'This will be used as the label when editing individual songs, and will show in API results.' => 
      array (
        0 => 'Dit wordt gebruikt als label bij het bewerken van individuele nummers, en zal worden weergegeven in API resultaten.',
      ),
      'Programmatic Name' => 
      array (
        0 => 'Programmatische naam',
      ),
      'Optionally specify an API-friendly name, such as "field_name". Leave this field blank to automatically create one based on the name.' => 
      array (
        0 => 'Optioneel geef een API-vriendelijke naam op, zoals <code>veld_naam</code>. Laat dit veld leeg om er automatisch een te maken op basis van de naam.',
      ),
      'Automatically Set from ID3v2 Value' => 
      array (
        0 => 'Automatisch instellen op basis van ID3v2 waarde',
      ),
      'Optionally select an ID3v2 metadata field that, if present, will be used to set this field\'s value.' => 
      array (
        0 => 'Optioneel selecteer een ID3v2 metadata veld dat indien aanwezig, gebruikt zal worden om de waarde van dit veld in te stellen.',
      ),
      'Edit Custom Field' => 
      array (
        0 => 'Aangepast veld toevoegen',
      ),
      'Add Custom Field' => 
      array (
        0 => 'Voeg aangepast veld toe',
      ),
      'Adapter' => 
      array (
        0 => 'Adapter',
      ),
      'Station(s)' => 
      array (
        0 => 'Station(s)',
      ),
      'Station Media' => 
      array (
        0 => 'Station media',
      ),
      'Station Recordings' => 
      array (
        0 => 'Station opnames',
      ),
      'Station Podcasts' => 
      array (
        0 => 'Station Podcasts',
      ),
      'Backups' => 
      array (
        0 => 'Back-ups',
      ),
      'Applying changes...' => 
      array (
        0 => 'Wijzigingen toepassen.',
      ),
      'Delete Storage Location?' => 
      array (
        0 => 'Opslaglocatie verwijderen?',
      ),
      'Storage Locations' => 
      array (
        0 => 'Opslaglocaties',
      ),
      'SHOUTcast version "%{ version }" is currently installed.' => 
      array (
        0 => '',
      ),
      'Install SHOUTcast 2 DNAS' => 
      array (
        0 => '',
      ),
      'SHOUTcast 2 DNAS is not free software, and its restrictive license does not allow AzuraCast to distribute the SHOUTcast binary.' => 
      array (
        0 => '',
      ),
      'In order to install SHOUTcast:' => 
      array (
        0 => '',
      ),
      'Download the Linux x64 binary from the SHOUTcast Radio Manager:' => 
      array (
        0 => '',
      ),
      'SHOUTcast Radio Manager' => 
      array (
        0 => '',
      ),
      'The file name should look like:' => 
      array (
        0 => '',
      ),
      'Upload the file on this page to automatically extract it into the proper directory.' => 
      array (
        0 => '',
      ),
      'SHOUTcast 2 DNAS is not currently installed on this installation.' => 
      array (
        0 => '',
      ),
      'Services' => 
      array (
        0 => 'Diensten',
      ),
      'Stable' => 
      array (
        0 => 'Stabiel',
      ),
      'Rolling Release' => 
      array (
        0 => 'Rolling Release',
      ),
      'AzuraCast Update Checks' => 
      array (
        0 => 'AzuraCast update controles',
      ),
      'Current Release Channel' => 
      array (
        0 => 'Huidig Release Kanaal',
      ),
      'Learn more about release channels in the AzuraCast docs.' => 
      array (
        0 => '',
      ),
      'Show Update Announcements' => 
      array (
        0 => 'Toon update aankondigingen',
      ),
      'Show new releases within your update channel on the AzuraCast homepage.' => 
      array (
        0 => 'Toon nieuwe releases binnen uw release-kanaal op de AzuraCast homepage.',
      ),
      'E-mail Delivery Service' => 
      array (
        0 => '',
      ),
      'Used for "Forgot Password" functionality, web hooks and other functions.' => 
      array (
        0 => 'Wordt gebruikt voor de "Wachtwoord vergeten" functionaliteit, webhooks en andere functies.',
      ),
      'Enable Mail Delivery' => 
      array (
        0 => '',
      ),
      'Sender Name' => 
      array (
        0 => 'Naam afzender',
      ),
      'Sender E-mail Address' => 
      array (
        0 => 'E-mailadres afzender',
      ),
      'SMTP Host' => 
      array (
        0 => 'SMTP-Host',
      ),
      'SMTP Port' => 
      array (
        0 => 'SMTP-poort',
      ),
      'Use Secure (TLS) SMTP Connection' => 
      array (
        0 => 'Gebruik beveiligde (TLS) SMTP verbinding',
      ),
      'Usually enabled for port 465, disabled for ports 587 or 25.' => 
      array (
        0 => '',
      ),
      'SMTP Username' => 
      array (
        0 => 'SMTP gebruikersnaam',
      ),
      'SMTP Password' => 
      array (
        0 => 'SMTP wachtwoord',
      ),
      'Avatar Services' => 
      array (
        0 => '',
      ),
      'Avatar Service' => 
      array (
        0 => '',
      ),
      'Default Avatar URL' => 
      array (
        0 => 'Standaard Avatar URL',
      ),
      'Album Art Services' => 
      array (
        0 => '',
      ),
      'Check Web Services for Album Art for "Now Playing" Tracks' => 
      array (
        0 => '',
      ),
      'Check Web Services for Album Art When Uploading Media' => 
      array (
        0 => '',
      ),
      'Last.fm API Key' => 
      array (
        0 => 'Last.fm API Sleutel',
      ),
      'This service can provide album art for tracks where none is available locally.' => 
      array (
        0 => '',
      ),
      'Apply for an API key at Last.fm' => 
      array (
        0 => '',
      ),
      'Last 60 Days' => 
      array (
        0 => 'Laatste 60 dagen',
      ),
      'Last Year' => 
      array (
        0 => 'Vorig jaar',
      ),
      'Last 2 Years' => 
      array (
        0 => 'Laatste 2 jaar',
      ),
      'Indefinitely' => 
      array (
        0 => 'Onvoltooid',
      ),
      'Site Base URL' => 
      array (
        0 => 'Website url',
      ),
      'The base URL where this service is located. Use either the external IP address or fully-qualified domain name (if one exists) pointing to this server.' => 
      array (
        0 => 'De basis URL waar deze service beschikbaar is gesteld. Gebruik het externe IP-adres of een domeinnaam (als deze bestaat) dat zich richt naar deze server.',
      ),
      'AzuraCast Instance Name' => 
      array (
        0 => 'AzuraCast: Stations Naam',
      ),
      'This name will appear as a sub-header next to the AzuraCast logo, to help identify this server.' => 
      array (
        0 => 'Deze naam wordt weergegeven als subtitel naast het AzuraCast logo, ter herkenning van deze server.',
      ),
      'Prefer Browser URL (If Available)' => 
      array (
        0 => 'Voorkeur browser URL (indien beschikbaar)',
      ),
      'If this setting is set to "Yes", the browser URL will be used instead of the base URL when it\'s available. Set to "No" to always use the base URL.' => 
      array (
        0 => 'Als deze instelling is ingesteld op "Ja" zal, in plaats van de basis URL, de browser URL worden gebruikt wanneer deze beschikbaar is. Stel in op "Nee" om altijd de basis URL te gebruiken.',
      ),
      'Use Web Proxy for Radio' => 
      array (
        0 => 'Web proxy gebruiken',
      ),
      'By default, radio stations broadcast on their own ports (i.e. 8000). If you\'re using a service like CloudFlare or accessing your radio station by SSL, you should enable this feature, which routes all radio through the web ports (80 and 443).' => 
      array (
        0 => 'Een radiouitzending is standaard te beluisteren op zijn eigen poorten (bijv. 8000). Wanneer je gebruikt maakt van een service als CloudFlare, of je je radiostation wilt beveiligen met SSL, dien je deze optie in te schakelen. Deze optie zorgt ervoor dat al het radioverkeer via web poorten wordt verzonden (80 en 443).',
      ),
      'Days of Playback History to Keep' => 
      array (
        0 => 'Aantal dagen waarvan afspeel geschiedenis bewaart dient te blijven',
      ),
      'Set longer to preserve more playback history and listener metadata for stations. Set shorter to save disk space.' => 
      array (
        0 => '',
      ),
      'Use WebSockets for Now Playing Updates' => 
      array (
        0 => 'Gebruik WebSockets voor Now Playing updates',
      ),
      'Enables or disables the use of the newer and faster WebSocket-based system for receiving live updates on public players. You may need to disable this if you encounter problems with it.' => 
      array (
        0 => 'Schakelt het gebruikt van het nieuwe en snelle op WebSocket gebaseerde systeem in of uit waarmee live updates worden verstuurd naar publieke radiospelers. Schakel dit uit als u problemen met deze functionaliteit ondervindt.',
      ),
      'Enable Advanced Features' => 
      array (
        0 => 'Geavanceerde functies inschakelen',
      ),
      'Enable certain advanced features in the web interface, including advanced playlist configuration, station port assignment, changing base media directories and other functionality that should only be used by users who are comfortable with advanced functionality.' => 
      array (
        0 => '',
      ),
      'Security & Privacy' => 
      array (
        0 => '',
      ),
      'Privacy' => 
      array (
        0 => 'Privacy',
      ),
      'Listener Analytics Collection' => 
      array (
        0 => 'Luisteraars statistieken',
      ),
      'Aggregate listener statistics are used to show station reports across the system. IP-based listener statistics are used to view live listener tracking and may be required for royalty reports.' => 
      array (
        0 => 'Luisterstatistieken worden gebruikt om stationsrapporten te tonen over het binnen het systeem. Op IP-gebaseerde luisterstatistieken worden gebruikt om de locatie van de luisteraar op te halen.',
      ),
      'Full:' => 
      array (
        0 => '',
      ),
      'Collect aggregate listener statistics and IP-based listener statistics' => 
      array (
        0 => '',
      ),
      'Limited:' => 
      array (
        0 => '',
      ),
      'Only collect aggregate listener statistics' => 
      array (
        0 => '',
      ),
      'None:' => 
      array (
        0 => '',
      ),
      'Do not collect any listener analytics' => 
      array (
        0 => '',
      ),
      'Security' => 
      array (
        0 => 'Veiligheid',
      ),
      'Always Use HTTPS' => 
      array (
        0 => 'Gebruik altijd HTTPS',
      ),
      'Set to "Yes" to always use "https://" secure URLs, and to automatically redirect to the secure URL when an insecure URL is visited.' => 
      array (
        0 => 'Stel in op "Ja" om altijd "https://" (veilige) URL\'s te gebruiken en automatisch naar de beveiligde URL te verwijzen wanneer een onveilige URL wordt bezocht.',
      ),
      'API "Access-Control-Allow-Origin" Header' => 
      array (
        0 => '',
      ),
      'Set to * to allow all sources, or specify a list of origins separated by a comma (,).' => 
      array (
        0 => '',
      ),
      'Learn more about this header.' => 
      array (
        0 => '',
      ),
      'Auto-Assign Value' => 
      array (
        0 => 'Waarde automatisch toewijzen',
      ),
      'None' => 
      array (
        0 => 'Geen',
      ),
      'Delete Custom Field?' => 
      array (
        0 => 'Aangepast veld verwijderen?',
      ),
      'Create custom fields to store extra metadata about each media file uploaded to your station libraries.' => 
      array (
        0 => 'Maak aangepaste velden om extra metadata op te slaan over elk mediabestand dat is geüpload naar uw station bibliotheken.',
      ),
      'Changes saved.' => 
      array (
        0 => 'Wijzigingen opgeslagen.',
      ),
      'System Settings' => 
      array (
        0 => 'Systeeminstellingen',
      ),
      'Browser Icon' => 
      array (
        0 => 'Browser icoon',
      ),
      'Public Page Background' => 
      array (
        0 => 'Openbare pagina achtergrond',
      ),
      'Default Album Art' => 
      array (
        0 => 'Standaard Albumhoes',
      ),
      'Custom Branding' => 
      array (
        0 => 'Aangepaste huisstijl',
      ),
      'Upload Custom Assets' => 
      array (
        0 => 'Aangepaste content uploaden',
      ),
      'Clear Image' => 
      array (
        0 => 'Afbeelding wissen',
      ),
      'Prefer System Default' => 
      array (
        0 => '',
      ),
      'Branding Settings' => 
      array (
        0 => 'Merk instellingen',
      ),
      'Base Theme for Public Pages' => 
      array (
        0 => 'Basis thema voor openbare pagina\'s',
      ),
      'Select a theme to use as a base for station public pages and the login page.' => 
      array (
        0 => 'Selecteer een thema dat als basis moet worden gebruikt voor openbare stations en de inlogpagina.',
      ),
      'Hide Album Art on Public Pages' => 
      array (
        0 => 'Verberg albumhoezen op openbare pagina\'s',
      ),
      'If selected, album art will not display on public-facing radio pages.' => 
      array (
        0 => 'Indien geselecteerd, worden albumhoezen niet weergegeven op publieke radio-pagina\'s.',
      ),
      'Hide AzuraCast Branding on Public Pages' => 
      array (
        0 => 'Verberg AzuraCast reclame op openbare pagina\'s',
      ),
      'If selected, this will remove the AzuraCast branding from public-facing pages.' => 
      array (
        0 => 'Indien geselecteerd, zal dit AzuraCast reclame van publieke pagina\'s verwijderen.',
      ),
      'Homepage Redirect URL' => 
      array (
        0 => 'URL van homepage omleiden',
      ),
      'If a visitor is not signed in and visits the AzuraCast homepage, you can automatically redirect them to the URL specified here. Leave blank to redirect them to the login screen by default.' => 
      array (
        0 => 'Als een bezoeker niet is aangemeld en de homepage van AzuraCast bezoekt, kunt u ze automatisch doorverwijzen naar de hier opgegeven URL. Laat leeg om ze standaard naar het login scherm te verwijzen.',
      ),
      'Custom CSS for Public Pages' => 
      array (
        0 => 'Aangepaste CSS voor openbare pagina\'s',
      ),
      'This CSS will be applied to the station public pages and login page.' => 
      array (
        0 => 'Deze CSS zal worden toegepast op de inlogpagina en openbare pagina\'s van het station.',
      ),
      'Custom JS for Public Pages' => 
      array (
        0 => 'Aangepaste JS voor openbare pagina\'s',
      ),
      'This javascript code will be applied to the station public pages and login page.' => 
      array (
        0 => 'Deze javascript code zal worden toegepast op de openbare pagina\'s van het station en de inlogpagina.',
      ),
      'Custom CSS for Internal Pages' => 
      array (
        0 => 'Aangepaste CSS voor interne pagina\'s',
      ),
      'This CSS will be applied to the main management pages, like this one.' => 
      array (
        0 => 'Deze CSS zal worden toegevoegd aan alle pagina\'s binnen de beheeromgeving, zoals deze pagina.',
      ),
      'Seek' => 
      array (
        0 => 'Zoeken',
      ),
      'Create Account' => 
      array (
        0 => 'Account Aanmaken',
      ),
      'Create Station' => 
      array (
        0 => 'Station toevoegen',
      ),
      'AzuraCast First-Time Setup' => 
      array (
        0 => 'AzuraCast installatie',
      ),
      'Welcome to AzuraCast!' => 
      array (
        0 => 'Welkom bij AzuraCast!',
      ),
      'Let\'s get started by creating your Super Administrator account.' => 
      array (
        0 => 'Laten we beginnen met het maken van een account voor de systeembeheerder.',
      ),
      'This account will have full access to the system, and you\'ll automatically be logged in to it for the rest of setup.' => 
      array (
        0 => 'Dit account heeft volledige toegang tot het systeem. U wordt automatisch ingelogd voor de rest van de setup.',
      ),
      'E-mail Address' => 
      array (
        0 => 'E-mailadres',
      ),
      'Create a New Radio Station' => 
      array (
        0 => 'Maak een nieuw radiostation',
      ),
      'Continue the setup process by creating your first radio station below. You can edit any of these details later.' => 
      array (
        0 => 'Ga verder met de installatie door je eerste radiostation aan te maken. Je kunt alle instellingen later nogmaals aanpassen.',
      ),
      'Create and Continue' => 
      array (
        0 => '',
      ),
      'Customize AzuraCast Settings' => 
      array (
        0 => 'AzuraCast instellingen aanpassen',
      ),
      'Complete the setup process by providing some information about your broadcast environment. These settings can be changed later from the administration panel.' => 
      array (
        0 => 'Voltooi de installatie door het verstrekken van informatie over je uitzendomgeving. Deze instellingen kunnen later gewijzigd worden vanuit het administratiepaneel.',
      ),
      'Save and Continue' => 
      array (
        0 => '',
      ),
      'An error occurred and your request could not be completed.' => 
      array (
        0 => 'Er is een fout opgetreden, uw verzoek kon niet worden voltooid',
      ),
      'Error' => 
      array (
        0 => '',
      ),
      'Success' => 
      array (
        0 => '',
      ),
      'Please wait...' => 
      array (
        0 => 'Even geduld...',
      ),
      'Delete Record?' => 
      array (
        0 => '',
      ),
      'The locale to use for CLI commands.' => 
      array (
        0 => 'De lokalisatie om te gebruiken voor CLI-commando\'s.',
      ),
      'The application environment.' => 
      array (
        0 => 'De applicatieomgeving.',
      ),
      'Manually modify the logging level.' => 
      array (
        0 => 'Logboek niveau handmatig wijzigen.',
      ),
      'This allows you to log debug-level errors temporarily (for problem-solving) or reduce the volume of logs that are produced by your installation, without needing to modify whether your installation is a production or development instance.' => 
      array (
        0 => 'Hiermee kunt u tijdelijk fouten op foutenniveau loggen (voor probleem-oplossing) of het volume van de logs verminderen die door uw installatie worden geproduceerd, zonder dat je hoeft te wijzigen of je installatie een productie- of ontwikkelingsinstantie is.',
      ),
      'Composer Plugin Mode' => 
      array (
        0 => 'Composer Plugin Modus',
      ),
      'Enable the composer "merge" functionality to combine the main application\'s composer.json file with any plugin composer files. This can have performance implications, so you should only use it if you use one or more plugins with their own Composer dependencies.' => 
      array (
        0 => 'Schakel de composer "samenvoegen" functionaliteit in om het composer.json bestand van de hoofdapplicatie te combineren met eventuele plugin composer bestanden. Dit kan implicaties hebben voor de prestaties, dus u dient het alleen te gebruiken als u een of meer plugins gebruikt met hun eigen Composer afhankelijkheden.',
      ),
      'Minimum Port for Station Port Assignment' => 
      array (
        0 => 'Minimale poort voor station instellen',
      ),
      'Modify this if your stations are listening on nonstandard ports.' => 
      array (
        0 => 'Pas dit aan als uw station een andere poort gebruikt dan de standaard poort',
      ),
      'Maximum Port for Station Port Assignment' => 
      array (
        0 => 'Maximale poorten instellen voor station',
      ),
      'MariaDB Host' => 
      array (
        0 => 'MariaDB host',
      ),
      'Do not modify this after installation.' => 
      array (
        0 => 'Wijzig dit niet na de installatie.',
      ),
      'MariaDB Port' => 
      array (
        0 => 'MariaDB poort',
      ),
      'MariaDB Username' => 
      array (
        0 => 'MariaDB gebruikersnaam',
      ),
      'MariaDB Password' => 
      array (
        0 => 'MariaDB wachtwoord',
      ),
      'MariaDB Database Name' => 
      array (
        0 => 'MariaDB databasenaam',
      ),
      'Auto-generate Random MariaDB Root Password' => 
      array (
        0 => 'Genereer een willekeurig MariaDB Root-wachtwoord',
      ),
      'MariaDB Root Password' => 
      array (
        0 => 'MariaDB Root wachtwoord',
      ),
      'Enable MariaDB Slow Query Log' => 
      array (
        0 => 'MariaDB vertraagde logboeken inschakelen',
      ),
      'Log slower queries to diagnose possible database issues. Only turn this on if needed.' => 
      array (
        0 => 'Logboeken voor langzame query\'s inschakelen om mogelijke database problemen te diagnosticeren. Schakel dit alleen in als het nodig is.',
      ),
      'MariaDB Maximum Connections' => 
      array (
        0 => 'MariaDB maximum aantal verbindingen',
      ),
      'Set the amount of allowed connections to the database. This value should be increased if you are seeing the "Too many connections" error in the logs.' => 
      array (
        0 => 'Stel het aantal toegestane verbindingen naar de database toe in. Deze waarde moet worden verhoogd als u de "Te veel verbindingen" fout ziet in de logboeken.',
      ),
      'Enable Redis' => 
      array (
        0 => 'Redis inschakelen',
      ),
      'Disable to use a flatfile cache instead of Redis.' => 
      array (
        0 => 'Uitschakelen om een flatfile cache te gebruiken in plaats van Redis.',
      ),
      'Redis Host' => 
      array (
        0 => 'Redis Host',
      ),
      'Redis Port' => 
      array (
        0 => 'Redis Poort',
      ),
      'Redis Database Index' => 
      array (
        0 => 'Redis Database Index',
      ),
      'PHP Maximum POST File Size' => 
      array (
        0 => 'PHP maximale POST bestandsgrootte',
      ),
      'PHP Memory Limit' => 
      array (
        0 => 'PHP Geheugenlimiet',
      ),
      'PHP Script Maximum Execution Time' => 
      array (
        0 => 'PHP Script Maximale uitvoeringstijd',
      ),
      '(in seconds)' => 
      array (
        0 => '(in seconden)',
      ),
      'Short Sync Task Execution Time' => 
      array (
        0 => 'Korte Sync Taak Uitvoeringtijd',
      ),
      'The maximum execution time (and lock timeout) for the 15-second, 1-minute and 5-minute synchronization tasks.' => 
      array (
        0 => 'De maximale uitvoeringstijd (en lock timeout) voor de 15-seconden, 1-minuut en 5-minuut synchronisatietaken.',
      ),
      'Long Sync Task Execution Time' => 
      array (
        0 => 'Lange Sync Taak Uitvoertijd',
      ),
      'The maximum execution time (and lock timeout) for the 1-hour synchronization task.' => 
      array (
        0 => 'De maximale uitvoeringstijd (en lock timeout) voor de 1-uurs synchronisatie-taak.',
      ),
      'Maximum PHP-FPM Worker Processes' => 
      array (
        0 => 'Maximale PHP-FPM Worker Processen',
      ),
      'Enable Performance Profiling Extension' => 
      array (
        0 => 'Prestatie van Profiling Uitbreiden Inschakelen',
      ),
      'Profiling data can be viewed by visiting %s.' => 
      array (
        0 => 'Profielgegevens kunnen worden bekeken door een bezoek aan %s.',
      ),
      'Profile Performance on All Requests' => 
      array (
        0 => 'Profiel prestaties op alle verzoeken',
      ),
      'This will have a significant performance impact on your installation.' => 
      array (
        0 => 'Dit zal een aanzienlijke invloed hebben op de prestaties van uw installatie.',
      ),
      'Profiling Extension HTTP Key' => 
      array (
        0 => 'HTTP-sleutel voor profileringsextensie',
      ),
      'The value for the "SPX_KEY" parameter for viewing profiling pages.' => 
      array (
        0 => 'De waarde voor de parameter "SPX_KEY" voor het bekijken van profielpagina\'s.',
      ),
      'Profiling Extension IP Allow List' => 
      array (
        0 => 'Lijst met toegestane IP-extensies voor profilering',
      ),
      '(Docker Compose) All Docker containers are prefixed by this name. Do not change this after installation.' => 
      array (
        0 => '(Docker Compose) Alle Docker containers beginnen met deze naam. Verander dit niet na installatie.',
      ),
      '(Docker Compose) The amount of time to wait before a Docker Compose operation fails. Increase this on lower performance computers.' => 
      array (
        0 => '(Docker Compose) De hoeveelheid tijd die moet worden gewacht voordat een Docker Compose-bewerking mislukt. Verhoog dit op computers / servers met lagere prestaties.',
      ),
      'AzuraCast Release Channel' => 
      array (
        0 => 'AzuraCast releasekanaal',
      ),
      'HTTP Port' => 
      array (
        0 => 'HTTP-poort',
      ),
      'The main port AzuraCast listens to for insecure HTTP connections.' => 
      array (
        0 => 'De hoofdpoort waar AzuraCast naar luistert voor onveilige HTTP-verbindingen.',
      ),
      'HTTPS Port' => 
      array (
        0 => 'HTTPS-poort',
      ),
      'The main port AzuraCast listens to for secure HTTPS connections.' => 
      array (
        0 => 'De hoofdpoort waar AzuraCast naar luistert voor veilige HTTPS-verbindingen.',
      ),
      'SFTP Port' => 
      array (
        0 => 'SFTP-poort',
      ),
      'The port AzuraCast listens to for SFTP file management connections.' => 
      array (
        0 => 'De poort waar AzuraCast naar luistert voor SFTP-bestandsbeheerverbindingen.',
      ),
      'Station Ports' => 
      array (
        0 => 'Station poorten',
      ),
      'The ports AzuraCast should listen to for station broadcasts and incoming DJ connections.' => 
      array (
        0 => 'De poorten waarnaar AzuraCast moet luisteren voor zenderuitzendingen en inkomende DJ-verbindingen.',
      ),
      'Docker User UID' => 
      array (
        0 => 'Docker gebruiker UID',
      ),
      'Set the UID of the user running inside the Docker containers. Matching this with your host UID can fix permission issues.' => 
      array (
        0 => 'Stel de UID in van de gebruiker die in de Docker-containers wordt uitgevoerd. Als u dit koppelt aan uw host-UID, kunnen problemen met machtigingen worden opgelost.',
      ),
      'Docker User GID' => 
      array (
        0 => 'Docker Gebruiker GID',
      ),
      'Set the GID of the user running inside the Docker containers. Matching this with your host GID can fix permission issues.' => 
      array (
        0 => 'Stel de GID in van de gebruiker die in de Docker-containers wordt uitgevoerd. Als u dit koppelt aan uw host-GID, kunnen problemen met machtigingen worden opgelost.',
      ),
      'Advanced: Use Privileged Docker Settings' => 
      array (
        0 => 'Geavanceerd: Rechten Docker-instellingen gebruiken',
      ),
      'LetsEncrypt Domain Name(s)' => 
      array (
        0 => 'LetsEncrypt domeinnaam/domeinnamen',
      ),
      'Domain name (example.com) or names (example.com,foo.bar) to use with LetsEncrypt.' => 
      array (
        0 => 'Domeinnaam (voorbeeld.com) of meerdere domeinnamen (voorbeeld.com,foo.bar) om te gebruiken in combinatie met LetsEncrypt.',
      ),
      'LetsEncrypt E-mail Address' => 
      array (
        0 => 'LetsEncrypt e-mailadres',
      ),
      'Optionally provide an e-mail address for updates from LetsEncrypt.' => 
      array (
        0 => 'Geef optioneel een e-mailadres op voor updates van LetsEncrypt.',
      ),
      'This file was automatically generated by AzuraCast.' => 
      array (
        0 => 'Dit bestand is automatisch gegenereerd door AzuraCast.',
      ),
      'You can modify it as necessary. To apply changes, restart the Docker containers.' => 
      array (
        0 => 'U kunt dit wijzigen indien nodig. Herstart de Docker containers om de wijzigingen toe te passen.',
      ),
      'Remove the leading "#" symbol from lines to uncomment them.' => 
      array (
        0 => 'Verwijder het leidende "#"-symbool van regels om ze te activeren.',
      ),
      'Valid options: %s' => 
      array (
        0 => 'Geldige opties: %s',
      ),
      'Default: %s' => 
      array (
        0 => 'Standaard: %s',
      ),
      'Additional Environment Variables' => 
      array (
        0 => 'Extra omgevingsvariabelen',
      ),
      'AzuraCast Installer' => 
      array (
        0 => 'AzuraCast installatieprogramma',
      ),
      'Welcome to AzuraCast! Complete the initial server setup by answering a few questions.' => 
      array (
        0 => 'Welkom bij AzuraCast! Voltooi de initiële server installatie door enkele vragen te beantwoorden.',
      ),
      'AzuraCast Updater' => 
      array (
        0 => 'AzuraCast Updater',
      ),
      'Change installation settings?' => 
      array (
        0 => 'Installatie instellingen wijzigen?',
      ),
      'AzuraCast is currently configured to listen on the following ports:' => 
      array (
        0 => 'AzuraCast is momenteel geconfigureerd om te luisteren op de volgende poorten:',
      ),
      'HTTP Port: %d' => 
      array (
        0 => 'HTTP poort: %d',
      ),
      'HTTPS Port: %d' => 
      array (
        0 => 'HTTPS poort: %d',
      ),
      'SFTP Port: %d' => 
      array (
        0 => 'SFTP poort: %d',
      ),
      'Radio Ports: %s' => 
      array (
        0 => 'Radio poorten: %s',
      ),
      'Customize ports used for AzuraCast?' => 
      array (
        0 => 'Poorten aanpassen die worden gebruikt door AzureCast?',
      ),
      'Set up LetsEncrypt?' => 
      array (
        0 => 'LetsEncryptie instellen?',
      ),
      'Writing configuration files...' => 
      array (
        0 => 'Configuratiebestanden genereren...',
      ),
      'Server configuration complete!' => 
      array (
        0 => 'Serverconfiguratie voltooid!',
      ),
      'This product includes GeoLite2 data created by MaxMind, available from %s.' => 
      array (
        0 => 'Deze functionaliteit bevat gegevens uit de GeoLite2 database van MaxMind, welke beschikbaar is via %s.',
      ),
      'IP Geolocation by DB-IP' => 
      array (
        0 => 'IP Geolocatie door DB-IP',
      ),
      'GeoLite database not configured for this installation. See System Administration for instructions.' => 
      array (
        0 => 'De GeoLite database is niet geconfigureerd voor deze installatie. Zie Systeembeheer voor instructies.',
      ),
      'Welcome to the AzuraCast Liquidsoap configuration editor.' => 
      array (
        0 => 'Welkom bij de AzuraCast Liquidsoap configuratieomgeving.',
      ),
      'Using this page, you can customize several sections of the Liquidsoap configuration.' => 
      array (
        0 => 'Met behulp van deze pagina kunt u meerdere secties van de Liquidsoap configuratie aanpassen.',
      ),
      'The non-editable sections are automatically generated by AzuraCast.' => 
      array (
        0 => 'De niet-bewerkbare secties worden automatisch gegenereerd door AzuraCast.',
      ),
      '%s is not recognized as a service.' => 
      array (
        0 => '%s is niet herkend als een service.',
      ),
      'It may not be registered with Supervisor yet. Restarting broadcasting may help.' => 
      array (
        0 => 'Het is mogelijk nog niet geregistreerd bij Supervisor. Het opnieuw starten van de uitzending kan helpen.',
      ),
      '%s cannot start' => 
      array (
        0 => '%s kan niet worden gestart',
      ),
      'It is already running.' => 
      array (
        0 => 'Proces is al gestart.',
      ),
      '%s cannot stop' => 
      array (
        0 => '%s kan niet stoppen',
      ),
      'It is not running.' => 
      array (
        0 => 'Het loopt niet.',
      ),
      '%s encountered an error' => 
      array (
        0 => '%s heeft een fout ondervonden',
      ),
      'Check the log for details.' => 
      array (
        0 => 'Controleer het logboek voor details.',
      ),
      'Select...' => 
      array (
        0 => 'Selecteer...',
      ),
      'This feature is not currently supported on this station.' => 
      array (
        0 => 'Deze functionaliteit is momenteel niet ondersteund op dit station.',
      ),
      'Now Playing Data' => 
      array (
        0 => 'Nu speelt gegevens',
      ),
      '1-Minute Sync' => 
      array (
        0 => '1 minuut synchronisatie',
      ),
      'Song Requests Queue' => 
      array (
        0 => 'Verzoeknummers in wachtrij',
      ),
      '5-Minute Sync' => 
      array (
        0 => '5 minuten synchronisatie',
      ),
      'Check Media Folders' => 
      array (
        0 => 'Check media mappen',
      ),
      '1-Hour Sync' => 
      array (
        0 => '1 uur synchronisatie',
      ),
      'Analytics/Statistics' => 
      array (
        0 => 'Analytics/Statistieken',
      ),
      'Cleanup' => 
      array (
        0 => 'Opschonen',
      ),
      'Installation Not Recently Backed Up' => 
      array (
        0 => 'Deze installatie heeft nog geen recente back-up.',
      ),
      'This installation has not been backed up in the last two weeks.' => 
      array (
        0 => 'Er is geen back-up van deze installatie gemaakt in de afgelopen twee weken.',
      ),
      'Update Instructions' => 
      array (
        0 => 'Update instructies',
      ),
      'AzuraCast <a href="%s" target="_blank">version %s</a> is now available.' => 
      array (
        0 => 'AzuraCast <a href="%s" target="_blank">versie %s</a> is nu beschikbaar.',
      ),
      'You are currently running version %s. Updating is highly recommended.' => 
      array (
        0 => 'U draait momenteel versie %s. We raden u aan een update uit te voeren.',
      ),
      'New AzuraCast Release Version Available' => 
      array (
        0 => 'Nieuwe versie van AzuraCast beschikbaar',
      ),
      'Your installation is currently %d update(s) behind the latest version.' => 
      array (
        0 => 'Uw installatie loopt momenteel %d updates achter op de laatste versie.',
      ),
      'View the changelog for full details.' => 
      array (
        0 => 'Bekijk de changelog voor volledige details.',
      ),
      'You should update to take advantage of bug and security fixes.' => 
      array (
        0 => 'U dient bij te werken om gebruik te maken van de laatste bug- en beveiligingsupdates.',
      ),
      'New AzuraCast Updates Available' => 
      array (
        0 => 'Er zijn nieuwe AzuraCast updates beschikbaar',
      ),
      'Synchronized Task Not Recently Run' => 
      array (
        0 => 'Gesynchroniseerde taak is recent nog niet uitgevoerd',
      ),
      'The "%s" synchronization task has not run recently. This may indicate an error with your installation.' => 
      array (
        0 => 'De synchronisatietaak "%s" is onlangs nog niet uitgevoerd. Dit kan duiden op een fout met uw installatie.',
      ),
      'Manually Run Task' => 
      array (
        0 => 'Taak handmatig uitvoeren',
      ),
      'The performance profiling extension is currently enabled on this installation.' => 
      array (
        0 => 'De extensie voor het prestatie profiel is momenteel ingeschakeld op deze installatie.',
      ),
      'You can track the execution time and memory usage of any AzuraCast page or application from the profiler page.' => 
      array (
        0 => 'U kunt de uitvoeringstijd en het geheugengebruik van elke AzuraCast-pagina of -toepassing volgen vanaf de profielpagina.',
      ),
      'Profiler Control Panel' => 
      array (
        0 => 'Profiel Configuratiescherm',
      ),
      'Performance profiling is currently enabled for all requests.' => 
      array (
        0 => 'Prestatieprofiel is momenteel ingeschakeld voor alle verzoeken.',
      ),
      'This can have an adverse impact on system performance. You should disable this when possible.' => 
      array (
        0 => 'Dit kan een negatieve invloed hebben op de systeemprestaties. U kunt dit het beste uitschakelen als dit mogelijk is.',
      ),
      'You should update your <code>docker-compose.yml</code> file to reflect the newest changes.' => 
      array (
        0 => 'U moet uw bestand <code>docker-compose.yml</code> bijwerken om de nieuwste wijzigingen weer te geven.',
      ),
      'If you manually maintain this file, review the <a href="%s" target="_blank">latest version of the file</a> and make any changes needed.' => 
      array (
        0 => 'Als je dit bestand handmatig onderhoudt, bekijk dan de <a href="%s" target="_blank">nieuwste versie van het bestand</a> en breng de nodige wijzigingen aan.',
      ),
      'Otherwise, update your installation and answer "Y" when prompted to update the file.' => 
      array (
        0 => 'Werk anders uw installatie bij en antwoord "Y" wanneer u wordt gevraagd om het bestand bij te werken.',
      ),
      'Your <code>docker-compose.yml</code> file is out of date!' => 
      array (
        0 => 'Uw <code>docker-compose.yml</code> bestand is verouderd!',
      ),
      'You must be logged in to access this page.' => 
      array (
        0 => 'U moet ingelogd zijn om toegang te krijgen tot deze pagina.',
      ),
      'You do not have permission to access this portion of the site.' => 
      array (
        0 => 'U heeft geen toestemming om dit deel van de website te bezoeken.',
      ),
      'All Permissions' => 
      array (
        0 => 'Alle rollen',
      ),
      'View Administration Page' => 
      array (
        0 => 'Bekijk beheerders pagina',
      ),
      'View System Logs' => 
      array (
        0 => 'Bekijk systeemlogs',
      ),
      'Administer Settings' => 
      array (
        0 => 'Instellingen beheren',
      ),
      'Administer API Keys' => 
      array (
        0 => 'API-sleutels beheren',
      ),
      'Administer Stations' => 
      array (
        0 => 'Stations beheren',
      ),
      'Administer Custom Fields' => 
      array (
        0 => 'Aangepaste velden beheren',
      ),
      'Administer Backups' => 
      array (
        0 => 'Back-ups beheren',
      ),
      'Administer Storage Locations' => 
      array (
        0 => 'Beheer opslag locaties',
      ),
      'View Station Page' => 
      array (
        0 => 'Bekijk stationspagina',
      ),
      'View Station Reports' => 
      array (
        0 => 'Bekijk station rapportages',
      ),
      'View Station Logs' => 
      array (
        0 => 'Bekijk station logs',
      ),
      'Manage Station Profile' => 
      array (
        0 => 'Beheer stationsprofiel',
      ),
      'Manage Station Broadcasting' => 
      array (
        0 => 'Beheer uitzending van station',
      ),
      'Manage Station Streamers' => 
      array (
        0 => 'Beheer streamers van station',
      ),
      'Manage Station Mount Points' => 
      array (
        0 => 'Beheer mount points van station',
      ),
      'Manage Station Remote Relays' => 
      array (
        0 => 'Beheer externe relays van station',
      ),
      'Manage Station Media' => 
      array (
        0 => 'Beheer media van station',
      ),
      'Manage Station Automation' => 
      array (
        0 => 'Beheer automatie van station',
      ),
      'Manage Station Web Hooks' => 
      array (
        0 => 'Beheer webhooks van station',
      ),
      'Manage Station Podcasts' => 
      array (
        0 => 'Beheer podcasts van station',
      ),
      'Imported locale: %s' => 
      array (
        0 => 'Taal geïmporteerd: %s',
      ),
      'The account associated with e-mail address "%s" has been set as an administrator' => 
      array (
        0 => 'Het account dat gekoppeld is aan het e-mailadres "%s" is ingesteld als administrator',
      ),
      'Account not found.' => 
      array (
        0 => 'Account niet gevonden.',
      ),
      'Fixtures loaded.' => 
      array (
        0 => 'Fixtures geladen.',
      ),
      'Configuration successfully written.' => 
      array (
        0 => 'Configuratie succesvol opgeslagen.',
      ),
      'AzuraCast Backup' => 
      array (
        0 => 'AzuraCast back-up',
      ),
      'Please wait while a backup is generated...' => 
      array (
        0 => 'Een ogenblik geduld, een back-up wordt gegenereerd...',
      ),
      'Creating temporary directories...' => 
      array (
        0 => 'Tijdelijke mappen maken...',
      ),
      'Directory "%s" was not created' => 
      array (
        0 => 'Map "%s" is niet aangemaakt',
      ),
      'Backing up MariaDB...' => 
      array (
        0 => 'MariaDB back-uppen...',
      ),
      'Creating backup archive...' => 
      array (
        0 => 'Backup archief aanmaken...',
      ),
      'Cleaning up temporary files...' => 
      array (
        0 => 'Tijdelijke bestanden opruimen...',
      ),
      'Backup complete in %.2f seconds.' => 
      array (
        0 => 'Back-up voltooid in %.2f seconden.',
      ),
      'Backup path %s not found!' => 
      array (
        0 => 'Back-up pad %s niet gevonden!',
      ),
      'AzuraCast Setup' => 
      array (
        0 => 'AzuraCast setup',
      ),
      'Welcome to AzuraCast. Please wait while some key dependencies of AzuraCast are set up...' => 
      array (
        0 => 'Welkom bij AzuraCast. Een ogenblik geduld terwijl enkele code afhankelijkheden worden ingesteld...',
      ),
      'Installing Data Fixtures' => 
      array (
        0 => 'Data Fixtures installeren',
      ),
      'Refreshing All Stations' => 
      array (
        0 => 'Alle stations verversen',
      ),
      'AzuraCast is now updated to the latest version!' => 
      array (
        0 => 'AzuraCast is bijgewerkt naar de laatste versie!',
      ),
      'AzuraCast installation complete!' => 
      array (
        0 => 'De installatie van AzuraCast is voltooid!',
      ),
      'Visit %s to complete setup.' => 
      array (
        0 => 'Bezoek %s om de setup te voltooien.',
      ),
      'Initialize AzuraCast' => 
      array (
        0 => 'Initialiseer AzuraCast',
      ),
      'Initializing essential settings...' => 
      array (
        0 => 'Essentiële instellingen initialiseren...',
      ),
      'Environment: %s' => 
      array (
        0 => 'Omgeving: %s',
      ),
      'Installation Method: %s' => 
      array (
        0 => 'Installatiemethode: %s',
      ),
      'Running Database Migrations' => 
      array (
        0 => 'Database migraties worden uitgevoerd',
      ),
      'Generating Database Proxy Classes' => 
      array (
        0 => 'Genereren van database proxy-klassen',
      ),
      'Reload System Data' => 
      array (
        0 => 'Herlaad systeemgegevens',
      ),
      'AzuraCast is now initialized.' => 
      array (
        0 => 'AzuraCast is nu geïnitialiseerd.',
      ),
      'AzuraCast Settings' => 
      array (
        0 => 'AzuraCast instellingen',
      ),
      'Setting Key' => 
      array (
        0 => 'Instellingssleutel',
      ),
      'Setting Value' => 
      array (
        0 => 'Instellingswaarde',
      ),
      'The port %s is in use by another station.' => 
      array (
        0 => 'De poort %s is in gebruik door een ander station.',
      ),
      'This value is already used.' => 
      array (
        0 => 'Deze waarde wordt al gebruikt.',
      ),
      'Storage location %s could not be validated: %s' => 
      array (
        0 => 'Opslaglocatie %s kon niet worden gevalideerd: %s',
      ),
      'Storage location %s already exists.' => 
      array (
        0 => 'Opslaglocatie %s bestaat al.',
      ),
      'Search engine crawlers are not permitted to use this feature.' => 
      array (
        0 => 'Zoekmachine crawlers zijn niet toegestaan om deze functie te gebruiken.',
      ),
      'This station does not accept requests currently.' => 
      array (
        0 => 'Dit station accepteert momenteel geen verzoeken.',
      ),
      'The song ID you specified could not be found in the station.' => 
      array (
        0 => 'Het opgeven nummer ID voor dit station kan niet worden gevonden.',
      ),
      'The song ID you specified cannot be requested for this station.' => 
      array (
        0 => 'Het opgeven nummer ID voor dit station kan niet worden aangevraagd.',
      ),
      'You have submitted a request too recently! Please wait before submitting another one.' => 
      array (
        0 => 'U heeft kortgeleden al een verzoekplaat ingediend! Wacht aub 15 minuten voordat u een volgende indient.',
      ),
      'Duplicate request: this song was already requested and will play soon.' => 
      array (
        0 => 'Dit nummer staat al in de wachtrij, en zal binnen 15 minuten worden afgespeeld.',
      ),
      'This song or artist has been played too recently. Wait a while before requesting it again.' => 
      array (
        0 => 'Dit nummer of deze artiest werd onlangs afgespeeld. Wacht even voordat u het opnieuw aanvraagt.',
      ),
      'Changes saved successfully.' => 
      array (
        0 => 'Wijzigingen succesvol opgeslagen.',
      ),
      'Record created successfully.' => 
      array (
        0 => 'Veld is met succes aangemaakt.',
      ),
      'Record updated successfully.' => 
      array (
        0 => 'Veld is met succes gewijzigd.',
      ),
      'Record deleted successfully.' => 
      array (
        0 => 'Record succesvol verwijderd.',
      ),
      'Record not found' => 
      array (
        0 => 'Record niet gevonden',
      ),
      'The uploaded file exceeds the upload_max_filesize directive in php.ini.' => 
      array (
        0 => 'Het geüploade bestand overschrijdt de upload_max_filesize waarde uit php.ini.',
      ),
      'The uploaded file exceeds the MAX_FILE_SIZE directive from the HTML form.' => 
      array (
        0 => 'Het geüploade bestand is groter dan de MAX_FILE_SIZE richtlijn uit het HTML-formulier.',
      ),
      'The uploaded file was only partially uploaded.' => 
      array (
        0 => 'Het geüploade bestand is slechts gedeeltelijk geüpload.',
      ),
      'No file was uploaded.' => 
      array (
        0 => 'Er is geen bestand geüpload.',
      ),
      'No temporary directory is available.' => 
      array (
        0 => 'Geen tijdelijke map beschikbaar.',
      ),
      'Could not write to filesystem.' => 
      array (
        0 => 'Kan niet naar het bestandssysteem schrijven.',
      ),
      'Upload halted by a PHP extension.' => 
      array (
        0 => 'Upload gestopt door een PHP-extensie.',
      ),
      'Unspecified error.' => 
      array (
        0 => 'Onbekende fout.',
      ),
      'Playlist: %s' => 
      array (
        0 => '
Afspeellijst: %s',
      ),
      'Streamer: %s' => 
      array (
        0 => 'Streamer: %s',
      ),
      'Edit Liquidsoap Configuration' => 
      array (
        0 => 'Liquidsoap configuratie bewerken',
      ),
      'Streamers enabled!' => 
      array (
        0 => 'Streamers ingeschakeld!',
      ),
      'You can now set up streamer (DJ) accounts.' => 
      array (
        0 => 'Je kunt nu streamer (DJ) accounts toevoegen.',
      ),
      'Record not found.' => 
      array (
        0 => 'Record niet gevonden.',
      ),
      'Profile' => 
      array (
        0 => 'Profiel',
      ),
      'Automated assignment complete!' => 
      array (
        0 => 'Automatische toewijzing voltooid!',
      ),
      'Automated assignment error' => 
      array (
        0 => 'Fout bij automatisch toewijzen',
      ),
      'Statistics Overview' => 
      array (
        0 => 'Statistieken overzicht',
      ),
      'SoundExchange Report' => 
      array (
        0 => 'SoundExchange verslag',
      ),
      'No episodes found.' => 
      array (
        0 => 'Geen afleveringen gevonden.',
      ),
      'Episode not found.' => 
      array (
        0 => 'Aflevering niet gevonden.',
      ),
      'Logged in successfully.' => 
      array (
        0 => 'U bent succesvol ingelogd.',
      ),
      'Login unsuccessful' => 
      array (
        0 => 'Fout tijdens inloggen',
      ),
      'Your credentials could not be verified.' => 
      array (
        0 => 'Je logingegevens zijn incorrect.',
      ),
      'Too many forgot password attempts' => 
      array (
        0 => 'Te veel wachtwoord vergeten pogingen',
      ),
      'You have attempted to reset your password too many times. Please wait 30 seconds and try again.' => 
      array (
        0 => 'U heeft te vaak geprobeerd uw wachtwoord opnieuw in te stellen. Wacht 30 seconden en probeer het opnieuw.',
      ),
      'Account Recovery Link' => 
      array (
        0 => 'Account herstellink',
      ),
      'Account recovery e-mail sent.' => 
      array (
        0 => 'E-mailbericht verzonden om account te herstellen.',
      ),
      'If the e-mail address you provided is in the system, check your inbox for a password reset message.' => 
      array (
        0 => 'Als het e-mailadres dat u heeft opgegeven in het systeem staat, check dan uw inbox voor een wachtwoord reset bericht.',
      ),
      'Invalid token specified.' => 
      array (
        0 => 'Ongeldige token gespecificeerd.',
      ),
      'Logged in using account recovery token' => 
      array (
        0 => 'Ingelogd met behulp van het account-herstel-token',
      ),
      'Your password has been updated.' => 
      array (
        0 => 'Uw wachtwoord is bijgewerkt.',
      ),
      'Too many login attempts' => 
      array (
        0 => 'Te veel inlogpogingen',
      ),
      'You have attempted to log in too many times. Please wait 30 seconds and try again.' => 
      array (
        0 => 'Je hebt te vaak geprobeerd om in te loggen. Gelieve 30 seconden te wachten en probeer opnieuw.',
      ),
      'Complete the setup process to get started.' => 
      array (
        0 => 'Voltooi het installatieproces om aan de slag te gaan.',
      ),
      'API Key not found.' => 
      array (
        0 => 'API sleutel niet gevonden.',
      ),
      'API Key updated.' => 
      array (
        0 => 'API-sleutel bijgewerkt.',
      ),
      'Edit API Key' => 
      array (
        0 => 'Wijzig API-sleutel',
      ),
      'Add API Key' => 
      array (
        0 => 'API-sleutel toevoegen',
      ),
      'API Key deleted.' => 
      array (
        0 => 'API-sleutel verwijderd.',
      ),
      'Profile saved!' => 
      array (
        0 => 'Profiel opgeslagen!',
      ),
      'The token you supplied is invalid. Please try again.' => 
      array (
        0 => 'De token die u hebt opgegeven is ongeldig. Probeer het opnieuw.',
      ),
      'Two-factor authentication enabled.' => 
      array (
        0 => 'Tweestapsverificatie ingeschakeld.',
      ),
      'Two-factor authentication disabled.' => 
      array (
        0 => 'Tweestapsverificatie uitgeschakeld.',
      ),
      'Set Up AzuraCast' => 
      array (
        0 => '',
      ),
      'Setup has already been completed!' => 
      array (
        0 => 'De installatie is al voltooid!',
      ),
      'Dashboard' => 
      array (
        0 => 'Dashboard',
      ),
      'AzuraCast User' => 
      array (
        0 => 'AzuraCast gebruiker',
      ),
      'This station does not support on-demand streaming.' => 
      array (
        0 => 'Dit station ondersteunt geen on-demand streaming.',
      ),
      'Playlist successfully imported; %d of %d files were successfully matched.' => 
      array (
        0 => 'Afspeellijst succesvol geïmporteerd; %d van de %d bestanden zijn succesvol gematcht.',
      ),
      'This playlist is not a sequential playlist.' => 
      array (
        0 => 'Deze afspeellijst is geen opeenvolgende afspeellijst.',
      ),
      'Playlist reshuffled.' => 
      array (
        0 => 'Afspeellijst geshuffeld.',
      ),
      'Playlist not found.' => 
      array (
        0 => 'Afspeellijst niet gevonden.',
      ),
      'Playlist enabled.' => 
      array (
        0 => 'Afspeellijst ingeschakeld.',
      ),
      'Playlist disabled.' => 
      array (
        0 => 'Afspeellijst uitgeschakeld.',
      ),
      'This station is out of available storage space.' => 
      array (
        0 => 'Dit station gebruikt teveel opslagruimte.',
      ),
      'No directory specified' => 
      array (
        0 => 'Geen map opgegeven',
      ),
      'File not specified.' => 
      array (
        0 => 'Bestand niet gespecificeerd.',
      ),
      'New path not specified.' => 
      array (
        0 => 'Nieuw pad niet gespecificeerd.',
      ),
      'File Not Processed: %s' => 
      array (
        0 => 'Bestand niet verwerkt: %s',
      ),
      'File Processing' => 
      array (
        0 => 'Bestand verwerken',
      ),
      'Station restarted.' => 
      array (
        0 => 'Station is opnieuw gestart.',
      ),
      'Frontend stopped.' => 
      array (
        0 => 'Frontend gestopt.',
      ),
      'Frontend started.' => 
      array (
        0 => 'Frontend gestart.',
      ),
      'Frontend restarted.' => 
      array (
        0 => 'Frontend is opnieuw gestart.',
      ),
      'Song skipped.' => 
      array (
        0 => 'Nummer overgeslagen.',
      ),
      'Streamer disconnected.' => 
      array (
        0 => 'Streamer ontkoppeld.',
      ),
      'Backend stopped.' => 
      array (
        0 => 'Backend gestopt.',
      ),
      'Backend started.' => 
      array (
        0 => 'Backend gestart.',
      ),
      'Backend restarted.' => 
      array (
        0 => 'Backend is opnieuw gestart.',
      ),
      'Web hook not found.' => 
      array (
        0 => 'Web hook niet gevonden.',
      ),
      'Web hook enabled.' => 
      array (
        0 => 'Webhook ingeschakeld.',
      ),
      'Web hook disabled.' => 
      array (
        0 => 'Web hook uitgeschakeld.',
      ),
      'Podcast not found!' => 
      array (
        0 => 'Podcast niet gevonden!',
      ),
      'No recording available.' => 
      array (
        0 => 'Geen opname beschikbaar.',
      ),
      'All Stations' => 
      array (
        0 => 'Alle stations',
      ),
      'You cannot remove yourself.' => 
      array (
        0 => 'Je kunt jezelf niet verwijderen.',
      ),
      'Create a new storage location based on the base directory.' => 
      array (
        0 => 'Maak een nieuwe opslaglocatie gebaseerd op de basismap.',
      ),
      'Liquidsoap Log' => 
      array (
        0 => 'Liquidsoap log',
      ),
      'Liquidsoap Configuration' => 
      array (
        0 => 'Liquidsoap configuratie',
      ),
      'Icecast Access Log' => 
      array (
        0 => 'Icecast toegangslogboek',
      ),
      'Icecast Error Log' => 
      array (
        0 => 'Icecast foutenlogboek',
      ),
      'Icecast Configuration' => 
      array (
        0 => 'Icecast configuratie',
      ),
      'SHOUTcast Log' => 
      array (
        0 => 'SHOUTcast log',
      ),
      'SHOUTcast Configuration' => 
      array (
        0 => 'SHOUTcast configuratie',
      ),
      'User updated.' => 
      array (
        0 => 'Gebruiker bijgewerkt.',
      ),
      'User added.' => 
      array (
        0 => 'Gebruiker toegevoegd.',
      ),
      'Another user already exists with this e-mail address. Please update the e-mail address.' => 
      array (
        0 => 'Er bestaat al een andere gebruiker met dit e-mailadres. Gelieve het e-mailadres aan te passen.',
      ),
      'Edit User' => 
      array (
        0 => 'Wijzig gebruiker',
      ),
      'Add User' => 
      array (
        0 => 'Gebruiker toevoegen',
      ),
      'You cannot delete your own account.' => 
      array (
        0 => 'U kunt uw eigen account niet verwijderen.',
      ),
      'User deleted.' => 
      array (
        0 => 'Gebruiker verwijderd.',
      ),
      'User not found.' => 
      array (
        0 => 'Gebruiker niet gevonden.',
      ),
      'AzuraCast Application Log' => 
      array (
        0 => 'AzuraCast applicatielog',
      ),
      'Nginx Access Log' => 
      array (
        0 => 'Nginx toegangslogboek',
      ),
      'Nginx Error Log' => 
      array (
        0 => 'Nginx foutlog',
      ),
      'PHP Application Log' => 
      array (
        0 => 'PHP applicatielog',
      ),
      'Supervisord Log' => 
      array (
        0 => 'Supervisord log',
      ),
      'Album Artist Sort Order' => 
      array (
        0 => 'Album Artiest Sorteervolgorde',
      ),
      'Album Sort Order' => 
      array (
        0 => 'Sorteervolgorde Album',
      ),
      'Band' => 
      array (
        0 => 'Band',
      ),
      'Bpm' => 
      array (
        0 => 'Bpm',
      ),
      'Comment' => 
      array (
        0 => 'Reactie',
      ),
      'Commercial Information' => 
      array (
        0 => 'Commerciële Informatie',
      ),
      'Composer' => 
      array (
        0 => 'Artiest',
      ),
      'Composer Sort Order' => 
      array (
        0 => 'Artiest sorteer volgorde',
      ),
      'Conductor' => 
      array (
        0 => 'Leider',
      ),
      'Content Group Description' => 
      array (
        0 => 'Groepsbeschrijving uitleg',
      ),
      'Copyright' => 
      array (
        0 => 'Auteursrecht',
      ),
      'Copyright Message' => 
      array (
        0 => 'Auteursrecht bericht',
      ),
      'Encoded By' => 
      array (
        0 => 'Gecodeerd door',
      ),
      'Encoder Settings' => 
      array (
        0 => 'Encoder instellingen',
      ),
      'Encoding Time' => 
      array (
        0 => 'Coderingstijd',
      ),
      'File Owner' => 
      array (
        0 => 'Bestands eigenaar',
      ),
      'File Type' => 
      array (
        0 => 'Bestandstype',
      ),
      'Initial Key' => 
      array (
        0 => 'Initiële sleutel',
      ),
      'Internet Radio Station Name' => 
      array (
        0 => 'Naam internetradio station',
      ),
      'Internet Radio Station Owner' => 
      array (
        0 => 'Eigenaar van internetradio station',
      ),
      'Involved People List' => 
      array (
        0 => 'Geïntegreerde lijst personen',
      ),
      'Linked Information' => 
      array (
        0 => 'Gekoppelde informatie',
      ),
      'Lyricist' => 
      array (
        0 => 'Songtekst',
      ),
      'Media Type' => 
      array (
        0 => 'Media type',
      ),
      'Mood' => 
      array (
        0 => 'Stemming',
      ),
      'Music CD Identifier' => 
      array (
        0 => 'CD-id voor muziek',
      ),
      'Musician Credits List' => 
      array (
        0 => 'muzikanten krediet lijst',
      ),
      'Original Album' => 
      array (
        0 => 'Origineel album',
      ),
      'Original Artist' => 
      array (
        0 => 'Originele artiest',
      ),
      'Original Filename' => 
      array (
        0 => 'Officiële bestandsnaam',
      ),
      'Original Lyricist' => 
      array (
        0 => 'Originele tekstschrijver',
      ),
      'Original Release Time' => 
      array (
        0 => 'Originele Release Tijd',
      ),
      'Original Year' => 
      array (
        0 => 'Origineel jaar',
      ),
      'Part Of A Compilation' => 
      array (
        0 => 'Deel van een compilatie',
      ),
      'Part Of A Set' => 
      array (
        0 => 'Deel van een set',
      ),
      'Performer Sort Order' => 
      array (
        0 => 'Artiest sorteer volgorde',
      ),
      'Playlist Delay' => 
      array (
        0 => 'Afspeellijst vertraging',
      ),
      'Produced Notice' => 
      array (
        0 => 'Geproduceerde melding',
      ),
      'Publisher' => 
      array (
        0 => 'Uitgever',
      ),
      'Recording Time' => 
      array (
        0 => 'Opname tijd',
      ),
      'Release Time' => 
      array (
        0 => 'Releasedatum',
      ),
      'Remixer' => 
      array (
        0 => 'Remixer',
      ),
      'Set Subtitle' => 
      array (
        0 => 'Ondertiteling instellen',
      ),
      'Subtitle' => 
      array (
        0 => 'Subtitel',
      ),
      'Tagging Time' => 
      array (
        0 => 'Tagging tijd',
      ),
      'Terms Of Use' => 
      array (
        0 => 'Gebruiksvoorwaarden',
      ),
      'Title Sort Order' => 
      array (
        0 => 'Titel sorteervolgorde',
      ),
      'Track Number' => 
      array (
        0 => 'Track Nummer',
      ),
      'Unsynchronised Lyric' => 
      array (
        0 => 'Niet-gesynchroniseerde songtekst',
      ),
      'URL Artist' => 
      array (
        0 => 'URL artiest',
      ),
      'URL File' => 
      array (
        0 => 'URL bestand',
      ),
      'URL Payment' => 
      array (
        0 => 'URL betaling',
      ),
      'URL Publisher' => 
      array (
        0 => 'URL uitgever',
      ),
      'URL Source' => 
      array (
        0 => 'URL bron',
      ),
      'URL Station' => 
      array (
        0 => 'URL station',
      ),
      'URL User' => 
      array (
        0 => 'URL gebruiker',
      ),
      'Year' => 
      array (
        0 => 'Jaar',
      ),
      'Run Synchronized Task' => 
      array (
        0 => 'Gesynchroniseerde taak uitvoeren',
      ),
      'Debug Output' => 
      array (
        0 => 'Debug-uitvoer',
      ),
      'Configure Backups' => 
      array (
        0 => 'Back-ups configureren',
      ),
      'Run Manual Backup' => 
      array (
        0 => 'Handmatige back-up uitvoeren',
      ),
      'Backup deleted.' => 
      array (
        0 => 'Back-up verwijderd.',
      ),
      'Backup not found.' => 
      array (
        0 => 'Back-up niet gevonden.',
      ),
      'Are you sure?' => 
      array (
        0 => 'Weet je het zeker?',
      ),
      'Enter a password to continue.' => 
      array (
        0 => 'Voer een wachtwoord in om door te gaan.',
      ),
      'No problems detected.' => 
      array (
        0 => 'Geen problemen gedetecteerd.',
      ),
      'Generate the translation locale file.' => 
      array (
        0 => 'Genereer het vertalingsbestand.',
      ),
      'Convert translated locale files into PHP arrays.' => 
      array (
        0 => 'Converteer vertalingsbestanden naar PHP arrays.',
      ),
      'Ensure key settings are initialized within AzuraCast.' => 
      array (
        0 => 'Zorg ervoor dat de belangrijkste instellingen kunnen worden geïnitialiseerd binnen AzuraCast.',
      ),
      'Migrate existing configuration to new INI format if any exists.' => 
      array (
        0 => 'Bestaande configuratie migreren naar nieuw INI-formaat indien er een bestaat.',
      ),
      'Install fixtures for demo / local development.' => 
      array (
        0 => 'Installeer fixtures voor demo / lokale ontwikkeling.',
      ),
      'Run all general AzuraCast setup steps.' => 
      array (
        0 => 'Voer alle algemene AzuraCast setup stappen uit.',
      ),
      'Run one or more scheduled synchronization tasks.' => 
      array (
        0 => 'Voer een of meer geplande synchronisatie taken uit.',
      ),
      'Process the message queue.' => 
      array (
        0 => 'Verwerk de berichtwachtrij.',
      ),
      'Clear the contents of the message queue.' => 
      array (
        0 => 'Wis de inhoud van berichten in de wachtrij.',
      ),
      'List all settings in the AzuraCast settings database.' => 
      array (
        0 => 'Lijst van alle instellingen in de AzuraCast instellingen database.',
      ),
      'Back up the AzuraCast database and statistics (and optionally media).' => 
      array (
        0 => 'Back-up de AzuraCast database en statistieken (en optionele media).',
      ),
      'System Maintenance' => 
      array (
        0 => 'Systeem Onderhoud',
      ),
      'System Logs' => 
      array (
        0 => 'Systeemlogs',
      ),
      'System Debugger' => 
      array (
        0 => 'Systeem Debugger',
      ),
      'Users' => 
      array (
        0 => 'Gebruikers',
      ),
      'User Accounts' => 
      array (
        0 => 'Gebruikers account',
      ),
      'API Keys' => 
      array (
        0 => 'API-Sleutels',
      ),
      'Connected AzuraRelays' => 
      array (
        0 => 'Verbonden AzuraRelays',
      ),
      'Install SHOUTcast' => 
      array (
        0 => 'Installeer SHOUTcast',
      ),
      'Start Station' => 
      array (
        0 => 'Start station',
      ),
      'Ready to start broadcasting? Click to start your station.' => 
      array (
        0 => 'Klaar om te beginnen met uitzenden? Klik om uw station te starten.',
      ),
      'Restart broadcasting? This will disconnect any current listeners.' => 
      array (
        0 => 'Uitzenden opnieuw starten? Dit zal alle huidige luisteraars ontkoppelen.',
      ),
      'Restart to Apply Changes' => 
      array (
        0 => 'Herstart om wijzigingen toe te passen',
      ),
      'Click to restart your station and apply configuration changes.' => 
      array (
        0 => 'Klik om uw station te herstarten en de configuratie wijzigingen toe te passen.',
      ),
      'Podcasts (Beta)' => 
      array (
        0 => 'Podcasts (Beta)',
      ),
      'Reports' => 
      array (
        0 => 'Rapportages',
      ),
      'Duplicate Songs' => 
      array (
        0 => 'Dupliceer nummers',
      ),
      'Unprocessable Files' => 
      array (
        0 => 'Niet verwerkte bestanden',
      ),
      'SoundExchange Royalties' => 
      array (
        0 => 'SoundExchange royalty\'s',
      ),
      'Utilities' => 
      array (
        0 => 'Hulpprogramma’s',
      ),
      'Automated Assignment' => 
      array (
        0 => 'Automatische toewijzing',
      ),
      'Log Viewer' => 
      array (
        0 => 'Log weergave',
      ),
      'Restart Broadcasting' => 
      array (
        0 => 'Uitzending herstarten',
      ),
      'Enable Automated Assignment' => 
      array (
        0 => 'Automatische toewijzing inschakelen',
      ),
      'Allow the system to periodically automatically assign songs to playlists based on their performance. This process will run in the background, and will only run if this option is set to "Enabled" and at least one playlist is set to "Include in Automated Assignment".' => 
      array (
        0 => 'Laat het systeem periodiek nummers toewijzen aan afspeellijsten op basis van hun prestaties. Dit proces zal uitgevoerd worden op de achtergrond, en kan alleen worden uitgevoerd als deze optie is ingeschakeld en als tenminste één station \'automatische toewijzing\' heeft ingeschakeld.',
      ),
      'Days Between Automated Assignments' => 
      array (
        0 => 'Dagen tussen geautomatiseerde toewijzingen',
      ),
      'Based on this setting, the system will automatically reassign songs every (this) days using data from the previous (this) days.' => 
      array (
        0 => 'Op basis van deze instelling zal het systeem elke (dit) dag(en) nummers automatisch opnieuw toewijzen van de vorige (dit) aantal dagen.',
      ),
      '%d days' => 
      array (
        0 => '%d dagen',
      ),
      'Use Browser Default' => 
      array (
        0 => 'Gebruik standaard browser',
      ),
      'Reset Password' => 
      array (
        0 => 'Wachtwoord Resetten',
      ),
      'Leave these fields blank to continue using your current password.' => 
      array (
        0 => 'Laat deze velden leeg om door te gaan met het gebruik van uw huidige wachtwoord.',
      ),
      'Current Password' => 
      array (
        0 => 'Huidig wachtwoord',
      ),
      'Confirm New Password' => 
      array (
        0 => 'Bevestig nieuw wachtwoord',
      ),
      'Customization' => 
      array (
        0 => 'Aanpassen',
      ),
      'Site Theme' => 
      array (
        0 => 'Website Thema',
      ),
      'Describe the use-case for this API key for future reference.' => 
      array (
        0 => 'Beschrijf de gebruikscase voor deze API-sleutel voor toekomstige referentie.',
      ),
      'Storage Location' => 
      array (
        0 => 'Opslaglocatie',
      ),
      'Backup Filename' => 
      array (
        0 => 'Backup bestandsnaam',
      ),
      'This will be the file name for your backup, include the file type (.zip or .rar) you wish to use.' => 
      array (
        0 => 'Dit zal de bestandsnaam van uw back-up zijn, inclusief het bestandstype (.zip of .rar) dat u wilt gebruiken.',
      ),
      'Exclude Media from Backup' => 
      array (
        0 => 'Media uitsluiten van back-up',
      ),
      'This will produce a significantly smaller backup, but you should make sure to back up your media elsewhere. Note that only locally stored media will be backed up.' => 
      array (
        0 => 'Dit levert een aanzienlijk kleinere back-up op, maar u moet ervoor zorgen dat u ergens anders een back-up van uw media maakt. Merk op dat er alleen een back-up wordt gemaakt van lokaal opgeslagen media.',
      ),
      'Yes' => 
      array (
        0 => 'Ja',
      ),
      'No' => 
      array (
        0 => 'Nee',
      ),
      'Run Automatic Nightly Backups' => 
      array (
        0 => 'Automatisch nachtelijks back-ups uitvoeren',
      ),
      'Enable to have AzuraCast automatically run nightly backups at the time specified.' => 
      array (
        0 => 'Inschakelen om AzuraCast automatisch nachtelijke back-ups te laten uitvoeren op het opgegeven tijdstip.',
      ),
      'Scheduled Backup Time' => 
      array (
        0 => 'Geplande back-up tijd',
      ),
      'The time (in UTC) to run the automated backup, if enabled.' => 
      array (
        0 => 'De tijd (in UTC) om de geautomatiseerde back-up uit te voeren, indien ingeschakeld.',
      ),
      'Exclude Media from Backups' => 
      array (
        0 => 'Media uitsluiten van back-ups',
      ),
      'Excluding media from automated backups will save space, but you should make sure to back up your media elsewhere. Note that only locally stored media will be backed up.' => 
      array (
        0 => 'Door media uit te sluiten van automatische back-ups bespaart u ruimte, maar u moet ervoor zorgen dat u ergens anders een back-up van uw media maakt. Merk op dat er alleen een back-up wordt gemaakt van lokaal opgeslagen media.',
      ),
      'Number of Backup Copies to Keep' => 
      array (
        0 => 'Aantal te bewaren back-up kopieën',
      ),
      'Copies older than the specified number of days will automatically be deleted. Set to zero to disable automatic deletion.' => 
      array (
        0 => 'Kopies ouder dan het opgegeven aantal dagen zullen automatisch worden verwijderd. Zet op nul om automatische verwijdering uit te schakelen.',
      ),
      'Attempt to Automatically Retrieve ISRC When Missing' => 
      array (
        0 => '',
      ),
      'If enabled, AzuraCast will connect to the MusicBrainz database to attempt to find an ISRC for any files where one is missing. Disabling this may improve performance.' => 
      array (
        0 => '',
      ),
      'Roles' => 
      array (
        0 => 'Rollen',
      ),
      'Code from Authenticator App' => 
      array (
        0 => 'Code van Authenticator App',
      ),
      'Enter the current code provided by your authenticator app to verify that it\'s working correctly.' => 
      array (
        0 => 'Voer de huidige code in die door uw authenticator app is opgegeven om te controleren of alles correct werkt.',
      ),
      'Verify Authenticator' => 
      array (
        0 => 'Verifieer Authenticator',
      ),
      'Any time the currently playing song changes' => 
      array (
        0 => 'Elke keer dat het huidige nummer verandert',
      ),
      'Any time the listener count increases' => 
      array (
        0 => 'Elke keer dat de luisteraar telt stijgt',
      ),
      'Any time the listener count decreases' => 
      array (
        0 => 'Elke keer dat het aantal luisteraars afneemt',
      ),
      'Any time a live streamer/DJ connects to the stream' => 
      array (
        0 => 'Elke keer dat een live streamer/DJ verbinding maakt met de stream',
      ),
      'Any time a live streamer/DJ disconnects from the stream' => 
      array (
        0 => 'Elke keer dat een live streamer/DJ verbinding verbreekt van de stream',
      ),
      'When the station broadcast goes offline.' => 
      array (
        0 => '',
      ),
      'When the station broadcast comes online.' => 
      array (
        0 => '',
      ),
      'Generic Web Hook' => 
      array (
        0 => 'Algemene Webhook',
      ),
      'Automatically send a message to any URL when your station data changes.' => 
      array (
        0 => 'Stuur automatisch een bericht naar elke URL wanneer uw station data verandert.',
      ),
      'Send E-mail' => 
      array (
        0 => 'E-mail verzenden',
      ),
      'Send an e-mail to specified address(es).' => 
      array (
        0 => 'Stuur een e-mail naar de opgegeven adres(sen).',
      ),
      'TuneIn AIR' => 
      array (
        0 => 'TuneIn AIR',
      ),
      'Send song metadata changes to TuneIn.' => 
      array (
        0 => 'Stuur metadata van het nummer naar TuneIn.',
      ),
      'Discord Webhook' => 
      array (
        0 => 'Discord Webhook',
      ),
      'Automatically send a customized message to your Discord server.' => 
      array (
        0 => 'Stuur automatisch een aangepast bericht naar je Discord server.',
      ),
      'Telegram Chat Message' => 
      array (
        0 => 'Telegram Chat Bericht',
      ),
      'Use the Telegram Bot API to send a message to a channel.' => 
      array (
        0 => 'Gebruik de Telegram Bot API om een bericht naar een kanaal te sturen.',
      ),
      'Twitter Post' => 
      array (
        0 => 'Twitter post',
      ),
      'Automatically send a tweet.' => 
      array (
        0 => 'Automatisch een tweet verzenden.',
      ),
      'Google Analytics Integration' => 
      array (
        0 => 'Google Analytics integratie',
      ),
      'Send stream listener details to Google Analytics.' => 
      array (
        0 => '',
      ),
      'Matomo Analytics Integration' => 
      array (
        0 => '',
      ),
      'Send stream listener details to Matomo Analytics.' => 
      array (
        0 => '',
      ),
      'Account Recovery' => 
      array (
        0 => 'Accountherstel',
      ),
      'An account recovery link has been requested for your account on "%s".' => 
      array (
        0 => 'Er is een link om uw account te herstellen aangevraagd op "%s".',
      ),
      'Click the link below to log in to your account.' => 
      array (
        0 => 'Klik op de link hieronder om in te loggen op uw account.',
      ),
      'Skip to main content' => 
      array (
        0 => 'Ga naar hoofdinhoud',
      ),
      'Toggle Sidebar' => 
      array (
        0 => 'Sidebar aan/uit',
      ),
      'Toggle Menu' => 
      array (
        0 => 'Menu aan/uit',
      ),
      'System Administration' => 
      array (
        0 => 'Systeembeheer',
      ),
      'Switch Theme' => 
      array (
        0 => 'Thema veranderen',
      ),
      'My API Keys' => 
      array (
        0 => 'Mijn API sleutels',
      ),
      'Help' => 
      array (
        0 => 'Help',
      ),
      'End Session' => 
      array (
        0 => 'Sessie beëindigen',
      ),
      'Sign Out' => 
      array (
        0 => 'Uitloggen',
      ),
      'Powered by %s' => 
      array (
        0 => 'Mogelijk gemaakt door %s',
      ),
      'Like our software? <a href="%s" target="_blank">Donate to support AzuraCast!</a>' => 
      array (
        0 => 'Vind je onze software leuk? <a href="%s" target="_blank">Doneer om AzuraCast te ondersteunen!</a>',
      ),
      'Errors were encountered when trying to save changes:' => 
      array (
        0 => 'Er zijn fouten opgetreden bij het opslaan van wijzigingen:',
      ),
      'General' => 
      array (
        0 => 'Algemeen',
      ),
      'Details' => 
      array (
        0 => 'Beschrijving',
      ),
      'Server Status' => 
      array (
        0 => 'Server status',
      ),
      'CPU Load' => 
      array (
        0 => 'CPU belasting',
      ),
      'Current' => 
      array (
        0 => 'Huidig',
      ),
      '15-Minute Average' => 
      array (
        0 => '15-Minuten Gemiddelde',
      ),
      'Memory' => 
      array (
        0 => 'Geheugen',
      ),
      '%s of %s Used' => 
      array (
        0 => '%s van %s gebruikt',
      ),
      'Disk Space' => 
      array (
        0 => 'Schijfruimte',
      ),
      'Synchronization Tasks' => 
      array (
        0 => 'Synchronisatie taken',
      ),
      'Last run: %s' => 
      array (
        0 => 'Laatst uitgevoerd: %s',
      ),
      'Run Task' => 
      array (
        0 => 'Taak uitvoeren',
      ),
      'API Key' => 
      array (
        0 => 'API code',
      ),
      'Owner' => 
      array (
        0 => 'Eigenaar',
      ),
      'Revoke' => 
      array (
        0 => 'Intrekken',
      ),
      'Clear Cache' => 
      array (
        0 => 'Cache legen',
      ),
      'Clearing the application cache may log you out of your session.' => 
      array (
        0 => 'Als u de applicatiecache wist, wordt u mogelijk uit uw sessie afgemeld.',
      ),
      'Clear All Message Queues' => 
      array (
        0 => 'Alle berichtenwachtrijen leegmaken',
      ),
      'This will clear any pending unprocessed messages in all message queues.' => 
      array (
        0 => 'Dit verwijdert alle wachtende en onverwerkte berichten in alle berichtenwachtrijen.',
      ),
      'Message Queues' => 
      array (
        0 => 'Berichten wachtrijen',
      ),
      '%d queued messages' => 
      array (
        0 => '%d berichten in wachtrij',
      ),
      'Station-Specific Debugging' => 
      array (
        0 => 'Station-Specifieke Debugging',
      ),
      'Rebuild AutoDJ Queue' => 
      array (
        0 => 'AutoDJ wachtrij opnieuw opbouwen',
      ),
      'Run Test' => 
      array (
        0 => 'Test uitvoeren',
      ),
      'Send Liquidsoap Telnet Command' => 
      array (
        0 => 'Stuur Liquidsoap Telnet commando',
      ),
      'Command' => 
      array (
        0 => 'Commando',
      ),
      'Execute Command' => 
      array (
        0 => 'Commando uitvoeren',
      ),
      'Run Synchronization Task' => 
      array (
        0 => 'Synchronisatietaak uitvoeren',
      ),
      'Debug Home' => 
      array (
        0 => 'Debug Home',
      ),
      'The synchronization task is running in the background. The log below will update automatically.' => 
      array (
        0 => 'De synchronisatie-taak wordt in de achtergrond uitgevoerd. Het logboek hieronder zal automatisch worden bijgewerkt.',
      ),
      'Log In' => 
      array (
        0 => 'Inloggen',
      ),
      'Delete user "%s"?' => 
      array (
        0 => 'Gebruiker "%s" verwijderen?',
      ),
      '(You)' => 
      array (
        0 => '(U)',
      ),
      'Because you are running Docker, some system logs can only be accessed from a shell session on the host computer. You can run <code>%s</code> to access container logs from the terminal.' => 
      array (
        0 => 'Omdat je Docker gebruikt, kunnen sommige systeemlogs alleen worden geopend vanaf een shell sessie op de host computer. Je kunt <code>%s</code> uitvoeren om toegang te krijgen tot containerlogs uit de terminal.',
      ),
      'Logs by Station' => 
      array (
        0 => 'Logs per station',
      ),
      'Relay' => 
      array (
        0 => 'Relay',
      ),
      'Is Public' => 
      array (
        0 => 'Is openbaar',
      ),
      'First Connected' => 
      array (
        0 => 'Eerste verbinding',
      ),
      'Latest Update' => 
      array (
        0 => 'Laatste update',
      ),
      'Backups Home' => 
      array (
        0 => 'Back-ups home',
      ),
      'The backup process is running in the background. The log below will update automatically.' => 
      array (
        0 => 'Het back-upproces wordt op de achtergrond uitgevoerd. Het logboek hieronder wordt automatisch bijgewerkt.',
      ),
      'Automatic Backups' => 
      array (
        0 => 'Automatische back-ups',
      ),
      'Never run' => 
      array (
        0 => 'Nooit uitvoeren',
      ),
      'Configure' => 
      array (
        0 => 'Configureren',
      ),
      'Most Recent Backup Log' => 
      array (
        0 => 'Meest recente back-up log',
      ),
      'Restoring Backups' => 
      array (
        0 => 'Herstellen van back-ups',
      ),
      'To restore a backup from your host computer, run:' => 
      array (
        0 => 'Om een back-up te herstellen vanaf uw computer, voer het volgende commando uit:',
      ),
      'Note that restoring a backup will clear your existing database. Never restore backup files from untrusted users.' => 
      array (
        0 => 'Let op dat het herstellen van een back-up uw bestaande database zal wissen. Herstel nooit back-up bestanden van niet-vertrouwde gebruikers.',
      ),
      'Backup' => 
      array (
        0 => 'Back-up',
      ),
      'Last Modified' => 
      array (
        0 => 'Laatst gewijzigd',
      ),
      'Delete backup "%s"?' => 
      array (
        0 => 'Back-up "%s" verwijderen?',
      ),
      'Report Not Available' => 
      array (
        0 => 'Rapport niet beschikbaar',
      ),
      'This report is not available for this station, because the system administrator has chosen not to collect detailed IP-based listener information.' => 
      array (
        0 => 'Dit rapport is niet beschikbaar voor dit station, aangezien de systeembeheerder ervoor heeft gekozen geen IP-gegevens van luisteraars op te slaan.',
      ),
      'Station Broadcasting Disabled' => 
      array (
        0 => 'Station uitzending uitgeschakeld',
      ),
      'Your station is currently not enabled for broadcasting. You can still manage media, playlists, and other station settings. To re-enable broadcasting, <a href="%s">edit your station profile</a>.' => 
      array (
        0 => 'Uitzenden is momenteel uitgeschakeld voor dit station. U kunt nog steeds media, afspeellijsten en andere instellingen beheren. <a href="%s">bewerk het profiel van uw station</a> om uitzenden in te schakelen.',
      ),
      'Available Logs' => 
      array (
        0 => 'Beschikbare logs',
      ),
      'Station Time' => 
      array (
        0 => 'Station tijd',
      ),
      'Automated Playlist Assignment' => 
      array (
        0 => 'Automatische toewijzing van afspeellijsten',
      ),
      'Based on the previous performance of your station\'s songs, %s can automatically distribute songs evenly among your playlists, placing the highest performing songs in the highest-weighted playlists.' => 
      array (
        0 => 'Op basis van eerdere prestaties van de muziek in jouw station kan %s automatisch nummers gelijkmatig spreiden over je afspeellijsten door het plaatsen van goed presterende nummers in de afspeellijsten met een zwaarder gewicht.',
      ),
      'Once you have configured automated assignment, click the button below to run the automated assignment process. This process will not run at all unless you have selected "Enable" below.' => 
      array (
        0 => 'Wanneer je automatische toewijzing hebt ingesteld, klik dan op de knop hieronder om het proces te laten lopen. Dit proces zal niet werken zonder dat je "Ingeschakeld" hebt geselecteerd.',
      ),
      'Run Automated Assignment' => 
      array (
        0 => 'Automatische toewijzing uitvoeren',
      ),
      'Configure Automated Assignment' => 
      array (
        0 => 'Configureer automatische toewijzing',
      ),
      'Streamer accounts are currently disabled for this station. To enable streamer accounts, click the button below.' => 
      array (
        0 => 'Streamer accounts zijn momenteel uitgeschakeld voor dit station. Om streamer account in te schakelen klik je op de onderstaande knop.',
      ),
      'Enable Streaming' => 
      array (
        0 => 'Activeer streaming',
      ),
      'Two-Factor Authentication' => 
      array (
        0 => 'Tweestapsverificatie',
      ),
      'Two-factor authentication improves the security of your account by requiring a second one-time access code in addition to your password when you log in.' => 
      array (
        0 => 'Tweestapsverificatie verbetert de veiligheid van uw account door een tweede eenmalige toegangscode te eisen naast uw wachtwoord wanneer u inlogt.',
      ),
      'Disable Two-Factor' => 
      array (
        0 => 'Twee-factor uitschakelen',
      ),
      'Enable Two-Factor' => 
      array (
        0 => 'Twee-factor inschakelen',
      ),
      'Enable Two-Factor Authentication' => 
      array (
        0 => 'Tweestapsverificatie inschakelen',
      ),
      'Step 1: Scan QR Code' => 
      array (
        0 => 'Stap 1: Scan QR Code',
      ),
      'From your smartphone, scan the code to the right using an authentication app of your choice (FreeOTP, Authy, etc).' => 
      array (
        0 => 'Scan de code via een authenticatie app naar keuze (FreeOTP, Authy, etc) op uw mobiele telefoon.',
      ),
      'Step 2: Verify Generated Code' => 
      array (
        0 => 'Stap 2: Controleer gegenereerde code',
      ),
      'To verify that the code was set up correctly, enter the 6-digit code the app shows you.' => 
      array (
        0 => 'Om te controleren of de code correct is ingesteld, voert u de 6-cijferige code in die binnen de app wordt getoond.',
      ),
      'QR-Code' => 
      array (
        0 => 'QR-code',
      ),
      'No entries found.' => 
      array (
        0 => '',
      ),
      'View Details' => 
      array (
        0 => 'Details bekijken',
      ),
      'New Key Generated' => 
      array (
        0 => 'Nieuwe sleutel gegenereerd',
      ),
      '<b>Important: copy the key below before continuing!</b> You will not be able to retrieve it again.' => 
      array (
        0 => '<b>Belangrijk: kopieer de onderstaande sleutel voordat u doorgaat!</b> U kunt deze niet opnieuw opvragen.',
      ),
      'Your full API key is below:' => 
      array (
        0 => 'Uw volledige API-sleutel wordt hieronder weergegeven:',
      ),
      'When making API calls, you can pass this value in the "X-API-Key" header to authenticate as yourself. You can only perform the actions your user account is allowed to perform.' => 
      array (
        0 => 'Wanneer u API-oproepen maakt, kunt u deze waarde doorgeven in de "X-API-Key" header om als uzelf te verifiëren. U kunt alleen de acties uitvoeren die uw gebruikersaccount mag uitvoeren.',
      ),
      'Continue' => 
      array (
        0 => 'Doorgaan',
      ),
      'API keys can be used to access some system functionality without needing to log in. All of the keys
            you create share your permissions in the system. For more information, see the <a href="%s">API documentation</a>.' => 
      array (
        0 => '',
      ),
      'Key Identifier' => 
      array (
        0 => 'Sleutel id',
      ),
      'Enter Two-Factor Code' => 
      array (
        0 => 'Voer twee factor code in',
      ),
      'Your account uses a two-factor security code. Enter the code your device is currently showing below.' => 
      array (
        0 => 'Uw account gebruikt tweestapsverificatie. Voer de code in die op uw apparaat wordt weergegeven.',
      ),
      'Security Code' => 
      array (
        0 => 'Beveiligingscode',
      ),
      'Sign in' => 
      array (
        0 => 'Inloggen',
      ),
      'Forgot Password' => 
      array (
        0 => 'Wachtwoord vergeten',
      ),
      'name@example.com' => 
      array (
        0 => 'naam@voorbeeld.com',
      ),
      'Send Recovery E-mail' => 
      array (
        0 => 'Verstuur herstel-e-mail',
      ),
      'Welcome!' => 
      array (
        0 => 'Welkom!',
      ),
      'Welcome to %s!' => 
      array (
        0 => 'Welkom bij %s!',
      ),
      'Enter your password' => 
      array (
        0 => 'Voer uw wachtwoord in',
      ),
      'Remember me' => 
      array (
        0 => 'Mijn gegevens onthouden',
      ),
      'Please log in to continue.' => 
      array (
        0 => 'Log-in om verder te gaan.',
      ),
      'Forgot your password?' => 
      array (
        0 => 'Wachtwoord vergeten?',
      ),
      'This installation\'s administrator has not configured this functionality.' => 
      array (
        0 => 'De beheerder van deze installatie heeft deze functionaliteit niet geconfigureerd.',
      ),
      'Contact an administrator to reset your password following the instructions in our documentation:' => 
      array (
        0 => 'Neem contact op met een beheerder om uw wachtwoord te resetten volgens de instructies in onze documentatie:',
      ),
      'Password Reset Instructions' => 
      array (
        0 => 'Wachtwoord herstel instructies',
      ),
      'Recover Account' => 
      array (
        0 => 'Account herstellen',
      ),
      'Choose a new password for your account.' => 
      array (
        0 => 'Kies een nieuw wachtwoord voor uw account.',
      ),
      'Automatically scroll to the bottom of the log' => 
      array (
        0 => 'Scroll automatisch naar de onderkant van het logboek',
      ),
      'Need Help?' => 
      array (
        0 => 'Hulp nodig?',
      ),
      'You can find answers for many common questions in our <a href="%s" target="_blank">support documents</a>.' => 
      array (
        0 => 'U kunt antwoorden vinden op veelgestelde vragen in onze <a href="%s" target="_blank">ondersteuningsdocumenten</a>.',
      ),
      'If you\'re experiencing a bug or error, you can submit a GitHub issue using the link below.' => 
      array (
        0 => 'Als je een bug of fout ontdekt, kun je een GitHub issue indienen met behulp van de onderstaande link.',
      ),
      'Your current installation type is <b>%s</b>. Be sure to include this when creating a new issue.' => 
      array (
        0 => 'Uw huidige installatie type is <b>%s</b>. Zorg ervoor dat dit wordt vermeld bij het toevoegen van een issue.',
      ),
      'Add New GitHub Issue' => 
      array (
        0 => 'Voeg nieuw GitHub probleem toe',
      ),
    ),
  ),
);