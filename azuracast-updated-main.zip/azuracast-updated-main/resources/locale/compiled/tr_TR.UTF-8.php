<?php return array (
  'domain' => NULL,
  'plural-forms' => 'nplurals=2; plural=(n != 1);',
  'messages' => 
  array (
    '' => 
    array (
      '' => 
      array (
        0 => 'Project-Id-Version: azuracast
Report-Msgid-Bugs-To: 
Last-Translator: 
Language-Team: Turkish
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
POT-Creation-Date: 2021-10-27T06:14:10+00:00
PO-Revision-Date: 2021-10-27 07:10
Language: tr_TR
Plural-Forms: nplurals=2; plural=(n != 1);
X-Crowdin-Project: azuracast
X-Crowdin-Project-ID: 217396
X-Crowdin-Language: tr
X-Crowdin-File: /main/resources/locale/default.pot
X-Crowdin-File-ID: 4
',
      ),
      'Avatars are retrieved based on your e-mail address from the %{service} service. Click to manage your %{service} settings.' => 
      array (
        0 => 'Avatarlar e-posta adresinize göre %{service} hizmetinden alınır. %{service} ayarlarınızı yönetmek için tıklayın.',
      ),
      'Drag file(s) here to upload or' => 
      array (
        0 => 'Dosya yüklemek için buraya sürükleyin veya',
      ),
      'Select File' => 
      array (
        0 => 'Dosya Seç',
      ),
      'Today' => 
      array (
        0 => 'Bugün',
      ),
      'Yesterday' => 
      array (
        0 => 'Dün',
      ),
      'Last 7 Days' => 
      array (
        0 => 'Son 7 Gün',
      ),
      'Last 14 Days' => 
      array (
        0 => 'Son 14 Gün',
      ),
      'Last 30 Days' => 
      array (
        0 => 'Son 30 Gün',
      ),
      'This Month' => 
      array (
        0 => 'Bu Ay',
      ),
      'Last Month' => 
      array (
        0 => 'Geçen Ay',
      ),
      'Volume' => 
      array (
        0 => 'Ses',
      ),
      'Waveform Zoom' => 
      array (
        0 => 'Dalga Formu Yakınlaştırma',
      ),
      'Mute' => 
      array (
        0 => 'Sustur',
      ),
      'Full Volume' => 
      array (
        0 => 'Full Ses',
      ),
      'Edit Record' => 
      array (
        0 => 'Kaydı Düzenle',
      ),
      'Add Record' => 
      array (
        0 => 'Kayıt Ekle',
      ),
      'Copy to Clipboard' => 
      array (
        0 => 'Panoya Kopyala',
      ),
      'Close' => 
      array (
        0 => 'Kapat',
      ),
      'Save Changes' => 
      array (
        0 => 'Kaydet',
      ),
      'Refresh rows' => 
      array (
        0 => 'Satırları Yenile',
      ),
      'Rows per page' => 
      array (
        0 => 'Sayfa Başına Satır',
      ),
      'Select displayed fields' => 
      array (
        0 => 'Gösterilecek Alanları Seçin',
      ),
      'Select all visible rows' => 
      array (
        0 => 'Tüm görünür satırları seç',
      ),
      'Select' => 
      array (
        0 => 'Seç',
      ),
      'Deselect' => 
      array (
        0 => 'Seçimi Kaldır',
      ),
      'Search' => 
      array (
        0 => 'Arama',
      ),
      'No records to display.' => 
      array (
        0 => 'Görüntülenecek kayıt bulunamadı!',
      ),
      'Loading...' => 
      array (
        0 => 'Yükleniyor...',
      ),
      'Stop' => 
      array (
        0 => 'Durdur',
      ),
      'Play' => 
      array (
        0 => 'Oynat',
      ),
      'Listeners' => 
      array (
        0 => 'Dinleyiciler',
      ),
      'Log View' => 
      array (
        0 => 'Günlüğü Görüntüle',
      ),
      'Average Listeners' => 
      array (
        0 => 'Ortalama Dinleyiciler',
      ),
      'Unique Listeners' => 
      array (
        0 => 'Bağımsız Dinleyiciler',
      ),
      'Hide Charts' => 
      array (
        0 => 'Grafikleri Gizle',
      ),
      'Show Charts' => 
      array (
        0 => 'Grafikleri Göster',
      ),
      'My Account' => 
      array (
        0 => 'Hesabım',
      ),
      'Administration' => 
      array (
        0 => 'Yönetim',
      ),
      'Listeners Per Station' => 
      array (
        0 => 'Radyo Başına Dinleyici',
      ),
      'Station Overview' => 
      array (
        0 => 'Radyo Önizlemesi',
      ),
      'Manage Stations' => 
      array (
        0 => 'Radyo Yönetimi',
      ),
      'Station Name' => 
      array (
        0 => 'Radyo İsmi',
      ),
      'Now Playing' => 
      array (
        0 => 'Çalan Şarkı',
      ),
      'Public Page' => 
      array (
        0 => 'Genel Sayfa',
      ),
      'Manage' => 
      array (
        0 => 'Yönetim',
      ),
      'Username' => 
      array (
        0 => 'Kullanıcı Adı',
      ),
      'New Password' => 
      array (
        0 => 'Yeni Şifre',
      ),
      'Password' => 
      array (
        0 => 'Şifre',
      ),
      'Leave blank to use the current password.' => 
      array (
        0 => 'Mevcut şifreyi kullanmak için boş bırakın.',
      ),
      'SSH Public Keys' => 
      array (
        0 => 'SSH Ortak Anahtarları',
      ),
      'Optionally supply SSH public keys this user can use to connect instead of a password. Enter one key per line.' => 
      array (
        0 => 'İsteğe bağlı olarak bu kullanıcının şifre yerine bağlanmak için kullanabileceği SSH ortak anahtarları sağlayın. Her satıra bir anahtar giriniz.',
      ),
      'Edit SFTP User' => 
      array (
        0 => 'SFTP Kullanıcı Düzenleme',
      ),
      'Add SFTP User' => 
      array (
        0 => 'SFTP Kullanıcısı Ekle',
      ),
      'Reorder Playlist' => 
      array (
        0 => 'Çalma Listesi Yeniden Sıralama',
      ),
      'Down' => 
      array (
        0 => 'Aşağı',
      ),
      'Up' => 
      array (
        0 => 'Yukarı',
      ),
      'Playlist order set.' => 
      array (
        0 => 'Çalma listesi sırası ayarlandı!',
      ),
      'Title' => 
      array (
        0 => 'Çalan Şarkı İsmi',
      ),
      'Artist' => 
      array (
        0 => 'Sanatçı',
      ),
      'Album' => 
      array (
        0 => 'Albüm',
      ),
      'Actions' => 
      array (
        0 => 'İşlemler',
      ),
      'Advanced' => 
      array (
        0 => 'Gelişmiş',
      ),
      'Warning' => 
      array (
        0 => 'Uyarı',
      ),
      'If any of these options are enabled, this playlist will be managed directly via Liquidsoap instead of via AzuraCast. This can have unintended effects and should only be used when you are comfortable with the results.' => 
      array (
        0 => 'Bu seçeneklerden herhangi biri etkinleştirilirse, bu oynatma listesi AzuraCast yerine doğrudan Liquidsoap üzerinden yönetilir. Bunun istenmeyen etkileri olabilir ve yalnızca sonuçlardan memnun olduğunuzda kullanılmalıdır.',
      ),
      'Advanced Manual AutoDJ Scheduling Options' => 
      array (
        0 => 'Gelişmiş Manuel AutoDJ Zamanlama Seçenekleri',
      ),
      'Control how this playlist is handled by the AutoDJ software.' => 
      array (
        0 => 'Bu çalma listesinin AutoDJ yazılımı tarafından nasıl işlendiğini ayarlayabilirsiniz.',
      ),
      'Interrupt other songs to play at scheduled time.' => 
      array (
        0 => 'Planlanan zamanda çalmak için diğer şarkıları kesin.',
      ),
      'Only loop through playlist once.' => 
      array (
        0 => 'Çalma listesinde yalnızca bir kez döngü yapın.',
      ),
      'Only play one track at scheduled time.' => 
      array (
        0 => 'Planlanan zamanda sadece bir parça çalın.',
      ),
      'Merge playlist to play as a single track.' => 
      array (
        0 => 'Tek bir parça olarak çalmak için çalma listesini birleştirin.',
      ),
      'Low' => 
      array (
        0 => 'Düşük',
      ),
      'Default' => 
      array (
        0 => 'Varsayılan',
      ),
      'High' => 
      array (
        0 => 'Yüksek',
      ),
      'Basic Info' => 
      array (
        0 => 'Temel Bilgiler',
      ),
      'Playlist Name' => 
      array (
        0 => 'Çalma Listesi İsmi',
      ),
      'Playlist Weight' => 
      array (
        0 => 'Çalma Listesi Önceliği',
      ),
      'Higher weight playlists are played more frequently compared to other lower-weight playlists.' => 
      array (
        0 => 'Yüksek önceliğe sahip çalma listeleri daha sık çalınır.',
      ),
      'Is Enabled' => 
      array (
        0 => 'Etkinleştir',
      ),
      'If disabled, the playlist will not be included in radio playback, but can still be managed.' => 
      array (
        0 => '"HAYIR" olarak ayarlanırsa AutoDJ müzik çalamaz.',
      ),
      'Avoid Duplicate Artists/Titles' => 
      array (
        0 => 'Yinelenen Sanatçılardan/Şarkı Adlarından Kaçının',
      ),
      'Whether the AutoDJ should attempt to avoid duplicate artists and track titles when playing media from this playlist.' => 
      array (
        0 => 'AutoDJ\'nin bu çalma listesinden medya oynatırken yinelenen sanatçılardan ve şarkı adlarından kaçınmaya çalışıp çalışmadığını ayarlayın.',
      ),
      'Include in On-Demand Player' => 
      array (
        0 => 'İsteğe Bağlı Oynatıcıya Dahil Et',
      ),
      'If this station has on-demand streaming and downloading enabled, only songs that are in playlists with this setting enabled will be visible.' => 
      array (
        0 => 'Bu istasyonda isteğe bağlı akış ve indirme etkinleştirilmişse yalnızca bu ayarın etkin olduğu çalma listelerindeki şarkılar görünür.',
      ),
      'Playlist Type' => 
      array (
        0 => 'Çalma Listesi Türü',
      ),
      'General Rotation' => 
      array (
        0 => 'Genel Oynatma',
      ),
      'Standard playlist, shuffles with other standard playlists based on weight.' => 
      array (
        0 => 'Gün boyu oynatılır ve önceliğe göre diğer standart çalma listeleriyle karıştırılır.',
      ),
      'Once per x Songs' => 
      array (
        0 => 'x Şarkıda Bir Çal',
      ),
      'Play exactly once every $x songs.' => 
      array (
        0 => 'Her $x şarkıda bir çalınır.',
      ),
      'Once per x Minutes' => 
      array (
        0 => 'x Dakikada Bir Çal',
      ),
      'Play exactly once every $x minutes.' => 
      array (
        0 => 'Her $x dakikada bir çalınır.',
      ),
      'Once per Hour' => 
      array (
        0 => 'Saatte Bir Çal',
      ),
      'Play once per hour at the specified minute.' => 
      array (
        0 => 'Belirtilen dakikada saatte bir çalınır.',
      ),
      'Manually define how this playlist is used in Liquidsoap configuration.' => 
      array (
        0 => 'Bu çalma listesinin Liquidsoap yapılandırmasında nasıl kullanıldığını manuel olarak tanımlayın.',
      ),
      'Learn about Advanced Playlists' => 
      array (
        0 => 'Gelişmiş Çalma Listeleri Hakkında Bilgi Edinin',
      ),
      'Include in Automated Assignment' => 
      array (
        0 => 'Otomatik Atamaya Dahil Et',
      ),
      'If auto-assignment is enabled, use this playlist as one of the targets for songs to be redistributed into. This will overwrite the existing contents of this playlist.' => 
      array (
        0 => 'Otomatik atama etkinse bu çalma listesini yeniden dağıtılacak şarkıların hedeflerinden biri olarak kullanın. Bu, bu oynatma listesinin mevcut içeriğinin üzerine yazacaktır.',
      ),
      'Number of Songs Between Plays' => 
      array (
        0 => 'Kaç Şarkıda Bir Çalınsın?',
      ),
      'This playlist will play every $x songs, where $x is specified below.' => 
      array (
        0 => 'Bu çalma listesi her $x şarkıda bir $x şarkı çalacaktır.',
      ),
      'Number of Minutes Between Plays' => 
      array (
        0 => 'Kaç Dakikada Bir Çalınsın?',
      ),
      'This playlist will play every $x minutes, where $x is specified below.' => 
      array (
        0 => 'Bu çalma listesi her $x dakikada bir $x şarkı çalacaktır.',
      ),
      'Minute of Hour to Play' => 
      array (
        0 => 'Saatin Hangi Dakikasında Çalınsın?',
      ),
      'Specify the minute of every hour that this playlist should play.' => 
      array (
        0 => 'Bu çalma listesinin saatin hangi dakikasında oynatılmasını istiyorsanız belirtin.',
      ),
      'Monday' => 
      array (
        0 => 'Pazartesi',
      ),
      'Tuesday' => 
      array (
        0 => 'Salı',
      ),
      'Wednesday' => 
      array (
        0 => 'Çarşamba',
      ),
      'Thursday' => 
      array (
        0 => 'Perşembe',
      ),
      'Friday' => 
      array (
        0 => 'Cuma',
      ),
      'Saturday' => 
      array (
        0 => 'Cumartesi',
      ),
      'Sunday' => 
      array (
        0 => 'Pazar',
      ),
      'Schedule' => 
      array (
        0 => 'Zamanla',
      ),
      'Not Scheduled' => 
      array (
        0 => 'Planlanmadı',
      ),
      'This playlist currently has no scheduled times. It will play at all times. To add a new scheduled time, click the button below.' => 
      array (
        0 => 'Bu oynatma listesinin şu anda planlanmış zamanı yok. Sistem tarafından her zaman oynatılacaktır. Yeni bir zamanlanmış saat eklemek için aşağıdaki düğmeyi tıklayın.',
      ),
      'Scheduled Time #%{num}' => 
      array (
        0 => 'Planlanan Zaman #%{num}',
      ),
      'Remove' => 
      array (
        0 => 'Kaldır',
      ),
      'Start Time' => 
      array (
        0 => 'Başlama Zamanı',
      ),
      'To play once per day, set the start and end times to the same value.' => 
      array (
        0 => 'Günde bir kez oynamak için başlangıç ​​ve bitiş zamanlarını aynı değere ayarlayın.',
      ),
      'End Time' => 
      array (
        0 => 'Bitiş Zamanı',
      ),
      'If the end time is before the start time, the playlist will play overnight.' => 
      array (
        0 => 'Bitiş saati başlangıç ​​saatinden önce ise çalma listesi gecede oynatılır.',
      ),
      'Station Time Zone' => 
      array (
        0 => 'Radyo Saat Dilimi',
      ),
      'This station\'s time zone is currently %{tz}.' => 
      array (
        0 => 'Bu radyonun saat dilimi %{tz} olarak ayarlanmıştır.',
      ),
      'Start Date' => 
      array (
        0 => 'Başlangıç Tarihi',
      ),
      'To set this schedule to run only within a certain date range, specify a start and end date.' => 
      array (
        0 => 'Bu zamanlamayı yalnızca belirli bir tarih aralığında çalışacak şekilde ayarlamak için bir başlangıç ve bitiş tarihi belirtin.',
      ),
      'Start/end date cannot be used on playlists with advanced settings!' => 
      array (
        0 => 'Başlangıç/bitiş tarihi gelişmiş ayarlara sahip çalma listelerinde kullanılamaz!',
      ),
      'End Date' => 
      array (
        0 => 'Bitiş Tarihi',
      ),
      'Loop Once' => 
      array (
        0 => 'Bir Kez Oynat',
      ),
      'Scheduled Play Days of Week' => 
      array (
        0 => 'Haftalık Zamanlama',
      ),
      'Leave blank to play on every day of the week.' => 
      array (
        0 => 'Haftanın hangi günlerinde oynatılmasını istiyorsanız seçin veya haftanın her günü oynatmak için boş bırakın.',
      ),
      'Add Schedule Item' => 
      array (
        0 => 'Zamanlanmış Öğe Ekle',
      ),
      'Source' => 
      array (
        0 => 'Kaynak',
      ),
      'Song-Based Playlist' => 
      array (
        0 => 'Çalma Listesinden Çal',
      ),
      'A playlist containing media files hosted on this server.' => 
      array (
        0 => 'Bu sunucuda barındırılan müzik dosyalarını içeren bir çalma listesidir.',
      ),
      'Remote URL Playlist' => 
      array (
        0 => 'Uzak Çalma Listesi URLsi',
      ),
      'A playlist that instructs the station to play from a remote URL.' => 
      array (
        0 => 'Uzak sunucudaki müzik dosyalarını içeren bir çalma listesidir.',
      ),
      'Song Playback Order' => 
      array (
        0 => 'Şarkı Çalma Sırası',
      ),
      'Shuffled' => 
      array (
        0 => 'Karıştır',
      ),
      'The full playlist is shuffled and then played through in the shuffled order.' => 
      array (
        0 => 'Tam oynatma listesi karıştırılır ve ardından karışık sırayla oynatılır.',
      ),
      'Random' => 
      array (
        0 => 'Rastgele',
      ),
      'A completely random track is picked for playback every time the queue is populated.' => 
      array (
        0 => 'Kuyruk her doldurulduğunda oynatma için tamamen rastgele bir parça seçilir.',
      ),
      'Sequential' => 
      array (
        0 => 'Sıralı',
      ),
      'The order of the playlist is manually specified and followed by the AutoDJ.' => 
      array (
        0 => 'Çalma listesinin sırası manuel olarak belirlenir ve ardından AutoDJ gelir.',
      ),
      'If requests are enabled for your station, users will be able to request media that is on this playlist.' => 
      array (
        0 => 'Radyodaki çalan müzikleri kullanıcıların erişimine açmak için burayı etkinleştirebilirsiniz.',
      ),
      'Allow Requests from This Playlist' => 
      array (
        0 => 'Çalma Listesinde İstekleri Etkinleştir',
      ),
      'Enable this setting to prevent metadata from being sent to the AutoDJ for files in this playlist. This is useful if the playlist contains jingles or bumpers.' => 
      array (
        0 => 'Bu çalma listesinde bulunan müziklerin meta verilerini dinleyicilerden gizlemek için etkinleştirebilirsiniz. Çalma listesinde Jingle veya Bumpers varsa işinize yarayacak bir özelliktir.',
      ),
      'Hide Metadata from Listeners ("Jingle Mode")' => 
      array (
        0 => 'Meta Verilerini Gizle ("Jingle Mode")',
      ),
      'Remote URL' => 
      array (
        0 => 'Uzak Çalma Listesi URLsi',
      ),
      'Remote URL Type' => 
      array (
        0 => 'Uzak Çalma Listesi Türü',
      ),
      'Direct Stream URL' => 
      array (
        0 => 'Doğrudan Yayın URLsi',
      ),
      'Playlist (M3U/PLS) URL' => 
      array (
        0 => 'Çalma Listesi URLsi (M3U/PLS)',
      ),
      'Remote Playback Buffer (Seconds)' => 
      array (
        0 => 'Uzaktan Oynatma Arabelliği (saniye)',
      ),
      'The length of playback time that Liquidsoap should buffer when playing this remote playlist. Shorter times may lead to intermittent playback on unstable connections.' => 
      array (
        0 => 'Uzak çalma listesi Liquidsoap tarafından oynatılırken arabellek için gereken süreyi belirtin. Bağlantı sorunları oluştuğunda daha kısa süreler takılmalara neden olabilir.',
      ),
      'Import from PLS/M3U' => 
      array (
        0 => 'PLS/M3U\'dan İçeri Aktar',
      ),
      'Select PLS/M3U File to Import' => 
      array (
        0 => 'İçe Aktarılacak PLS/M3U Dosyasını Seçin',
      ),
      'AzuraCast will scan the uploaded file for matches in this station\'s music library. Media should already be uploaded before running this step. You can re-run this tool as many times as needed.' => 
      array (
        0 => 'AzuraCast yüklenen dosyayı bu istasyonun müzik kitaplığındaki eşleşmelere karşı tarar. Bu adımı çalıştırmadan önce medya zaten yüklenmiş olmalıdır. Bu aracı gerektiği kadar tekrar çalıştırabilirsiniz.',
      ),
      'Duplicate Playlist' => 
      array (
        0 => 'Çalma Listesini Kopyala',
      ),
      '%{name} - Copy' => 
      array (
        0 => '%{name} - Kopyala',
      ),
      'New Playlist Name' => 
      array (
        0 => 'Yeni Çalma Listesi İsmi',
      ),
      'Customize Copy' => 
      array (
        0 => 'Kopyayı Özelleştir',
      ),
      'Copy associated media and folders.' => 
      array (
        0 => 'İlişkili medya ve klasörleri kopyalayın.',
      ),
      'Copy scheduled playback times.' => 
      array (
        0 => 'Planlanmış oynatma zamanlarını kopyalayın.',
      ),
      'Playback Queue' => 
      array (
        0 => 'Oynatma Sırası',
      ),
      'Playlist queue cleared.' => 
      array (
        0 => 'Çalma listesi sırası temizlendi.',
      ),
      'This queue contains the remaining tracks in the order they will be queued by the AzuraCast AutoDJ (if the tracks are eligible to be played).' => 
      array (
        0 => 'Bu sıra kalan parçaları AzuraCast AutoDJ tarafından sıraya alınacakları sıraya göre içerir (parçalar oynatılmaya uygunsa).',
      ),
      'Clear Queue' => 
      array (
        0 => 'Kuyruğu Temizle',
      ),
      'Edit Playlist' => 
      array (
        0 => 'Çalma Listesi Düzenle',
      ),
      'Add Playlist' => 
      array (
        0 => 'Çalma Listesi Ekle',
      ),
      'Edit Station Profile' => 
      array (
        0 => '',
      ),
      'Song Title' => 
      array (
        0 => 'Şarkı',
      ),
      'Cued On' => 
      array (
        0 => 'Bağla',
      ),
      'Delete Queue Item?' => 
      array (
        0 => 'Sıradaki öğe silinsin mi?',
      ),
      'Clear Upcoming Song Queue?' => 
      array (
        0 => 'Yaklaşan şarkı sırası temizlensin mi?',
      ),
      'Clear' => 
      array (
        0 => 'Temizle',
      ),
      'Upcoming Song Queue' => 
      array (
        0 => 'Sıradaki Şarkı Kuyruğu',
      ),
      'Clear Upcoming Song Queue' => 
      array (
        0 => 'Yaklaşan Şarkı Sırasını Temizle',
      ),
      'Logs' => 
      array (
        0 => 'Kayıtlar',
      ),
      'Delete' => 
      array (
        0 => 'Sil',
      ),
      'Listener Request' => 
      array (
        0 => 'Dinleyici İsteği',
      ),
      'Playlist:' => 
      array (
        0 => 'Çalma Listesi: ',
      ),
      'Remote Station Type' => 
      array (
        0 => 'Uzak Radyo Türü',
      ),
      'Display Name' => 
      array (
        0 => 'Ekran Adı',
      ),
      'The display name assigned to this relay when viewing it on administrative or public pages. Leave blank to automatically generate one.' => 
      array (
        0 => 'Yönetici veya genel sayfalarda görüntülerken bu yönlendirmeye atanan ismi belirleyin. Otomatik olarak oluşturmak için boş bırakın.',
      ),
      'Remote Station Listening URL' => 
      array (
        0 => 'Uzak Radyo Dinleme URLsi',
      ),
      'Example: if the remote radio URL is http://station.example.com:8000/radio.mp3, enter "http://station.example.com:8000".' => 
      array (
        0 => 'Örnek: Uzak radyo URLsi http://station.example.com:8000/radio.mp3, ise "http://station.example.com:8000" girin.',
      ),
      'Remote Station Listening Mountpoint/SID' => 
      array (
        0 => 'Uzak Radyo Dinleme Bağlantı Noktası/SID',
      ),
      'Specify a mountpoint (i.e. "/radio.mp3") or a Shoutcast SID (i.e. "2") to specify a specific stream to use for statistics or broadcasting.' => 
      array (
        0 => 'İstatistikler veya yayın için kullanılacak belirli bir akışı belirtmek için bir bağlama noktası (örn: "/radio.mp3") veya bir Shoutcast SID (örn: "2") yazın.',
      ),
      'Remote Station Administrator Password' => 
      array (
        0 => 'Uzak Radyo Yönetici Parolası',
      ),
      'To retrieve detailed unique listeners and client details, an administrator password is often required.' => 
      array (
        0 => 'Ziyaretçi dinleyicileri ve kullanıcı ayrıntılarını almak için genellikle bir yönetici parolası gerekir.',
      ),
      'Show on Public Pages' => 
      array (
        0 => 'Genel Sayfaları Göster',
      ),
      'Enable to allow listeners to select this relay on this station\'s public pages.' => 
      array (
        0 => 'Dinleyicilerin bu radyonun genel sayfalarında bu yönlendirmeyi seçmelerine izin vermek için etkinleştirin.',
      ),
      'AutoDJ' => 
      array (
        0 => 'AutoDJ',
      ),
      'Broadcast AutoDJ to Remote Station' => 
      array (
        0 => 'Uzak Radyoya AutoDJ Yayını',
      ),
      'If enabled, the AutoDJ on this installation will automatically play music to this mount point.' => 
      array (
        0 => 'Etkinleştirilse bu kurulumdaki AutoDJ otomatik olarak uzak radyo bağlama noktasına müzik çalacaktır.',
      ),
      'AutoDJ Format' => 
      array (
        0 => 'AutoDJ Biçimi',
      ),
      'AutoDJ Bitrate (kbps)' => 
      array (
        0 => 'AutoDJ Bitrate (kbps)',
      ),
      'Remote Station Source Port' => 
      array (
        0 => 'Uzak Radyo Portu',
      ),
      'If the port you broadcast to is different from the one you listed in the URL above, specify the source port here.' => 
      array (
        0 => 'Yayınladığınız bağlantı noktası yukarıdaki URLde belirtiğiniz bağlantıdan farklıysa kaynak bağlantı noktasını burada belirtin.',
      ),
      'Remote Station Source Mountpoint/SID' => 
      array (
        0 => 'Uzak Radyo Bağlantı Noktası/SID',
      ),
      'If the mountpoint (i.e. /radio.mp3) or Shoutcast SID (i.e. 2) you broadcast to is different from the one listed above, specify the source mount point here.' => 
      array (
        0 => '',
      ),
      'Remote Station Source Username' => 
      array (
        0 => 'Uzak Radyo Kullanıcı Adı',
      ),
      'If you are broadcasting using AutoDJ, enter the source username here. This may be blank.' => 
      array (
        0 => 'AutoDJ kullanarak yayın yapıyorsanız kullanıcı adını buraya girin veya boş bırakın.',
      ),
      'Remote Station Source Password' => 
      array (
        0 => 'Uzak Radyo Şifresi',
      ),
      'If you are broadcasting using AutoDJ, enter the source password here.' => 
      array (
        0 => 'AutoDJ kullanarak yayın yapıyorsanız şifreyi buraya girin.',
      ),
      'Publish to "Yellow Pages" Directories' => 
      array (
        0 => '"Yellow Pages" Dizininde Yayınla',
      ),
      'Enable to advertise this relay on "Yellow Pages" public radio directories.' => 
      array (
        0 => 'Radyoyu "Yellow Pages" dizininde yayınlamak istiyorsanız etkinleştirmelisiniz.',
      ),
      'Edit Remote Relay' => 
      array (
        0 => 'Yönlendirme Düzenle',
      ),
      'Add Remote Relay' => 
      array (
        0 => 'Yönlendirme Ekle',
      ),
      'Playlist' => 
      array (
        0 => 'Çalma Listesi',
      ),
      'Scheduling' => 
      array (
        0 => 'Zamanlama',
      ),
      '# Songs' => 
      array (
        0 => '# Şarkılar',
      ),
      'All Playlists' => 
      array (
        0 => 'Tüm Çalma Listeleri',
      ),
      'Schedule View' => 
      array (
        0 => 'Zamanlama Görünümü',
      ),
      'More' => 
      array (
        0 => 'Daha Fazla',
      ),
      'Reorder' => 
      array (
        0 => 'Yeniden Sırala',
      ),
      'Reshuffle' => 
      array (
        0 => 'Yeniden Karıştırma',
      ),
      'Duplicate' => 
      array (
        0 => 'Kopyala',
      ),
      'Disable' => 
      array (
        0 => 'Devredışı',
      ),
      'Enable' => 
      array (
        0 => 'Etkin',
      ),
      'Disabled' => 
      array (
        0 => 'Kapalı',
      ),
      'Weight' => 
      array (
        0 => 'Öncelik',
      ),
      'Once per %{songs} Songs' => 
      array (
        0 => '%{songs} Şarkıda Bir',
      ),
      'Once per %{minutes} Minutes' => 
      array (
        0 => '%{minutes} Dakikada Bir',
      ),
      'Once per Hour (at %{minute})' => 
      array (
        0 => 'Saatte Bir Kez ( %{minute} ) ',
      ),
      'Custom' => 
      array (
        0 => 'Özel',
      ),
      'Delete Playlist?' => 
      array (
        0 => 'Çalma listesi silinsin mi?',
      ),
      'Playlists' => 
      array (
        0 => 'Çalma Listeleri',
      ),
      'Edit' => 
      array (
        0 => 'Düzenle',
      ),
      'Export %{format}' => 
      array (
        0 => 'Dışa Aktar %{format}',
      ),
      'Song-based' => 
      array (
        0 => 'Çalma Listesi Modu',
      ),
      'Jingle Mode' => 
      array (
        0 => 'Jingle Modu',
      ),
      'On-Demand' => 
      array (
        0 => 'İsteğe Bağlı',
      ),
      'Auto-Assigned' => 
      array (
        0 => 'Otomatik Atanmış',
      ),
      'Name' => 
      array (
        0 => 'İsim',
      ),
      'Delete Remote Relay?' => 
      array (
        0 => 'Yönlendirme silinsin mi?',
      ),
      'Remote Relays' => 
      array (
        0 => 'Yönlendirme',
      ),
      'Remote relays let you work with broadcasting software outside this server. Any relay you include here will be included in your station\'s statistics. You can also broadcast from this server to remote relays.' => 
      array (
        0 => 'Yönlendirme bu sunucunun dışındaki yayın yazılımı ile çalışmanızı sağlar. Buraya dahil ettiğiniz herhangi bir yönlendirme radyonuzun istatistiklerine dahil edilecektir. Ayrıca bu sunucudan uzak sunuculara da yayın yapabilirsiniz.',
      ),
      'Enabled' => 
      array (
        0 => 'Açık',
      ),
      'Mount Point URL' => 
      array (
        0 => 'Bağlantı Noktası URLsi',
      ),
      'You can set a custom URL for this stream that AzuraCast will use when referring to it. Leave empty to use the default value.' => 
      array (
        0 => 'Bu yayının AzuraCast de kullanılacağı özel bir URL belirleyebilirsiniz. Varsayılan değeri kullanmak için boş bırakın.',
      ),
      'Custom Frontend Configuration' => 
      array (
        0 => 'Özelleştirilmiş Sunucu Ayarları',
      ),
      'You can include any special mount point settings here, in either JSON { key: \'value\' } format or XML <key>value</key>' => 
      array (
        0 => '',
      ),
      'This name should always begin with a slash (/), and must be a valid URL, such as /autodj.mp3' => 
      array (
        0 => 'Bu isim her zaman bir (/) işareti ile başlamalıdır ve /autodj.mp3 gibi geçerli bir URLye sahip olmalıdır.',
      ),
      'The display name assigned to this mount point when viewing it on administrative or public pages. Leave blank to automatically generate one.' => 
      array (
        0 => 'Yönetici ve genel sayfalarda görüntülenecek bağlama noktasına atanacak ekran adını belirtin. Otomatik oluşturmak için boş bırakın.',
      ),
      'Enable to allow listeners to select this mount point on this station\'s public pages.' => 
      array (
        0 => 'Dinleyicilerin genel sayfalarını bağlantı noktası kullanarak görüntülemesini istiyorsanız etkinleştirebilirsiniz.',
      ),
      'Set as Default Mount Point' => 
      array (
        0 => 'Varsayılan Bağlantı Noktası',
      ),
      'If this mount is the default, it will be played on the radio preview and the public radio page in this system.' => 
      array (
        0 => 'Bu bağlantı noktası varsayılan ise radyo önizlemesinde ve bu sistemdeki genel radyo sayfasında oynatılacaktır.',
      ),
      'Relay Stream URL' => 
      array (
        0 => 'Yönlendirme URLsi',
      ),
      'Enter the full URL of another stream to relay its broadcast through this mount point.' => 
      array (
        0 => 'Yönlendirilmek üzere uzak sunucu URLsini belirtin.',
      ),
      'Enable to advertise this mount point on "Yellow Pages" public radio directories.' => 
      array (
        0 => 'Radyoyu "Yellow Pages" dizininde yayınlamak istiyorsanız etkinleştirmelisiniz.',
      ),
      'Max Listener Duration' => 
      array (
        0 => 'Maksimum Dinleyici Süresi',
      ),
      'Set the length of time (seconds) a listener will stay connected to the stream. If set to 0, listeners can stay connected infinitely.' => 
      array (
        0 => 'Dinleyicinin akışa bağlı kalacağı süreyi saniye olarak ayarlayın. Sıfır (0) olarak ayarlanırsa dinleyiciler sonsuza kadar bağlı kalabilir.',
      ),
      'YP Directory Authorization Hash' => 
      array (
        0 => 'YP Dizini Yetkilendirme Kodu',
      ),
      'Fallback Mount' => 
      array (
        0 => 'Fallback Mount',
      ),
      'If this mount point is not playing audio, listeners will automatically be redirected to this mount point. The default is /error.mp3, a repeating error message.' => 
      array (
        0 => 'Bu bağlantı noktası ses çalmadığında dinleyiciler otomatik olarak buraya yönlendirilecektir. Varsayılan hata sesi /error.mp3 tekrarlanarak çalınacaktır.',
      ),
      'Enable AutoDJ' => 
      array (
        0 => 'AutoDJ kullan',
      ),
      'If enabled, the AutoDJ will automatically play music to this mount point.' => 
      array (
        0 => 'AutoDJ kullanmak için burayı etkinleştirmelisiniz.',
      ),
      'Intro' => 
      array (
        0 => 'Karşılama',
      ),
      'Select Intro File' => 
      array (
        0 => 'Karşılama Müziği Seç',
      ),
      'This introduction file should exactly match the bitrate and format of the mount point itself.' => 
      array (
        0 => 'Bu tanıtım dosyası, bağlantı noktasının kendisinin bit hızı ve biçimiyle tam olarak eşleşmelidir.',
      ),
      'Current Intro File' => 
      array (
        0 => 'Mevcut Karşılama Müziği',
      ),
      'Download' => 
      array (
        0 => 'İndir',
      ),
      'Clear File' => 
      array (
        0 => 'Dosyayı Temizle',
      ),
      'There is no existing intro file associated with this mount point.' => 
      array (
        0 => 'Bu bağlantı noktasıyla ilişkilendirilmiş mevcut bir karşılama müziği yok.',
      ),
      'Edit Mount Point' => 
      array (
        0 => 'Bağlantı Noktası Düzenle',
      ),
      'Add Mount Point' => 
      array (
        0 => 'Bağlantı Noktası Ekle',
      ),
      'Delete SFTP User?' => 
      array (
        0 => 'SFTP kullanıcısı silinsin mi?',
      ),
      'SFTP Users' => 
      array (
        0 => 'SFTP Kullanıcıları',
      ),
      'Connection Information' => 
      array (
        0 => 'Bağlantı Bilgileri',
      ),
      'Server:' => 
      array (
        0 => 'Sunucu:',
      ),
      'You may need to connect directly to your IP address:' => 
      array (
        0 => '',
      ),
      'Port:' => 
      array (
        0 => 'Port:',
      ),
      'Web Hook Details' => 
      array (
        0 => 'Web Kancası Detayları',
      ),
      'Web hooks automatically send a HTTP POST request to the URL you specify to notify it any time one of the triggers you specify occurs on your station.' => 
      array (
        0 => '',
      ),
      'The body of the POST message is the exact same as the NowPlaying API response for your station.' => 
      array (
        0 => '',
      ),
      'NowPlaying API Response' => 
      array (
        0 => '',
      ),
      'In order to process quickly, web hooks have a short timeout, so the responding service should be optimized to handle the request in under 2 seconds.' => 
      array (
        0 => '',
      ),
      'Web Hook URL' => 
      array (
        0 => 'Web Kanca URLsi',
      ),
      'The URL that will receive the POST messages any time an event is triggered.' => 
      array (
        0 => 'Bir URL olay tetiklendiğinde POST mesajlarını alacaktır.',
      ),
      'Optional: HTTP Basic Authentication Username' => 
      array (
        0 => 'İsteğe Bağlı: HTTP Temel Kimlik Doğrulama Kullanıcı Adı',
      ),
      'If your web hook requires HTTP basic authentication, provide the username here.' => 
      array (
        0 => 'Web Kancası HTTP temel kimlik doğrulaması gerektiriyorsa kullanıcı adını belirtin.',
      ),
      'Optional: HTTP Basic Authentication Password' => 
      array (
        0 => 'İsteğe Bağlı: HTTP Temel Kimlik Doğrulama Şifresi',
      ),
      'If your web hook requires HTTP basic authentication, provide the password here.' => 
      array (
        0 => 'Web Kancası HTTP temel kimlik doğrulaması gerektiriyorsa şifre belirtin.',
      ),
      'Matomo Installation Base URL' => 
      array (
        0 => 'Matomo Kurulum Temel URLsi',
      ),
      'The full base URL of your Matomo installation.' => 
      array (
        0 => 'Matomo kurulumunuzun tam temel URLsini yazın.',
      ),
      'Matomo Site ID' => 
      array (
        0 => 'Matomo Site ID',
      ),
      'The numeric site ID for this site.' => 
      array (
        0 => 'Bu site için sayısal site kimliğini yazın.',
      ),
      'Matomo API Token' => 
      array (
        0 => 'Matomo API Anahtarı',
      ),
      'Optionally supply an API token to allow IP address overriding.' => 
      array (
        0 => 'İsteğe bağlı olarak IP adresinin geçersiz kılınmasına izin vermek için bir API anahtarı sağlayın.',
      ),
      'Discord Web Hook URL' => 
      array (
        0 => 'Discord Web Kanca URLsi',
      ),
      'This URL is provided within the Discord application.' => 
      array (
        0 => 'Bu URL Discord uygulamasından sağlanır.',
      ),
      'Main Message Content' => 
      array (
        0 => 'Ana Mesaj İçeriği',
      ),
      'Description' => 
      array (
        0 => 'Açıklama',
      ),
      'URL' => 
      array (
        0 => 'URL',
      ),
      'Author Name' => 
      array (
        0 => 'Yazar İsmi',
      ),
      'Thumbnail Image URL' => 
      array (
        0 => 'Küçük Resim URLsi',
      ),
      'Footer Text' => 
      array (
        0 => 'Alt Bilgi Metni',
      ),
      'Web Hook Name' => 
      array (
        0 => 'Web Kancası İsmi',
      ),
      'Choose a name for this webhook that will help you distinguish it from others. This will only be shown on the administration page.' => 
      array (
        0 => 'Bu entegrasyonu diğerlerinden ayırmanıza yardımcı olacak bir isim seçin. Bu sadece yönetim sayfasında gösterilecektir.',
      ),
      'Web Hook Triggers' => 
      array (
        0 => 'Web Kanca Tetikleyicileri',
      ),
      'This web hook will only run when the selected event(s) occur on this specific station.' => 
      array (
        0 => '',
      ),
      'Message Customization Tips' => 
      array (
        0 => '',
      ),
      'Variables are in the form of:' => 
      array (
        0 => '',
      ),
      'All values in the NowPlaying API response are available for use. Any empty fields are ignored.' => 
      array (
        0 => '',
      ),
      'TuneIn Station ID' => 
      array (
        0 => 'TuneIn Radyo ID',
      ),
      'The station ID will be a numeric string that starts with the letter S.' => 
      array (
        0 => '"S" harfi ile başlayan TuneIn Radyo ID\'sini buraya yazın.',
      ),
      'TuneIn Partner ID' => 
      array (
        0 => 'TuneIn Ortak ID',
      ),
      'TuneIn Partner Key' => 
      array (
        0 => 'TuneIn Ortak Anahtarı',
      ),
      'Markdown' => 
      array (
        0 => 'Etiketleme',
      ),
      'HTML' => 
      array (
        0 => 'HTML',
      ),
      'Bot Token' => 
      array (
        0 => 'Bot Bilgisi',
      ),
      'See the Telegram Documentation for more details.' => 
      array (
        0 => '',
      ),
      'Chat ID' => 
      array (
        0 => 'Sohbet ID',
      ),
      'Unique identifier for the target chat or username of the target channel (in the format @channelusername).' => 
      array (
        0 => 'Hedef sohbeti veya hedef kanalın kullanıcı adı için benzersiz tanımlayıcıyı belirleyin. (@channelusername biçiminde)',
      ),
      'Custom API Base URL' => 
      array (
        0 => 'Özel API Temel URLsi',
      ),
      'Leave blank to use the default Telegram API URL (recommended).' => 
      array (
        0 => '',
      ),
      'Message parsing mode' => 
      array (
        0 => 'Mesaj Ayrıştırma Modu',
      ),
      'See the Telegram documentation for more details.' => 
      array (
        0 => '',
      ),
      'GA Property Tracking ID' => 
      array (
        0 => 'GA Özellik Takibi ID',
      ),
      'The property ID used to track live listeners.' => 
      array (
        0 => 'Canlı dinleyicileri izlemek için kullanılan ID numarasıdır.',
      ),
      'Message Recipient(s)' => 
      array (
        0 => 'Mesaj Alıcıları',
      ),
      'E-mail addresses can be separated by commas.' => 
      array (
        0 => 'E-posta adresleri virgülle ayrılabilir.',
      ),
      'Message Subject' => 
      array (
        0 => 'Mesaj Konusu',
      ),
      'Message Body' => 
      array (
        0 => 'Mesaj Metni',
      ),
      'Select Web Hook Type' => 
      array (
        0 => '',
      ),
      '%{ seconds } seconds' => 
      array (
        0 => '%{ seconds } saniye',
      ),
      '%{ minutes } minutes' => 
      array (
        0 => '%{ minutes } dakika',
      ),
      'No Limit' => 
      array (
        0 => 'Limitsiz',
      ),
      'Twitter Account Details' => 
      array (
        0 => 'Twitter Hesap Detayları',
      ),
      'Steps for configuring a Twitter application:' => 
      array (
        0 => '',
      ),
      'Create a new app on the Twitter Applications site. Use this installation\'s base URL as the application URL.' => 
      array (
        0 => '',
      ),
      'Twitter Applications' => 
      array (
        0 => '',
      ),
      'In the newly created application, click the "Keys and Access Tokens" tab.' => 
      array (
        0 => '',
      ),
      'At the bottom of the page, click "Create my access token".' => 
      array (
        0 => '',
      ),
      'Once these steps are completed, enter the information from the "Keys and Access Tokens" page into the fields below.' => 
      array (
        0 => '',
      ),
      'Consumer Key (API Key)' => 
      array (
        0 => 'Alıcı Anahtarı (API Anahtarı)',
      ),
      'Consumer Secret (API Secret)' => 
      array (
        0 => 'Alıcı Gizliliği (API Gizliliği)',
      ),
      'Access Token' => 
      array (
        0 => 'Erişim Kodu',
      ),
      'Access Token Secret' => 
      array (
        0 => 'Erişim Kodu Gizliliği',
      ),
      'Only Send One Tweet Every...' => 
      array (
        0 => 'Her Tweet Sadece Bir Kez Gönderilir...',
      ),
      'Edit Web Hook' => 
      array (
        0 => 'Web Kancasını Düzenle',
      ),
      'Add Web Hook' => 
      array (
        0 => 'Web Kancası Ekle',
      ),
      'Powered by AzuraCast' => 
      array (
        0 => '',
      ),
      'Now playing on %{ station }:' => 
      array (
        0 => '',
      ),
      'Now playing on %{ station }: %{ title } by %{ artist }! Tune in now.' => 
      array (
        0 => '',
      ),
      'Now playing on %{ station }: %{ title } by %{ artist }! Tune in now: %{ url }' => 
      array (
        0 => '',
      ),
      'Disable song requests?' => 
      array (
        0 => 'Şarkı istekleri devredışı bırakılsın mı?',
      ),
      'Enable song requests?' => 
      array (
        0 => 'Şarkı istekleri aktifleştirilsin mi?',
      ),
      'Song Requests' => 
      array (
        0 => 'Şarkı İstekleri',
      ),
      'View' => 
      array (
        0 => 'Görüntüle',
      ),
      'Streams' => 
      array (
        0 => 'Yayınlar',
      ),
      'Local Streams' => 
      array (
        0 => 'Yerel Yayınlar',
      ),
      'Unique' => 
      array (
        0 => 'Ziyaretçi',
      ),
      'Download PLS' => 
      array (
        0 => 'PLS İndir',
      ),
      'Download M3U' => 
      array (
        0 => 'M3U İndir',
      ),
      '%{listeners} Listener' => 
      array (
        0 => '%{listeners} Dinleyici',
        1 => '%{listeners} Dinleyici',
      ),
      'On the Air' => 
      array (
        0 => 'Yayında',
      ),
      'Playing Next' => 
      array (
        0 => 'Sıradaki Şarkı',
      ),
      'Live' => 
      array (
        0 => 'Canlı',
      ),
      'Skip Song' => 
      array (
        0 => 'Şarkıyı Atla',
      ),
      'Disconnect Streamer' => 
      array (
        0 => 'DJ Bağlantısını Kes',
      ),
      'Disable streamers?' => 
      array (
        0 => 'DJler devredışı bırakılsın mı?',
      ),
      'Enable streamers?' => 
      array (
        0 => 'DJler aktifleştirilsin mi?',
      ),
      'Streamers/DJs' => 
      array (
        0 => 'DJ Yönetimi',
      ),
      'Edit Profile' => 
      array (
        0 => 'Profili Düzenle',
      ),
      'Disable public pages?' => 
      array (
        0 => 'Genel sayfalar devredışı bırakılsın mı?',
      ),
      'Enable public pages?' => 
      array (
        0 => 'Genel sayfalar aktifleştirilsin mi?',
      ),
      'Public Pages' => 
      array (
        0 => 'Genel Sayfalar',
      ),
      'Web DJ' => 
      array (
        0 => 'Web DJ',
      ),
      'On-Demand Media' => 
      array (
        0 => 'İsteğe Bağlı Medya',
      ),
      'Podcasts' => 
      array (
        0 => 'Podcasts',
      ),
      'Embed Widgets' => 
      array (
        0 => 'Widget Ekleme',
      ),
      'Broadcasting Service' => 
      array (
        0 => 'Yayın Sunucusu',
      ),
      'Administration URL' => 
      array (
        0 => 'Yönetim URLsi',
      ),
      'Administrator Password' => 
      array (
        0 => 'Yayın Yönetici Şifresi',
      ),
      'Source Password' => 
      array (
        0 => 'Yayın Şifresi',
      ),
      'Relay Password' => 
      array (
        0 => 'Yönlendirme Şifresi',
      ),
      'Restart' => 
      array (
        0 => 'Yeniden Başlat',
      ),
      'Start' => 
      array (
        0 => 'Başlat',
      ),
      'Radio Player' => 
      array (
        0 => 'Radyo Çalar',
      ),
      'History' => 
      array (
        0 => 'Geçmiş',
      ),
      'Requests' => 
      array (
        0 => 'İstekler',
      ),
      'Light' => 
      array (
        0 => 'Açık Tema',
      ),
      'Dark' => 
      array (
        0 => 'Koyu Tema',
      ),
      'Widget Type' => 
      array (
        0 => 'Widget Türü',
      ),
      'Theme' => 
      array (
        0 => 'Tema',
      ),
      'Customize' => 
      array (
        0 => 'Özelleştir',
      ),
      'Embed Code' => 
      array (
        0 => 'Ekleme Kodu',
      ),
      'Preview' => 
      array (
        0 => 'Önizleme',
      ),
      'Scheduled' => 
      array (
        0 => 'Zamanlanmış',
      ),
      'Streamer/DJ' => 
      array (
        0 => 'DJ',
      ),
      'Now' => 
      array (
        0 => 'Şimdi',
      ),
      'AutoDJ Disabled' => 
      array (
        0 => 'AutoDJ Devredışı',
      ),
      'AutoDJ has been disabled for this station. No music will automatically be played when a source is not live.' => 
      array (
        0 => 'AutoDJ bu radyoda için devredışı bırakıldı. Canlı yayın olmadığında hiçbir müzik otomatik olarak çalınmaz.',
      ),
      '%{numSongs} uploaded song' => 
      array (
        0 => '%{numSongs} adet yüklenmiş şarkı',
        1 => '%{numSongs} adet yüklenmiş şarkı',
      ),
      '%{numPlaylists} playlist' => 
      array (
        0 => '%{numPlaylists} Çalma Listesi',
        1 => '%{numPlaylists} Çalma Listesi',
      ),
      'LiquidSoap is currently shuffling from %{songs} and %{playlists}.' => 
      array (
        0 => 'LiquidSoap şu anda %{songs} adet şarkıyı %{playlists} adet çalma listesinden karışık olarak çalıyor.',
      ),
      'AutoDJ Service' => 
      array (
        0 => 'AutoDJ Servisi',
      ),
      'Running' => 
      array (
        0 => 'Çalışıyor',
      ),
      'Not Running' => 
      array (
        0 => 'Çalışmıyor',
      ),
      'Delete Mount Point?' => 
      array (
        0 => 'Bağlantı Noktası Silinsin mi?',
      ),
      'Mount Points' => 
      array (
        0 => 'Bağlantı Noktası',
      ),
      'Mount points are how listeners connect and listen to your station. Each mount point can be a different audio format or quality. Using mount points, you can set up a high-quality stream for broadband listeners and a mobile stream for phone users.' => 
      array (
        0 => 'Bağlantı noktaları dinleyicilerin radyonuza nasıl bağlayıp dinlediğini gösterir. Her bir bağlantı noktası farklı ses formatı veya kalitede olabilir. Bağlantı noktalarını kullanarak limitsiz internetli dinleyiciler için yüksek kaliteli bir yayın belirleyebilir veya telefon kullanıcıları için düşük kaliteli bir yayın ayarlayabilirsiniz.',
      ),
      'Default Mount' => 
      array (
        0 => 'Varsayılan Bağlantı Noktası',
      ),
      'Genre' => 
      array (
        0 => 'Tür',
      ),
      'Length' => 
      array (
        0 => 'Uzunluk',
      ),
      'Size' => 
      array (
        0 => 'Boyut',
      ),
      'Modified' => 
      array (
        0 => 'Değiştirme Zamanı',
      ),
      'Album Art' => 
      array (
        0 => 'Albüm Sanatçısı',
      ),
      'Rename' => 
      array (
        0 => 'Yeniden Adlandır',
      ),
      'View tracks in playlist' => 
      array (
        0 => 'Çalma Listesindeki Parçaları Görüntüle',
      ),
      '%{spaceUsed} of %{spaceTotal} Used (%{filesCount} Files)' => 
      array (
        0 => 'Kullanılan Alan: %{spaceUsed} - Toplam Alan: %{spaceTotal} - Dosya Sayısı: %{filesCount}',
      ),
      '%{spaceUsed} Used (%{filesCount} Files)' => 
      array (
        0 => 'Kullanılan: %{spaceUsed} - Dosya Sayısı: %{filesCount}',
      ),
      'Music Files' => 
      array (
        0 => 'Müzik Dosyaları',
      ),
      'You can also upload files in bulk via SFTP.' => 
      array (
        0 => 'Dosyaları SFTP üzerinden toplu olarak yükleyebilirsiniz.',
      ),
      'Manage SFTP Accounts' => 
      array (
        0 => 'SFTP Hesaplarını Yönet',
      ),
      'Directory' => 
      array (
        0 => 'Klasör',
      ),
      'Move %{ num } File(s) to' => 
      array (
        0 => '%{ num } adet dosyayı taşı',
      ),
      'Files moved:' => 
      array (
        0 => 'Dosyalar taşındı:',
      ),
      'Back' => 
      array (
        0 => 'Geri',
      ),
      'Move to Directory' => 
      array (
        0 => 'Dizine Taşı',
      ),
      'Home' => 
      array (
        0 => 'Anasayfa',
      ),
      'Basic Information' => 
      array (
        0 => 'Temel Bilgiler',
      ),
      'File Name' => 
      array (
        0 => 'Dosya Adı',
      ),
      'The relative path of the file in the station\'s media directory.' => 
      array (
        0 => 'Radyonun müzik dosyalarının geçici dizinidir.',
      ),
      'Song Artist' => 
      array (
        0 => 'Sanatçı',
      ),
      'Song Genre' => 
      array (
        0 => 'Şarkı Türü',
      ),
      'Song Album' => 
      array (
        0 => 'Albüm',
      ),
      'Song Lyrics' => 
      array (
        0 => 'Şarkı Sözleri',
      ),
      'ISRC' => 
      array (
        0 => 'ISRC',
      ),
      'International Standard Recording Code, used for licensing reports.' => 
      array (
        0 => 'Uluslararası Standart Kayıt Kodu lisans raporları için kullanılır.',
      ),
      'Visual Cue Editor' => 
      array (
        0 => 'Görsel Cue Editörü',
      ),
      'Set cue and fade points using the visual editor. The timestamps will be saved to the corresponding fields in the advanced playback settings.' => 
      array (
        0 => 'Görsel düzenleyiciyi kullanarak işaret ve solma noktalarını ayarlayın. Zaman damgaları gelişmiş oynatma ayarlarındaki ilgili alanlara kaydedilecektir.',
      ),
      'Set Cue In' => 
      array (
        0 => 'Giriş İşaretleme Ayarı',
      ),
      'Set Cue Out' => 
      array (
        0 => 'Çıkış İşaretleme Ayarı',
      ),
      'Set Overlap' => 
      array (
        0 => 'Çakışma Ayarı',
      ),
      'Set Fade In' => 
      array (
        0 => 'Giriş Solma Ayarı',
      ),
      'Set Fade Out' => 
      array (
        0 => 'Çıkış Solma Ayarı',
      ),
      'Custom Fields' => 
      array (
        0 => 'Özelleştirme',
      ),
      'Delete Album Art' => 
      array (
        0 => 'Albüm Kapağını Sil',
      ),
      'Replace Album Cover Art' => 
      array (
        0 => 'Albüm Kapağını Değiştir',
      ),
      'Song Length' => 
      array (
        0 => 'Şarkı Süresi',
      ),
      'Amplify: Amplification (dB)' => 
      array (
        0 => 'Amplify: Amplification (dB)',
      ),
      'The volume in decibels to amplify the track with. Leave blank to use the system default.' => 
      array (
        0 => 'Parçanın sesini yükseltmek için desibel cinsinden hacim miktarı giriniz. Sistem varsayılanını kullanmak için boş bırakın.',
      ),
      'Custom Fading: Overlap Time (seconds)' => 
      array (
        0 => 'Custom Fading: Örtüşme Zamanı (saniye)',
      ),
      'The time that this song should overlap its surrounding songs when fading. Leave blank to use the system default.' => 
      array (
        0 => 'Bu şarkıdan sonraki şarkıya geçiş sırasında örtüşme süresini belirtin. Sistem varsayılan değeri için boş bırakın.',
      ),
      'Custom Fading: Fade-In Time (seconds)' => 
      array (
        0 => 'Custom Fading: Solma Zamanı (saniye)',
      ),
      'The time period that the song should fade in. Leave blank to use the system default.' => 
      array (
        0 => 'Bu şarkıya geçiş sırasında önceki şarkının solma zamanını belirtin. Sistem varsayılan değeri için boş bırakın.',
      ),
      'Custom Fading: Fade-Out Time (seconds)' => 
      array (
        0 => 'Custom Fading: Solma Zamanı (saniye)',
      ),
      'The time period that the song should fade out. Leave blank to use the system default.' => 
      array (
        0 => 'Bu şarkıdan diğer şarkıya geçiş sırasında sonraki şarkının solma zamanını belirtin. Sistem varsayılan değeri için boş bırakın.',
      ),
      'Custom Cues: Cue-In Point (seconds)' => 
      array (
        0 => 'Custom Cue: Giriş Noktası (saniye)',
      ),
      'Seconds from the start of the song that the AutoDJ should start playing.' => 
      array (
        0 => 'AutoDJ\'in şarkıyı çalmaya başlaması için gereken zamanı belirtin.',
      ),
      'Custom Cues: Cue-Out Point (seconds)' => 
      array (
        0 => 'Custom Cues: Çıkış Noktası (saniye)',
      ),
      'Seconds from the start of the song that the AutoDJ should stop playing.' => 
      array (
        0 => 'AutoDJ\'in şarkıyı çalmaya sonlandırması için gereken zamanı belirtin.',
      ),
      'Rename File/Directory' => 
      array (
        0 => 'Dosya/Klasör Yeniden Adlandır',
      ),
      'New File Name' => 
      array (
        0 => 'Yeni Klasör Adı',
      ),
      'Set or clear playlists from the selected media' => 
      array (
        0 => 'Seçilen müzik dosyalarını çalma listesinden temizle veya ekle',
      ),
      'New Playlist' => 
      array (
        0 => 'Yeni Çalma Listesi',
      ),
      'Queue the selected media to play next' => 
      array (
        0 => 'Bir sonrakini oynatmak için seçilen müzik dosyasını sırala',
      ),
      'Analyze and reprocess the selected media' => 
      array (
        0 => 'Müzik dosyalarını analiz et ve yeniden işle',
      ),
      'The request could not be processed.' => 
      array (
        0 => 'İsteğiniz işlenemedi!',
      ),
      'Files queued for playback:' => 
      array (
        0 => 'Çalınmak üzere sıraya alınmış müzik dosyaları:',
      ),
      'Files marked for reprocessing:' => 
      array (
        0 => 'Tekrar işlenecek dosyalar:',
      ),
      'Delete %{ num } media files?' => 
      array (
        0 => '%{ num } adet müzik dosyası silinsin mi?',
      ),
      'Files removed:' => 
      array (
        0 => 'Silinen Dosyalar:',
      ),
      'Playlists updated for selected files:' => 
      array (
        0 => 'Seçilen dosyalar çalma listesinde güncellendi:',
      ),
      'Playlists cleared for selected files:' => 
      array (
        0 => 'Seçilen dosyalar çalma listesiden silindi:',
      ),
      'No files selected.' => 
      array (
        0 => 'Hiçbir dosya seçilmedi!',
      ),
      'Save' => 
      array (
        0 => 'Kaydet',
      ),
      'Move' => 
      array (
        0 => 'Taşı',
      ),
      'Queue' => 
      array (
        0 => 'Sırala',
      ),
      'Reprocess' => 
      array (
        0 => 'Yeniden İşle',
      ),
      'New Folder' => 
      array (
        0 => 'Yeni Klasör',
      ),
      'Edit Media' => 
      array (
        0 => 'Müzik Dosyası Düzenle',
      ),
      'New Directory' => 
      array (
        0 => 'Yeni Dizin',
      ),
      'New directory created.' => 
      array (
        0 => 'Yeni Klasör Oluşturuldu!',
      ),
      'Directory Name' => 
      array (
        0 => 'Dizin İsmi',
      ),
      'Create Directory' => 
      array (
        0 => 'Dizin Oluştur',
      ),
      'Artwork' => 
      array (
        0 => 'Kapak Resmi',
      ),
      'Select PNG/JPG artwork file' => 
      array (
        0 => 'Kapak Resmini (PNG/JPG) Seç',
      ),
      'Artwork must be a minimum size of 1400 x 1400 pixels and a maximum size of 3000 x 3000 pixels for Apple Podcasts.' => 
      array (
        0 => 'Kapak resmi Apple Podcastler için minimum 1400x1400 piksel boyutunda ve maksimum 3000x3000 piksel boyutunda olmalıdır.',
      ),
      'Clear Artwork' => 
      array (
        0 => 'Kapak Resmini Temizle',
      ),
      'Edit Episode' => 
      array (
        0 => 'Bölümü Düzenle',
      ),
      'Add Episode' => 
      array (
        0 => 'Bölüm Ekle',
      ),
      'Edit Podcast' => 
      array (
        0 => 'Podcast Düzenle',
      ),
      'Add Podcast' => 
      array (
        0 => 'Podcast Ekle',
      ),
      'Podcast Title' => 
      array (
        0 => 'Podcast Başlığı',
      ),
      'Website' => 
      array (
        0 => 'İnternet Sitesi',
      ),
      'Typically the home page of a podcast.' => 
      array (
        0 => 'Genellikle bir podcast ana sayfası.',
      ),
      'The description of your podcast. The typical maximum amount of text allowed for this is 4000 characters.' => 
      array (
        0 => 'Podcast açıklaması. Bunun için izin verilen tipik maksimum metin miktarı 4000 karakterdir.',
      ),
      'Language' => 
      array (
        0 => 'Dil',
      ),
      'The language spoken on the podcast.' => 
      array (
        0 => 'Podcast konuşma dili.',
      ),
      'Author' => 
      array (
        0 => 'Yazar',
      ),
      'The contact person of the podcast. May be required in order to list the podcast on services like Apple Podcasts, Spotify, Google Podcasts, etc.' => 
      array (
        0 => 'Podcast\'in ilgili kişisi. Podcast\'i Apple Podcasts, Spotify, Google Podcasts vb. hizmetlerde listelemek için gerekli olabilir.',
      ),
      'E-Mail' => 
      array (
        0 => 'E-Posta',
      ),
      'The email of the podcast contact. May be required in order to list the podcast on services like Apple Podcasts, Spotify, Google Podcasts, etc.' => 
      array (
        0 => 'Podcast kişisinin e-postası. Podcast\'i Apple Podcasts, Spotify, Google Podcasts vb. hizmetlerde listelemek için gerekli olabilir.',
      ),
      'Categories' => 
      array (
        0 => 'Kategoriler',
      ),
      'Select the category/categories that best reflects the content of your podcast.' => 
      array (
        0 => 'Podcast içeriğini en iyi yansıtan kategoriyi/kategorileri seçin.',
      ),
      'Art' => 
      array (
        0 => 'Sanat',
      ),
      'Podcast' => 
      array (
        0 => 'Podcast',
      ),
      '# Episodes' => 
      array (
        0 => '# Bölüm',
      ),
      'All Podcasts' => 
      array (
        0 => 'Tüm Podcastler',
      ),
      'Delete Podcast?' => 
      array (
        0 => 'Podcast silinsin mi?',
      ),
      'RSS Feed' => 
      array (
        0 => 'RSS Beslemesi',
      ),
      'Episodes' => 
      array (
        0 => 'Bölümler',
      ),
      'Episode' => 
      array (
        0 => 'Bölüm',
      ),
      'File' => 
      array (
        0 => 'Dosya',
      ),
      'Explicit' => 
      array (
        0 => 'Açık',
      ),
      'Delete Episode?' => 
      array (
        0 => 'Bölüm silinsin mi?',
      ),
      'Typically a website with content about the episode.' => 
      array (
        0 => 'Genellikle bölümle ilgili içeriğin bulunduğu bir web sitesi.',
      ),
      'The description of the episode. The typical maximum amount of text allowed for this is 4000 characters.' => 
      array (
        0 => 'Bölüm açıklaması. Bunun için izin verilen tipik maksimum metin miktarı 4000 karakterdir.',
      ),
      'Publish Date' => 
      array (
        0 => 'Podcast Tarihi',
      ),
      'The date when the episode should be published.' => 
      array (
        0 => 'Bölümün yayınlanması gereken tarih.',
      ),
      'Publish Time' => 
      array (
        0 => 'Podcast Zamanı',
      ),
      'The time when the episode should be published (according to the stations timezone).' => 
      array (
        0 => 'Bölümün yayınlanması gereken saat (radyoların saat dilimine göre).',
      ),
      'Contains explicit content' => 
      array (
        0 => 'Yetişkinlere yönelik içerik vardır',
      ),
      'Indicates the presence of explicit content (explicit language or adult content). Apple Podcasts displays an Explicit parental advisory graphic for your episode if turned on. Episodes containing explicit material aren’t available in some Apple Podcasts territories.' => 
      array (
        0 => 'Yetişkinlere ait içeriğin varlığını gösterir (açık dil veya yetişkinlere uygun içerik). Apple Podcasts aktif ise yetişkinlere ait bölümünüz için bir ebeveyn danışma grafiği görüntüler. Yetişkinlere ait materyal içeren bölümler bazı Apple Podcasts bölgelerinde mevcut değildir.',
      ),
      'Media' => 
      array (
        0 => 'Medya',
      ),
      'Select Media File' => 
      array (
        0 => 'Medya Dosyasını Seç',
      ),
      'Podcast media should be in the MP3 or M4A (AAC) format for the greatest compatibility.' => 
      array (
        0 => 'Podcast dosyası en yüksek uyumluluk için MP3 veya M4A (AAC) formatında olmalıdır.',
      ),
      'Current Podcast Media' => 
      array (
        0 => 'Mevcut Podcast Medyası',
      ),
      'Clear Media' => 
      array (
        0 => 'Müzik Dosyasını Temizle',
      ),
      'There is no existing media associated with this episode.' => 
      array (
        0 => 'Bu bölümle ilişkilendirilmiş mevcut medya dosyası yok.',
      ),
      'Notes' => 
      array (
        0 => 'Notlar',
      ),
      'Account List' => 
      array (
        0 => 'Hesap Listesi',
      ),
      'Delete Streamer?' => 
      array (
        0 => 'DJ silinsin mi?',
      ),
      'Streamer/DJ Accounts' => 
      array (
        0 => 'DJ Yönetimi',
      ),
      'Add Streamer' => 
      array (
        0 => 'DJ Ekle',
      ),
      'Broadcasts' => 
      array (
        0 => 'Canlı Yayınlar',
      ),
      'Icecast Clients' => 
      array (
        0 => 'IceCast Bilgileri',
      ),
      'You may need to connect directly via your IP address:' => 
      array (
        0 => '',
      ),
      'Mount Name:' => 
      array (
        0 => 'Bağlantı Noktası:',
      ),
      'SHOUTcast Clients' => 
      array (
        0 => 'Shoutcast Bilgileri',
      ),
      'For some clients, use port:' => 
      array (
        0 => '',
      ),
      'Password:' => 
      array (
        0 => 'Şifre:',
      ),
      'or' => 
      array (
        0 => 'veya',
      ),
      'Setup instructions for broadcasting software are available on the AzuraCast wiki.' => 
      array (
        0 => 'Canlı yayın programlarına ait dökümanlar için AzuraCast Wiki sayfasını ziyaret edebilirsiniz.',
      ),
      'AzuraCast Wiki' => 
      array (
        0 => '',
      ),
      'Streamer Username' => 
      array (
        0 => 'DJ Kullanıcı Adı',
      ),
      'The streamer will use this username to connect to the radio server.' => 
      array (
        0 => 'Radyo sunucusuna bağlanmak için bir kullanıcı adı belirtin.',
      ),
      'Streamer password' => 
      array (
        0 => 'DJ Şifresi',
      ),
      'The streamer will use this password to connect to the radio server.' => 
      array (
        0 => 'Radyo sunucusuna bağlanmak için bir şifre belirtin.',
      ),
      'Streamer Display Name' => 
      array (
        0 => 'DJ İsmi',
      ),
      'This is the informal display name that will be shown in API responses if the streamer/DJ is live.' => 
      array (
        0 => 'Bu DJ canlı yayında olduğunda API yanıtlarında gösterilecek olan resmi olmayan ekran adıdır.',
      ),
      'Comments' => 
      array (
        0 => 'Açıklamalar',
      ),
      'Internal notes or comments about the user, visible only on this control panel.' => 
      array (
        0 => 'Kullanıcıyla ilgili dahili notlar veya yorumlar yalnızca bu kontrol panelinde görünür.',
      ),
      'Account is Active' => 
      array (
        0 => 'Hesabı Etkinleştir',
      ),
      'Enable to allow this account to log in and stream.' => 
      array (
        0 => 'Bu hesabın oturum açmasına ve yayın yapmasına izin vermek için etkinleştirin.',
      ),
      'Enforce Schedule Times' => 
      array (
        0 => 'Program Zamanlarını Zorla',
      ),
      'If enabled, this streamer will only be able to connect during their scheduled broadcast times.' => 
      array (
        0 => 'Etkinleştirilirse bu DJ yalnızca planlanan yayın sürelerinde bağlantı kurabilir.',
      ),
      'This streamer is not scheduled to play at any times.' => 
      array (
        0 => 'Bu DJ hiçbir zaman oynatılamaz.',
      ),
      'If the end time is before the start time, the schedule entry will continue overnight.' => 
      array (
        0 => 'Bitiş zamanı başlangıç zamanından önce ise program girişi gece de devam edecektir.',
      ),
      'Streamer Broadcasts' => 
      array (
        0 => 'DJ Yayınları',
      ),
      'Play/Pause' => 
      array (
        0 => 'Oynat/Duraklat',
      ),
      'Delete Broadcast?' => 
      array (
        0 => 'Canlı yayın silinsin mi?',
      ),
      'Edit Streamer' => 
      array (
        0 => 'DJ Düzenle',
      ),
      'Hour' => 
      array (
        0 => 'Saat',
      ),
      'IP' => 
      array (
        0 => 'IP',
      ),
      'Time' => 
      array (
        0 => 'Zaman',
      ),
      'Time (sec)' => 
      array (
        0 => 'Zaman (sn)',
      ),
      'User Agent' => 
      array (
        0 => 'Tarayıcı Bilgisi',
      ),
      'Stream' => 
      array (
        0 => 'Yayınlar',
      ),
      'Location' => 
      array (
        0 => 'Konum',
      ),
      'Live Listeners' => 
      array (
        0 => 'Canlı Dinleyiciler',
      ),
      'Download CSV' => 
      array (
        0 => 'CSV İndir',
      ),
      'for selected period' => 
      array (
        0 => 'seçilen dönem için',
      ),
      'Total Listener Hours' => 
      array (
        0 => 'Toplam Dinleyici Saati',
      ),
      'Mobile Device' => 
      array (
        0 => 'Mobil Cihaz',
      ),
      'Desktop Device' => 
      array (
        0 => 'Masaüstü Cihazı',
      ),
      'Unknown' => 
      array (
        0 => 'Bilinmiyor',
      ),
      'Local' => 
      array (
        0 => 'Yerel',
      ),
      'Remote' => 
      array (
        0 => 'Uzak',
      ),
      'Filename' => 
      array (
        0 => 'Dosya Adı',
      ),
      'Length Text' => 
      array (
        0 => 'Uzunluk',
      ),
      'Playlist(s)' => 
      array (
        0 => 'Çalma Listesi',
      ),
      'Joins' => 
      array (
        0 => 'Katılanlar',
      ),
      'Losses' => 
      array (
        0 => 'Kayıplar',
      ),
      'Total' => 
      array (
        0 => 'Toplam',
      ),
      'Num Plays' => 
      array (
        0 => 'Oynatma Sayısı',
      ),
      'Play %' => 
      array (
        0 => 'Oynama Yüzdesi',
      ),
      'Ratio' => 
      array (
        0 => 'Oran',
      ),
      'Song Listener Impact' => 
      array (
        0 => 'Şarkı Dinleyici Etkisi',
      ),
      'Date Requested' => 
      array (
        0 => 'Talep Edilen Tarih',
      ),
      'Date Played' => 
      array (
        0 => 'Oynatılan Tarih',
      ),
      'Requester IP' => 
      array (
        0 => 'Talep Eden IP',
      ),
      'Delete Request?' => 
      array (
        0 => 'İstek silinsin mi?',
      ),
      'Clear All Pending Requests?' => 
      array (
        0 => 'Bekleyen tüm istekler silinsin mi?',
      ),
      'Clear Pending Requests' => 
      array (
        0 => 'Bekleyen İstekleri Temizle',
      ),
      'Not Played' => 
      array (
        0 => 'Oynatılmadı',
      ),
      'Listeners by Day' => 
      array (
        0 => 'Günlük Dinleyiciler',
      ),
      'Listeners by Day of Week' => 
      array (
        0 => 'Haftanın Günlerine Göre Dinleyiciler',
      ),
      'Listeners by Hour' => 
      array (
        0 => 'Saatlik Dinleyiciler',
      ),
      'Best Performing Songs' => 
      array (
        0 => 'En İyi Performanslı Şarkılar',
      ),
      'in the last 48 hours' => 
      array (
        0 => 'son 48 saatte',
      ),
      'Change' => 
      array (
        0 => 'Değiştir',
      ),
      'Song' => 
      array (
        0 => 'Şarkı',
      ),
      'Worst Performing Songs' => 
      array (
        0 => 'En Kötü Performanslı Şarkılar',
      ),
      'Most Played Songs' => 
      array (
        0 => 'En Çok Çalınan Şarkılar',
      ),
      'in the last month' => 
      array (
        0 => 'geçen ayda',
      ),
      'Plays' => 
      array (
        0 => 'Oynatılma',
      ),
      'Date/Time' => 
      array (
        0 => 'Tarih/Saat',
      ),
      'Song Playback Timeline' => 
      array (
        0 => 'Şarkı Oynatma Zaman Çizelgesi',
      ),
      'Live Streamer:' => 
      array (
        0 => 'DJ:',
      ),
      'Name/Type' => 
      array (
        0 => '',
      ),
      'Triggers' => 
      array (
        0 => 'Tetikleyiciler',
      ),
      'Delete Web Hook?' => 
      array (
        0 => 'Web kancası silinsin mi?',
      ),
      'Web Hooks' => 
      array (
        0 => 'Web Kancaları',
      ),
      'Web hooks let you connect to external web services and broadcast changes to your station to them.' => 
      array (
        0 => 'Web kancaları harici web servislerine bağlanmanıza ve radyonuzdaki değişiklikleri onlara yansıtmasınıza izin verir.',
      ),
      'Test' => 
      array (
        0 => 'Deneme',
      ),
      'Song History' => 
      array (
        0 => 'Şarkı Geçmişi',
      ),
      'Request Song' => 
      array (
        0 => 'Şarkı İste',
      ),
      'Request a Song' => 
      array (
        0 => 'Bir Şarkı İsteyin',
      ),
      'Microphone' => 
      array (
        0 => 'Mikrofon',
      ),
      'Cue' => 
      array (
        0 => 'Bağla',
      ),
      'Microphone Source' => 
      array (
        0 => 'Mikrofon Kaynağı',
      ),
      'Stop Streaming' => 
      array (
        0 => 'Yayını Durdur',
      ),
      'Start Streaming' => 
      array (
        0 => 'Yayını Başlat',
      ),
      'Metadata updated!' => 
      array (
        0 => 'Meta verileri güncellendi!',
      ),
      'Settings' => 
      array (
        0 => 'Ayarlar',
      ),
      'Metadata' => 
      array (
        0 => 'Meta Verileri',
      ),
      'Encoder' => 
      array (
        0 => 'Encoder',
      ),
      'MP3' => 
      array (
        0 => 'MP3',
      ),
      'Raw' => 
      array (
        0 => 'HAM DATA',
      ),
      'Sample Rate' => 
      array (
        0 => 'Sample Rate',
      ),
      'Bit Rate' => 
      array (
        0 => 'Bitrate',
      ),
      'DJ Credentials' => 
      array (
        0 => 'DJ Bilgileri',
      ),
      'Use Asynchronous Worker' => 
      array (
        0 => 'Eşzamansız Çalışma Kullan',
      ),
      'Update Metadata' => 
      array (
        0 => 'Meta Verilerini Güncelle',
      ),
      'Mixer' => 
      array (
        0 => 'Mixer',
      ),
      'Playlist 1' => 
      array (
        0 => 'Çalma Listesi 1',
      ),
      'Playlist 2' => 
      array (
        0 => 'Çalma Listesi 2',
      ),
      'Unknown Title' => 
      array (
        0 => 'Bilinmeyen Şarkı İsmi',
      ),
      'Unknown Artist' => 
      array (
        0 => 'Bilinmeyen Sanatçı',
      ),
      'Add Files to Playlist' => 
      array (
        0 => 'Çalma Listesine Ekle',
      ),
      'Continuous Play' => 
      array (
        0 => 'Çalmaya Devam Et',
      ),
      'Repeat Playlist' => 
      array (
        0 => 'Çalma Listesini Tekrarla',
      ),
      'Request' => 
      array (
        0 => 'İstek',
      ),
      'This field is required.' => 
      array (
        0 => 'Bu alan gereklidir.',
      ),
      'This field must have at least %{ min } letters.' => 
      array (
        0 => 'Bu alan en az %{ min } harf içermelidir.',
      ),
      'This field must have at most %{ max } letters.' => 
      array (
        0 => 'Bu alan en fazla %{ max } harf içermelidir.',
      ),
      'This field must be between %{ min } and %{ max }.' => 
      array (
        0 => 'Bu alan %{ min } ile %{ max } arasında olmalıdır.',
      ),
      'This field must only contain alphabetic characters.' => 
      array (
        0 => 'Bu alan yalnızca alfabetik karakterler içermelidir.',
      ),
      'This field must only contain alphanumeric characters.' => 
      array (
        0 => 'Bu alan yalnızca alfasayısal karakterler içermelidir.',
      ),
      'This field must only contain numeric characters.' => 
      array (
        0 => 'Bu alan yalnızca sayısal karakterler içermelidir.',
      ),
      'This field must be a valid integer.' => 
      array (
        0 => 'Bu alan geçerli bir tam sayı olmalıdır.',
      ),
      'This field must be a valid decimal number.' => 
      array (
        0 => 'Bu alan geçerli bir ondalık sayı olmalıdır.',
      ),
      'This field must be a valid e-mail address.' => 
      array (
        0 => 'Bu alan geçerli bir e-posta adresi olmalıdır.',
      ),
      'This field must be a valid IP address.' => 
      array (
        0 => 'Bu alan geçerli bir IP adresi olmalıdır.',
      ),
      'This field must be a valid URL.' => 
      array (
        0 => 'Bu alan geçerli bir URL olmalıdır.',
      ),
      'This password is too common or insecure.' => 
      array (
        0 => '',
      ),
      'Global Permissions' => 
      array (
        0 => 'Global İzinler',
      ),
      'Role Name' => 
      array (
        0 => 'Yetki İsmi',
      ),
      'Users with this role will have these permissions across the entire installation.' => 
      array (
        0 => 'Bu yetkiye sahip kullanıcılar AzuraCast yönetimi üzerinde bu izinlere sahip olacaktır.',
      ),
      'Station Permissions' => 
      array (
        0 => 'Radyo İzinleri',
      ),
      'Users with this role will have these permissions for this single station.' => 
      array (
        0 => 'Bu yetkiye sahip kullanıcılar seçilen tek radyo için bu izinlere sahip olacaktır.',
      ),
      'Add Station' => 
      array (
        0 => 'Radyo Ekle',
      ),
      'Edit Role' => 
      array (
        0 => 'Yetki Düzenle',
      ),
      'Add Role' => 
      array (
        0 => 'Yetki Ekle',
      ),
      'User' => 
      array (
        0 => 'Kullanıcı',
      ),
      'Operation' => 
      array (
        0 => 'Operasyon',
      ),
      'Identifier' => 
      array (
        0 => 'Tanımlayıcı',
      ),
      'Target' => 
      array (
        0 => 'Hedef',
      ),
      'Insert' => 
      array (
        0 => 'Ekle',
      ),
      'Update' => 
      array (
        0 => 'Güncelle',
      ),
      'Audit Log' => 
      array (
        0 => 'Denetim Günlüğü',
      ),
      'N/A' => 
      array (
        0 => 'Bilinmeyen',
      ),
      'Changes' => 
      array (
        0 => 'Değişiklikler',
      ),
      'Field' => 
      array (
        0 => 'Alan',
      ),
      'Previous' => 
      array (
        0 => 'Önceki',
      ),
      'Updated' => 
      array (
        0 => 'Güncellendi',
      ),
      'Broadcasting' => 
      array (
        0 => 'Canlı Yayın',
      ),
      'Only connect to a remote server.' => 
      array (
        0 => '',
      ),
      'Use Icecast 2.4 on this server.' => 
      array (
        0 => '',
      ),
      'Use SHOUTcast DNAS 2 on this server.' => 
      array (
        0 => '',
      ),
      'This software delivers your broadcast to the listening audience.' => 
      array (
        0 => 'Bu yazılım yayınınızı dinleyen kitleye ulaştırır.',
      ),
      'SHOUTcast License ID' => 
      array (
        0 => '',
      ),
      'SHOUTcast User ID' => 
      array (
        0 => '',
      ),
      'Customize Source Password' => 
      array (
        0 => 'Yayın Şifresi',
      ),
      'Leave blank to automatically generate a new password.' => 
      array (
        0 => 'Otomatik olarak bu şifreyi oluşturmak için boş bırakın.',
      ),
      'Customize Administrator Password' => 
      array (
        0 => 'Yayın Yönetici Şifresi',
      ),
      'Customize Broadcasting Port' => 
      array (
        0 => 'Yayın Portu',
      ),
      'No other program can be using this port. Leave blank to automatically assign a port.' => 
      array (
        0 => 'Bu port başka hiçbir programda kullanamaz. Portu otomatik olarak atamak için boş bırakın.',
      ),
      'Maximum Listeners' => 
      array (
        0 => 'Maksimum Dinleyici',
      ),
      'Maximum number of total listeners across all streams. Leave blank to use the default.' => 
      array (
        0 => '',
      ),
      'Banned IP Addresses' => 
      array (
        0 => 'Yasaklanmış IP Adresleri',
      ),
      'List one IP address or group (in CIDR format) per line.' => 
      array (
        0 => 'Her satıra bir IP adresi veya grup (CIDR biçiminde) yazın.',
      ),
      'Allowed IP Addresses' => 
      array (
        0 => 'İzin Verilen IP Adresleri',
      ),
      'Banned Countries' => 
      array (
        0 => 'Yasaklanan Ülkeler',
      ),
      'Select the countries that are not allowed to connect to the streams.' => 
      array (
        0 => 'Canlı yayınlara bağlanmasına izin verilmeyen ülkeleri seçin.',
      ),
      'Clear List' => 
      array (
        0 => '',
      ),
      'Custom Configuration' => 
      array (
        0 => 'Özel Yapılandırma',
      ),
      'This code will be included in the frontend configuration. Allowed formats are:' => 
      array (
        0 => '',
      ),
      'Station Profile' => 
      array (
        0 => 'Radyo Profili',
      ),
      'Web Site URL' => 
      array (
        0 => 'Web Site URLsi',
      ),
      'Note: This should be the public-facing homepage of the radio station, not the AzuraCast URL. It will be included in broadcast details.' => 
      array (
        0 => 'Not: AzuraCast URLsi değil radyonuzun web adresi olmalıdır. Yayın detaylarına eklenecektir.',
      ),
      'Time Zone' => 
      array (
        0 => 'Saat Dilimi',
      ),
      'Scheduled playlists and other timed items will be controlled by this time zone.' => 
      array (
        0 => 'Zamanlanmış çalma listeleri ve zamanlanmış diğer öğeler bu zaman dilimi tarafından kontrol edilir.',
      ),
      'Default Album Art URL' => 
      array (
        0 => 'Varsayılan Albüm Kapağı URLsi',
      ),
      'If a song has no album art, this URL will be listed instead. Leave blank to use the standard placeholder art.' => 
      array (
        0 => 'Bir şarkının albüm kapağı yoksa burada URLsi yazılan resim görünecektir. Varsayılan albüm kapağı için boş bırakın.',
      ),
      'URL Stub' => 
      array (
        0 => 'Sabit URL',
      ),
      'Optionally specify a short URL-friendly name, such as "my_station_name", that will be used in this station\'s URLs. Leave this field blank to automatically create one based on the station name.' => 
      array (
        0 => '',
      ),
      'Number of Visible Recent Songs' => 
      array (
        0 => '',
      ),
      'Customize the number of songs that will appear in the "Song History" section for this station and in all public APIs.' => 
      array (
        0 => 'Bu istasyon için "Şarkı Geçmişi" bölümünde ve tüm ortak API\'lerde görünecek şarkı sayısını belirtin.',
      ),
      'Enable Public Pages' => 
      array (
        0 => '',
      ),
      'Show the station in public pages and general API results.' => 
      array (
        0 => 'Radyonuzu genel sayfalarda ve genel API sonuçlarında gösterin.',
      ),
      'On-Demand Streaming' => 
      array (
        0 => '',
      ),
      'Enable On-Demand Streaming' => 
      array (
        0 => 'İsteğe Bağlı Canlı Yayını Etkinleştir',
      ),
      'If enabled, music from playlists with on-demand streaming enabled will be available to stream via a specialized public page.' => 
      array (
        0 => '',
      ),
      'Enable Downloads on On-Demand Page' => 
      array (
        0 => 'İsteğe Bağlı İndirmeleri Etkinleştir',
      ),
      'If enabled, a download button will also be present on the public "On-Demand" page.' => 
      array (
        0 => '',
      ),
      'Use Liquidsoap on this server.' => 
      array (
        0 => '',
      ),
      'Do not use an AutoDJ service.' => 
      array (
        0 => '',
      ),
      'Smart Mode' => 
      array (
        0 => 'Akıllı Mod',
      ),
      'Normal Mode' => 
      array (
        0 => 'Normal Mod',
      ),
      'Disable Crossfading' => 
      array (
        0 => 'Kapat',
      ),
      'This software shuffles from playlists of music constantly and plays when no other radio source is available.' => 
      array (
        0 => 'Bu yazılım çalma listesindeki müzikleri otomatik olarak çalar.',
      ),
      'Crossfade Method' => 
      array (
        0 => 'Crossfade Seçenekleri',
      ),
      'Choose a method to use when transitioning from one song to another. Smart Mode considers the volume of the two tracks when fading for a smoother effect, but requires more CPU resources.' => 
      array (
        0 => 'Bir şarkıdan diğerine geçiş yaparken kullanılacak bir yöntemi belirleyin.  Akıllı Mod daha yumuşak bir efekt ile geçişi yaparken iki parçanın sesini dikkate alır ancak daha fazla CPU kaynağı gerektirir.',
      ),
      'Crossfade Duration (Seconds)' => 
      array (
        0 => 'Crossfade Süresi (saniye)',
      ),
      'Number of seconds to overlap songs.' => 
      array (
        0 => 'Şarkıların üst üste geleceği zamanı belirleyin.',
      ),
      'Apply Compression and Normalization' => 
      array (
        0 => 'Normalleştirme ve Sıkıştırma Uygula',
      ),
      'Compress and normalize your station\'s audio, producing a more uniform and "full" sound.' => 
      array (
        0 => 'Daha düzenli ve "tam" bir ses üreten radyonuzun sesini sıkıştırın ve normalleştirin.',
      ),
      'Some stream licensing providers may have specific rules regarding song requests. Check your local regulations for more information.' => 
      array (
        0 => '',
      ),
      'Allow Song Requests' => 
      array (
        0 => 'Şarkı İsteklerine İzin Ver',
      ),
      'Enable listeners to request a song for play on your station. Only songs that are already in your playlists are requestable.' => 
      array (
        0 => 'Dinleyicilerin yalnızca çalma listelerinde bulunan şarkıları indirmeleri için bu seçeceği etkinleştirebilirsiniz.',
      ),
      'Request Minimum Delay (Minutes)' => 
      array (
        0 => 'Minumum Gecikme İsteği (dakika)',
      ),
      'If requests are enabled, this specifies the minimum delay (in minutes) between a request being submitted and being played. If set to zero, a minor delay of 15 seconds is applied to prevent request floods.' => 
      array (
        0 => '',
      ),
      'Request Last Played Threshold (Minutes)' => 
      array (
        0 => 'En Son Oynatma Aralığı İsteği (dakika)',
      ),
      'This specifies the minimum time (in minutes) between a song playing on the radio and being available to request again. Set to 0 for no threshold.' => 
      array (
        0 => '',
      ),
      'Streamers / DJs' => 
      array (
        0 => '',
      ),
      'Allow Streamers / DJs' => 
      array (
        0 => 'DJlere İzin Ver',
      ),
      'If enabled, streamers (or DJs) will be able to connect directly to your stream and broadcast live music that interrupts the AutoDJ stream.' => 
      array (
        0 => 'Etkinleştirildiğinde DJler doğrudan yayına bağlanabilir ve AutoDJ yayını kesilerek canlı müzik yayınlanır.',
      ),
      'Record Live Broadcasts' => 
      array (
        0 => 'Canlı Yayını Kaydet',
      ),
      'If enabled, AzuraCast will automatically record any live broadcasts made to this station to per-broadcast recordings.' => 
      array (
        0 => 'Etkinleştirilirse, AzuraCast bu istasyona yapılan tüm canlı yayınları yayın başına kayıtlara otomatik olarak kaydeder.',
      ),
      'Live Broadcast Recording Format' => 
      array (
        0 => 'Canlı Yayın Kayıt Formatı',
      ),
      'Live Broadcast Recording Bitrate (kbps)' => 
      array (
        0 => 'Canlı Yayın Kayıt Bit Hızı (kbps)',
      ),
      'Deactivate Streamer on Disconnect (Seconds)' => 
      array (
        0 => 'DJ Bağlantısı Kesmede Devredışı Bırakma Süresi (saniye)',
      ),
      'This is the number of seconds until a streamer who has been manually disconnected can reconnect to the stream. Set to 0 to allow the streamer to immediately reconnect.' => 
      array (
        0 => '',
      ),
      'Customize DJ/Streamer Port' => 
      array (
        0 => 'DJ Portu',
      ),
      'Note: the port after this one will automatically be used for legacy connections.' => 
      array (
        0 => '',
      ),
      'DJ/Streamer Buffer Time (Seconds)' => 
      array (
        0 => 'DJ Arabellek Zamanı (saniye)',
      ),
      'The number of seconds of signal to store in case of interruption. Set to the lowest value that your DJs can use without stream interruptions.' => 
      array (
        0 => 'Kesinti sırasında saklanacak sinyalin saniyesini belirleyin. DJlerin yayın kesintileri olmadan kullanabileceği en düşük değere ayarlayın.',
      ),
      'Customize DJ/Streamer Mount Point' => 
      array (
        0 => 'DJ Bağlantı Noktası',
      ),
      'If your streaming software requires a specific mount point path, specify it here. Otherwise, use the default.' => 
      array (
        0 => 'Canlı yayın yazılımınız belirli bir bağlantı noktası yolu gerektiriyorsa burada belirtin. Aksi takdirde varsayılanı kullanın.',
      ),
      'Advanced Configuration' => 
      array (
        0 => '',
      ),
      'Customize Internal Request Processing Port' => 
      array (
        0 => 'İstek Portu',
      ),
      'This port is not used by any external process. Only modify this port if the assigned port is in use. Leave blank to automatically assign a port.' => 
      array (
        0 => 'Bu port başka hiçbir programda kullanamaz. Portu otomatik olarak atamak için boş bırakın. Bu portu yalnızca atanmış port kullanılıyorsa değiştirin.',
      ),
      'Use Replaygain Metadata' => 
      array (
        0 => 'Replaygain Meta Verilerini Kullan',
      ),
      'Instruct Liquidsoap to use any replaygain metadata associated with a song to control its volume level.' => 
      array (
        0 => 'Liquidsoap cihazına ses seviyesini kontrol etmek için bir şarkıyla ilişkili herhangi bir replaygain meta verisini kullanması talimatını verin.',
      ),
      'AutoDJ Queue Length' => 
      array (
        0 => 'AutoDJ Kuyruk Uzunluğu',
      ),
      'This determines how many songs in advance the AutoDJ will automatically fill the queue.' => 
      array (
        0 => '',
      ),
      'Manual AutoDJ Mode' => 
      array (
        0 => 'Manuel AutoDJ Modu',
      ),
      'This mode disables AzuraCast\'s AutoDJ management, using Liquidsoap itself to manage song playback. "Next Song" and some other features will not be available.' => 
      array (
        0 => 'Bu mod AutoDJ yönetimini devre dışı bırakır ve şarkı çalmayı yönetmek için Liquidsoap işlevini kullanır. "Sıradaki Şarkı" ve diğer bazı özellikler kullanılamayacaktır.',
      ),
      'Character Set Encoding' => 
      array (
        0 => 'Kodlama Karakter Seti',
      ),
      'For most cases, use the default UTF-8 encoding. The older ISO-8859-1 encoding can be used if accepting connections from SHOUTcast 1 DJs or using other legacy software.' => 
      array (
        0 => 'Çoğu durumda varsayılan UTF-8 kodlamasını kullanın. Eski yazılım kullanılıyorsa ISO-8859-1 kodlaması kullanılabilir.',
      ),
      'Duplicate Prevention Time Range (Minutes)' => 
      array (
        0 => 'Yinelenen Önleme Süresi Aralığı (Dakika)',
      ),
      'This specifies the time range (in minutes) of the song history that the duplicate song prevention algorithm should take into account.' => 
      array (
        0 => 'Bu, yinelenen şarkı önleme algoritmasının hesaba katması gereken şarkı geçmişinin zaman aralığını (dakika cinsinden) belirtir.',
      ),
      'Enable Broadcasting' => 
      array (
        0 => 'Yayını Etkinleştir',
      ),
      'If disabled, the station will not broadcast or shuffle its AutoDJ.' => 
      array (
        0 => 'Devre dışı bırakılırsa radyonuz çalmaz ve AutoDJ veya DJler yayın yapamazlar.',
      ),
      'Base Station Directory' => 
      array (
        0 => 'Radyo Temel Dizini',
      ),
      'The parent directory where station playlist and configuration files are stored. Leave blank to use default directory.' => 
      array (
        0 => 'Radyo çalma listesi ve ayar dosyalarının saklanacağı dizini belirtin. Varsayılan dizini kullanmak için boş bırakın.',
      ),
      'Media Storage Location' => 
      array (
        0 => 'Müzik Dosyaları Depolama Konumu',
      ),
      'Live Recordings Storage Location' => 
      array (
        0 => 'Canlı Yayın Depolama Yeri',
      ),
      'Podcasts Storage Location' => 
      array (
        0 => 'Podcast Depolama Konumu',
      ),
      'Clone Station' => 
      array (
        0 => '',
      ),
      '%{station} - Copy' => 
      array (
        0 => '',
      ),
      'Edit Station' => 
      array (
        0 => 'Radyo Düzenle',
      ),
      'Share Media Storage Location' => 
      array (
        0 => 'Müzik Dosyaları Depolama Konumunu Paylaş',
      ),
      'Share Recordings Storage Location' => 
      array (
        0 => 'Canlı Yayın Kayıtlarının Depolama Konumunu Paylaş',
      ),
      'Share Podcasts Storage Location' => 
      array (
        0 => 'Podcast Depolama Konumunu Paylaş',
      ),
      'User Permissions' => 
      array (
        0 => 'Kullanıcı İzinleri',
      ),
      'New Station Name' => 
      array (
        0 => 'Yeni Radyo İsmi',
      ),
      'New Station Description' => 
      array (
        0 => 'Yeni Radyo Açıklaması',
      ),
      'Copy to New Station' => 
      array (
        0 => '',
      ),
      'Permissions' => 
      array (
        0 => 'İzinler',
      ),
      'Delete Role?' => 
      array (
        0 => 'Yetki silinsin mi?',
      ),
      'Roles & Permissions' => 
      array (
        0 => 'Yetkiler ve İzinler',
      ),
      'AzuraCast uses a role-based access control system. Roles are given permissions to certain sections of the site, then users are assigned into those roles.' => 
      array (
        0 => 'AzuraCast yetki tabanlı bir erişim kontrol sistemi kullanır. Yetkilerle sitenin belirli bölümlerine izin verilir ve ardından kullanıcılar bu yetkilere atanır.',
      ),
      'Global' => 
      array (
        0 => 'Global',
      ),
      'Storage Adapter' => 
      array (
        0 => 'Depolama Adaptörü',
      ),
      'Local Filesystem' => 
      array (
        0 => 'Yerel Dosya Sistemi',
      ),
      'Remote: S3 Compatible' => 
      array (
        0 => 'Uzak: S3 Uyumlu',
      ),
      'Remote: Dropbox' => 
      array (
        0 => 'Uzak: Dropbox',
      ),
      'Path/Suffix' => 
      array (
        0 => 'Yol/Son Ek',
      ),
      'For local filesystems, this is the base path of the directory. For remote filesystems, this is the folder prefix.' => 
      array (
        0 => 'Bu yerel dosya sistemleri için dizinin temel yoludur. Bu uzak dosya sistemleri için klasör önekidir.',
      ),
      'Storage Quota' => 
      array (
        0 => 'Depolama Alanı',
      ),
      'Set a maximum disk space that this storage location can use. Specify the size with unit, i.e. "8 GB". Units are measured in 1024 bytes. Leave blank to default to the available space on the disk.' => 
      array (
        0 => 'Bu radyonun kullanabileceği maksimum disk alanı ayarlayın. Boş bırakırsanız sunucu depolama alanı dolana kadar kullanılabilir. Depolama alanı büyüklüğünü 1024 bayt cinsinden hesaplayarak yazmalınısız. Örnek: "2 GB" veya "2048 MB"',
      ),
      'Access Key ID' => 
      array (
        0 => 'Erişim Anahtarı Kimliği',
      ),
      'Secret Key' => 
      array (
        0 => 'Güvenlik Anahtarı',
      ),
      'Endpoint' => 
      array (
        0 => 'Uç Noktası',
      ),
      'Bucket Name' => 
      array (
        0 => 'Kova Adı',
      ),
      'Region' => 
      array (
        0 => 'Bölge',
      ),
      'API Version' => 
      array (
        0 => 'API Sürümü',
      ),
      'Dropbox Generated Access Token' => 
      array (
        0 => 'Dropbox Tarafından Oluşturulan Erişim Anahtarı',
      ),
      'Learn More about Dropbox Auth Tokens' => 
      array (
        0 => 'Dropbox Kimlik Doğrulama Hakkında Daha Fazla Bilgi Edinin',
      ),
      'Edit Storage Location' => 
      array (
        0 => 'Depolama Konumunu Düzenle',
      ),
      'Add Storage Location' => 
      array (
        0 => 'Depolama Konumu Ekle',
      ),
      'GeoLite version "%{ version }" is currently installed.' => 
      array (
        0 => 'GeoLite %{ version } versiyonu kuruludur.',
      ),
      'Install GeoLite IP Database' => 
      array (
        0 => 'GeoLite IP Veritabanı Kurulumu',
      ),
      'IP Geolocation is used to guess the approximate location of your listeners based on the IP address they connect with. Use the free built-in IP Geolocation library or enter a license key on this page to use MaxMind GeoLite.' => 
      array (
        0 => '',
      ),
      'Instructions' => 
      array (
        0 => 'Talimatlar',
      ),
      'AzuraCast ships with a built-in free IP geolocation database. You may prefer to use the MaxMind GeoLite service instead to achieve more accurate results. Using MaxMind GeoLite requires a license key, but once the key is provided, we will automatically keep the database updated.' => 
      array (
        0 => '',
      ),
      'To download the GeoLite database:' => 
      array (
        0 => '',
      ),
      'Create an account on the MaxMind developer site.' => 
      array (
        0 => '',
      ),
      'MaxMind Developer Site' => 
      array (
        0 => '',
      ),
      'Visit the "My License Key" page under the "Services" section.' => 
      array (
        0 => '"Hizmetler" bölümünün altındaki "Lisans Anahtarım" sayfasını ziyaret edin.',
      ),
      'Click "Generate new license key".' => 
      array (
        0 => '"Yeni lisans anahtarı oluştur"u tıklayın.',
      ),
      'Paste the generated license key into the field on this page.' => 
      array (
        0 => 'Oluşturulan lisans anahtarını bu sayfadaki alana yapıştırınız.',
      ),
      'Current Installed Version' => 
      array (
        0 => 'Kurulmuş Mevcut Sürüm',
      ),
      'GeoLite is not currently installed on this installation.' => 
      array (
        0 => 'GeoLite henüz kurulmamıştır.',
      ),
      'MaxMind License Key' => 
      array (
        0 => 'MaxMind Lisans Anahtarı',
      ),
      'Remove Key' => 
      array (
        0 => 'Anahtarı Kaldır',
      ),
      'Delete Station?' => 
      array (
        0 => '',
      ),
      'Stations' => 
      array (
        0 => 'Radyolar',
      ),
      'Clone' => 
      array (
        0 => 'Kopyalama',
      ),
      'Field Name' => 
      array (
        0 => 'Alan Adı',
      ),
      'This will be used as the label when editing individual songs, and will show in API results.' => 
      array (
        0 => 'Tek tek şarkıları düzenlerken etiket olarak kullanılacak ve API sonuçlarında gösterilecektir.',
      ),
      'Programmatic Name' => 
      array (
        0 => 'Program İsmi',
      ),
      'Optionally specify an API-friendly name, such as "field_name". Leave this field blank to automatically create one based on the name.' => 
      array (
        0 => 'İsteğe bağlı olarak "field_name" gibi bir API dostu isim belirtin. İsme göre otomatik olarak bir tane oluşturmak için bu alanı boş bırakın.',
      ),
      'Automatically Set from ID3v2 Value' => 
      array (
        0 => 'ID3v2 Değerinden Otomatik Olarak Ayarla',
      ),
      'Optionally select an ID3v2 metadata field that, if present, will be used to set this field\'s value.' => 
      array (
        0 => 'İsteğe bağlı olarak varsa bu alanın değerini ayarlamak için kullanılacak bir ID3v2 metadata alanı belirtin.',
      ),
      'Edit Custom Field' => 
      array (
        0 => 'Özel Alan Düzenle',
      ),
      'Add Custom Field' => 
      array (
        0 => 'Özel Alan Ekle',
      ),
      'Adapter' => 
      array (
        0 => 'Adaptör',
      ),
      'Station(s)' => 
      array (
        0 => 'Radyo(lar)',
      ),
      'Station Media' => 
      array (
        0 => 'Radyo Müzik Dosyaları',
      ),
      'Station Recordings' => 
      array (
        0 => 'Radyo Canlı Yayın Kayıtları',
      ),
      'Station Podcasts' => 
      array (
        0 => 'Radyo Podcastleri',
      ),
      'Backups' => 
      array (
        0 => 'Yedekleme',
      ),
      'Applying changes...' => 
      array (
        0 => 'Değişiklikler Uygulanıyor...',
      ),
      'Delete Storage Location?' => 
      array (
        0 => 'Depolama yeri silinsin mi?',
      ),
      'Storage Locations' => 
      array (
        0 => 'Depolama Yönetimi',
      ),
      'SHOUTcast version "%{ version }" is currently installed.' => 
      array (
        0 => 'SHOUTcast %{ version } versiyonu kuruludur.',
      ),
      'Install SHOUTcast 2 DNAS' => 
      array (
        0 => 'SHOUTcast Kurulumu',
      ),
      'SHOUTcast 2 DNAS is not free software, and its restrictive license does not allow AzuraCast to distribute the SHOUTcast binary.' => 
      array (
        0 => '',
      ),
      'In order to install SHOUTcast:' => 
      array (
        0 => '',
      ),
      'Download the Linux x64 binary from the SHOUTcast Radio Manager:' => 
      array (
        0 => '',
      ),
      'SHOUTcast Radio Manager' => 
      array (
        0 => '',
      ),
      'The file name should look like:' => 
      array (
        0 => '',
      ),
      'Upload the file on this page to automatically extract it into the proper directory.' => 
      array (
        0 => '',
      ),
      'SHOUTcast 2 DNAS is not currently installed on this installation.' => 
      array (
        0 => 'SHOUTcast henüz kurulmamıştır.',
      ),
      'Services' => 
      array (
        0 => 'Hizmetler',
      ),
      'Stable' => 
      array (
        0 => 'Kararlı',
      ),
      'Rolling Release' => 
      array (
        0 => 'Değişiklikler Günlüğü',
      ),
      'AzuraCast Update Checks' => 
      array (
        0 => 'AzuraCast Güncelleme Kontrolleri',
      ),
      'Current Release Channel' => 
      array (
        0 => 'Mevcut Güncelleme Kanalı',
      ),
      'Learn more about release channels in the AzuraCast docs.' => 
      array (
        0 => '',
      ),
      'Show Update Announcements' => 
      array (
        0 => 'Güncelleme Duyurularını Göster',
      ),
      'Show new releases within your update channel on the AzuraCast homepage.' => 
      array (
        0 => 'AzuraCast anasayfasında güncelleme kanalınızda yeni sürümleri gösterin.',
      ),
      'E-mail Delivery Service' => 
      array (
        0 => 'E-posta İletim Raporu Hizmeti',
      ),
      'Used for "Forgot Password" functionality, web hooks and other functions.' => 
      array (
        0 => '"Şifremi Unuttum" sistemi web kancaları ve diğer işlevler için kullanılır.',
      ),
      'Enable Mail Delivery' => 
      array (
        0 => 'E-Posta İletim Raporunu Etkinleştir',
      ),
      'Sender Name' => 
      array (
        0 => 'Gönderen Adı',
      ),
      'Sender E-mail Address' => 
      array (
        0 => 'Gönderen E-posta Adresi',
      ),
      'SMTP Host' => 
      array (
        0 => 'SMTP Sunucusu',
      ),
      'SMTP Port' => 
      array (
        0 => 'SMTP Port',
      ),
      'Use Secure (TLS) SMTP Connection' => 
      array (
        0 => 'Güvenli (TLS) SMTP Bağlantısını Kullan',
      ),
      'Usually enabled for port 465, disabled for ports 587 or 25.' => 
      array (
        0 => 'Genellikle 465 numaralı bağlantı portu için etkinleştirilir. 587 veya 25 numaralı bağlantı portları için devre dışı bırakılır.',
      ),
      'SMTP Username' => 
      array (
        0 => 'SMTP Kullanıcı Adı',
      ),
      'SMTP Password' => 
      array (
        0 => 'SMTP Şifresi',
      ),
      'Avatar Services' => 
      array (
        0 => 'Avatar Servisleri',
      ),
      'Avatar Service' => 
      array (
        0 => 'Avatar Servisi',
      ),
      'Default Avatar URL' => 
      array (
        0 => 'Varsayılan Avatar URLsi',
      ),
      'Album Art Services' => 
      array (
        0 => 'Albüm Kapağı Servisleri',
      ),
      'Check Web Services for Album Art for "Now Playing" Tracks' => 
      array (
        0 => '"Şimdi Çalan" Parçalar için Albüm Resmi için Web Hizmetlerini Kontrol Edin',
      ),
      'Check Web Services for Album Art When Uploading Media' => 
      array (
        0 => 'Müzik Dosyası Yüklerken Albüm Resmi için Web Hizmetlerini Kontrol Edin',
      ),
      'Last.fm API Key' => 
      array (
        0 => 'Last.fm API Anahtarı',
      ),
      'This service can provide album art for tracks where none is available locally.' => 
      array (
        0 => '',
      ),
      'Apply for an API key at Last.fm' => 
      array (
        0 => '',
      ),
      'Last 60 Days' => 
      array (
        0 => 'Son 60 Gün',
      ),
      'Last Year' => 
      array (
        0 => 'Geçen Yıl',
      ),
      'Last 2 Years' => 
      array (
        0 => 'Son 2 Yıl',
      ),
      'Indefinitely' => 
      array (
        0 => 'Süresiz',
      ),
      'Site Base URL' => 
      array (
        0 => 'Sunucu Kontrol Paneli URLsi',
      ),
      'The base URL where this service is located. Use either the external IP address or fully-qualified domain name (if one exists) pointing to this server.' => 
      array (
        0 => 'Sunucu kontrol paneli URL tam adresi veya IP adresini yazın.',
      ),
      'AzuraCast Instance Name' => 
      array (
        0 => 'AzuraCast Slogan İsmi',
      ),
      'This name will appear as a sub-header next to the AzuraCast logo, to help identify this server.' => 
      array (
        0 => 'AzuraCast logosunun yanında yer alacak slogan adını yazın.',
      ),
      'Prefer Browser URL (If Available)' => 
      array (
        0 => 'Tarayıcı URLsini Tercih Et (Varsa)',
      ),
      'If this setting is set to "Yes", the browser URL will be used instead of the base URL when it\'s available. Set to "No" to always use the base URL.' => 
      array (
        0 => 'Bu ayar "Evet" olarak ayarlanmışsa kullanılabilir olduğunda temel URL yerine tarayıcı URLsi kullanılacaktır. Her zaman temel URLyi kullanmak için "Hayır" olarak ayarlayın.',
      ),
      'Use Web Proxy for Radio' => 
      array (
        0 => 'Radyolar İçin Proxy Kullan',
      ),
      'By default, radio stations broadcast on their own ports (i.e. 8000). If you\'re using a service like CloudFlare or accessing your radio station by SSL, you should enable this feature, which routes all radio through the web ports (80 and 443).' => 
      array (
        0 => 'Varsayılan olarak radyo istasyonları kendi bağlantı noktalarında (örnek: 8000) yayın yapar. CloudFlare gibi bir servis kullanıyorsanız veya radyo istasyonunuza SSL ile erişiyorsanız, tüm radyoları web bağlantı noktalarından (80 ve 443) yönlendiren bu özelliği etkinleştirmelisiniz.',
      ),
      'Days of Playback History to Keep' => 
      array (
        0 => 'Çalma Geçmişini Saklama',
      ),
      'Set longer to preserve more playback history and listener metadata for stations. Set shorter to save disk space.' => 
      array (
        0 => '',
      ),
      'Use WebSockets for Now Playing Updates' => 
      array (
        0 => 'Çalan Şarkı Bilgisi İçin WebSocket Kullanın',
      ),
      'Enables or disables the use of the newer and faster WebSocket-based system for receiving live updates on public players. You may need to disable this if you encounter problems with it.' => 
      array (
        0 => 'Genel oynatıcılarda canlı güncellemeler almak için daha yeni ve daha hızlı WebSocket tabanlı sistemin kullanımını etkinleştirir veya devredışı bırakır. Bir sorunla karşılaşırsanız bunu devredışı bırakmanız gerekebilir.',
      ),
      'Enable Advanced Features' => 
      array (
        0 => 'Gelişmiş Özellikleri Etkinleştir',
      ),
      'Enable certain advanced features in the web interface, including advanced playlist configuration, station port assignment, changing base media directories and other functionality that should only be used by users who are comfortable with advanced functionality.' => 
      array (
        0 => 'Gelişmiş çalma listesi yapılandırması, istasyon bağlantı noktası ataması, temel ortam dizinlerini değiştirme ve yalnızca gelişmiş işlevlerden memnun olan kullanıcılar tarafından kullanılması gereken diğer işlevler dahil olmak üzere web arayüzündeki bazı gelişmiş özellikleri etkinleştirin.',
      ),
      'Security & Privacy' => 
      array (
        0 => '',
      ),
      'Privacy' => 
      array (
        0 => 'Gizlilik',
      ),
      'Listener Analytics Collection' => 
      array (
        0 => 'Dinleyici İstatistik Koleksiyonu',
      ),
      'Aggregate listener statistics are used to show station reports across the system. IP-based listener statistics are used to view live listener tracking and may be required for royalty reports.' => 
      array (
        0 => 'Dinleyici istatistik koleksiyonu sistemdeki radyo raporlarını göstermek için kullanılır. IP tabanlı dinleyici istatistikleri canlı dinleyici izlemesini görüntülemek için kullanılır ve telif hakkı raporları için gerekli olabilir.',
      ),
      'Full:' => 
      array (
        0 => 'Dolu:',
      ),
      'Collect aggregate listener statistics and IP-based listener statistics' => 
      array (
        0 => 'Toplu dinleyici istatistiklerini ve IP tabanlı dinleyici istatistiklerini toplayın',
      ),
      'Limited:' => 
      array (
        0 => 'Sınırlı:',
      ),
      'Only collect aggregate listener statistics' => 
      array (
        0 => 'Yalnızca toplu dinleyici istatistiklerini topla',
      ),
      'None:' => 
      array (
        0 => 'Hiçbiri:',
      ),
      'Do not collect any listener analytics' => 
      array (
        0 => 'Herhangi bir dinleyici istatistiği toplamayın',
      ),
      'Security' => 
      array (
        0 => 'Güvenlik',
      ),
      'Always Use HTTPS' => 
      array (
        0 => 'Her Zaman HTTPS Kullan',
      ),
      'Set to "Yes" to always use "https://" secure URLs, and to automatically redirect to the secure URL when an insecure URL is visited.' => 
      array (
        0 => '"Evet" olarak ayarlandığında her zaman güvenli bağlantı "https://" kullanılır.',
      ),
      'API "Access-Control-Allow-Origin" Header' => 
      array (
        0 => '"Access-Control-Allow-Origin" API Başlığı',
      ),
      'Set to * to allow all sources, or specify a list of origins separated by a comma (,).' => 
      array (
        0 => '',
      ),
      'Learn more about this header.' => 
      array (
        0 => 'Bu başlık hakkında daha fazla bilgi edinin.',
      ),
      'Auto-Assign Value' => 
      array (
        0 => 'Otomatik Atanmış Değer',
      ),
      'None' => 
      array (
        0 => 'Hiçbiri',
      ),
      'Delete Custom Field?' => 
      array (
        0 => 'Özel alan silinsin mi?',
      ),
      'Create custom fields to store extra metadata about each media file uploaded to your station libraries.' => 
      array (
        0 => 'Radyo müzik dosyalarına yüklenen her müzik dosyası hakkında fazladan meta verisi depolamak için özel alanlar oluşturun.',
      ),
      'Changes saved.' => 
      array (
        0 => 'Değişiklikler Kaydedildi.',
      ),
      'System Settings' => 
      array (
        0 => 'Sistem Ayarları',
      ),
      'Browser Icon' => 
      array (
        0 => 'Tarayıcı Simgesi',
      ),
      'Public Page Background' => 
      array (
        0 => 'Genel Sayfa Arkaplanı',
      ),
      'Default Album Art' => 
      array (
        0 => 'Varsayılan Albüm Kapağı',
      ),
      'Custom Branding' => 
      array (
        0 => 'Marka Yönetimi',
      ),
      'Upload Custom Assets' => 
      array (
        0 => 'Marka Görünümü Özelleştir',
      ),
      'Clear Image' => 
      array (
        0 => 'Resmi Temizle',
      ),
      'Prefer System Default' => 
      array (
        0 => 'Sistem Varsayılanını Kullan',
      ),
      'Branding Settings' => 
      array (
        0 => 'Marka Ayarları',
      ),
      'Base Theme for Public Pages' => 
      array (
        0 => 'Site Teması',
      ),
      'Select a theme to use as a base for station public pages and the login page.' => 
      array (
        0 => 'Radyo genel sayfaları ve giriş sayfası için kullanılacak bir tema seçin.',
      ),
      'Hide Album Art on Public Pages' => 
      array (
        0 => 'Genel Sayfalarda Albüm Kapağını Gizle',
      ),
      'If selected, album art will not display on public-facing radio pages.' => 
      array (
        0 => 'Genel sayfalarda albüm kapak resmini gizlemek için etkinleştirin.',
      ),
      'Hide AzuraCast Branding on Public Pages' => 
      array (
        0 => 'AzuraCast Markasını Gizle',
      ),
      'If selected, this will remove the AzuraCast branding from public-facing pages.' => 
      array (
        0 => 'AzuraCast markasını genel sayfa ve giriş ekranından gizlemek için etkinleştirin.',
      ),
      'Homepage Redirect URL' => 
      array (
        0 => 'Anasayfa Yönlendirme URLsi',
      ),
      'If a visitor is not signed in and visits the AzuraCast homepage, you can automatically redirect them to the URL specified here. Leave blank to redirect them to the login screen by default.' => 
      array (
        0 => 'Bir ziyaretçi oturum açmamışsa ve AzuraCast anasayfasını ziyaret ediyorsa onları otomatik olarak burada belirtilen URLye yönlendirebilirsiniz. Varsayılan olarak giriş ekranına yönlendirmek için boş bırakın.',
      ),
      'Custom CSS for Public Pages' => 
      array (
        0 => 'Genel Sayfalar İçin Özelleştirilmiş CSS',
      ),
      'This CSS will be applied to the station public pages and login page.' => 
      array (
        0 => 'Bu CSS genel sayfa ve giriş sayfasına uygulanacaktır.',
      ),
      'Custom JS for Public Pages' => 
      array (
        0 => 'Genel Sayfalar İçin Özelleştirilmiş JS',
      ),
      'This javascript code will be applied to the station public pages and login page.' => 
      array (
        0 => 'Bu JS genel sayfa ve giriş sayfasına uygulanacaktır.',
      ),
      'Custom CSS for Internal Pages' => 
      array (
        0 => 'Dahili Sayfalar İçin Özelleştirilmiş CSS',
      ),
      'This CSS will be applied to the main management pages, like this one.' => 
      array (
        0 => 'Bu CSS yönetim sayfalarına uygulanacaktır.',
      ),
      'Seek' => 
      array (
        0 => 'Arama',
      ),
      'Create Account' => 
      array (
        0 => 'Hesap Oluştur',
      ),
      'Create Station' => 
      array (
        0 => 'Radyo Oluştur',
      ),
      'AzuraCast First-Time Setup' => 
      array (
        0 => 'AzuraCast İlk Kurulumu',
      ),
      'Welcome to AzuraCast!' => 
      array (
        0 => 'AzuraCast\'e Hoşgeldiniz!',
      ),
      'Let\'s get started by creating your Super Administrator account.' => 
      array (
        0 => 'Süper yönetici hesabınızı oluşturarak başlayalım.',
      ),
      'This account will have full access to the system, and you\'ll automatically be logged in to it for the rest of setup.' => 
      array (
        0 => 'Bu hesap sisteme tam erişime sahip olacak ve kurulumun geri kalanında otomatik olarak oturum açmış olacaksınız.',
      ),
      'E-mail Address' => 
      array (
        0 => 'E-Posta Adresi',
      ),
      'Create a New Radio Station' => 
      array (
        0 => 'Yeni Bir Radyo Oluştur',
      ),
      'Continue the setup process by creating your first radio station below. You can edit any of these details later.' => 
      array (
        0 => 'İlk radyonuzu aşağıdan oluşturarak kurulum işlemine devam edin. Bu ayrıntılardan herhangi birini daha sonra düzenleyebilirsiniz.',
      ),
      'Create and Continue' => 
      array (
        0 => '',
      ),
      'Customize AzuraCast Settings' => 
      array (
        0 => 'AzuraCast Ayarlarını Özelleştir',
      ),
      'Complete the setup process by providing some information about your broadcast environment. These settings can be changed later from the administration panel.' => 
      array (
        0 => 'Yayın ortamınız hakkında biraz bilgi vererek kurulum işlemini tamamlayın. Bu ayarları daha sonra yönetim panelinden değiştirilebilir.',
      ),
      'Save and Continue' => 
      array (
        0 => 'Kaydet ve Devam Et',
      ),
      'An error occurred and your request could not be completed.' => 
      array (
        0 => 'Bir hata oluştu ve işleminiz tamamlanamadı.',
      ),
      'Error' => 
      array (
        0 => '',
      ),
      'Success' => 
      array (
        0 => '',
      ),
      'Please wait...' => 
      array (
        0 => 'Lütfen bekleyin...',
      ),
      'Delete Record?' => 
      array (
        0 => '',
      ),
      'The locale to use for CLI commands.' => 
      array (
        0 => 'CLI komutları için kullanılacak yerel ayarlar.',
      ),
      'The application environment.' => 
      array (
        0 => 'Uygulama Ortamı',
      ),
      'Manually modify the logging level.' => 
      array (
        0 => 'Günlük seviyesini manuel olarak değiştirin.',
      ),
      'This allows you to log debug-level errors temporarily (for problem-solving) or reduce the volume of logs that are produced by your installation, without needing to modify whether your installation is a production or development instance.' => 
      array (
        0 => 'Bu kurulumunuzun bir üretim veya geliştirme örneği olup olmadığını değiştirmenize gerek kalmadan hata ayıklama düzeyindeki hataları geçici olarak (sorun çözmek için) günlüğe kaydetmenize veya kurulumunuz tarafından üretilen günlüklerin boyutlarını azaltmanıza olanak tanır.',
      ),
      'Composer Plugin Mode' => 
      array (
        0 => 'Composer Eklenti Modu',
      ),
      'Enable the composer "merge" functionality to combine the main application\'s composer.json file with any plugin composer files. This can have performance implications, so you should only use it if you use one or more plugins with their own Composer dependencies.' => 
      array (
        0 => 'Ana uygulamanın composer.json dosyasını herhangi bir eklenti oluşturucu dosyasıyla birleştirmek için composer "merge" işlevini etkinleştirin. Bunun performans etkileri olabilir. Bu nedenle yalnızca kendi Composer bağımlılıklarına sahip bir veya daha fazla eklenti kullanıyorsanız kullanmalısınız.',
      ),
      'Minimum Port for Station Port Assignment' => 
      array (
        0 => 'Radyolar İçin Minimum Port Numarası',
      ),
      'Modify this if your stations are listening on nonstandard ports.' => 
      array (
        0 => 'Radyolar standart olmayan port numaralarını dinliyorsa bunu değiştirin.',
      ),
      'Maximum Port for Station Port Assignment' => 
      array (
        0 => 'Radyolar İçin Maksimum Port Numarası',
      ),
      'MariaDB Host' => 
      array (
        0 => 'MariaDB Sunucusu',
      ),
      'Do not modify this after installation.' => 
      array (
        0 => 'Kurulumdan sonra bunu değiştirmeyin.',
      ),
      'MariaDB Port' => 
      array (
        0 => 'MariaDB Portu',
      ),
      'MariaDB Username' => 
      array (
        0 => 'MariaDB Kullanıcı Adı',
      ),
      'MariaDB Password' => 
      array (
        0 => 'MariaDB Şifresi',
      ),
      'MariaDB Database Name' => 
      array (
        0 => 'MariaDB Veritabanı Adı',
      ),
      'Auto-generate Random MariaDB Root Password' => 
      array (
        0 => 'MariaDB Root Parolasını Rastgele Otomatik Oluştur',
      ),
      'MariaDB Root Password' => 
      array (
        0 => 'MariaDB Root Şifresi',
      ),
      'Enable MariaDB Slow Query Log' => 
      array (
        0 => 'MariaDB Yavaş Sorgu Günlüğünü Etkinleştir',
      ),
      'Log slower queries to diagnose possible database issues. Only turn this on if needed.' => 
      array (
        0 => 'Olası veritabanı sorunlarını tanılamak için daha yavaş sorguları günlüğe kaydedin. Bunu yalnızca gerekirse açın.',
      ),
      'MariaDB Maximum Connections' => 
      array (
        0 => 'MariaDB Maksimum Bağlantı Sınırı',
      ),
      'Set the amount of allowed connections to the database. This value should be increased if you are seeing the "Too many connections" error in the logs.' => 
      array (
        0 => 'Veritabanına izin verilen bağlantıların sınırını ayarlayın. Günlüklerde "Too many connections" hatası görüyorsanız bu değer artırılmalıdır.',
      ),
      'Enable Redis' => 
      array (
        0 => 'Redis Etkinleştirme',
      ),
      'Disable to use a flatfile cache instead of Redis.' => 
      array (
        0 => 'Redis yerine düz dosya önbelleği kullanmayı devre dışı bırakın.',
      ),
      'Redis Host' => 
      array (
        0 => 'Redis Sunucusu',
      ),
      'Redis Port' => 
      array (
        0 => 'Redis Portu',
      ),
      'Redis Database Index' => 
      array (
        0 => 'Redis Veritabanı Dizini',
      ),
      'PHP Maximum POST File Size' => 
      array (
        0 => 'PHP Maksimum POST Dosya Boyutu',
      ),
      'PHP Memory Limit' => 
      array (
        0 => 'PHP Bellek Sınırı',
      ),
      'PHP Script Maximum Execution Time' => 
      array (
        0 => 'PHP Komut Dosyası Maksimum Yürütme Süresi',
      ),
      '(in seconds)' => 
      array (
        0 => '(saniye içinde)',
      ),
      'Short Sync Task Execution Time' => 
      array (
        0 => 'Kısa Senkronizasyon Görevi Yürütme Süresi',
      ),
      'The maximum execution time (and lock timeout) for the 15-second, 1-minute and 5-minute synchronization tasks.' => 
      array (
        0 => '15 saniyelik, 1 dakikalık ve 5 dakikalık eşitleme görevleri için maksimum yürütme süresi (ve kilit zaman aşımı).',
      ),
      'Long Sync Task Execution Time' => 
      array (
        0 => 'Uzun Senkronizasyon Görevi Yürütme Süresi',
      ),
      'The maximum execution time (and lock timeout) for the 1-hour synchronization task.' => 
      array (
        0 => '1 saatlik senkronizasyon görevi için maksimum yürütme süresi (ve kilit zaman aşımı).',
      ),
      'Maximum PHP-FPM Worker Processes' => 
      array (
        0 => 'Maksimum PHP-FPM Çalışan İşlemleri',
      ),
      'Enable Performance Profiling Extension' => 
      array (
        0 => 'Performans Profili Oluşturma Uzantısını Etkinleştir',
      ),
      'Profiling data can be viewed by visiting %s.' => 
      array (
        0 => 'Profil oluşturma verileri %s adresini ziyaret ederek görüntülenebilir.',
      ),
      'Profile Performance on All Requests' => 
      array (
        0 => 'Tüm İsteklerde Profil Performansı',
      ),
      'This will have a significant performance impact on your installation.' => 
      array (
        0 => 'Bunun kurulumunuz üzerinde önemli bir performans etkisi olacaktır.',
      ),
      'Profiling Extension HTTP Key' => 
      array (
        0 => 'Profil Oluşturma Uzantısı HTTP Anahtarı',
      ),
      'The value for the "SPX_KEY" parameter for viewing profiling pages.' => 
      array (
        0 => 'Profil oluşturma sayfalarını görüntülemek için "SPX_KEY" parametresinin değerini yazın.',
      ),
      'Profiling Extension IP Allow List' => 
      array (
        0 => 'Profil Oluşturma Uzantısı IP İzin Listesi',
      ),
      '(Docker Compose) All Docker containers are prefixed by this name. Do not change this after installation.' => 
      array (
        0 => '(Docker Compose) Tüm Docker kapsayıcıları bu adla öne çıkar. Kurulumdan sonra bunu değiştirmeyin.',
      ),
      '(Docker Compose) The amount of time to wait before a Docker Compose operation fails. Increase this on lower performance computers.' => 
      array (
        0 => '(Docker Compose) Bir Docker oluşturma işlemi başarısız olmadan önce beklenecek süre. Daha düşük performanslı bilgisayarlarda bunu artırın.',
      ),
      'AzuraCast Release Channel' => 
      array (
        0 => 'AzuraCast Güncelleme Kanalı',
      ),
      'HTTP Port' => 
      array (
        0 => 'HTTP Portu',
      ),
      'The main port AzuraCast listens to for insecure HTTP connections.' => 
      array (
        0 => 'AzuraCast ana bağlantı noktası güvenli olmayan HTTP bağlantılarını dinler.',
      ),
      'HTTPS Port' => 
      array (
        0 => 'HTTPS Portu',
      ),
      'The main port AzuraCast listens to for secure HTTPS connections.' => 
      array (
        0 => 'AzuraCast ana bağlantı noktası güvenli HTTPS bağlantılarını dinler.',
      ),
      'SFTP Port' => 
      array (
        0 => 'SFTP Portu',
      ),
      'The port AzuraCast listens to for SFTP file management connections.' => 
      array (
        0 => 'AzuraCast bağlantı noktası SFTP dosya yönetimi bağlantılarını dinler.',
      ),
      'Station Ports' => 
      array (
        0 => 'Radyo Yayın Portları',
      ),
      'The ports AzuraCast should listen to for station broadcasts and incoming DJ connections.' => 
      array (
        0 => 'AzuraCast bağlantı noktaları radyo yayınlarını ve gelen DJ bağlantılarını dinlemelidir.',
      ),
      'Docker User UID' => 
      array (
        0 => 'Docker Kullanıcı UID',
      ),
      'Set the UID of the user running inside the Docker containers. Matching this with your host UID can fix permission issues.' => 
      array (
        0 => 'Docker konteynerlerinin içinde çalışan kullanıcının UIDsini ayarlayın. Bunu ana bilgisayar UIDnizle eşleştirmek izin sorunlarını çözebilir.',
      ),
      'Docker User GID' => 
      array (
        0 => 'Docker Kullanıcı GID',
      ),
      'Set the GID of the user running inside the Docker containers. Matching this with your host GID can fix permission issues.' => 
      array (
        0 => 'Docker konteynerlerinin içinde çalışan kullanıcının GIDsini ayarlayın. Bunu ana bilgisayar GIDnizle eşleştirmek izin sorunlarını çözebilir.',
      ),
      'Advanced: Use Privileged Docker Settings' => 
      array (
        0 => 'Gelişmiş: Ayrıcalıklı Docker Ayarlarını Kullan',
      ),
      'LetsEncrypt Domain Name(s)' => 
      array (
        0 => 'LetsEncrypt Alan Adı',
      ),
      'Domain name (example.com) or names (example.com,foo.bar) to use with LetsEncrypt.' => 
      array (
        0 => 'LetsEncrypt ile kullanılacak alan adı (example.com) veya adlar (example.com,foo.bar) yazın.',
      ),
      'LetsEncrypt E-mail Address' => 
      array (
        0 => 'LetsEncrypt E-Posta Adresi',
      ),
      'Optionally provide an e-mail address for updates from LetsEncrypt.' => 
      array (
        0 => 'İsteğe bağlı olarak LetsEncrypt\'ten güncellemeler için bir e-posta adresi yazın.',
      ),
      'This file was automatically generated by AzuraCast.' => 
      array (
        0 => 'Bu dosya AzuraCast tarafından otomatik olarak oluşturulmuştur.',
      ),
      'You can modify it as necessary. To apply changes, restart the Docker containers.' => 
      array (
        0 => 'Gerektiğinde değiştirebilirsiniz. Değişiklikleri uygulamak için Docker konteynerlerini yeniden başlatın.',
      ),
      'Remove the leading "#" symbol from lines to uncomment them.' => 
      array (
        0 => 'Yorumları kaldırmak için satırların başındaki "#" sembolünü kaldırın.',
      ),
      'Valid options: %s' => 
      array (
        0 => 'Geçerli seçenekler: %s',
      ),
      'Default: %s' => 
      array (
        0 => 'Varsayılan: %s',
      ),
      'Additional Environment Variables' => 
      array (
        0 => 'Ek Ortam Değişkenleri',
      ),
      'AzuraCast Installer' => 
      array (
        0 => 'AzuraCast Yükleyici',
      ),
      'Welcome to AzuraCast! Complete the initial server setup by answering a few questions.' => 
      array (
        0 => 'AzuraCast\'a hoş geldiniz! Birkaç soruyu yanıtlayarak ilk sunucu kurulumunu tamamlayın.',
      ),
      'AzuraCast Updater' => 
      array (
        0 => 'AzuraCast Güncelleyici',
      ),
      'Change installation settings?' => 
      array (
        0 => 'Kurulum ayarları değiştirilsin mi?',
      ),
      'AzuraCast is currently configured to listen on the following ports:' => 
      array (
        0 => 'AzuraCast şu anda aşağıdaki port numaralarını kullanacak şekilde yapılandırılmıştır:',
      ),
      'HTTP Port: %d' => 
      array (
        0 => 'HTTP Portu: %d',
      ),
      'HTTPS Port: %d' => 
      array (
        0 => 'HTTPS Portu: %d',
      ),
      'SFTP Port: %d' => 
      array (
        0 => 'SFTP Portu: %d',
      ),
      'Radio Ports: %s' => 
      array (
        0 => 'Radyo Canlı Yayın Portları: %s',
      ),
      'Customize ports used for AzuraCast?' => 
      array (
        0 => 'AzuraCast için kullanılacak port numaraları özelleştirilsin mi?',
      ),
      'Set up LetsEncrypt?' => 
      array (
        0 => 'LetsEncrypt kurulsun mu?',
      ),
      'Writing configuration files...' => 
      array (
        0 => 'Yapılandırma dosyaları yazılıyor...',
      ),
      'Server configuration complete!' => 
      array (
        0 => 'Sunucu yapılandırması tamamlandı!',
      ),
      'This product includes GeoLite2 data created by MaxMind, available from %s.' => 
      array (
        0 => 'Bu ürün MaxMind tarafından oluşturulan GeoLite2 verilerini içerir. Daha geniş bilgi için %s internet adresini ziyaret edebilirsiniz.',
      ),
      'IP Geolocation by DB-IP' => 
      array (
        0 => 'DB-IP ile IP Konumu',
      ),
      'GeoLite database not configured for this installation. See System Administration for instructions.' => 
      array (
        0 => 'GeoLite veritabanı bu kurulum için yapılandırılmamış. Talimatlar için "Sistem Yönetimi" sayfasına gidiniz.',
      ),
      'Welcome to the AzuraCast Liquidsoap configuration editor.' => 
      array (
        0 => 'AzuraCast Liquidsoap yapılandırma düzenleyicisine hoş geldiniz.',
      ),
      'Using this page, you can customize several sections of the Liquidsoap configuration.' => 
      array (
        0 => 'Bu sayfayı kullanarak Liquidsoap yapılandırmasının birkaç bölümünü özelleştirebilirsiniz.',
      ),
      'The non-editable sections are automatically generated by AzuraCast.' => 
      array (
        0 => 'Düzenlenemeyen bölümler AzuraCast tarafından otomatik olarak oluşturulur.',
      ),
      '%s is not recognized as a service.' => 
      array (
        0 => '%s bir servis olarak tanınmıyor.',
      ),
      'It may not be registered with Supervisor yet. Restarting broadcasting may help.' => 
      array (
        0 => 'Supervisor\'a henüz kayıtlı olmayabilir. Yayını yeniden başlatmak yardımcı olabilir.',
      ),
      '%s cannot start' => 
      array (
        0 => '%s başlatılamadı!',
      ),
      'It is already running.' => 
      array (
        0 => 'Zaten Çalışıyor.',
      ),
      '%s cannot stop' => 
      array (
        0 => '%s durdurulamadı!',
      ),
      'It is not running.' => 
      array (
        0 => 'Zaten Çalışmıyor.',
      ),
      '%s encountered an error' => 
      array (
        0 => '%s bir hata ile karşılaştı.',
      ),
      'Check the log for details.' => 
      array (
        0 => 'Detaylar için günlükleri kontrol edin.',
      ),
      'Select...' => 
      array (
        0 => 'Seç...',
      ),
      'This feature is not currently supported on this station.' => 
      array (
        0 => 'Bu radyoda bu özellik şu an desteklenmiyor.',
      ),
      'Now Playing Data' => 
      array (
        0 => 'Şimdi Çalan Şarkı Bilgisi',
      ),
      '1-Minute Sync' => 
      array (
        0 => '1-Dakika Senkronizasyonu',
      ),
      'Song Requests Queue' => 
      array (
        0 => 'Şarkı İstek Kuyruğu',
      ),
      '5-Minute Sync' => 
      array (
        0 => '5-Dakika Senkronizasyonu',
      ),
      'Check Media Folders' => 
      array (
        0 => 'Müzik Klasörlerini Kontrol Et',
      ),
      '1-Hour Sync' => 
      array (
        0 => '1-Saat Senkronizasyonu',
      ),
      'Analytics/Statistics' => 
      array (
        0 => 'İstatistik',
      ),
      'Cleanup' => 
      array (
        0 => 'Temizleme',
      ),
      'Installation Not Recently Backed Up' => 
      array (
        0 => 'Yükleme Son Zamanlarda Yedeklenmedi',
      ),
      'This installation has not been backed up in the last two weeks.' => 
      array (
        0 => 'Bu kurulum son iki hafta içerisinde yedeklenmedi.',
      ),
      'Update Instructions' => 
      array (
        0 => 'Güncelleme Talimatları',
      ),
      'AzuraCast <a href="%s" target="_blank">version %s</a> is now available.' => 
      array (
        0 => 'AzuraCast <a href="%s" target="_blank">%s sürümü</a> şu an kullanılabilir.',
      ),
      'You are currently running version %s. Updating is highly recommended.' => 
      array (
        0 => 'Şu anda AzuraCast %s sürümüne sahipsiniz. Güncelleme şiddetle tavsiye edilir.',
      ),
      'New AzuraCast Release Version Available' => 
      array (
        0 => 'AzuraCast Yeni Sürümü Yayınlandı!',
      ),
      'Your installation is currently %d update(s) behind the latest version.' => 
      array (
        0 => 'AzuraCast şu anda en son sürümün %d güncellemesini içerir.',
      ),
      'View the changelog for full details.' => 
      array (
        0 => 'Tüm ayrıntılar için değişiklik günlüğünü görüntüleyin.',
      ),
      'You should update to take advantage of bug and security fixes.' => 
      array (
        0 => 'Hata ve güvenlik düzeltmelerinden yararlanmak için güncelleme yapmalısınız.',
      ),
      'New AzuraCast Updates Available' => 
      array (
        0 => 'AzuraCast Yeni Güncellemesi Yayınlandı!',
      ),
      'Synchronized Task Not Recently Run' => 
      array (
        0 => 'Yakın Zamanda Çalıştırılmayan Senkronize Görevi',
      ),
      'The "%s" synchronization task has not run recently. This may indicate an error with your installation.' => 
      array (
        0 => 'Senkronizasyon görevi "%s" son zamanlarda çalışmadı. Bu, kurulumunuzla ilgili bir problemi belirtiyor olabilir.',
      ),
      'Manually Run Task' => 
      array (
        0 => 'Görevi Manuel Olarak Çalıştır',
      ),
      'The performance profiling extension is currently enabled on this installation.' => 
      array (
        0 => 'Performans profili oluşturma uzantısı şu anda bu kurulumda etkin.',
      ),
      'You can track the execution time and memory usage of any AzuraCast page or application from the profiler page.' => 
      array (
        0 => 'Profil oluşturucu sayfasından herhangi bir AzuraCast sayfasının veya uygulamasının yürütme süresini ve bellek kullanımını izleyebilirsiniz.',
      ),
      'Profiler Control Panel' => 
      array (
        0 => 'Profiler Kontrol Paneli',
      ),
      'Performance profiling is currently enabled for all requests.' => 
      array (
        0 => 'Performans profili oluşturma şu anda tüm istekler için etkindir.',
      ),
      'This can have an adverse impact on system performance. You should disable this when possible.' => 
      array (
        0 => 'Bunun sistem performansı üzerinde olumsuz bir etkisi olabilir. Mümkün olduğunda bunu devre dışı bırakmalısınız.',
      ),
      'You should update your <code>docker-compose.yml</code> file to reflect the newest changes.' => 
      array (
        0 => 'Yeni güncellemeleri uygulamak için <code>docker-compose.yml</code> dosyanızı güncellemelisiniz.',
      ),
      'If you manually maintain this file, review the <a href="%s" target="_blank">latest version of the file</a> and make any changes needed.' => 
      array (
        0 => 'Bu dosyayı manuel olarak güncelliyorsanız dosyanın <a href="%s" target="_blank">güncel</a> halini görüntüleyebilir ve gerekli düzenlemeleri yapabilirsiniz.',
      ),
      'Otherwise, update your installation and answer "Y" when prompted to update the file.' => 
      array (
        0 => 'Aksi takdirde, kurulumunuzu güncelleyin ve dosya güncelleneceği zaman komut satırında "Y" cevabını verin.',
      ),
      'Your <code>docker-compose.yml</code> file is out of date!' => 
      array (
        0 => '<code>docker-compose.yml</code> dosyanız güncel değildir!',
      ),
      'You must be logged in to access this page.' => 
      array (
        0 => 'Bu sayfayı görüntülemek için giriş yapmalısınız.',
      ),
      'You do not have permission to access this portion of the site.' => 
      array (
        0 => 'Sitenin bu bölümüne erişmek için yetkiniz bulunmamaktadır.',
      ),
      'All Permissions' => 
      array (
        0 => 'Tüm İzinler',
      ),
      'View Administration Page' => 
      array (
        0 => 'Yönetici Panelini Görme',
      ),
      'View System Logs' => 
      array (
        0 => 'Sistem Günlüklerini Görme',
      ),
      'Administer Settings' => 
      array (
        0 => 'Ayar Yönetimi',
      ),
      'Administer API Keys' => 
      array (
        0 => 'API Anahtarı Yönetimi',
      ),
      'Administer Stations' => 
      array (
        0 => 'Radyo Yönetimi',
      ),
      'Administer Custom Fields' => 
      array (
        0 => 'Özel Alan Yönetimi',
      ),
      'Administer Backups' => 
      array (
        0 => 'Yedekleme Yönetimi',
      ),
      'Administer Storage Locations' => 
      array (
        0 => 'Depolama Konumlarını Yönet',
      ),
      'View Station Page' => 
      array (
        0 => 'Radyo Sayfasını Görme',
      ),
      'View Station Reports' => 
      array (
        0 => 'Radyo Raporlarını Görme',
      ),
      'View Station Logs' => 
      array (
        0 => 'Radyo Günlüklerini Görme',
      ),
      'Manage Station Profile' => 
      array (
        0 => 'Radyo Profil Yönetimi',
      ),
      'Manage Station Broadcasting' => 
      array (
        0 => 'Radyo Canlı Yayın Yönetimi',
      ),
      'Manage Station Streamers' => 
      array (
        0 => 'Radyo DJ Yönetimi',
      ),
      'Manage Station Mount Points' => 
      array (
        0 => 'Radyo Bağlantı Noktası Yönetimi',
      ),
      'Manage Station Remote Relays' => 
      array (
        0 => 'Radyo Yönlendirme Yönetimi',
      ),
      'Manage Station Media' => 
      array (
        0 => 'Radyo Müzik Yönetimi',
      ),
      'Manage Station Automation' => 
      array (
        0 => 'Radyo Otomasyon Yönetimi',
      ),
      'Manage Station Web Hooks' => 
      array (
        0 => 'Radyo Web Kancası Yönetimi',
      ),
      'Manage Station Podcasts' => 
      array (
        0 => 'Radyo Podcasts Yönetimi',
      ),
      'Imported locale: %s' => 
      array (
        0 => 'İçe aktarılan dil: %s',
      ),
      'The account associated with e-mail address "%s" has been set as an administrator' => 
      array (
        0 => '%s e-posta adresi yönetici olarak atandı.',
      ),
      'Account not found.' => 
      array (
        0 => 'Hesap bulunamadı.',
      ),
      'Fixtures loaded.' => 
      array (
        0 => 'Fikstürler yüklendi.',
      ),
      'Configuration successfully written.' => 
      array (
        0 => 'Yapılandırma başarıyla yazıldı.',
      ),
      'AzuraCast Backup' => 
      array (
        0 => 'AzuraCast Yedekleme',
      ),
      'Please wait while a backup is generated...' => 
      array (
        0 => 'Lütfen bir yedekleme oluşturulurken bekleyin...',
      ),
      'Creating temporary directories...' => 
      array (
        0 => 'Geçici dizinler oluşturuluyor...',
      ),
      'Directory "%s" was not created' => 
      array (
        0 => '"%s" dizini oluşturulamadı!',
      ),
      'Backing up MariaDB...' => 
      array (
        0 => 'MariaDB yedekleniyor...',
      ),
      'Creating backup archive...' => 
      array (
        0 => 'Yedekleme arşivi oluşturuluyor...',
      ),
      'Cleaning up temporary files...' => 
      array (
        0 => 'Geçici dizin dosyaları temizleniyor...',
      ),
      'Backup complete in %.2f seconds.' => 
      array (
        0 => 'Yedekleme %.2f saniyede tamamlandı.',
      ),
      'Backup path %s not found!' => 
      array (
        0 => 'Yedekleme dizini %s bulunamadı!',
      ),
      'AzuraCast Setup' => 
      array (
        0 => 'AzuraCast Kurulumu',
      ),
      'Welcome to AzuraCast. Please wait while some key dependencies of AzuraCast are set up...' => 
      array (
        0 => 'AzuraCast\'a hoşgeldiniz. AzuraCast’in bazı temel sistemleri kurulurken lütfen bekleyin...',
      ),
      'Installing Data Fixtures' => 
      array (
        0 => 'Veri Fikstürleri Kuruluyor',
      ),
      'Refreshing All Stations' => 
      array (
        0 => 'Tüm Radyolar Yenileniyor',
      ),
      'AzuraCast is now updated to the latest version!' => 
      array (
        0 => 'AzuraCast şimdi en son sürüme güncellendi!',
      ),
      'AzuraCast installation complete!' => 
      array (
        0 => 'AzuraCast kurulumu tamamlandı!',
      ),
      'Visit %s to complete setup.' => 
      array (
        0 => 'Kurulumu tamamlamak için %s adresini ziyaret edin.',
      ),
      'Initialize AzuraCast' => 
      array (
        0 => 'AzuraCast\'i Başlat',
      ),
      'Initializing essential settings...' => 
      array (
        0 => 'Temel ayarlar başlatılıyor...',
      ),
      'Environment: %s' => 
      array (
        0 => 'Ortam: %s',
      ),
      'Installation Method: %s' => 
      array (
        0 => 'Kurulum Yöntemi: %s',
      ),
      'Running Database Migrations' => 
      array (
        0 => 'Veritabanı Geçişleri Çalışıyor',
      ),
      'Generating Database Proxy Classes' => 
      array (
        0 => 'Veritabanı Proxy Sınıfları Oluşturuluyor',
      ),
      'Reload System Data' => 
      array (
        0 => 'Sistem Verilerini Yeniden Yükle',
      ),
      'AzuraCast is now initialized.' => 
      array (
        0 => 'AzuraCast şimdi başlatıldı.',
      ),
      'AzuraCast Settings' => 
      array (
        0 => 'AzuraCast Ayarları',
      ),
      'Setting Key' => 
      array (
        0 => 'Ayar Anahtarı',
      ),
      'Setting Value' => 
      array (
        0 => 'Ayar Değeri',
      ),
      'The port %s is in use by another station.' => 
      array (
        0 => '%s portu başka bir radyo tarafından kullanılıyor.',
      ),
      'This value is already used.' => 
      array (
        0 => 'Bu değer zaten kullanılıyor.',
      ),
      'Storage location %s could not be validated: %s' => 
      array (
        0 => '%s depolama konumu doğrulanamadı: %s',
      ),
      'Storage location %s already exists.' => 
      array (
        0 => '%s depolama alanı zaten var.',
      ),
      'Search engine crawlers are not permitted to use this feature.' => 
      array (
        0 => 'Arama motoru tarayıcılarının bu özelliği kullanmasına izin verilmemektedir.',
      ),
      'This station does not accept requests currently.' => 
      array (
        0 => 'Bu radyo şu anda istekleri kabul etmiyor.',
      ),
      'The song ID you specified could not be found in the station.' => 
      array (
        0 => 'Belirttiğiniz şarkı kimliği radyoda bulunamadı.',
      ),
      'The song ID you specified cannot be requested for this station.' => 
      array (
        0 => 'Belirttiğiniz şarkı kimliği bu radyo için talep edilemez.',
      ),
      'You have submitted a request too recently! Please wait before submitting another one.' => 
      array (
        0 => 'Çok yakın zamanda bir istek gönderdiniz! Lütfen başka bir tane göndermeden önce bekleyin.',
      ),
      'Duplicate request: this song was already requested and will play soon.' => 
      array (
        0 => 'Yinelenen İstek: Bu şarkı zaten talep edildi ve yakında çalınacaktır.',
      ),
      'This song or artist has been played too recently. Wait a while before requesting it again.' => 
      array (
        0 => 'Bu şarkı veya sanatçı zaten çok yeni çalındı. Tekrar talep etmeden önce biraz bekleyin.',
      ),
      'Changes saved successfully.' => 
      array (
        0 => 'Değişiklikler başarıyla kaydedildi.',
      ),
      'Record created successfully.' => 
      array (
        0 => 'Kayıt başarıyla oluşturuldu.',
      ),
      'Record updated successfully.' => 
      array (
        0 => 'Kayıt başarıyla güncellendi.',
      ),
      'Record deleted successfully.' => 
      array (
        0 => 'Kayıt başarıyla silindi.',
      ),
      'Record not found' => 
      array (
        0 => 'Kayıt bulunamadı',
      ),
      'The uploaded file exceeds the upload_max_filesize directive in php.ini.' => 
      array (
        0 => 'Yüklenen dosya php.ini\'deki upload_max_filesize yönergesini aşıyor.',
      ),
      'The uploaded file exceeds the MAX_FILE_SIZE directive from the HTML form.' => 
      array (
        0 => 'Yüklenen dosya HTML formundaki MAX_FILE_SIZE yönergesini aşıyor.',
      ),
      'The uploaded file was only partially uploaded.' => 
      array (
        0 => 'Yüklenen dosya yalnızca kısmen yüklendi.',
      ),
      'No file was uploaded.' => 
      array (
        0 => 'Dosya yüklenemedi.',
      ),
      'No temporary directory is available.' => 
      array (
        0 => 'Geçici dizin kullanılamaz.',
      ),
      'Could not write to filesystem.' => 
      array (
        0 => 'Dosya sistemine yazılamadı.',
      ),
      'Upload halted by a PHP extension.' => 
      array (
        0 => 'Yükleme bir PHP uzantısı tarafından durduruldu.',
      ),
      'Unspecified error.' => 
      array (
        0 => 'Belirtilmemiş hata.',
      ),
      'Playlist: %s' => 
      array (
        0 => 'Çalma Listesi: %s',
      ),
      'Streamer: %s' => 
      array (
        0 => 'DJ: %s',
      ),
      'Edit Liquidsoap Configuration' => 
      array (
        0 => 'Liquidsoap Yapılandırmasını Düzenle',
      ),
      'Streamers enabled!' => 
      array (
        0 => 'DJ Etkinleştirildi!',
      ),
      'You can now set up streamer (DJ) accounts.' => 
      array (
        0 => 'DJ hesaplarını şimdi ekleyebilirsiniz.',
      ),
      'Record not found.' => 
      array (
        0 => 'Kayıt bulunamadı!',
      ),
      'Profile' => 
      array (
        0 => 'Profil',
      ),
      'Automated assignment complete!' => 
      array (
        0 => 'Otomatik atama tamamlandı!',
      ),
      'Automated assignment error' => 
      array (
        0 => 'Otomatik atama hatası!',
      ),
      'Statistics Overview' => 
      array (
        0 => 'İstatistik Önizlemesi',
      ),
      'SoundExchange Report' => 
      array (
        0 => 'SoundExchange Raporu',
      ),
      'No episodes found.' => 
      array (
        0 => 'Bölüm bulunamadı.',
      ),
      'Episode not found.' => 
      array (
        0 => 'Bölüm bulunamadı.',
      ),
      'Logged in successfully.' => 
      array (
        0 => 'Giriş Yapıldı!',
      ),
      'Login unsuccessful' => 
      array (
        0 => 'Giriş Başarısız!',
      ),
      'Your credentials could not be verified.' => 
      array (
        0 => 'Kimlik bilgileriniz doğrulamanadı!',
      ),
      'Too many forgot password attempts' => 
      array (
        0 => 'Çok fazla unutulmuş şifre denemesi',
      ),
      'You have attempted to reset your password too many times. Please wait 30 seconds and try again.' => 
      array (
        0 => 'Şifrenizi birçok kez sıfırlamayı denediniz. Lütfen 30 saniye bekleyin ve tekrar deneyin.',
      ),
      'Account Recovery Link' => 
      array (
        0 => 'Hesap Kurtarma Bağlantısı',
      ),
      'Account recovery e-mail sent.' => 
      array (
        0 => 'Hesap kurtarma e-postası gönderildi.',
      ),
      'If the e-mail address you provided is in the system, check your inbox for a password reset message.' => 
      array (
        0 => 'Verdiğiniz e-posta adresi sistemimizde kayıtlı ise şifre sıfırlama mesajı için gelen kutunuzu kontrol edin.',
      ),
      'Invalid token specified.' => 
      array (
        0 => 'Geçersiz anahtar belirtildi.',
      ),
      'Logged in using account recovery token' => 
      array (
        0 => 'Hesap kurtarma anahtarı kullanılarak giriş yapıldı',
      ),
      'Your password has been updated.' => 
      array (
        0 => 'Şifreniz güncellendi.',
      ),
      'Too many login attempts' => 
      array (
        0 => 'Çok fazla giriş denemesi yapıldı',
      ),
      'You have attempted to log in too many times. Please wait 30 seconds and try again.' => 
      array (
        0 => 'Çok fazla giriş yapmayı denediniz. Lütfen 30 saniye bekleyin ve tekrar deneyin.',
      ),
      'Complete the setup process to get started.' => 
      array (
        0 => 'Başlamak için kurulum işlemini tamamlayın.',
      ),
      'API Key not found.' => 
      array (
        0 => 'API anahtarı bulunamadı!',
      ),
      'API Key updated.' => 
      array (
        0 => 'API anahtarı güncellendi!',
      ),
      'Edit API Key' => 
      array (
        0 => 'API Anahtarı Düzenle',
      ),
      'Add API Key' => 
      array (
        0 => 'API Anahtarı Ekle',
      ),
      'API Key deleted.' => 
      array (
        0 => 'API Anahtarı silindi!',
      ),
      'Profile saved!' => 
      array (
        0 => 'Profil Kaydedildi!',
      ),
      'The token you supplied is invalid. Please try again.' => 
      array (
        0 => 'Geçersiz bilgi girildi. Lütfen tekrar deneyiniz.',
      ),
      'Two-factor authentication enabled.' => 
      array (
        0 => 'İki faktörlü kimlik doğrulama etkinleştirildi.',
      ),
      'Two-factor authentication disabled.' => 
      array (
        0 => 'İki faktörlü kimlik doğrulama devredışı bırakıldı.',
      ),
      'Set Up AzuraCast' => 
      array (
        0 => '',
      ),
      'Setup has already been completed!' => 
      array (
        0 => 'Kurulum zaten tamamlanmış!',
      ),
      'Dashboard' => 
      array (
        0 => 'Anasayfa',
      ),
      'AzuraCast User' => 
      array (
        0 => 'AzuraCast Kullanıcısı',
      ),
      'This station does not support on-demand streaming.' => 
      array (
        0 => 'Bu istasyon isteğe bağlı akışı desteklemiyor.',
      ),
      'Playlist successfully imported; %d of %d files were successfully matched.' => 
      array (
        0 => 'Oynatma listesi başarıyla içe aktarıldı; %d tanesi %d dosyadan başarıyla eşleştirildi.',
      ),
      'This playlist is not a sequential playlist.' => 
      array (
        0 => 'Bu çalma listesi "SIRALI" bir çalma listesi değildir.',
      ),
      'Playlist reshuffled.' => 
      array (
        0 => 'Çalma listesi yeniden karıştırıldı!',
      ),
      'Playlist not found.' => 
      array (
        0 => 'Çalma listesi bulunamadı!',
      ),
      'Playlist enabled.' => 
      array (
        0 => 'Çalma Listesi Etkinleştirildi!',
      ),
      'Playlist disabled.' => 
      array (
        0 => 'Çalma Listesi Devredışı Bırakıldı!',
      ),
      'This station is out of available storage space.' => 
      array (
        0 => 'Radyo depolama alanı doldu.',
      ),
      'No directory specified' => 
      array (
        0 => 'Hiçbir dizin seçilmedi',
      ),
      'File not specified.' => 
      array (
        0 => 'Dosya belirtilmedi!',
      ),
      'New path not specified.' => 
      array (
        0 => 'Yeni dizin belirlenmedi!',
      ),
      'File Not Processed: %s' => 
      array (
        0 => 'Dosya İşlenemedi: %s',
      ),
      'File Processing' => 
      array (
        0 => 'Dosya İşleniyor',
      ),
      'Station restarted.' => 
      array (
        0 => 'Sunucu yeniden başlatıldı!',
      ),
      'Frontend stopped.' => 
      array (
        0 => 'Sunucu durduruldu!',
      ),
      'Frontend started.' => 
      array (
        0 => 'Sunucu başlatıldı!',
      ),
      'Frontend restarted.' => 
      array (
        0 => 'Sunucu yeniden başlatıldı!',
      ),
      'Song skipped.' => 
      array (
        0 => 'Şarkı atlandı!',
      ),
      'Streamer disconnected.' => 
      array (
        0 => 'DJ bağlantısı kesildi!',
      ),
      'Backend stopped.' => 
      array (
        0 => 'AutoDJ durduruldu!',
      ),
      'Backend started.' => 
      array (
        0 => 'AutoDJ başlatıldı!',
      ),
      'Backend restarted.' => 
      array (
        0 => 'AutoDJ yeniden başlatıldı!',
      ),
      'Web hook not found.' => 
      array (
        0 => 'Web kancası bulunamadı!',
      ),
      'Web hook enabled.' => 
      array (
        0 => 'Web kancası etkinleştirildi!',
      ),
      'Web hook disabled.' => 
      array (
        0 => 'Web kancası devredışı bırakıldı!',
      ),
      'Podcast not found!' => 
      array (
        0 => 'Podcasts Bulunamadı!',
      ),
      'No recording available.' => 
      array (
        0 => 'Kullanılabilir kayıt yoktur.',
      ),
      'All Stations' => 
      array (
        0 => 'Tüm Radyolar',
      ),
      'You cannot remove yourself.' => 
      array (
        0 => 'Kendini silemezsin!',
      ),
      'Create a new storage location based on the base directory.' => 
      array (
        0 => 'Temel dizini temel alan yeni bir depolama konumu oluşturun.',
      ),
      'Liquidsoap Log' => 
      array (
        0 => 'Liquidsoap Günlüğü',
      ),
      'Liquidsoap Configuration' => 
      array (
        0 => 'Liquidsoap Ayar Dosyası',
      ),
      'Icecast Access Log' => 
      array (
        0 => 'Icecast Erişim Günlüğü',
      ),
      'Icecast Error Log' => 
      array (
        0 => 'Icecast Hata Günlüğü',
      ),
      'Icecast Configuration' => 
      array (
        0 => 'Icecast Ayar Dosyası',
      ),
      'SHOUTcast Log' => 
      array (
        0 => 'SHOUTcast Günlüğü',
      ),
      'SHOUTcast Configuration' => 
      array (
        0 => 'SHOUTcast Ayar Dosyası',
      ),
      'User updated.' => 
      array (
        0 => 'Kullanıcı güncellendi!',
      ),
      'User added.' => 
      array (
        0 => 'Kullanıcı eklendi!',
      ),
      'Another user already exists with this e-mail address. Please update the e-mail address.' => 
      array (
        0 => 'Bu e-posta adresi başka bir kullanıcı için kullanılmaktadır. Lütfen farklı bir e-posta adresi ile tekrar deneyiniz.',
      ),
      'Edit User' => 
      array (
        0 => 'Kullanıcı Düzenle',
      ),
      'Add User' => 
      array (
        0 => 'Kullanıcı Ekle',
      ),
      'You cannot delete your own account.' => 
      array (
        0 => 'Kendi hesabını silemezsin!',
      ),
      'User deleted.' => 
      array (
        0 => 'Kullanıcı silindi!',
      ),
      'User not found.' => 
      array (
        0 => 'Kullanıcı bulunamadı!',
      ),
      'AzuraCast Application Log' => 
      array (
        0 => 'AzuraCast Günlüğü',
      ),
      'Nginx Access Log' => 
      array (
        0 => 'Nginx Erişim Günlüğü',
      ),
      'Nginx Error Log' => 
      array (
        0 => 'Nginx Hata Günlüğü',
      ),
      'PHP Application Log' => 
      array (
        0 => 'PHP Uygulama Günlüğü',
      ),
      'Supervisord Log' => 
      array (
        0 => 'Supervisord Günlüğü',
      ),
      'Album Artist Sort Order' => 
      array (
        0 => 'Albüm Sanatçısı Sıralama Düzeni',
      ),
      'Album Sort Order' => 
      array (
        0 => 'Albüm Sıralama Düzeni',
      ),
      'Band' => 
      array (
        0 => 'Grup',
      ),
      'Bpm' => 
      array (
        0 => 'Bpm',
      ),
      'Comment' => 
      array (
        0 => 'Yorum',
      ),
      'Commercial Information' => 
      array (
        0 => 'Ticari Bilgiler',
      ),
      'Composer' => 
      array (
        0 => 'Besteci',
      ),
      'Composer Sort Order' => 
      array (
        0 => 'Besteci Sıralama Düzeni',
      ),
      'Conductor' => 
      array (
        0 => 'Kondüktör',
      ),
      'Content Group Description' => 
      array (
        0 => 'İçerik Grubu Açıklaması',
      ),
      'Copyright' => 
      array (
        0 => 'Telif Hakkı',
      ),
      'Copyright Message' => 
      array (
        0 => 'Telif Hakkı Mesajı',
      ),
      'Encoded By' => 
      array (
        0 => 'Kodlama Cinsi',
      ),
      'Encoder Settings' => 
      array (
        0 => 'Kodlayıcı Ayarları',
      ),
      'Encoding Time' => 
      array (
        0 => 'Kodlama Zamanı',
      ),
      'File Owner' => 
      array (
        0 => 'Dosya Sahibi',
      ),
      'File Type' => 
      array (
        0 => 'Dosya Türü',
      ),
      'Initial Key' => 
      array (
        0 => 'İlk Anahtar',
      ),
      'Internet Radio Station Name' => 
      array (
        0 => 'İnternet Radyo İstasyonu Adı',
      ),
      'Internet Radio Station Owner' => 
      array (
        0 => 'İnternet Radyo İstasyonu Sahibi',
      ),
      'Involved People List' => 
      array (
        0 => 'İlgili Kişi Listesi',
      ),
      'Linked Information' => 
      array (
        0 => 'Bağlantılı Bilgi',
      ),
      'Lyricist' => 
      array (
        0 => 'Söz Yazarı',
      ),
      'Media Type' => 
      array (
        0 => 'Ortam Türü',
      ),
      'Mood' => 
      array (
        0 => 'Ruh Hali',
      ),
      'Music CD Identifier' => 
      array (
        0 => 'Müzik CD Tanımlayıcısı',
      ),
      'Musician Credits List' => 
      array (
        0 => 'Müzisyen Kredileri Listesi',
      ),
      'Original Album' => 
      array (
        0 => 'Orijinal Albüm',
      ),
      'Original Artist' => 
      array (
        0 => 'Orijinal Sanatçı',
      ),
      'Original Filename' => 
      array (
        0 => 'Orijinal Dosya Adı',
      ),
      'Original Lyricist' => 
      array (
        0 => 'Orijinal Söz Yazarı',
      ),
      'Original Release Time' => 
      array (
        0 => 'Orijinal Çıkış Zamanı',
      ),
      'Original Year' => 
      array (
        0 => 'Orjinal Yıl',
      ),
      'Part Of A Compilation' => 
      array (
        0 => 'Derleme Bölümü',
      ),
      'Part Of A Set' => 
      array (
        0 => 'Set Bölümü',
      ),
      'Performer Sort Order' => 
      array (
        0 => 'Sanatçı Sıralama Düzeni',
      ),
      'Playlist Delay' => 
      array (
        0 => 'Çalma Listesi Gecikmesi',
      ),
      'Produced Notice' => 
      array (
        0 => 'Üretilme Bildirimi',
      ),
      'Publisher' => 
      array (
        0 => 'Yayımcı',
      ),
      'Recording Time' => 
      array (
        0 => 'Kayıt Zamanı',
      ),
      'Release Time' => 
      array (
        0 => 'Çıkış Zamanı',
      ),
      'Remixer' => 
      array (
        0 => 'Remix Yapan',
      ),
      'Set Subtitle' => 
      array (
        0 => 'Altyazıyı Ayarla',
      ),
      'Subtitle' => 
      array (
        0 => 'Altyazı',
      ),
      'Tagging Time' => 
      array (
        0 => 'Etiketleme Zamanı',
      ),
      'Terms Of Use' => 
      array (
        0 => 'Kullanım Şartları',
      ),
      'Title Sort Order' => 
      array (
        0 => 'Başlık Sıralama Düzeni',
      ),
      'Track Number' => 
      array (
        0 => 'Parça Numarası',
      ),
      'Unsynchronised Lyric' => 
      array (
        0 => 'Senkronize Edilmemiş Şarkı Sözü',
      ),
      'URL Artist' => 
      array (
        0 => 'Sanatçı URLsi',
      ),
      'URL File' => 
      array (
        0 => 'Dosya URLsi',
      ),
      'URL Payment' => 
      array (
        0 => 'Ödeme URLsi',
      ),
      'URL Publisher' => 
      array (
        0 => 'Yayımcı URLsi',
      ),
      'URL Source' => 
      array (
        0 => 'Kaynak URLsi',
      ),
      'URL Station' => 
      array (
        0 => 'Radyo URLsi',
      ),
      'URL User' => 
      array (
        0 => 'Kullanıcı URLsi',
      ),
      'Year' => 
      array (
        0 => 'Yıl',
      ),
      'Run Synchronized Task' => 
      array (
        0 => 'Senkronizasyon Görevlerini Çalıştır',
      ),
      'Debug Output' => 
      array (
        0 => 'Hata Ayıklama Çıktısı',
      ),
      'Configure Backups' => 
      array (
        0 => 'Yedeklemeyi Yapılandır',
      ),
      'Run Manual Backup' => 
      array (
        0 => 'Manuel Yedeklemeyi Çalıştır',
      ),
      'Backup deleted.' => 
      array (
        0 => 'Yedekleme silindi!',
      ),
      'Backup not found.' => 
      array (
        0 => 'Yedekleme bulunamadı!',
      ),
      'Are you sure?' => 
      array (
        0 => 'Emin misiniz?',
      ),
      'Enter a password to continue.' => 
      array (
        0 => 'Devam etmek için bir şifre girin.',
      ),
      'No problems detected.' => 
      array (
        0 => 'Hiçbir sorun tespit edilmedi.',
      ),
      'Generate the translation locale file.' => 
      array (
        0 => 'Dil çevirisi yerel dosyasını oluşturun.',
      ),
      'Convert translated locale files into PHP arrays.' => 
      array (
        0 => 'Çevrilen yerel dosyaları PHP dizilerine dönüştürün.',
      ),
      'Ensure key settings are initialized within AzuraCast.' => 
      array (
        0 => 'AzuraCast içinde anahtar ayarların başlatıldığından emin olun.',
      ),
      'Migrate existing configuration to new INI format if any exists.' => 
      array (
        0 => 'Varsa mevcut ayarları yeni bir INI formatına taşıyın.',
      ),
      'Install fixtures for demo / local development.' => 
      array (
        0 => 'Demo / yerel geliştirme için fikstürleri kurun.',
      ),
      'Run all general AzuraCast setup steps.' => 
      array (
        0 => 'Tüm genel AzuraCast kurulum adımlarını çalıştırın.',
      ),
      'Run one or more scheduled synchronization tasks.' => 
      array (
        0 => 'Bir veya daha fazla zamanlanmış senkronizasyon görevi çalıştırın.',
      ),
      'Process the message queue.' => 
      array (
        0 => 'Mesaj kuyruğunu işleyin.',
      ),
      'Clear the contents of the message queue.' => 
      array (
        0 => 'Mesaj kuyruğunun içeriğini temizleyin.',
      ),
      'List all settings in the AzuraCast settings database.' => 
      array (
        0 => 'AzuraCast ayarları veritabanında tüm ayarları listeleyin.',
      ),
      'Back up the AzuraCast database and statistics (and optionally media).' => 
      array (
        0 => 'AzuraCast veritabanını ve istatistiklerini (ve isteğe bağlı olarak medyayı) yedekleyin.',
      ),
      'System Maintenance' => 
      array (
        0 => 'Sunucu Bakımı',
      ),
      'System Logs' => 
      array (
        0 => 'Sistem Günlükleri',
      ),
      'System Debugger' => 
      array (
        0 => 'Sistem Hata Ayıklama',
      ),
      'Users' => 
      array (
        0 => 'Kullanıcılar',
      ),
      'User Accounts' => 
      array (
        0 => 'Kullanıcı Hesapları',
      ),
      'API Keys' => 
      array (
        0 => 'API Anahtarları',
      ),
      'Connected AzuraRelays' => 
      array (
        0 => 'AzuraRelays Bağlantısı',
      ),
      'Install SHOUTcast' => 
      array (
        0 => 'SHOUTcast Kurulumu',
      ),
      'Start Station' => 
      array (
        0 => 'Radyoyu Başlat',
      ),
      'Ready to start broadcasting? Click to start your station.' => 
      array (
        0 => 'Yayına başlamak için hazır mısınız? Radyonuzu başlatmak için tıklayın.',
      ),
      'Restart broadcasting? This will disconnect any current listeners.' => 
      array (
        0 => 'Canlı yayın yeniden başlatılsın mı? Mevcut dinleyicilerin bağlantısı kesilir.',
      ),
      'Restart to Apply Changes' => 
      array (
        0 => 'Değişiklikleri Uygulamak İçin Yeniden Başlat',
      ),
      'Click to restart your station and apply configuration changes.' => 
      array (
        0 => 'Radyonuzu yeniden başlatmak ve yapılandırma değişikliklerini uygulamak için tıklayın.',
      ),
      'Podcasts (Beta)' => 
      array (
        0 => 'Podcasts (Beta)',
      ),
      'Reports' => 
      array (
        0 => 'Raporlar',
      ),
      'Duplicate Songs' => 
      array (
        0 => 'Yinelenen Şarkılar',
      ),
      'Unprocessable Files' => 
      array (
        0 => 'İşlenemeyen Dosyalar',
      ),
      'SoundExchange Royalties' => 
      array (
        0 => 'SoundExchange Raporu',
      ),
      'Utilities' => 
      array (
        0 => 'Araçlar',
      ),
      'Automated Assignment' => 
      array (
        0 => 'Otomatik Atama',
      ),
      'Log Viewer' => 
      array (
        0 => 'Günlük Görüntüleyici',
      ),
      'Restart Broadcasting' => 
      array (
        0 => 'Yayını Yeniden Başlat',
      ),
      'Enable Automated Assignment' => 
      array (
        0 => 'Otomatik Atamayı Etkinleştir',
      ),
      'Allow the system to periodically automatically assign songs to playlists based on their performance. This process will run in the background, and will only run if this option is set to "Enabled" and at least one playlist is set to "Include in Automated Assignment".' => 
      array (
        0 => 'Sistemin performanslarına bağlı olarak şarkı listelerinin otomatik olarak şarkı listelerine atamasına izin verin. Bu işlem arka planda çalışır ve yalnızca bu seçenek "Etkin" olarak ayarlanmışsa ve en az bir parça listesi "Otomatik Atamaya Dahil Et" olarak ayarlanmışsa çalışır.',
      ),
      'Days Between Automated Assignments' => 
      array (
        0 => 'Otomatik Atama Günleri',
      ),
      'Based on this setting, the system will automatically reassign songs every (this) days using data from the previous (this) days.' => 
      array (
        0 => 'Bu ayara göre sistem önceki (bu) günlerden gelen verileri kullanarak her (bu) günde bir şarkıları otomatik olarak yeniden atar.',
      ),
      '%d days' => 
      array (
        0 => '%d gün',
      ),
      'Use Browser Default' => 
      array (
        0 => 'Tarayıcı Dilini Kullan',
      ),
      'Reset Password' => 
      array (
        0 => 'Şifreyi Değiştir',
      ),
      'Leave these fields blank to continue using your current password.' => 
      array (
        0 => 'Geçerli şifrenizi kullanmaya devam etmek için bu alanları boş bırakın.',
      ),
      'Current Password' => 
      array (
        0 => 'Şimdiki Şifre',
      ),
      'Confirm New Password' => 
      array (
        0 => 'Yeni Şifreyi Doğrula',
      ),
      'Customization' => 
      array (
        0 => 'Özelleştirme',
      ),
      'Site Theme' => 
      array (
        0 => 'Site Teması',
      ),
      'Describe the use-case for this API key for future reference.' => 
      array (
        0 => 'İleride başvurmak üzere bu API anahtarının kullanım durumunu açıklayın.',
      ),
      'Storage Location' => 
      array (
        0 => 'Depolama Konumu',
      ),
      'Backup Filename' => 
      array (
        0 => 'Yedek Dosya Adı',
      ),
      'This will be the file name for your backup, include the file type (.zip or .rar) you wish to use.' => 
      array (
        0 => 'Bu yedeklemenizin dosya adı olacak ve kullanmak istediğiniz dosya türünü (.zip veya .rar) içerecektir.',
      ),
      'Exclude Media from Backup' => 
      array (
        0 => 'Yedeklemeye Müzik Dosyalarını Dahil Etme',
      ),
      'This will produce a significantly smaller backup, but you should make sure to back up your media elsewhere. Note that only locally stored media will be backed up.' => 
      array (
        0 => 'Bu önemli ölçüde daha küçük bir yedekleme üretecektir. Ancak müzik dosyalarını başka bir yerde yedeklediğinizden emin olmalısınız. Yalnızca yerel olarak depolanan müzik dosyalarının yedekleneceğini unutmayın.',
      ),
      'Yes' => 
      array (
        0 => 'Evet',
      ),
      'No' => 
      array (
        0 => 'Hayır',
      ),
      'Run Automatic Nightly Backups' => 
      array (
        0 => 'Otomatik Gecelik Yedeklemeyi Çalıştır',
      ),
      'Enable to have AzuraCast automatically run nightly backups at the time specified.' => 
      array (
        0 => 'AzuraCast her gece belirtilen saatte otomatik olarak yedekleme yapmasını etkinleştirin.',
      ),
      'Scheduled Backup Time' => 
      array (
        0 => 'Belirlenmiş Yedekleme Zamanı',
      ),
      'The time (in UTC) to run the automated backup, if enabled.' => 
      array (
        0 => 'Etkinleştirilmiş ise otomatik yedekleme zamanı (UTC) cinsindendir.',
      ),
      'Exclude Media from Backups' => 
      array (
        0 => 'Yedeklemelere Müzik Dosyalarını Dahil Etme',
      ),
      'Excluding media from automated backups will save space, but you should make sure to back up your media elsewhere. Note that only locally stored media will be backed up.' => 
      array (
        0 => 'Medyayı otomatik yedeklemelerin dışında bırakmak yerden tasarruf sağlar. Ancak medyanızı başka bir yerde yedeklediğinizden emin olmalısınız. Yalnızca yerel olarak depolanan medyanın yedekleneceğini unutmayın.',
      ),
      'Number of Backup Copies to Keep' => 
      array (
        0 => 'Saklanacak Yedek Kopya Sayısı',
      ),
      'Copies older than the specified number of days will automatically be deleted. Set to zero to disable automatic deletion.' => 
      array (
        0 => 'Belirtilen gün sayısından daha eski kopyalar otomatik olarak silinir. Otomatik silmeyi devre dışı bırakmak için sıfıra ayarlayın.',
      ),
      'Attempt to Automatically Retrieve ISRC When Missing' => 
      array (
        0 => 'Eksik Olduğunda ISRC\'yi Otomatik Olarak Almayı Dene',
      ),
      'If enabled, AzuraCast will connect to the MusicBrainz database to attempt to find an ISRC for any files where one is missing. Disabling this may improve performance.' => 
      array (
        0 => 'Etkinleştirilirse, AzuraCast eksik olan tüm dosyalar için bir ISRC bulmaya çalışmak üzere MusicBrainz veritabanına bağlanacaktır. Bunu devre dışı bırakmak performansı artırabilir.',
      ),
      'Roles' => 
      array (
        0 => 'Yetkiler',
      ),
      'Code from Authenticator App' => 
      array (
        0 => 'Authenticator Uygulaması Kodu',
      ),
      'Enter the current code provided by your authenticator app to verify that it\'s working correctly.' => 
      array (
        0 => 'Doğru çalıştığını doğrulamak için doğrulayıcı uygulamanız tarafından sağlanan geçerli kodu girin.',
      ),
      'Verify Authenticator' => 
      array (
        0 => 'Authenticator Kodunu Doğrula',
      ),
      'Any time the currently playing song changes' => 
      array (
        0 => 'Çalan Şarkı Her Değiştiğinde',
      ),
      'Any time the listener count increases' => 
      array (
        0 => 'Dinleyici Sayısı Arttığında',
      ),
      'Any time the listener count decreases' => 
      array (
        0 => 'Dinleyici Sayısı Azaldığında',
      ),
      'Any time a live streamer/DJ connects to the stream' => 
      array (
        0 => 'DJ Yayına Bağlandığında',
      ),
      'Any time a live streamer/DJ disconnects from the stream' => 
      array (
        0 => 'DJ Yayından Ayrıldığında',
      ),
      'When the station broadcast goes offline.' => 
      array (
        0 => 'Radyo yayını çevrimdışı olduğunda.',
      ),
      'When the station broadcast comes online.' => 
      array (
        0 => 'Radyo yayını çevrimiçi olduğunda.',
      ),
      'Generic Web Hook' => 
      array (
        0 => 'Genel Web Kancası',
      ),
      'Automatically send a message to any URL when your station data changes.' => 
      array (
        0 => 'Radyo verileriniz değiştiğinde otomatik olarak herhangi bir URLye mesaj gönderin.',
      ),
      'Send E-mail' => 
      array (
        0 => 'E-Posta Gönder',
      ),
      'Send an e-mail to specified address(es).' => 
      array (
        0 => 'Belirtilen adres(ler)e bir e-posta gönderin.',
      ),
      'TuneIn AIR' => 
      array (
        0 => 'TuneIn Web Kancası',
      ),
      'Send song metadata changes to TuneIn.' => 
      array (
        0 => 'Şarkı meta verileri değişikliklerini TuneIn\'e gönderin.',
      ),
      'Discord Webhook' => 
      array (
        0 => 'Discord Web Kancası',
      ),
      'Automatically send a customized message to your Discord server.' => 
      array (
        0 => 'Discord sunucunuza otomatik olarak özelleştirilmiş bir mesaj gönderin.',
      ),
      'Telegram Chat Message' => 
      array (
        0 => 'Telegram Sohbet Mesajı',
      ),
      'Use the Telegram Bot API to send a message to a channel.' => 
      array (
        0 => 'Bir kanala mesaj göndermek için Telegram Bot APIsini kullanın.',
      ),
      'Twitter Post' => 
      array (
        0 => 'Twitter Gönderisi',
      ),
      'Automatically send a tweet.' => 
      array (
        0 => 'Otomatik olarak bir tweet gönderin.',
      ),
      'Google Analytics Integration' => 
      array (
        0 => 'Google Analytics Entegrasyonu',
      ),
      'Send stream listener details to Google Analytics.' => 
      array (
        0 => 'Canlı yayın dinleyici ayrıntılarını Google Analytics\'e gönderin.',
      ),
      'Matomo Analytics Integration' => 
      array (
        0 => 'Matomo Analiz Entegrasyonu',
      ),
      'Send stream listener details to Matomo Analytics.' => 
      array (
        0 => 'Akış dinleyici ayrıntılarını Matomo Analiz\'e gönderin.',
      ),
      'Account Recovery' => 
      array (
        0 => 'Hesap Kurtarma',
      ),
      'An account recovery link has been requested for your account on "%s".' => 
      array (
        0 => '"%s" tarihinde hesabınız için bir hesap kurtarma bağlantısı talep edildi.',
      ),
      'Click the link below to log in to your account.' => 
      array (
        0 => 'Hesabınıza giriş yapmak için aşağıdaki bağlantıya tıklayın.',
      ),
      'Skip to main content' => 
      array (
        0 => 'Ana İçeriğe Atla',
      ),
      'Toggle Sidebar' => 
      array (
        0 => 'Kenar Çubuğunu Değiştir',
      ),
      'Toggle Menu' => 
      array (
        0 => 'Menüyü Değiştir',
      ),
      'System Administration' => 
      array (
        0 => 'Sistem Yönetimi',
      ),
      'Switch Theme' => 
      array (
        0 => 'Temayı Değiştir',
      ),
      'My API Keys' => 
      array (
        0 => 'API Anahtarlarım',
      ),
      'Help' => 
      array (
        0 => 'Yardım',
      ),
      'End Session' => 
      array (
        0 => 'Oturumu Sonlandır',
      ),
      'Sign Out' => 
      array (
        0 => 'Çıkış Yap',
      ),
      'Powered by %s' => 
      array (
        0 => '%s tarafından güçlendirilmiştir.',
      ),
      'Like our software? <a href="%s" target="_blank">Donate to support AzuraCast!</a>' => 
      array (
        0 => 'AzuraCast\'i beğendiniz mi? <a href="%s" target="_blank">Destek olmak için bağış yapın!</a> ',
      ),
      'Errors were encountered when trying to save changes:' => 
      array (
        0 => 'Değişiklikleri kaydetmeye çalışırken hatalarla karşılaşıldı:',
      ),
      'General' => 
      array (
        0 => 'Genel',
      ),
      'Details' => 
      array (
        0 => 'Ayrıntılar',
      ),
      'Server Status' => 
      array (
        0 => 'Sunucu Durumu',
      ),
      'CPU Load' => 
      array (
        0 => 'CPU Yükü',
      ),
      'Current' => 
      array (
        0 => 'Şu Anki',
      ),
      '15-Minute Average' => 
      array (
        0 => '15-Dakikalık Ortalama',
      ),
      'Memory' => 
      array (
        0 => 'Bellek',
      ),
      '%s of %s Used' => 
      array (
        0 => 'Kullanılan Alan: %s / %s',
      ),
      'Disk Space' => 
      array (
        0 => 'Disk Alanı',
      ),
      'Synchronization Tasks' => 
      array (
        0 => 'Senkronizasyon Görevleri',
      ),
      'Last run: %s' => 
      array (
        0 => 'Son Çalıştırma: %s',
      ),
      'Run Task' => 
      array (
        0 => 'Görevi Çalıştır',
      ),
      'API Key' => 
      array (
        0 => 'API Anahtarı',
      ),
      'Owner' => 
      array (
        0 => 'Sahip',
      ),
      'Revoke' => 
      array (
        0 => 'Geri Al',
      ),
      'Clear Cache' => 
      array (
        0 => 'Önbelleği Temizle',
      ),
      'Clearing the application cache may log you out of your session.' => 
      array (
        0 => 'Uygulama önbelleğini temizlemek oturumunuzdan çıkmanıza neden olabilir.',
      ),
      'Clear All Message Queues' => 
      array (
        0 => 'Mesaj Kuyruğunu Temizle',
      ),
      'This will clear any pending unprocessed messages in all message queues.' => 
      array (
        0 => 'Bu mesaj kuyruğundaki tüm işlenmemiş bekleyen mesajları temizleyecektir.',
      ),
      'Message Queues' => 
      array (
        0 => 'Mesaj Sırası',
      ),
      '%d queued messages' => 
      array (
        0 => '%d okunmayan mesaj',
      ),
      'Station-Specific Debugging' => 
      array (
        0 => 'Radyo Hata Ayıklama',
      ),
      'Rebuild AutoDJ Queue' => 
      array (
        0 => 'AutoDJ Sırasını Yeniden Oluştur',
      ),
      'Run Test' => 
      array (
        0 => 'Testi Çalıştır',
      ),
      'Send Liquidsoap Telnet Command' => 
      array (
        0 => 'Liquidsoap Telnet Komutu Gönder',
      ),
      'Command' => 
      array (
        0 => 'Komut',
      ),
      'Execute Command' => 
      array (
        0 => 'Komutu Çalıştır',
      ),
      'Run Synchronization Task' => 
      array (
        0 => 'Senkronizasyon Görevini Çalıştır',
      ),
      'Debug Home' => 
      array (
        0 => 'Hata Ayıklama Sayfası',
      ),
      'The synchronization task is running in the background. The log below will update automatically.' => 
      array (
        0 => 'Senkronizasyon görevi arka planda çalışıyor. Aşağıdaki günlük otomatik olarak güncellenecektir.',
      ),
      'Log In' => 
      array (
        0 => 'Giriş Yap',
      ),
      'Delete user "%s"?' => 
      array (
        0 => '"%s" kullanıcı silinsin mi?',
      ),
      '(You)' => 
      array (
        0 => '(Sen)',
      ),
      'Because you are running Docker, some system logs can only be accessed from a shell session on the host computer. You can run <code>%s</code> to access container logs from the terminal.' => 
      array (
        0 => 'Docker kullandığınız için bazı sistem günlüklerine yalnızca sunudaki SSH oturumuyla erişilebilir. Terminalden Docker günlüklerine erişmek için <code>%s</code> komutunu çalıştırabilirsiniz.',
      ),
      'Logs by Station' => 
      array (
        0 => 'Radyo Günlükleri',
      ),
      'Relay' => 
      array (
        0 => 'Yönlendirme',
      ),
      'Is Public' => 
      array (
        0 => 'Genel',
      ),
      'First Connected' => 
      array (
        0 => 'Birinci Bağlantı',
      ),
      'Latest Update' => 
      array (
        0 => 'Son Güncelleme',
      ),
      'Backups Home' => 
      array (
        0 => 'Yedekleme Anasayfası',
      ),
      'The backup process is running in the background. The log below will update automatically.' => 
      array (
        0 => 'Yedekleme işlemi arka planda çalışıyor. Aşağıdaki günlük otomatik olarak güncellenecektir.',
      ),
      'Automatic Backups' => 
      array (
        0 => 'Otomatik Yedeklemeler',
      ),
      'Never run' => 
      array (
        0 => 'Asla Çalıştırma',
      ),
      'Configure' => 
      array (
        0 => 'Yapılandırma',
      ),
      'Most Recent Backup Log' => 
      array (
        0 => 'En Yeni Yedekleme Günlüğü',
      ),
      'Restoring Backups' => 
      array (
        0 => 'Yedekleri Geri Yükleme',
      ),
      'To restore a backup from your host computer, run:' => 
      array (
        0 => 'Kendi bilgisayarınızdan bir yedek geri yüklemek için aşağıdakileri çalıştırın:',
      ),
      'Note that restoring a backup will clear your existing database. Never restore backup files from untrusted users.' => 
      array (
        0 => 'Bir yedeğin geri yüklenmesinin mevcut veritabanınızı temizleyeceğini unutmayın. Hiçbir zaman güvenilmeyen kullanıcılardan yedekleme dosyalarını geri yüklemeyin.',
      ),
      'Backup' => 
      array (
        0 => 'Yedek',
      ),
      'Last Modified' => 
      array (
        0 => 'Değişiklik Tarihi',
      ),
      'Delete backup "%s"?' => 
      array (
        0 => '"%s" yedeklemesi silinsin mi?',
      ),
      'Report Not Available' => 
      array (
        0 => 'Rapor Kullanılamaz',
      ),
      'This report is not available for this station, because the system administrator has chosen not to collect detailed IP-based listener information.' => 
      array (
        0 => 'Sistem yöneticisi IP tabanlı ayrıntılı dinleyici bilgilerini toplamayı devre dışı bıraktığı için bu rapor bulunmuyor.',
      ),
      'Station Broadcasting Disabled' => 
      array (
        0 => 'Radyo Canlı Yayını Devredışı',
      ),
      'Your station is currently not enabled for broadcasting. You can still manage media, playlists, and other station settings. To re-enable broadcasting, <a href="%s">edit your station profile</a>.' => 
      array (
        0 => 'Radyonuz yayın için şu anda etkin değildir. Müzikleri, çalma listelerini ve diğer radyo ayarlarını halen yönetebilirsiniz. Yayını yeniden etkinleştirmek için <a href="%s">radyo profili</a>ni düzenleyin.',
      ),
      'Available Logs' => 
      array (
        0 => 'Mevcut Günlükler',
      ),
      'Station Time' => 
      array (
        0 => 'Radyo Saati',
      ),
      'Automated Playlist Assignment' => 
      array (
        0 => 'Otomatik Oynatma Listesi Ataması',
      ),
      'Based on the previous performance of your station\'s songs, %s can automatically distribute songs evenly among your playlists, placing the highest performing songs in the highest-weighted playlists.' => 
      array (
        0 => '%s şarkılarınızın performansına bağlı olarak en yüksek öncelikli çalma listelerinde en iyi şekilde yer alan çalma listeleriniz arasında otomatik olarak şarkıları eşit şekilde dağıtacaktır.',
      ),
      'Once you have configured automated assignment, click the button below to run the automated assignment process. This process will not run at all unless you have selected "Enable" below.' => 
      array (
        0 => 'Otomatik atamayı yapılandırdıktan sonra otomatik atama işlemini çalıştırmak için aşağıdaki düğmeyi tıklayın. Aşağıda "Etkinleştir" seçeneğini seçmediğiniz sürece bu işlem hiç çalışmayacaktır.',
      ),
      'Run Automated Assignment' => 
      array (
        0 => 'Otomatik Atamayı Çalıştır',
      ),
      'Configure Automated Assignment' => 
      array (
        0 => 'Otomatik Atamayı Yapılandır',
      ),
      'Streamer accounts are currently disabled for this station. To enable streamer accounts, click the button below.' => 
      array (
        0 => 'Bu radyo için DJ hesapları şu an devre dışıdır. Etkinleştirmek için aşağıdaki butona tıklayın.',
      ),
      'Enable Streaming' => 
      array (
        0 => 'Canlı Yayını Etkinleştir',
      ),
      'Two-Factor Authentication' => 
      array (
        0 => 'İki Faktörlü Kimlik Doğrulama',
      ),
      'Two-factor authentication improves the security of your account by requiring a second one-time access code in addition to your password when you log in.' => 
      array (
        0 => 'İki faktörlü kimlik doğrulama oturum açtığınızda şifrenizin yanı sıra ikinci güvenlik olarak bir kerelik erişim kodu gerektirerek hesabınızın güvenliğini artırır.',
      ),
      'Disable Two-Factor' => 
      array (
        0 => 'İki Faktörlü Doğrulamayı Devredışı Bırak',
      ),
      'Enable Two-Factor' => 
      array (
        0 => 'İki Faktörlü Doğrulamayı Etkinleştir',
      ),
      'Enable Two-Factor Authentication' => 
      array (
        0 => 'İki Faktörlü Kimlik Doğrulamayı Etkinleştir',
      ),
      'Step 1: Scan QR Code' => 
      array (
        0 => 'Adım 1: QR Kodunu Tara',
      ),
      'From your smartphone, scan the code to the right using an authentication app of your choice (FreeOTP, Authy, etc).' => 
      array (
        0 => 'Akıllı telefonunuzdan seçtiğiniz bir doğrulayıcı uygulamayı (FreeOTP, Authy, vb.) kullanarak sağdaki kodu tarayın.',
      ),
      'Step 2: Verify Generated Code' => 
      array (
        0 => 'Adım 2: Oluşturulan Kodu Doğrulayın',
      ),
      'To verify that the code was set up correctly, enter the 6-digit code the app shows you.' => 
      array (
        0 => 'Kodun doğru ayarlandığından emin olmak için uygulamanın size gösterdiği 6 basamaklı kodu girin.',
      ),
      'QR-Code' => 
      array (
        0 => 'QR Kodu',
      ),
      'No entries found.' => 
      array (
        0 => 'Hiçbir girdi bulunamadı.',
      ),
      'View Details' => 
      array (
        0 => 'Ayrıntıları Görüntüle',
      ),
      'New Key Generated' => 
      array (
        0 => 'Yeni Anahtar Üretildi',
      ),
      '<b>Important: copy the key below before continuing!</b> You will not be able to retrieve it again.' => 
      array (
        0 => '<b>Önemli: Devam etmeden önce aşağıdaki anahtarı kopyalayın!</b> Tekrar alamayacaksınız.',
      ),
      'Your full API key is below:' => 
      array (
        0 => 'Tam API anahtarınız aşağıdadır:',
      ),
      'When making API calls, you can pass this value in the "X-API-Key" header to authenticate as yourself. You can only perform the actions your user account is allowed to perform.' => 
      array (
        0 => 'API çağrıları yaparken bu değeri "X-API-Key" başlığında kendiniz gibi doğrulamak için iletebilirsiniz. Yalnızca kullanıcı hesabınızın gerçekleştirmesine izin verilen işlemleri gerçekleştirebilirsiniz.',
      ),
      'Continue' => 
      array (
        0 => 'Devam Et',
      ),
      'API keys can be used to access some system functionality without needing to log in. All of the keys
            you create share your permissions in the system. For more information, see the <a href="%s">API documentation</a>.' => 
      array (
        0 => 'API anahtarları bazı sistem işlevlerine giriş yapmak zorunda kalmadan erişmek için kullanılabilir. Oluşturduğunuz tüm anahtarlar
            sistemdeki izinlerinizi paylaşır. Daha fazla bilgi için <a href="%s">API Belgeleri</a>ne bakın.',
      ),
      'Key Identifier' => 
      array (
        0 => 'Anahtar Tanımlayıcı',
      ),
      'Enter Two-Factor Code' => 
      array (
        0 => 'İki Faktörlü Doğrulama Kodu',
      ),
      'Your account uses a two-factor security code. Enter the code your device is currently showing below.' => 
      array (
        0 => 'Hesabınız iki faktörlü güvenlik doğrulamasını kullanıyor. Cihazınızın şu anda göstermekte olduğu kodu girin.',
      ),
      'Security Code' => 
      array (
        0 => 'Güvenlik Kodu',
      ),
      'Sign in' => 
      array (
        0 => 'Giriş Yap',
      ),
      'Forgot Password' => 
      array (
        0 => 'Şifremi Unuttum',
      ),
      'name@example.com' => 
      array (
        0 => 'E-Posta Adresinizi Yazın',
      ),
      'Send Recovery E-mail' => 
      array (
        0 => 'Kurtarma E-postası Gönderin',
      ),
      'Welcome!' => 
      array (
        0 => 'Hoşgeldiniz!',
      ),
      'Welcome to %s!' => 
      array (
        0 => 'Hoşgeldiniz!',
      ),
      'Enter your password' => 
      array (
        0 => 'Şifrenizi Girin',
      ),
      'Remember me' => 
      array (
        0 => 'Beni Hatırla',
      ),
      'Please log in to continue.' => 
      array (
        0 => 'Devam etmek için lütfen giriş yapın.',
      ),
      'Forgot your password?' => 
      array (
        0 => 'Şifrenizi mi unuttunuz?',
      ),
      'This installation\'s administrator has not configured this functionality.' => 
      array (
        0 => 'Bu kurulumun yöneticisi bu işlevi yapılandırmadı.',
      ),
      'Contact an administrator to reset your password following the instructions in our documentation:' => 
      array (
        0 => 'Belgelerimizdeki talimatları izleyerek parolanızı sıfırlaması için bir yöneticiyle iletişime geçin:',
      ),
      'Password Reset Instructions' => 
      array (
        0 => 'Şifre Sıfırlama Talimatları',
      ),
      'Recover Account' => 
      array (
        0 => 'Hesap Kurtarma',
      ),
      'Choose a new password for your account.' => 
      array (
        0 => 'Hesabınız için yeni bir şifre giriniz.',
      ),
      'Automatically scroll to the bottom of the log' => 
      array (
        0 => 'Günlüğü en alta otomatik kaydır',
      ),
      'Need Help?' => 
      array (
        0 => 'Yardıma Mı İhtiyacınız Var?',
      ),
      'You can find answers for many common questions in our <a href="%s" target="_blank">support documents</a>.' => 
      array (
        0 => 'SSS belgelerine ulaşmak için <a href="%s" target="_blank">destek dökümanları</a> sayfasına göz atabilirsiniz.',
      ),
      'If you\'re experiencing a bug or error, you can submit a GitHub issue using the link below.' => 
      array (
        0 => 'Bir bug veya hata yaşıyorsanız aşağıdaki bağlantıyı kullanarak GitHub sorunu gönderebilirsiniz.',
      ),
      'Your current installation type is <b>%s</b>. Be sure to include this when creating a new issue.' => 
      array (
        0 => '<b>%s</b> mevcut kurulum türünüzdür ve yeni bir sorun oluştururken bunu eklediğinizden emin olun.',
      ),
      'Add New GitHub Issue' => 
      array (
        0 => 'Yeni GitHub Sorunu',
      ),
    ),
  ),
);