<?php return array (
  'domain' => NULL,
  'plural-forms' => 'nplurals=2; plural=(n != 1);',
  'messages' => 
  array (
    '' => 
    array (
      '' => 
      array (
        0 => 'Project-Id-Version: azuracast
Report-Msgid-Bugs-To: 
Last-Translator: 
Language-Team: Swedish
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
POT-Creation-Date: 2021-10-27T06:14:10+00:00
PO-Revision-Date: 2021-10-27 07:09
Language: sv_SE
Plural-Forms: nplurals=2; plural=(n != 1);
X-Crowdin-Project: azuracast
X-Crowdin-Project-ID: 217396
X-Crowdin-Language: sv-SE
X-Crowdin-File: /main/resources/locale/default.pot
X-Crowdin-File-ID: 4
',
      ),
      'Avatars are retrieved based on your e-mail address from the %{service} service. Click to manage your %{service} settings.' => 
      array (
        0 => '',
      ),
      'Drag file(s) here to upload or' => 
      array (
        0 => '',
      ),
      'Select File' => 
      array (
        0 => 'Välj fil',
      ),
      'Today' => 
      array (
        0 => 'Idag',
      ),
      'Yesterday' => 
      array (
        0 => 'Igår',
      ),
      'Last 7 Days' => 
      array (
        0 => 'Senaste 7 dagarna',
      ),
      'Last 14 Days' => 
      array (
        0 => 'Senaste 14 dagarna',
      ),
      'Last 30 Days' => 
      array (
        0 => 'Senaste 30 dagarna',
      ),
      'This Month' => 
      array (
        0 => 'Denna månad',
      ),
      'Last Month' => 
      array (
        0 => 'Förra månaden',
      ),
      'Volume' => 
      array (
        0 => 'Volym',
      ),
      'Waveform Zoom' => 
      array (
        0 => 'Vågform Zoom',
      ),
      'Mute' => 
      array (
        0 => 'Tysta',
      ),
      'Full Volume' => 
      array (
        0 => 'Full volym',
      ),
      'Edit Record' => 
      array (
        0 => '',
      ),
      'Add Record' => 
      array (
        0 => '',
      ),
      'Copy to Clipboard' => 
      array (
        0 => 'Kopiera till urklipp',
      ),
      'Close' => 
      array (
        0 => 'Stäng',
      ),
      'Save Changes' => 
      array (
        0 => 'Spara ändringar',
      ),
      'Refresh rows' => 
      array (
        0 => 'Uppdatera rader',
      ),
      'Rows per page' => 
      array (
        0 => 'Rader per sida',
      ),
      'Select displayed fields' => 
      array (
        0 => 'Välj visade fält',
      ),
      'Select all visible rows' => 
      array (
        0 => 'Markera alla synliga rader',
      ),
      'Select' => 
      array (
        0 => '',
      ),
      'Deselect' => 
      array (
        0 => '',
      ),
      'Search' => 
      array (
        0 => 'Sök',
      ),
      'No records to display.' => 
      array (
        0 => 'Inga poster att visa.',
      ),
      'Loading...' => 
      array (
        0 => 'Laddar...',
      ),
      'Stop' => 
      array (
        0 => 'Stoppa',
      ),
      'Play' => 
      array (
        0 => 'Spela',
      ),
      'Listeners' => 
      array (
        0 => 'Lyssnare',
      ),
      'Log View' => 
      array (
        0 => 'Logg vy',
      ),
      'Average Listeners' => 
      array (
        0 => 'Genomsnittliga lyssnare',
      ),
      'Unique Listeners' => 
      array (
        0 => 'Unika lyssnare',
      ),
      'Hide Charts' => 
      array (
        0 => '',
      ),
      'Show Charts' => 
      array (
        0 => '',
      ),
      'My Account' => 
      array (
        0 => 'Mitt konto',
      ),
      'Administration' => 
      array (
        0 => 'Administration',
      ),
      'Listeners Per Station' => 
      array (
        0 => 'Lyssnare Per Station',
      ),
      'Station Overview' => 
      array (
        0 => 'Stationsöversikt',
      ),
      'Manage Stations' => 
      array (
        0 => '',
      ),
      'Station Name' => 
      array (
        0 => 'Stationens namn',
      ),
      'Now Playing' => 
      array (
        0 => 'Nu Spelas',
      ),
      'Public Page' => 
      array (
        0 => 'Offentlig sida',
      ),
      'Manage' => 
      array (
        0 => 'Hantera',
      ),
      'Username' => 
      array (
        0 => 'Användarnamn',
      ),
      'New Password' => 
      array (
        0 => 'Nytt lösenord',
      ),
      'Password' => 
      array (
        0 => 'Lösenord',
      ),
      'Leave blank to use the current password.' => 
      array (
        0 => 'Lämna tomt för att använda det aktuella lösenordet.',
      ),
      'SSH Public Keys' => 
      array (
        0 => 'Offentliga SSH-nycklar',
      ),
      'Optionally supply SSH public keys this user can use to connect instead of a password. Enter one key per line.' => 
      array (
        0 => 'Som tillval tillhandahåller SSH publika nycklar som användaren kan använda för att ansluta istället för ett lösenord. Ange en nyckel per rad.',
      ),
      'Edit SFTP User' => 
      array (
        0 => 'Redigera SFTP-användare',
      ),
      'Add SFTP User' => 
      array (
        0 => 'Lägg till SFTP-användare',
      ),
      'Reorder Playlist' => 
      array (
        0 => '',
      ),
      'Down' => 
      array (
        0 => 'Ner',
      ),
      'Up' => 
      array (
        0 => 'Upp',
      ),
      'Playlist order set.' => 
      array (
        0 => 'Sorteringsordning för spellista.',
      ),
      'Title' => 
      array (
        0 => 'Titel',
      ),
      'Artist' => 
      array (
        0 => 'Artist',
      ),
      'Album' => 
      array (
        0 => 'Album',
      ),
      'Actions' => 
      array (
        0 => '',
      ),
      'Advanced' => 
      array (
        0 => 'Avancerat',
      ),
      'Warning' => 
      array (
        0 => 'Varning',
      ),
      'If any of these options are enabled, this playlist will be managed directly via Liquidsoap instead of via AzuraCast. This can have unintended effects and should only be used when you are comfortable with the results.' => 
      array (
        0 => 'Om något av dessa alternativ är aktiverat, kommer denna spellista att hanteras direkt via Liquidsoap istället för via AzuraCast. Detta kan ha oavsiktliga effekter och bör endast användas när du är bekväm med resultatet.',
      ),
      'Advanced Manual AutoDJ Scheduling Options' => 
      array (
        0 => 'Avancerade manuella AutoDJ schemaläggningsalternativ',
      ),
      'Control how this playlist is handled by the AutoDJ software.' => 
      array (
        0 => 'Styr hur denna spellista hanteras av AutoDJ-programvaran.',
      ),
      'Interrupt other songs to play at scheduled time.' => 
      array (
        0 => 'Förhindra andra låtar att spela på schemalagd tid.',
      ),
      'Only loop through playlist once.' => 
      array (
        0 => 'Loopa bara igenom spellistan en gång.',
      ),
      'Only play one track at scheduled time.' => 
      array (
        0 => 'Spela bara ett spår vid schemalagd tidpunkt.',
      ),
      'Merge playlist to play as a single track.' => 
      array (
        0 => 'Slå ihop spellistan för att spela som ett enda spår.',
      ),
      'Low' => 
      array (
        0 => 'Låg',
      ),
      'Default' => 
      array (
        0 => 'Standard',
      ),
      'High' => 
      array (
        0 => 'Hög',
      ),
      'Basic Info' => 
      array (
        0 => 'Grundläggande information',
      ),
      'Playlist Name' => 
      array (
        0 => 'Namn på spellista',
      ),
      'Playlist Weight' => 
      array (
        0 => 'Vikt för spellista',
      ),
      'Higher weight playlists are played more frequently compared to other lower-weight playlists.' => 
      array (
        0 => 'Spellistor med högre vikt spelas oftare jämfört med andra lägre vikt.',
      ),
      'Is Enabled' => 
      array (
        0 => 'Är aktiverad',
      ),
      'If disabled, the playlist will not be included in radio playback, but can still be managed.' => 
      array (
        0 => 'Om inaktiverad kommer spellistan inte att inkluderas i radiouppspelningen, men den kan fortfarande hanteras.',
      ),
      'Avoid Duplicate Artists/Titles' => 
      array (
        0 => 'Undvik duplicerade artister/titlar',
      ),
      'Whether the AutoDJ should attempt to avoid duplicate artists and track titles when playing media from this playlist.' => 
      array (
        0 => 'Om AutoDJ ska försöka undvika dubbla artister och spåra titlar när du spelar media från den här spellistan.',
      ),
      'Include in On-Demand Player' => 
      array (
        0 => 'Inkludera i On-Demand spelare',
      ),
      'If this station has on-demand streaming and downloading enabled, only songs that are in playlists with this setting enabled will be visible.' => 
      array (
        0 => 'Om denna station har on-demand streaming och nedladdning aktiverad, kommer endast låtar som finns i spellistor med denna inställning aktiverade att synas.',
      ),
      'Playlist Type' => 
      array (
        0 => 'Typ av spellista',
      ),
      'General Rotation' => 
      array (
        0 => 'Allmän rotation',
      ),
      'Standard playlist, shuffles with other standard playlists based on weight.' => 
      array (
        0 => '',
      ),
      'Once per x Songs' => 
      array (
        0 => 'En gång per x låtar',
      ),
      'Play exactly once every $x songs.' => 
      array (
        0 => 'Spela exakt en gång var $x låt.',
      ),
      'Once per x Minutes' => 
      array (
        0 => 'En gång per x minuter',
      ),
      'Play exactly once every $x minutes.' => 
      array (
        0 => 'Spela exakt en gång var $x minut.',
      ),
      'Once per Hour' => 
      array (
        0 => 'En gång i timmen',
      ),
      'Play once per hour at the specified minute.' => 
      array (
        0 => 'Spela en gång i timmen på angiven minut.',
      ),
      'Manually define how this playlist is used in Liquidsoap configuration.' => 
      array (
        0 => 'Definiera manuellt hur denna spellista används i Liquidsoap-konfigurationen.',
      ),
      'Learn about Advanced Playlists' => 
      array (
        0 => 'Lär dig mer om avancerade spellistor',
      ),
      'Include in Automated Assignment' => 
      array (
        0 => 'Inkludera i automatiserad tilldelning',
      ),
      'If auto-assignment is enabled, use this playlist as one of the targets for songs to be redistributed into. This will overwrite the existing contents of this playlist.' => 
      array (
        0 => 'Om auto-tilldelning är aktiverad, använd den här spellistan som ett av målen för låtar att omfördelas till. Detta kommer att skriva över det befintliga innehållet i denna spellista.',
      ),
      'Number of Songs Between Plays' => 
      array (
        0 => 'Antal låtar mellan spelningar',
      ),
      'This playlist will play every $x songs, where $x is specified below.' => 
      array (
        0 => '',
      ),
      'Number of Minutes Between Plays' => 
      array (
        0 => 'Antal minuter mellan spelningar',
      ),
      'This playlist will play every $x minutes, where $x is specified below.' => 
      array (
        0 => '',
      ),
      'Minute of Hour to Play' => 
      array (
        0 => 'Minut i timmen att spela',
      ),
      'Specify the minute of every hour that this playlist should play.' => 
      array (
        0 => '',
      ),
      'Monday' => 
      array (
        0 => 'Måndag',
      ),
      'Tuesday' => 
      array (
        0 => 'Tisdag',
      ),
      'Wednesday' => 
      array (
        0 => 'Onsdag',
      ),
      'Thursday' => 
      array (
        0 => 'Torsdag',
      ),
      'Friday' => 
      array (
        0 => 'Fredag',
      ),
      'Saturday' => 
      array (
        0 => 'Lördag',
      ),
      'Sunday' => 
      array (
        0 => 'Söndag',
      ),
      'Schedule' => 
      array (
        0 => 'Schema',
      ),
      'Not Scheduled' => 
      array (
        0 => 'Inte schemalagd',
      ),
      'This playlist currently has no scheduled times. It will play at all times. To add a new scheduled time, click the button below.' => 
      array (
        0 => '',
      ),
      'Scheduled Time #%{num}' => 
      array (
        0 => 'Schemalagd tid #%{num}',
      ),
      'Remove' => 
      array (
        0 => 'Radera',
      ),
      'Start Time' => 
      array (
        0 => 'Starttid',
      ),
      'To play once per day, set the start and end times to the same value.' => 
      array (
        0 => 'Om du vill spela en gång per dag, ange start- och sluttider till samma värde.',
      ),
      'End Time' => 
      array (
        0 => 'Sluttid',
      ),
      'If the end time is before the start time, the playlist will play overnight.' => 
      array (
        0 => 'Om sluttiden är före starttiden kommer spellistan att spelas över natten.',
      ),
      'Station Time Zone' => 
      array (
        0 => 'Tidszon för station',
      ),
      'This station\'s time zone is currently %{tz}.' => 
      array (
        0 => '',
      ),
      'Start Date' => 
      array (
        0 => '',
      ),
      'To set this schedule to run only within a certain date range, specify a start and end date.' => 
      array (
        0 => 'För att ställa in detta schema till att endast köras inom ett visst datumintervall, ange ett start- och slutdatum.',
      ),
      'Start/end date cannot be used on playlists with advanced settings!' => 
      array (
        0 => '',
      ),
      'End Date' => 
      array (
        0 => 'Slutdatum',
      ),
      'Loop Once' => 
      array (
        0 => '',
      ),
      'Scheduled Play Days of Week' => 
      array (
        0 => 'Schemalagda speldagar i veckan',
      ),
      'Leave blank to play on every day of the week.' => 
      array (
        0 => 'Lämna tomt för att spela på varje dag i veckan.',
      ),
      'Add Schedule Item' => 
      array (
        0 => 'Lägg till Schemaläggning',
      ),
      'Source' => 
      array (
        0 => 'Källa',
      ),
      'Song-Based Playlist' => 
      array (
        0 => 'Låtbaserad spellista',
      ),
      'A playlist containing media files hosted on this server.' => 
      array (
        0 => 'En spellista som innehåller mediafiler som finns på denna server.',
      ),
      'Remote URL Playlist' => 
      array (
        0 => 'Fjärr-URL spellista',
      ),
      'A playlist that instructs the station to play from a remote URL.' => 
      array (
        0 => 'En spellista som instruerar stationen att spela från en fjärr-URL.',
      ),
      'Song Playback Order' => 
      array (
        0 => 'Ordning för Låtuppspelning',
      ),
      'Shuffled' => 
      array (
        0 => '',
      ),
      'The full playlist is shuffled and then played through in the shuffled order.' => 
      array (
        0 => '',
      ),
      'Random' => 
      array (
        0 => 'Slumpmässig',
      ),
      'A completely random track is picked for playback every time the queue is populated.' => 
      array (
        0 => 'Ett helt slumpmässigt spår väljs för uppspelning varje gång kön är aktiv.',
      ),
      'Sequential' => 
      array (
        0 => 'Sekventiell',
      ),
      'The order of the playlist is manually specified and followed by the AutoDJ.' => 
      array (
        0 => '',
      ),
      'If requests are enabled for your station, users will be able to request media that is on this playlist.' => 
      array (
        0 => 'Om önskningar är aktiverade för din station, kommer användare att kunna önska låtar som finns i den här spellistan.',
      ),
      'Allow Requests from This Playlist' => 
      array (
        0 => 'Tillåt önskemål från den här spellistan',
      ),
      'Enable this setting to prevent metadata from being sent to the AutoDJ for files in this playlist. This is useful if the playlist contains jingles or bumpers.' => 
      array (
        0 => 'Aktivera denna inställning för att förhindra att metadata skickas till AutoDJ för filer i den här spellistan. Detta är användbart om spellistan innehåller jingles eller liknande.',
      ),
      'Hide Metadata from Listeners ("Jingle Mode")' => 
      array (
        0 => 'Dölj Metadata från lyssnare ("Jingle Mode")',
      ),
      'Remote URL' => 
      array (
        0 => 'Fjärr-URL',
      ),
      'Remote URL Type' => 
      array (
        0 => 'Fjärr-URL-typ',
      ),
      'Direct Stream URL' => 
      array (
        0 => 'Direkt Stream URL',
      ),
      'Playlist (M3U/PLS) URL' => 
      array (
        0 => 'Spellista (M3U/PLS) URL',
      ),
      'Remote Playback Buffer (Seconds)' => 
      array (
        0 => 'Fjärruppspelningsbuffert (sekunder)',
      ),
      'The length of playback time that Liquidsoap should buffer when playing this remote playlist. Shorter times may lead to intermittent playback on unstable connections.' => 
      array (
        0 => '',
      ),
      'Import from PLS/M3U' => 
      array (
        0 => 'Importera från PLS/M3U',
      ),
      'Select PLS/M3U File to Import' => 
      array (
        0 => 'Välj PLS/M3U-fil att importera',
      ),
      'AzuraCast will scan the uploaded file for matches in this station\'s music library. Media should already be uploaded before running this step. You can re-run this tool as many times as needed.' => 
      array (
        0 => 'AzuraCast kommer att skanna den uppladdade filen för matcher i den här stationens musikbibliotek. Media bör redan ha laddats upp innan du kör detta steg. Du kan använda denna tjänst hur många gånger du vill.',
      ),
      'Duplicate Playlist' => 
      array (
        0 => '',
      ),
      '%{name} - Copy' => 
      array (
        0 => '',
      ),
      'New Playlist Name' => 
      array (
        0 => '',
      ),
      'Customize Copy' => 
      array (
        0 => '',
      ),
      'Copy associated media and folders.' => 
      array (
        0 => '',
      ),
      'Copy scheduled playback times.' => 
      array (
        0 => '',
      ),
      'Playback Queue' => 
      array (
        0 => '',
      ),
      'Playlist queue cleared.' => 
      array (
        0 => '',
      ),
      'This queue contains the remaining tracks in the order they will be queued by the AzuraCast AutoDJ (if the tracks are eligible to be played).' => 
      array (
        0 => '',
      ),
      'Clear Queue' => 
      array (
        0 => '',
      ),
      'Edit Playlist' => 
      array (
        0 => 'Redigera spellista',
      ),
      'Add Playlist' => 
      array (
        0 => 'Lägg till ny spellista',
      ),
      'Edit Station Profile' => 
      array (
        0 => '',
      ),
      'Song Title' => 
      array (
        0 => 'Låttitel',
      ),
      'Cued On' => 
      array (
        0 => 'Köad på',
      ),
      'Delete Queue Item?' => 
      array (
        0 => '',
      ),
      'Clear Upcoming Song Queue?' => 
      array (
        0 => '',
      ),
      'Clear' => 
      array (
        0 => 'Rensa',
      ),
      'Upcoming Song Queue' => 
      array (
        0 => '',
      ),
      'Clear Upcoming Song Queue' => 
      array (
        0 => '',
      ),
      'Logs' => 
      array (
        0 => '',
      ),
      'Delete' => 
      array (
        0 => '',
      ),
      'Listener Request' => 
      array (
        0 => '',
      ),
      'Playlist:' => 
      array (
        0 => '',
      ),
      'Remote Station Type' => 
      array (
        0 => '',
      ),
      'Display Name' => 
      array (
        0 => '',
      ),
      'The display name assigned to this relay when viewing it on administrative or public pages. Leave blank to automatically generate one.' => 
      array (
        0 => '',
      ),
      'Remote Station Listening URL' => 
      array (
        0 => '',
      ),
      'Example: if the remote radio URL is http://station.example.com:8000/radio.mp3, enter "http://station.example.com:8000".' => 
      array (
        0 => '',
      ),
      'Remote Station Listening Mountpoint/SID' => 
      array (
        0 => '',
      ),
      'Specify a mountpoint (i.e. "/radio.mp3") or a Shoutcast SID (i.e. "2") to specify a specific stream to use for statistics or broadcasting.' => 
      array (
        0 => '',
      ),
      'Remote Station Administrator Password' => 
      array (
        0 => '',
      ),
      'To retrieve detailed unique listeners and client details, an administrator password is often required.' => 
      array (
        0 => '',
      ),
      'Show on Public Pages' => 
      array (
        0 => '',
      ),
      'Enable to allow listeners to select this relay on this station\'s public pages.' => 
      array (
        0 => '',
      ),
      'AutoDJ' => 
      array (
        0 => 'AutoDJ',
      ),
      'Broadcast AutoDJ to Remote Station' => 
      array (
        0 => '',
      ),
      'If enabled, the AutoDJ on this installation will automatically play music to this mount point.' => 
      array (
        0 => '',
      ),
      'AutoDJ Format' => 
      array (
        0 => '',
      ),
      'AutoDJ Bitrate (kbps)' => 
      array (
        0 => '',
      ),
      'Remote Station Source Port' => 
      array (
        0 => '',
      ),
      'If the port you broadcast to is different from the one you listed in the URL above, specify the source port here.' => 
      array (
        0 => '',
      ),
      'Remote Station Source Mountpoint/SID' => 
      array (
        0 => '',
      ),
      'If the mountpoint (i.e. /radio.mp3) or Shoutcast SID (i.e. 2) you broadcast to is different from the one listed above, specify the source mount point here.' => 
      array (
        0 => '',
      ),
      'Remote Station Source Username' => 
      array (
        0 => '',
      ),
      'If you are broadcasting using AutoDJ, enter the source username here. This may be blank.' => 
      array (
        0 => '',
      ),
      'Remote Station Source Password' => 
      array (
        0 => '',
      ),
      'If you are broadcasting using AutoDJ, enter the source password here.' => 
      array (
        0 => '',
      ),
      'Publish to "Yellow Pages" Directories' => 
      array (
        0 => '',
      ),
      'Enable to advertise this relay on "Yellow Pages" public radio directories.' => 
      array (
        0 => '',
      ),
      'Edit Remote Relay' => 
      array (
        0 => '',
      ),
      'Add Remote Relay' => 
      array (
        0 => '',
      ),
      'Playlist' => 
      array (
        0 => 'Spellista',
      ),
      'Scheduling' => 
      array (
        0 => 'Schemaläggning',
      ),
      '# Songs' => 
      array (
        0 => '# Låtar',
      ),
      'All Playlists' => 
      array (
        0 => 'Alla spellistor',
      ),
      'Schedule View' => 
      array (
        0 => 'Schemalägg vy',
      ),
      'More' => 
      array (
        0 => 'Mer',
      ),
      'Reorder' => 
      array (
        0 => 'Omordna',
      ),
      'Reshuffle' => 
      array (
        0 => 'Omfördela',
      ),
      'Duplicate' => 
      array (
        0 => '',
      ),
      'Disable' => 
      array (
        0 => 'Inaktivera',
      ),
      'Enable' => 
      array (
        0 => 'Aktivera',
      ),
      'Disabled' => 
      array (
        0 => 'Inaktiverad',
      ),
      'Weight' => 
      array (
        0 => 'Vikt',
      ),
      'Once per %{songs} Songs' => 
      array (
        0 => 'En gång per %{songs} låtar',
      ),
      'Once per %{minutes} Minutes' => 
      array (
        0 => 'En gång per %{minutes} minuter',
      ),
      'Once per Hour (at %{minute})' => 
      array (
        0 => 'En gång i timmen (på %{minute})',
      ),
      'Custom' => 
      array (
        0 => 'Anpassad',
      ),
      'Delete Playlist?' => 
      array (
        0 => '',
      ),
      'Playlists' => 
      array (
        0 => 'Spellistor',
      ),
      'Edit' => 
      array (
        0 => 'Redigera',
      ),
      'Export %{format}' => 
      array (
        0 => 'Exportera %{format}',
      ),
      'Song-based' => 
      array (
        0 => 'Låt-baserad',
      ),
      'Jingle Mode' => 
      array (
        0 => 'Jingelläge/Jingle Mode',
      ),
      'On-Demand' => 
      array (
        0 => 'On-Demand',
      ),
      'Auto-Assigned' => 
      array (
        0 => 'Auto-tilldelad',
      ),
      'Name' => 
      array (
        0 => 'Namn',
      ),
      'Delete Remote Relay?' => 
      array (
        0 => '',
      ),
      'Remote Relays' => 
      array (
        0 => '',
      ),
      'Remote relays let you work with broadcasting software outside this server. Any relay you include here will be included in your station\'s statistics. You can also broadcast from this server to remote relays.' => 
      array (
        0 => '',
      ),
      'Enabled' => 
      array (
        0 => 'Aktiverad',
      ),
      'Mount Point URL' => 
      array (
        0 => '',
      ),
      'You can set a custom URL for this stream that AzuraCast will use when referring to it. Leave empty to use the default value.' => 
      array (
        0 => '',
      ),
      'Custom Frontend Configuration' => 
      array (
        0 => '',
      ),
      'You can include any special mount point settings here, in either JSON { key: \'value\' } format or XML <key>value</key>' => 
      array (
        0 => '',
      ),
      'This name should always begin with a slash (/), and must be a valid URL, such as /autodj.mp3' => 
      array (
        0 => '',
      ),
      'The display name assigned to this mount point when viewing it on administrative or public pages. Leave blank to automatically generate one.' => 
      array (
        0 => '',
      ),
      'Enable to allow listeners to select this mount point on this station\'s public pages.' => 
      array (
        0 => '',
      ),
      'Set as Default Mount Point' => 
      array (
        0 => '',
      ),
      'If this mount is the default, it will be played on the radio preview and the public radio page in this system.' => 
      array (
        0 => '',
      ),
      'Relay Stream URL' => 
      array (
        0 => '',
      ),
      'Enter the full URL of another stream to relay its broadcast through this mount point.' => 
      array (
        0 => '',
      ),
      'Enable to advertise this mount point on "Yellow Pages" public radio directories.' => 
      array (
        0 => '',
      ),
      'Max Listener Duration' => 
      array (
        0 => '',
      ),
      'Set the length of time (seconds) a listener will stay connected to the stream. If set to 0, listeners can stay connected infinitely.' => 
      array (
        0 => '',
      ),
      'YP Directory Authorization Hash' => 
      array (
        0 => '',
      ),
      'Fallback Mount' => 
      array (
        0 => '',
      ),
      'If this mount point is not playing audio, listeners will automatically be redirected to this mount point. The default is /error.mp3, a repeating error message.' => 
      array (
        0 => '',
      ),
      'Enable AutoDJ' => 
      array (
        0 => '',
      ),
      'If enabled, the AutoDJ will automatically play music to this mount point.' => 
      array (
        0 => '',
      ),
      'Intro' => 
      array (
        0 => '',
      ),
      'Select Intro File' => 
      array (
        0 => '',
      ),
      'This introduction file should exactly match the bitrate and format of the mount point itself.' => 
      array (
        0 => '',
      ),
      'Current Intro File' => 
      array (
        0 => '',
      ),
      'Download' => 
      array (
        0 => 'Hämta',
      ),
      'Clear File' => 
      array (
        0 => '',
      ),
      'There is no existing intro file associated with this mount point.' => 
      array (
        0 => '',
      ),
      'Edit Mount Point' => 
      array (
        0 => '',
      ),
      'Add Mount Point' => 
      array (
        0 => '',
      ),
      'Delete SFTP User?' => 
      array (
        0 => '',
      ),
      'SFTP Users' => 
      array (
        0 => '',
      ),
      'Connection Information' => 
      array (
        0 => '',
      ),
      'Server:' => 
      array (
        0 => '',
      ),
      'You may need to connect directly to your IP address:' => 
      array (
        0 => '',
      ),
      'Port:' => 
      array (
        0 => '',
      ),
      'Web Hook Details' => 
      array (
        0 => '',
      ),
      'Web hooks automatically send a HTTP POST request to the URL you specify to notify it any time one of the triggers you specify occurs on your station.' => 
      array (
        0 => '',
      ),
      'The body of the POST message is the exact same as the NowPlaying API response for your station.' => 
      array (
        0 => '',
      ),
      'NowPlaying API Response' => 
      array (
        0 => '',
      ),
      'In order to process quickly, web hooks have a short timeout, so the responding service should be optimized to handle the request in under 2 seconds.' => 
      array (
        0 => '',
      ),
      'Web Hook URL' => 
      array (
        0 => '',
      ),
      'The URL that will receive the POST messages any time an event is triggered.' => 
      array (
        0 => '',
      ),
      'Optional: HTTP Basic Authentication Username' => 
      array (
        0 => '',
      ),
      'If your web hook requires HTTP basic authentication, provide the username here.' => 
      array (
        0 => '',
      ),
      'Optional: HTTP Basic Authentication Password' => 
      array (
        0 => '',
      ),
      'If your web hook requires HTTP basic authentication, provide the password here.' => 
      array (
        0 => '',
      ),
      'Matomo Installation Base URL' => 
      array (
        0 => '',
      ),
      'The full base URL of your Matomo installation.' => 
      array (
        0 => '',
      ),
      'Matomo Site ID' => 
      array (
        0 => '',
      ),
      'The numeric site ID for this site.' => 
      array (
        0 => '',
      ),
      'Matomo API Token' => 
      array (
        0 => '',
      ),
      'Optionally supply an API token to allow IP address overriding.' => 
      array (
        0 => '',
      ),
      'Discord Web Hook URL' => 
      array (
        0 => '',
      ),
      'This URL is provided within the Discord application.' => 
      array (
        0 => '',
      ),
      'Main Message Content' => 
      array (
        0 => '',
      ),
      'Description' => 
      array (
        0 => 'Beskrivning',
      ),
      'URL' => 
      array (
        0 => 'URL',
      ),
      'Author Name' => 
      array (
        0 => '',
      ),
      'Thumbnail Image URL' => 
      array (
        0 => '',
      ),
      'Footer Text' => 
      array (
        0 => '',
      ),
      'Web Hook Name' => 
      array (
        0 => '',
      ),
      'Choose a name for this webhook that will help you distinguish it from others. This will only be shown on the administration page.' => 
      array (
        0 => '',
      ),
      'Web Hook Triggers' => 
      array (
        0 => '',
      ),
      'This web hook will only run when the selected event(s) occur on this specific station.' => 
      array (
        0 => '',
      ),
      'Message Customization Tips' => 
      array (
        0 => '',
      ),
      'Variables are in the form of:' => 
      array (
        0 => '',
      ),
      'All values in the NowPlaying API response are available for use. Any empty fields are ignored.' => 
      array (
        0 => '',
      ),
      'TuneIn Station ID' => 
      array (
        0 => '',
      ),
      'The station ID will be a numeric string that starts with the letter S.' => 
      array (
        0 => '',
      ),
      'TuneIn Partner ID' => 
      array (
        0 => '',
      ),
      'TuneIn Partner Key' => 
      array (
        0 => '',
      ),
      'Markdown' => 
      array (
        0 => '',
      ),
      'HTML' => 
      array (
        0 => '',
      ),
      'Bot Token' => 
      array (
        0 => '',
      ),
      'See the Telegram Documentation for more details.' => 
      array (
        0 => '',
      ),
      'Chat ID' => 
      array (
        0 => '',
      ),
      'Unique identifier for the target chat or username of the target channel (in the format @channelusername).' => 
      array (
        0 => '',
      ),
      'Custom API Base URL' => 
      array (
        0 => '',
      ),
      'Leave blank to use the default Telegram API URL (recommended).' => 
      array (
        0 => '',
      ),
      'Message parsing mode' => 
      array (
        0 => '',
      ),
      'See the Telegram documentation for more details.' => 
      array (
        0 => '',
      ),
      'GA Property Tracking ID' => 
      array (
        0 => '',
      ),
      'The property ID used to track live listeners.' => 
      array (
        0 => '',
      ),
      'Message Recipient(s)' => 
      array (
        0 => '',
      ),
      'E-mail addresses can be separated by commas.' => 
      array (
        0 => '',
      ),
      'Message Subject' => 
      array (
        0 => '',
      ),
      'Message Body' => 
      array (
        0 => '',
      ),
      'Select Web Hook Type' => 
      array (
        0 => '',
      ),
      '%{ seconds } seconds' => 
      array (
        0 => '',
      ),
      '%{ minutes } minutes' => 
      array (
        0 => '',
      ),
      'No Limit' => 
      array (
        0 => '',
      ),
      'Twitter Account Details' => 
      array (
        0 => '',
      ),
      'Steps for configuring a Twitter application:' => 
      array (
        0 => '',
      ),
      'Create a new app on the Twitter Applications site. Use this installation\'s base URL as the application URL.' => 
      array (
        0 => '',
      ),
      'Twitter Applications' => 
      array (
        0 => '',
      ),
      'In the newly created application, click the "Keys and Access Tokens" tab.' => 
      array (
        0 => '',
      ),
      'At the bottom of the page, click "Create my access token".' => 
      array (
        0 => '',
      ),
      'Once these steps are completed, enter the information from the "Keys and Access Tokens" page into the fields below.' => 
      array (
        0 => '',
      ),
      'Consumer Key (API Key)' => 
      array (
        0 => '',
      ),
      'Consumer Secret (API Secret)' => 
      array (
        0 => '',
      ),
      'Access Token' => 
      array (
        0 => '',
      ),
      'Access Token Secret' => 
      array (
        0 => '',
      ),
      'Only Send One Tweet Every...' => 
      array (
        0 => '',
      ),
      'Edit Web Hook' => 
      array (
        0 => 'Redigera Web Hook',
      ),
      'Add Web Hook' => 
      array (
        0 => 'Lägg till Web Hook',
      ),
      'Powered by AzuraCast' => 
      array (
        0 => '',
      ),
      'Now playing on %{ station }:' => 
      array (
        0 => '',
      ),
      'Now playing on %{ station }: %{ title } by %{ artist }! Tune in now.' => 
      array (
        0 => '',
      ),
      'Now playing on %{ station }: %{ title } by %{ artist }! Tune in now: %{ url }' => 
      array (
        0 => '',
      ),
      'Disable song requests?' => 
      array (
        0 => 'Inaktivera låtönskningar?',
      ),
      'Enable song requests?' => 
      array (
        0 => 'Aktivera låtönskningar?',
      ),
      'Song Requests' => 
      array (
        0 => '',
      ),
      'View' => 
      array (
        0 => 'Visa',
      ),
      'Streams' => 
      array (
        0 => '',
      ),
      'Local Streams' => 
      array (
        0 => '',
      ),
      'Unique' => 
      array (
        0 => 'Unika',
      ),
      'Download PLS' => 
      array (
        0 => 'Hämta PLS',
      ),
      'Download M3U' => 
      array (
        0 => 'Hämta M3U',
      ),
      '%{listeners} Listener' => 
      array (
        0 => '%{listeners} lyssnare',
        1 => '%{listeners} lyssnare',
      ),
      'On the Air' => 
      array (
        0 => 'On Air just nu',
      ),
      'Playing Next' => 
      array (
        0 => 'Nästa låt',
      ),
      'Live' => 
      array (
        0 => 'Live',
      ),
      'Skip Song' => 
      array (
        0 => 'Hoppa över låt',
      ),
      'Disconnect Streamer' => 
      array (
        0 => 'Koppla ifrån Streamer/DJ',
      ),
      'Disable streamers?' => 
      array (
        0 => 'Inaktivera streamers?',
      ),
      'Enable streamers?' => 
      array (
        0 => 'Aktivera streamers?',
      ),
      'Streamers/DJs' => 
      array (
        0 => 'Streamers/DJs',
      ),
      'Edit Profile' => 
      array (
        0 => 'Redigera profil',
      ),
      'Disable public pages?' => 
      array (
        0 => 'Inaktivera publika sidor?',
      ),
      'Enable public pages?' => 
      array (
        0 => 'Aktivera publika sidor?',
      ),
      'Public Pages' => 
      array (
        0 => 'Offentliga sidor',
      ),
      'Web DJ' => 
      array (
        0 => '',
      ),
      'On-Demand Media' => 
      array (
        0 => '',
      ),
      'Podcasts' => 
      array (
        0 => '',
      ),
      'Embed Widgets' => 
      array (
        0 => '',
      ),
      'Broadcasting Service' => 
      array (
        0 => '',
      ),
      'Administration URL' => 
      array (
        0 => 'Administration URL',
      ),
      'Administrator Password' => 
      array (
        0 => 'Administratörens lösenord',
      ),
      'Source Password' => 
      array (
        0 => 'Source lösenord',
      ),
      'Relay Password' => 
      array (
        0 => 'Relay lösenord',
      ),
      'Restart' => 
      array (
        0 => 'Starta om',
      ),
      'Start' => 
      array (
        0 => 'Starta',
      ),
      'Radio Player' => 
      array (
        0 => '',
      ),
      'History' => 
      array (
        0 => '',
      ),
      'Requests' => 
      array (
        0 => '',
      ),
      'Light' => 
      array (
        0 => 'Ljus',
      ),
      'Dark' => 
      array (
        0 => 'Mörk',
      ),
      'Widget Type' => 
      array (
        0 => '',
      ),
      'Theme' => 
      array (
        0 => '',
      ),
      'Customize' => 
      array (
        0 => 'Anpassa',
      ),
      'Embed Code' => 
      array (
        0 => '',
      ),
      'Preview' => 
      array (
        0 => '',
      ),
      'Scheduled' => 
      array (
        0 => 'Planerad',
      ),
      'Streamer/DJ' => 
      array (
        0 => 'Streamer/DJ',
      ),
      'Now' => 
      array (
        0 => 'Nu',
      ),
      'AutoDJ Disabled' => 
      array (
        0 => 'AutoDJ inaktiverad',
      ),
      'AutoDJ has been disabled for this station. No music will automatically be played when a source is not live.' => 
      array (
        0 => 'AutoDJ har inaktiverats för den här stationen. Ingen musik spelas automatiskt när en källa inte är live.',
      ),
      '%{numSongs} uploaded song' => 
      array (
        0 => '',
      ),
      '%{numPlaylists} playlist' => 
      array (
        0 => '',
      ),
      'LiquidSoap is currently shuffling from %{songs} and %{playlists}.' => 
      array (
        0 => '',
      ),
      'AutoDJ Service' => 
      array (
        0 => 'AutoDJ tjänst',
      ),
      'Running' => 
      array (
        0 => 'Körs',
      ),
      'Not Running' => 
      array (
        0 => 'Körs inte',
      ),
      'Delete Mount Point?' => 
      array (
        0 => '',
      ),
      'Mount Points' => 
      array (
        0 => '',
      ),
      'Mount points are how listeners connect and listen to your station. Each mount point can be a different audio format or quality. Using mount points, you can set up a high-quality stream for broadband listeners and a mobile stream for phone users.' => 
      array (
        0 => '',
      ),
      'Default Mount' => 
      array (
        0 => '',
      ),
      'Genre' => 
      array (
        0 => '',
      ),
      'Length' => 
      array (
        0 => 'Längd',
      ),
      'Size' => 
      array (
        0 => 'Storlek',
      ),
      'Modified' => 
      array (
        0 => 'Ändrad',
      ),
      'Album Art' => 
      array (
        0 => 'Skivomslag',
      ),
      'Rename' => 
      array (
        0 => 'Döp om',
      ),
      'View tracks in playlist' => 
      array (
        0 => 'Visa spår i spellistan',
      ),
      '%{spaceUsed} of %{spaceTotal} Used (%{filesCount} Files)' => 
      array (
        0 => '',
      ),
      '%{spaceUsed} Used (%{filesCount} Files)' => 
      array (
        0 => '',
      ),
      'Music Files' => 
      array (
        0 => 'Musikfiler',
      ),
      'You can also upload files in bulk via SFTP.' => 
      array (
        0 => 'Du kan också ladda upp filer i bulk via SFTP.',
      ),
      'Manage SFTP Accounts' => 
      array (
        0 => 'Hantera SFTP-konton',
      ),
      'Directory' => 
      array (
        0 => 'Katalog',
      ),
      'Move %{ num } File(s) to' => 
      array (
        0 => 'Flytta %{ num } fil(er) till',
      ),
      'Files moved:' => 
      array (
        0 => 'Filer flyttade:',
      ),
      'Back' => 
      array (
        0 => 'Tillbaka',
      ),
      'Move to Directory' => 
      array (
        0 => 'Flytta till katalog',
      ),
      'Home' => 
      array (
        0 => 'Hem',
      ),
      'Basic Information' => 
      array (
        0 => 'Grundläggande information',
      ),
      'File Name' => 
      array (
        0 => 'Filnamn',
      ),
      'The relative path of the file in the station\'s media directory.' => 
      array (
        0 => '',
      ),
      'Song Artist' => 
      array (
        0 => 'Låtartist',
      ),
      'Song Genre' => 
      array (
        0 => 'Låten genre',
      ),
      'Song Album' => 
      array (
        0 => 'Låtalbum',
      ),
      'Song Lyrics' => 
      array (
        0 => 'Låttext',
      ),
      'ISRC' => 
      array (
        0 => '',
      ),
      'International Standard Recording Code, used for licensing reports.' => 
      array (
        0 => 'International Standard Recording Code, används för licensrapporter.',
      ),
      'Visual Cue Editor' => 
      array (
        0 => 'Visuell Cue Editor',
      ),
      'Set cue and fade points using the visual editor. The timestamps will be saved to the corresponding fields in the advanced playback settings.' => 
      array (
        0 => '',
      ),
      'Set Cue In' => 
      array (
        0 => '',
      ),
      'Set Cue Out' => 
      array (
        0 => '',
      ),
      'Set Overlap' => 
      array (
        0 => '',
      ),
      'Set Fade In' => 
      array (
        0 => '',
      ),
      'Set Fade Out' => 
      array (
        0 => '',
      ),
      'Custom Fields' => 
      array (
        0 => '',
      ),
      'Delete Album Art' => 
      array (
        0 => 'Ta bort skivomslag',
      ),
      'Replace Album Cover Art' => 
      array (
        0 => 'Ersätt skivomslag',
      ),
      'Song Length' => 
      array (
        0 => 'Låtlängd',
      ),
      'Amplify: Amplification (dB)' => 
      array (
        0 => 'Förstärkning: Förstärkning (dB)',
      ),
      'The volume in decibels to amplify the track with. Leave blank to use the system default.' => 
      array (
        0 => '',
      ),
      'Custom Fading: Overlap Time (seconds)' => 
      array (
        0 => 'Anpassad Fading: Överlappningstid (sekunder)',
      ),
      'The time that this song should overlap its surrounding songs when fading. Leave blank to use the system default.' => 
      array (
        0 => '',
      ),
      'Custom Fading: Fade-In Time (seconds)' => 
      array (
        0 => 'Anpassad Fading: Fade-In Tid (sekunder)',
      ),
      'The time period that the song should fade in. Leave blank to use the system default.' => 
      array (
        0 => '',
      ),
      'Custom Fading: Fade-Out Time (seconds)' => 
      array (
        0 => 'Anpassad Fading: Fade-Out tid (sekunder)',
      ),
      'The time period that the song should fade out. Leave blank to use the system default.' => 
      array (
        0 => '',
      ),
      'Custom Cues: Cue-In Point (seconds)' => 
      array (
        0 => '',
      ),
      'Seconds from the start of the song that the AutoDJ should start playing.' => 
      array (
        0 => 'Sekunder från början av låten som AutoDJ borde börja spela.',
      ),
      'Custom Cues: Cue-Out Point (seconds)' => 
      array (
        0 => '',
      ),
      'Seconds from the start of the song that the AutoDJ should stop playing.' => 
      array (
        0 => 'Sekunder från början av låten som AutoDJ borde sluta spela.',
      ),
      'Rename File/Directory' => 
      array (
        0 => 'Döp om fil/katalog',
      ),
      'New File Name' => 
      array (
        0 => 'Nytt filnamn',
      ),
      'Set or clear playlists from the selected media' => 
      array (
        0 => '',
      ),
      'New Playlist' => 
      array (
        0 => 'Ny spellista',
      ),
      'Queue the selected media to play next' => 
      array (
        0 => 'Lägg det valda mediet i kö',
      ),
      'Analyze and reprocess the selected media' => 
      array (
        0 => '',
      ),
      'The request could not be processed.' => 
      array (
        0 => '',
      ),
      'Files queued for playback:' => 
      array (
        0 => 'Filer köade för uppspelning:',
      ),
      'Files marked for reprocessing:' => 
      array (
        0 => '',
      ),
      'Delete %{ num } media files?' => 
      array (
        0 => '',
      ),
      'Files removed:' => 
      array (
        0 => 'Filer borttagna:',
      ),
      'Playlists updated for selected files:' => 
      array (
        0 => 'Spellistor uppdaterade för valda filer:',
      ),
      'Playlists cleared for selected files:' => 
      array (
        0 => 'Spellistor rensade för valda filer:',
      ),
      'No files selected.' => 
      array (
        0 => 'Inga filer valda.',
      ),
      'Save' => 
      array (
        0 => 'Spara',
      ),
      'Move' => 
      array (
        0 => 'Flytta',
      ),
      'Queue' => 
      array (
        0 => 'Kö',
      ),
      'Reprocess' => 
      array (
        0 => '',
      ),
      'New Folder' => 
      array (
        0 => 'Ny mapp',
      ),
      'Edit Media' => 
      array (
        0 => 'Redigera media',
      ),
      'New Directory' => 
      array (
        0 => 'Ny katalog',
      ),
      'New directory created.' => 
      array (
        0 => 'Ny katalog skapad.',
      ),
      'Directory Name' => 
      array (
        0 => 'Katalogens namn',
      ),
      'Create Directory' => 
      array (
        0 => 'Skapa katalog',
      ),
      'Artwork' => 
      array (
        0 => '',
      ),
      'Select PNG/JPG artwork file' => 
      array (
        0 => '',
      ),
      'Artwork must be a minimum size of 1400 x 1400 pixels and a maximum size of 3000 x 3000 pixels for Apple Podcasts.' => 
      array (
        0 => '',
      ),
      'Clear Artwork' => 
      array (
        0 => '',
      ),
      'Edit Episode' => 
      array (
        0 => '',
      ),
      'Add Episode' => 
      array (
        0 => '',
      ),
      'Edit Podcast' => 
      array (
        0 => '',
      ),
      'Add Podcast' => 
      array (
        0 => '',
      ),
      'Podcast Title' => 
      array (
        0 => '',
      ),
      'Website' => 
      array (
        0 => '',
      ),
      'Typically the home page of a podcast.' => 
      array (
        0 => '',
      ),
      'The description of your podcast. The typical maximum amount of text allowed for this is 4000 characters.' => 
      array (
        0 => '',
      ),
      'Language' => 
      array (
        0 => 'Språk',
      ),
      'The language spoken on the podcast.' => 
      array (
        0 => '',
      ),
      'Author' => 
      array (
        0 => '',
      ),
      'The contact person of the podcast. May be required in order to list the podcast on services like Apple Podcasts, Spotify, Google Podcasts, etc.' => 
      array (
        0 => '',
      ),
      'E-Mail' => 
      array (
        0 => '',
      ),
      'The email of the podcast contact. May be required in order to list the podcast on services like Apple Podcasts, Spotify, Google Podcasts, etc.' => 
      array (
        0 => '',
      ),
      'Categories' => 
      array (
        0 => '',
      ),
      'Select the category/categories that best reflects the content of your podcast.' => 
      array (
        0 => '',
      ),
      'Art' => 
      array (
        0 => '',
      ),
      'Podcast' => 
      array (
        0 => '',
      ),
      '# Episodes' => 
      array (
        0 => '',
      ),
      'All Podcasts' => 
      array (
        0 => '',
      ),
      'Delete Podcast?' => 
      array (
        0 => '',
      ),
      'RSS Feed' => 
      array (
        0 => '',
      ),
      'Episodes' => 
      array (
        0 => '',
      ),
      'Episode' => 
      array (
        0 => '',
      ),
      'File' => 
      array (
        0 => '',
      ),
      'Explicit' => 
      array (
        0 => '',
      ),
      'Delete Episode?' => 
      array (
        0 => '',
      ),
      'Typically a website with content about the episode.' => 
      array (
        0 => '',
      ),
      'The description of the episode. The typical maximum amount of text allowed for this is 4000 characters.' => 
      array (
        0 => '',
      ),
      'Publish Date' => 
      array (
        0 => '',
      ),
      'The date when the episode should be published.' => 
      array (
        0 => '',
      ),
      'Publish Time' => 
      array (
        0 => '',
      ),
      'The time when the episode should be published (according to the stations timezone).' => 
      array (
        0 => '',
      ),
      'Contains explicit content' => 
      array (
        0 => '',
      ),
      'Indicates the presence of explicit content (explicit language or adult content). Apple Podcasts displays an Explicit parental advisory graphic for your episode if turned on. Episodes containing explicit material aren’t available in some Apple Podcasts territories.' => 
      array (
        0 => '',
      ),
      'Media' => 
      array (
        0 => '',
      ),
      'Select Media File' => 
      array (
        0 => '',
      ),
      'Podcast media should be in the MP3 or M4A (AAC) format for the greatest compatibility.' => 
      array (
        0 => '',
      ),
      'Current Podcast Media' => 
      array (
        0 => '',
      ),
      'Clear Media' => 
      array (
        0 => '',
      ),
      'There is no existing media associated with this episode.' => 
      array (
        0 => '',
      ),
      'Notes' => 
      array (
        0 => 'Anteckningar',
      ),
      'Account List' => 
      array (
        0 => 'Kontolista',
      ),
      'Delete Streamer?' => 
      array (
        0 => '',
      ),
      'Streamer/DJ Accounts' => 
      array (
        0 => 'DJ konton',
      ),
      'Add Streamer' => 
      array (
        0 => 'Lägg till Streamer',
      ),
      'Broadcasts' => 
      array (
        0 => 'Sändningar',
      ),
      'Icecast Clients' => 
      array (
        0 => '',
      ),
      'You may need to connect directly via your IP address:' => 
      array (
        0 => '',
      ),
      'Mount Name:' => 
      array (
        0 => '',
      ),
      'SHOUTcast Clients' => 
      array (
        0 => '',
      ),
      'For some clients, use port:' => 
      array (
        0 => '',
      ),
      'Password:' => 
      array (
        0 => '',
      ),
      'or' => 
      array (
        0 => '',
      ),
      'Setup instructions for broadcasting software are available on the AzuraCast wiki.' => 
      array (
        0 => '',
      ),
      'AzuraCast Wiki' => 
      array (
        0 => '',
      ),
      'Streamer Username' => 
      array (
        0 => '',
      ),
      'The streamer will use this username to connect to the radio server.' => 
      array (
        0 => '',
      ),
      'Streamer password' => 
      array (
        0 => '',
      ),
      'The streamer will use this password to connect to the radio server.' => 
      array (
        0 => '',
      ),
      'Streamer Display Name' => 
      array (
        0 => '',
      ),
      'This is the informal display name that will be shown in API responses if the streamer/DJ is live.' => 
      array (
        0 => '',
      ),
      'Comments' => 
      array (
        0 => '',
      ),
      'Internal notes or comments about the user, visible only on this control panel.' => 
      array (
        0 => 'Interna anteckningar eller kommentarer om användaren, synliga endast på den här kontrollpanelen.',
      ),
      'Account is Active' => 
      array (
        0 => 'Kontot är aktiverat',
      ),
      'Enable to allow this account to log in and stream.' => 
      array (
        0 => 'Aktivera för att tillåta detta konto att logga in och strömma.',
      ),
      'Enforce Schedule Times' => 
      array (
        0 => 'Tvinga schemalagda tidee',
      ),
      'If enabled, this streamer will only be able to connect during their scheduled broadcast times.' => 
      array (
        0 => 'Om aktiverad, kommer denna streamer/DJ bara att kunna ansluta under sina schemalagda sändningstider.',
      ),
      'This streamer is not scheduled to play at any times.' => 
      array (
        0 => '',
      ),
      'If the end time is before the start time, the schedule entry will continue overnight.' => 
      array (
        0 => 'Om sluttiden är före starttiden kommer schemat att fortsätta över natten.',
      ),
      'Streamer Broadcasts' => 
      array (
        0 => 'DJ Sändningar',
      ),
      'Play/Pause' => 
      array (
        0 => 'Spela/Pausa',
      ),
      'Delete Broadcast?' => 
      array (
        0 => '',
      ),
      'Edit Streamer' => 
      array (
        0 => 'Redigera streamer',
      ),
      'Hour' => 
      array (
        0 => 'Timme',
      ),
      'IP' => 
      array (
        0 => 'IP',
      ),
      'Time' => 
      array (
        0 => 'Tid',
      ),
      'Time (sec)' => 
      array (
        0 => 'Tid (sek)',
      ),
      'User Agent' => 
      array (
        0 => '',
      ),
      'Stream' => 
      array (
        0 => '',
      ),
      'Location' => 
      array (
        0 => 'Plats',
      ),
      'Live Listeners' => 
      array (
        0 => 'Live lyssnare',
      ),
      'Download CSV' => 
      array (
        0 => 'Ladda ner CSV',
      ),
      'for selected period' => 
      array (
        0 => 'för vald period',
      ),
      'Total Listener Hours' => 
      array (
        0 => 'Totalt antal lyssnartimmar',
      ),
      'Mobile Device' => 
      array (
        0 => 'Mobil enhet',
      ),
      'Desktop Device' => 
      array (
        0 => 'Skrivbordsenhet',
      ),
      'Unknown' => 
      array (
        0 => 'Okänd',
      ),
      'Local' => 
      array (
        0 => '',
      ),
      'Remote' => 
      array (
        0 => '',
      ),
      'Filename' => 
      array (
        0 => 'Filnamn',
      ),
      'Length Text' => 
      array (
        0 => '',
      ),
      'Playlist(s)' => 
      array (
        0 => 'Spellistor',
      ),
      'Joins' => 
      array (
        0 => 'Anslutningar',
      ),
      'Losses' => 
      array (
        0 => 'Förluster',
      ),
      'Total' => 
      array (
        0 => 'Totalt',
      ),
      'Num Plays' => 
      array (
        0 => '',
      ),
      'Play %' => 
      array (
        0 => 'Spela %',
      ),
      'Ratio' => 
      array (
        0 => '',
      ),
      'Song Listener Impact' => 
      array (
        0 => '',
      ),
      'Date Requested' => 
      array (
        0 => 'Önskad',
      ),
      'Date Played' => 
      array (
        0 => '',
      ),
      'Requester IP' => 
      array (
        0 => 'Önskarens IP',
      ),
      'Delete Request?' => 
      array (
        0 => '',
      ),
      'Clear All Pending Requests?' => 
      array (
        0 => '',
      ),
      'Clear Pending Requests' => 
      array (
        0 => 'Rensa väntande önskningar',
      ),
      'Not Played' => 
      array (
        0 => 'Inte spelad',
      ),
      'Listeners by Day' => 
      array (
        0 => 'Lyssnare per dag',
      ),
      'Listeners by Day of Week' => 
      array (
        0 => 'Lyssnare per veckodag',
      ),
      'Listeners by Hour' => 
      array (
        0 => 'Lyssnare per timme',
      ),
      'Best Performing Songs' => 
      array (
        0 => 'Låtar med bäst utförande',
      ),
      'in the last 48 hours' => 
      array (
        0 => 'under de senaste 48 timmarna',
      ),
      'Change' => 
      array (
        0 => 'Ändra',
      ),
      'Song' => 
      array (
        0 => 'Låt',
      ),
      'Worst Performing Songs' => 
      array (
        0 => 'Låtar med sämst utförande',
      ),
      'Most Played Songs' => 
      array (
        0 => 'Mest spelade låtar',
      ),
      'in the last month' => 
      array (
        0 => 'under den senaste månaden',
      ),
      'Plays' => 
      array (
        0 => 'Spelningar',
      ),
      'Date/Time' => 
      array (
        0 => '',
      ),
      'Song Playback Timeline' => 
      array (
        0 => '',
      ),
      'Live Streamer:' => 
      array (
        0 => '',
      ),
      'Name/Type' => 
      array (
        0 => '',
      ),
      'Triggers' => 
      array (
        0 => '',
      ),
      'Delete Web Hook?' => 
      array (
        0 => '',
      ),
      'Web Hooks' => 
      array (
        0 => 'Web Hookar',
      ),
      'Web hooks let you connect to external web services and broadcast changes to your station to them.' => 
      array (
        0 => '',
      ),
      'Test' => 
      array (
        0 => 'Testa',
      ),
      'Song History' => 
      array (
        0 => 'Låtlista',
      ),
      'Request Song' => 
      array (
        0 => '',
      ),
      'Request a Song' => 
      array (
        0 => '',
      ),
      'Microphone' => 
      array (
        0 => 'Mikrofon',
      ),
      'Cue' => 
      array (
        0 => 'Kö',
      ),
      'Microphone Source' => 
      array (
        0 => 'Mikrofon källa',
      ),
      'Stop Streaming' => 
      array (
        0 => '',
      ),
      'Start Streaming' => 
      array (
        0 => '',
      ),
      'Metadata updated!' => 
      array (
        0 => '',
      ),
      'Settings' => 
      array (
        0 => '',
      ),
      'Metadata' => 
      array (
        0 => '',
      ),
      'Encoder' => 
      array (
        0 => 'Encoder',
      ),
      'MP3' => 
      array (
        0 => 'MP3',
      ),
      'Raw' => 
      array (
        0 => '',
      ),
      'Sample Rate' => 
      array (
        0 => '',
      ),
      'Bit Rate' => 
      array (
        0 => 'Bit hastighet',
      ),
      'DJ Credentials' => 
      array (
        0 => 'DJ-uppgifter',
      ),
      'Use Asynchronous Worker' => 
      array (
        0 => '',
      ),
      'Update Metadata' => 
      array (
        0 => 'Uppdatera metadata',
      ),
      'Mixer' => 
      array (
        0 => 'Mixer',
      ),
      'Playlist 1' => 
      array (
        0 => 'Spellista 1',
      ),
      'Playlist 2' => 
      array (
        0 => 'Spellista 2',
      ),
      'Unknown Title' => 
      array (
        0 => 'Okänd titel',
      ),
      'Unknown Artist' => 
      array (
        0 => 'Okänd artist',
      ),
      'Add Files to Playlist' => 
      array (
        0 => 'Lägg till filer i spellistan',
      ),
      'Continuous Play' => 
      array (
        0 => 'Kontinuerlig uppspelning',
      ),
      'Repeat Playlist' => 
      array (
        0 => 'Upprepa spellista',
      ),
      'Request' => 
      array (
        0 => 'Önska',
      ),
      'This field is required.' => 
      array (
        0 => '',
      ),
      'This field must have at least %{ min } letters.' => 
      array (
        0 => '',
      ),
      'This field must have at most %{ max } letters.' => 
      array (
        0 => '',
      ),
      'This field must be between %{ min } and %{ max }.' => 
      array (
        0 => '',
      ),
      'This field must only contain alphabetic characters.' => 
      array (
        0 => '',
      ),
      'This field must only contain alphanumeric characters.' => 
      array (
        0 => '',
      ),
      'This field must only contain numeric characters.' => 
      array (
        0 => '',
      ),
      'This field must be a valid integer.' => 
      array (
        0 => '',
      ),
      'This field must be a valid decimal number.' => 
      array (
        0 => '',
      ),
      'This field must be a valid e-mail address.' => 
      array (
        0 => '',
      ),
      'This field must be a valid IP address.' => 
      array (
        0 => '',
      ),
      'This field must be a valid URL.' => 
      array (
        0 => '',
      ),
      'This password is too common or insecure.' => 
      array (
        0 => '',
      ),
      'Global Permissions' => 
      array (
        0 => '',
      ),
      'Role Name' => 
      array (
        0 => 'Rollens namn',
      ),
      'Users with this role will have these permissions across the entire installation.' => 
      array (
        0 => '',
      ),
      'Station Permissions' => 
      array (
        0 => '',
      ),
      'Users with this role will have these permissions for this single station.' => 
      array (
        0 => '',
      ),
      'Add Station' => 
      array (
        0 => 'Lägg till station',
      ),
      'Edit Role' => 
      array (
        0 => '',
      ),
      'Add Role' => 
      array (
        0 => '',
      ),
      'User' => 
      array (
        0 => '',
      ),
      'Operation' => 
      array (
        0 => '',
      ),
      'Identifier' => 
      array (
        0 => '',
      ),
      'Target' => 
      array (
        0 => '',
      ),
      'Insert' => 
      array (
        0 => '',
      ),
      'Update' => 
      array (
        0 => '',
      ),
      'Audit Log' => 
      array (
        0 => '',
      ),
      'N/A' => 
      array (
        0 => '',
      ),
      'Changes' => 
      array (
        0 => '',
      ),
      'Field' => 
      array (
        0 => '',
      ),
      'Previous' => 
      array (
        0 => '',
      ),
      'Updated' => 
      array (
        0 => '',
      ),
      'Broadcasting' => 
      array (
        0 => 'Sändning',
      ),
      'Only connect to a remote server.' => 
      array (
        0 => '',
      ),
      'Use Icecast 2.4 on this server.' => 
      array (
        0 => '',
      ),
      'Use SHOUTcast DNAS 2 on this server.' => 
      array (
        0 => '',
      ),
      'This software delivers your broadcast to the listening audience.' => 
      array (
        0 => '',
      ),
      'SHOUTcast License ID' => 
      array (
        0 => '',
      ),
      'SHOUTcast User ID' => 
      array (
        0 => '',
      ),
      'Customize Source Password' => 
      array (
        0 => '',
      ),
      'Leave blank to automatically generate a new password.' => 
      array (
        0 => '',
      ),
      'Customize Administrator Password' => 
      array (
        0 => '',
      ),
      'Customize Broadcasting Port' => 
      array (
        0 => '',
      ),
      'No other program can be using this port. Leave blank to automatically assign a port.' => 
      array (
        0 => '',
      ),
      'Maximum Listeners' => 
      array (
        0 => '',
      ),
      'Maximum number of total listeners across all streams. Leave blank to use the default.' => 
      array (
        0 => '',
      ),
      'Banned IP Addresses' => 
      array (
        0 => 'Förbjudna IP-adresser',
      ),
      'List one IP address or group (in CIDR format) per line.' => 
      array (
        0 => '',
      ),
      'Allowed IP Addresses' => 
      array (
        0 => '',
      ),
      'Banned Countries' => 
      array (
        0 => '',
      ),
      'Select the countries that are not allowed to connect to the streams.' => 
      array (
        0 => '',
      ),
      'Clear List' => 
      array (
        0 => '',
      ),
      'Custom Configuration' => 
      array (
        0 => '',
      ),
      'This code will be included in the frontend configuration. Allowed formats are:' => 
      array (
        0 => '',
      ),
      'Station Profile' => 
      array (
        0 => 'Station Profil',
      ),
      'Web Site URL' => 
      array (
        0 => '',
      ),
      'Note: This should be the public-facing homepage of the radio station, not the AzuraCast URL. It will be included in broadcast details.' => 
      array (
        0 => '',
      ),
      'Time Zone' => 
      array (
        0 => 'Tidszon',
      ),
      'Scheduled playlists and other timed items will be controlled by this time zone.' => 
      array (
        0 => '',
      ),
      'Default Album Art URL' => 
      array (
        0 => 'Standard-skivomslag URL',
      ),
      'If a song has no album art, this URL will be listed instead. Leave blank to use the standard placeholder art.' => 
      array (
        0 => 'Om en låt inte har något skivomslag, kommer denna URL att listas istället. Lämna tomt för att använda det förvalda skivomslaget.',
      ),
      'URL Stub' => 
      array (
        0 => '',
      ),
      'Optionally specify a short URL-friendly name, such as "my_station_name", that will be used in this station\'s URLs. Leave this field blank to automatically create one based on the station name.' => 
      array (
        0 => '',
      ),
      'Number of Visible Recent Songs' => 
      array (
        0 => '',
      ),
      'Customize the number of songs that will appear in the "Song History" section for this station and in all public APIs.' => 
      array (
        0 => '',
      ),
      'Enable Public Pages' => 
      array (
        0 => '',
      ),
      'Show the station in public pages and general API results.' => 
      array (
        0 => '',
      ),
      'On-Demand Streaming' => 
      array (
        0 => '',
      ),
      'Enable On-Demand Streaming' => 
      array (
        0 => '',
      ),
      'If enabled, music from playlists with on-demand streaming enabled will be available to stream via a specialized public page.' => 
      array (
        0 => '',
      ),
      'Enable Downloads on On-Demand Page' => 
      array (
        0 => '',
      ),
      'If enabled, a download button will also be present on the public "On-Demand" page.' => 
      array (
        0 => '',
      ),
      'Use Liquidsoap on this server.' => 
      array (
        0 => '',
      ),
      'Do not use an AutoDJ service.' => 
      array (
        0 => '',
      ),
      'Smart Mode' => 
      array (
        0 => 'Smart läge',
      ),
      'Normal Mode' => 
      array (
        0 => 'Normalt läge',
      ),
      'Disable Crossfading' => 
      array (
        0 => 'Inaktivera övertoning',
      ),
      'This software shuffles from playlists of music constantly and plays when no other radio source is available.' => 
      array (
        0 => '',
      ),
      'Crossfade Method' => 
      array (
        0 => 'Övertoningsmetod',
      ),
      'Choose a method to use when transitioning from one song to another. Smart Mode considers the volume of the two tracks when fading for a smoother effect, but requires more CPU resources.' => 
      array (
        0 => 'Välj en metod att använda vid övergången från en låt till en annan. Smart läge överväger volymen av de två spåren när övergången sker för en jämnare effekt, men kräver mer CPU-resurser.',
      ),
      'Crossfade Duration (Seconds)' => 
      array (
        0 => 'Övertoning varaktighet (sekunder)',
      ),
      'Number of seconds to overlap songs.' => 
      array (
        0 => 'Antal sekunder att överlappa låtar.',
      ),
      'Apply Compression and Normalization' => 
      array (
        0 => 'Tillämpa komprimering och normalisering',
      ),
      'Compress and normalize your station\'s audio, producing a more uniform and "full" sound.' => 
      array (
        0 => 'Komprimera och normalisera din stations ljud, vilket ger ett mer enhetligt och "fullt" ljud.',
      ),
      'Some stream licensing providers may have specific rules regarding song requests. Check your local regulations for more information.' => 
      array (
        0 => '',
      ),
      'Allow Song Requests' => 
      array (
        0 => 'Tillåt låtönksningar',
      ),
      'Enable listeners to request a song for play on your station. Only songs that are already in your playlists are requestable.' => 
      array (
        0 => 'Tillåt lyssnare önska låtar på din station. Endast låtar som redan finns i dina spellistor är begärbara.',
      ),
      'Request Minimum Delay (Minutes)' => 
      array (
        0 => '',
      ),
      'If requests are enabled, this specifies the minimum delay (in minutes) between a request being submitted and being played. If set to zero, a minor delay of 15 seconds is applied to prevent request floods.' => 
      array (
        0 => '',
      ),
      'Request Last Played Threshold (Minutes)' => 
      array (
        0 => '',
      ),
      'This specifies the minimum time (in minutes) between a song playing on the radio and being available to request again. Set to 0 for no threshold.' => 
      array (
        0 => '',
      ),
      'Streamers / DJs' => 
      array (
        0 => '',
      ),
      'Allow Streamers / DJs' => 
      array (
        0 => '',
      ),
      'If enabled, streamers (or DJs) will be able to connect directly to your stream and broadcast live music that interrupts the AutoDJ stream.' => 
      array (
        0 => '',
      ),
      'Record Live Broadcasts' => 
      array (
        0 => 'Spela in direktsändningar',
      ),
      'If enabled, AzuraCast will automatically record any live broadcasts made to this station to per-broadcast recordings.' => 
      array (
        0 => 'Om aktiverad, kommer AzuraCast automatiskt spela in alla livesändningar som görs till denna station till inspelningar per sändning.',
      ),
      'Live Broadcast Recording Format' => 
      array (
        0 => '',
      ),
      'Live Broadcast Recording Bitrate (kbps)' => 
      array (
        0 => '',
      ),
      'Deactivate Streamer on Disconnect (Seconds)' => 
      array (
        0 => '',
      ),
      'This is the number of seconds until a streamer who has been manually disconnected can reconnect to the stream. Set to 0 to allow the streamer to immediately reconnect.' => 
      array (
        0 => '',
      ),
      'Customize DJ/Streamer Port' => 
      array (
        0 => '',
      ),
      'Note: the port after this one will automatically be used for legacy connections.' => 
      array (
        0 => '',
      ),
      'DJ/Streamer Buffer Time (Seconds)' => 
      array (
        0 => '',
      ),
      'The number of seconds of signal to store in case of interruption. Set to the lowest value that your DJs can use without stream interruptions.' => 
      array (
        0 => '',
      ),
      'Customize DJ/Streamer Mount Point' => 
      array (
        0 => '',
      ),
      'If your streaming software requires a specific mount point path, specify it here. Otherwise, use the default.' => 
      array (
        0 => '',
      ),
      'Advanced Configuration' => 
      array (
        0 => '',
      ),
      'Customize Internal Request Processing Port' => 
      array (
        0 => '',
      ),
      'This port is not used by any external process. Only modify this port if the assigned port is in use. Leave blank to automatically assign a port.' => 
      array (
        0 => '',
      ),
      'Use Replaygain Metadata' => 
      array (
        0 => '',
      ),
      'Instruct Liquidsoap to use any replaygain metadata associated with a song to control its volume level.' => 
      array (
        0 => '',
      ),
      'AutoDJ Queue Length' => 
      array (
        0 => '',
      ),
      'This determines how many songs in advance the AutoDJ will automatically fill the queue.' => 
      array (
        0 => '',
      ),
      'Manual AutoDJ Mode' => 
      array (
        0 => '',
      ),
      'This mode disables AzuraCast\'s AutoDJ management, using Liquidsoap itself to manage song playback. "Next Song" and some other features will not be available.' => 
      array (
        0 => '',
      ),
      'Character Set Encoding' => 
      array (
        0 => '',
      ),
      'For most cases, use the default UTF-8 encoding. The older ISO-8859-1 encoding can be used if accepting connections from SHOUTcast 1 DJs or using other legacy software.' => 
      array (
        0 => '',
      ),
      'Duplicate Prevention Time Range (Minutes)' => 
      array (
        0 => '',
      ),
      'This specifies the time range (in minutes) of the song history that the duplicate song prevention algorithm should take into account.' => 
      array (
        0 => '',
      ),
      'Enable Broadcasting' => 
      array (
        0 => '',
      ),
      'If disabled, the station will not broadcast or shuffle its AutoDJ.' => 
      array (
        0 => '',
      ),
      'Base Station Directory' => 
      array (
        0 => '',
      ),
      'The parent directory where station playlist and configuration files are stored. Leave blank to use default directory.' => 
      array (
        0 => '',
      ),
      'Media Storage Location' => 
      array (
        0 => '',
      ),
      'Live Recordings Storage Location' => 
      array (
        0 => '',
      ),
      'Podcasts Storage Location' => 
      array (
        0 => '',
      ),
      'Clone Station' => 
      array (
        0 => '',
      ),
      '%{station} - Copy' => 
      array (
        0 => '',
      ),
      'Edit Station' => 
      array (
        0 => 'Redigera station',
      ),
      'Share Media Storage Location' => 
      array (
        0 => '',
      ),
      'Share Recordings Storage Location' => 
      array (
        0 => '',
      ),
      'Share Podcasts Storage Location' => 
      array (
        0 => '',
      ),
      'User Permissions' => 
      array (
        0 => '',
      ),
      'New Station Name' => 
      array (
        0 => 'Nytt Stationsnamn',
      ),
      'New Station Description' => 
      array (
        0 => 'Ny Stationsbeskrivning',
      ),
      'Copy to New Station' => 
      array (
        0 => '',
      ),
      'Permissions' => 
      array (
        0 => '',
      ),
      'Delete Role?' => 
      array (
        0 => '',
      ),
      'Roles & Permissions' => 
      array (
        0 => '',
      ),
      'AzuraCast uses a role-based access control system. Roles are given permissions to certain sections of the site, then users are assigned into those roles.' => 
      array (
        0 => '',
      ),
      'Global' => 
      array (
        0 => '',
      ),
      'Storage Adapter' => 
      array (
        0 => '',
      ),
      'Local Filesystem' => 
      array (
        0 => '',
      ),
      'Remote: S3 Compatible' => 
      array (
        0 => '',
      ),
      'Remote: Dropbox' => 
      array (
        0 => '',
      ),
      'Path/Suffix' => 
      array (
        0 => '',
      ),
      'For local filesystems, this is the base path of the directory. For remote filesystems, this is the folder prefix.' => 
      array (
        0 => '',
      ),
      'Storage Quota' => 
      array (
        0 => '',
      ),
      'Set a maximum disk space that this storage location can use. Specify the size with unit, i.e. "8 GB". Units are measured in 1024 bytes. Leave blank to default to the available space on the disk.' => 
      array (
        0 => '',
      ),
      'Access Key ID' => 
      array (
        0 => '',
      ),
      'Secret Key' => 
      array (
        0 => '',
      ),
      'Endpoint' => 
      array (
        0 => '',
      ),
      'Bucket Name' => 
      array (
        0 => '',
      ),
      'Region' => 
      array (
        0 => '',
      ),
      'API Version' => 
      array (
        0 => '',
      ),
      'Dropbox Generated Access Token' => 
      array (
        0 => '',
      ),
      'Learn More about Dropbox Auth Tokens' => 
      array (
        0 => '',
      ),
      'Edit Storage Location' => 
      array (
        0 => '',
      ),
      'Add Storage Location' => 
      array (
        0 => '',
      ),
      'GeoLite version "%{ version }" is currently installed.' => 
      array (
        0 => '',
      ),
      'Install GeoLite IP Database' => 
      array (
        0 => 'Installera GeoLite IP-databas',
      ),
      'IP Geolocation is used to guess the approximate location of your listeners based on the IP address they connect with. Use the free built-in IP Geolocation library or enter a license key on this page to use MaxMind GeoLite.' => 
      array (
        0 => '',
      ),
      'Instructions' => 
      array (
        0 => 'Instruktioner',
      ),
      'AzuraCast ships with a built-in free IP geolocation database. You may prefer to use the MaxMind GeoLite service instead to achieve more accurate results. Using MaxMind GeoLite requires a license key, but once the key is provided, we will automatically keep the database updated.' => 
      array (
        0 => '',
      ),
      'To download the GeoLite database:' => 
      array (
        0 => '',
      ),
      'Create an account on the MaxMind developer site.' => 
      array (
        0 => '',
      ),
      'MaxMind Developer Site' => 
      array (
        0 => '',
      ),
      'Visit the "My License Key" page under the "Services" section.' => 
      array (
        0 => '',
      ),
      'Click "Generate new license key".' => 
      array (
        0 => '',
      ),
      'Paste the generated license key into the field on this page.' => 
      array (
        0 => '',
      ),
      'Current Installed Version' => 
      array (
        0 => 'Nuvarande installerad version',
      ),
      'GeoLite is not currently installed on this installation.' => 
      array (
        0 => '',
      ),
      'MaxMind License Key' => 
      array (
        0 => '',
      ),
      'Remove Key' => 
      array (
        0 => '',
      ),
      'Delete Station?' => 
      array (
        0 => '',
      ),
      'Stations' => 
      array (
        0 => '',
      ),
      'Clone' => 
      array (
        0 => '',
      ),
      'Field Name' => 
      array (
        0 => '',
      ),
      'This will be used as the label when editing individual songs, and will show in API results.' => 
      array (
        0 => 'Detta kommer att användas som etikett när du redigerar enskilda låtar, och kommer att visa i API-resultat.',
      ),
      'Programmatic Name' => 
      array (
        0 => '',
      ),
      'Optionally specify an API-friendly name, such as "field_name". Leave this field blank to automatically create one based on the name.' => 
      array (
        0 => '',
      ),
      'Automatically Set from ID3v2 Value' => 
      array (
        0 => '',
      ),
      'Optionally select an ID3v2 metadata field that, if present, will be used to set this field\'s value.' => 
      array (
        0 => '',
      ),
      'Edit Custom Field' => 
      array (
        0 => 'Redigera anpassat fält',
      ),
      'Add Custom Field' => 
      array (
        0 => 'Lägg till anpassat fält',
      ),
      'Adapter' => 
      array (
        0 => '',
      ),
      'Station(s)' => 
      array (
        0 => '',
      ),
      'Station Media' => 
      array (
        0 => '',
      ),
      'Station Recordings' => 
      array (
        0 => '',
      ),
      'Station Podcasts' => 
      array (
        0 => '',
      ),
      'Backups' => 
      array (
        0 => '',
      ),
      'Applying changes...' => 
      array (
        0 => 'Tillämpar ändringar...',
      ),
      'Delete Storage Location?' => 
      array (
        0 => '',
      ),
      'Storage Locations' => 
      array (
        0 => '',
      ),
      'SHOUTcast version "%{ version }" is currently installed.' => 
      array (
        0 => '',
      ),
      'Install SHOUTcast 2 DNAS' => 
      array (
        0 => '',
      ),
      'SHOUTcast 2 DNAS is not free software, and its restrictive license does not allow AzuraCast to distribute the SHOUTcast binary.' => 
      array (
        0 => '',
      ),
      'In order to install SHOUTcast:' => 
      array (
        0 => '',
      ),
      'Download the Linux x64 binary from the SHOUTcast Radio Manager:' => 
      array (
        0 => '',
      ),
      'SHOUTcast Radio Manager' => 
      array (
        0 => '',
      ),
      'The file name should look like:' => 
      array (
        0 => '',
      ),
      'Upload the file on this page to automatically extract it into the proper directory.' => 
      array (
        0 => '',
      ),
      'SHOUTcast 2 DNAS is not currently installed on this installation.' => 
      array (
        0 => '',
      ),
      'Services' => 
      array (
        0 => '',
      ),
      'Stable' => 
      array (
        0 => '',
      ),
      'Rolling Release' => 
      array (
        0 => '',
      ),
      'AzuraCast Update Checks' => 
      array (
        0 => '',
      ),
      'Current Release Channel' => 
      array (
        0 => '',
      ),
      'Learn more about release channels in the AzuraCast docs.' => 
      array (
        0 => '',
      ),
      'Show Update Announcements' => 
      array (
        0 => '',
      ),
      'Show new releases within your update channel on the AzuraCast homepage.' => 
      array (
        0 => '',
      ),
      'E-mail Delivery Service' => 
      array (
        0 => '',
      ),
      'Used for "Forgot Password" functionality, web hooks and other functions.' => 
      array (
        0 => '',
      ),
      'Enable Mail Delivery' => 
      array (
        0 => '',
      ),
      'Sender Name' => 
      array (
        0 => '',
      ),
      'Sender E-mail Address' => 
      array (
        0 => '',
      ),
      'SMTP Host' => 
      array (
        0 => '',
      ),
      'SMTP Port' => 
      array (
        0 => '',
      ),
      'Use Secure (TLS) SMTP Connection' => 
      array (
        0 => '',
      ),
      'Usually enabled for port 465, disabled for ports 587 or 25.' => 
      array (
        0 => '',
      ),
      'SMTP Username' => 
      array (
        0 => '',
      ),
      'SMTP Password' => 
      array (
        0 => '',
      ),
      'Avatar Services' => 
      array (
        0 => '',
      ),
      'Avatar Service' => 
      array (
        0 => '',
      ),
      'Default Avatar URL' => 
      array (
        0 => '',
      ),
      'Album Art Services' => 
      array (
        0 => '',
      ),
      'Check Web Services for Album Art for "Now Playing" Tracks' => 
      array (
        0 => '',
      ),
      'Check Web Services for Album Art When Uploading Media' => 
      array (
        0 => '',
      ),
      'Last.fm API Key' => 
      array (
        0 => '',
      ),
      'This service can provide album art for tracks where none is available locally.' => 
      array (
        0 => '',
      ),
      'Apply for an API key at Last.fm' => 
      array (
        0 => '',
      ),
      'Last 60 Days' => 
      array (
        0 => 'Senaste 60 dagarna',
      ),
      'Last Year' => 
      array (
        0 => 'Senaste året',
      ),
      'Last 2 Years' => 
      array (
        0 => 'Senaste 2 åren',
      ),
      'Indefinitely' => 
      array (
        0 => 'Obegränsat',
      ),
      'Site Base URL' => 
      array (
        0 => '',
      ),
      'The base URL where this service is located. Use either the external IP address or fully-qualified domain name (if one exists) pointing to this server.' => 
      array (
        0 => '',
      ),
      'AzuraCast Instance Name' => 
      array (
        0 => '',
      ),
      'This name will appear as a sub-header next to the AzuraCast logo, to help identify this server.' => 
      array (
        0 => '',
      ),
      'Prefer Browser URL (If Available)' => 
      array (
        0 => '',
      ),
      'If this setting is set to "Yes", the browser URL will be used instead of the base URL when it\'s available. Set to "No" to always use the base URL.' => 
      array (
        0 => 'Om denna inställning är inställd på "Ja", kommer webbläsarens URL att användas istället för bas-URL när den är tillgänglig. Sätt till "Nej" för att alltid använda bas-URL.',
      ),
      'Use Web Proxy for Radio' => 
      array (
        0 => 'Använd Web Proxy för Radio',
      ),
      'By default, radio stations broadcast on their own ports (i.e. 8000). If you\'re using a service like CloudFlare or accessing your radio station by SSL, you should enable this feature, which routes all radio through the web ports (80 and 443).' => 
      array (
        0 => 'Som standard sänds radiostationer på sina egna portar (dvs. 8000). Om du använder en tjänst som CloudFlare eller använder din radiostation via SSL, bör du aktivera denna funktion, som leder all radio genom webbportarna (80 och 443).',
      ),
      'Days of Playback History to Keep' => 
      array (
        0 => 'Dagar av uppspelningshistorik att behålla',
      ),
      'Set longer to preserve more playback history and listener metadata for stations. Set shorter to save disk space.' => 
      array (
        0 => '',
      ),
      'Use WebSockets for Now Playing Updates' => 
      array (
        0 => '',
      ),
      'Enables or disables the use of the newer and faster WebSocket-based system for receiving live updates on public players. You may need to disable this if you encounter problems with it.' => 
      array (
        0 => '',
      ),
      'Enable Advanced Features' => 
      array (
        0 => '',
      ),
      'Enable certain advanced features in the web interface, including advanced playlist configuration, station port assignment, changing base media directories and other functionality that should only be used by users who are comfortable with advanced functionality.' => 
      array (
        0 => '',
      ),
      'Security & Privacy' => 
      array (
        0 => '',
      ),
      'Privacy' => 
      array (
        0 => '',
      ),
      'Listener Analytics Collection' => 
      array (
        0 => '',
      ),
      'Aggregate listener statistics are used to show station reports across the system. IP-based listener statistics are used to view live listener tracking and may be required for royalty reports.' => 
      array (
        0 => '',
      ),
      'Full:' => 
      array (
        0 => '',
      ),
      'Collect aggregate listener statistics and IP-based listener statistics' => 
      array (
        0 => '',
      ),
      'Limited:' => 
      array (
        0 => '',
      ),
      'Only collect aggregate listener statistics' => 
      array (
        0 => '',
      ),
      'None:' => 
      array (
        0 => '',
      ),
      'Do not collect any listener analytics' => 
      array (
        0 => '',
      ),
      'Security' => 
      array (
        0 => '',
      ),
      'Always Use HTTPS' => 
      array (
        0 => 'Använd alltid HTTPS',
      ),
      'Set to "Yes" to always use "https://" secure URLs, and to automatically redirect to the secure URL when an insecure URL is visited.' => 
      array (
        0 => 'Sätt till "Ja" för att alltid använda "https://" säkra webbadresser, och att automatiskt omdirigera till den säkra webbadressen när en osäker webbadress besöks.',
      ),
      'API "Access-Control-Allow-Origin" Header' => 
      array (
        0 => '',
      ),
      'Set to * to allow all sources, or specify a list of origins separated by a comma (,).' => 
      array (
        0 => '',
      ),
      'Learn more about this header.' => 
      array (
        0 => '',
      ),
      'Auto-Assign Value' => 
      array (
        0 => '',
      ),
      'None' => 
      array (
        0 => '',
      ),
      'Delete Custom Field?' => 
      array (
        0 => '',
      ),
      'Create custom fields to store extra metadata about each media file uploaded to your station libraries.' => 
      array (
        0 => '',
      ),
      'Changes saved.' => 
      array (
        0 => 'Ändringar sparade.',
      ),
      'System Settings' => 
      array (
        0 => 'Systeminställningar',
      ),
      'Browser Icon' => 
      array (
        0 => '',
      ),
      'Public Page Background' => 
      array (
        0 => '',
      ),
      'Default Album Art' => 
      array (
        0 => '',
      ),
      'Custom Branding' => 
      array (
        0 => '',
      ),
      'Upload Custom Assets' => 
      array (
        0 => '',
      ),
      'Clear Image' => 
      array (
        0 => '',
      ),
      'Prefer System Default' => 
      array (
        0 => '',
      ),
      'Branding Settings' => 
      array (
        0 => '',
      ),
      'Base Theme for Public Pages' => 
      array (
        0 => 'Bastema för offentliga sidor',
      ),
      'Select a theme to use as a base for station public pages and the login page.' => 
      array (
        0 => 'Välj ett tema att använda som bas för offentliga sidor och inloggningssidan.',
      ),
      'Hide Album Art on Public Pages' => 
      array (
        0 => 'Dölj skivomslag på offentliga sidor',
      ),
      'If selected, album art will not display on public-facing radio pages.' => 
      array (
        0 => 'Om vald, kommer skivomslag inte visas på offentliga radio sidor.',
      ),
      'Hide AzuraCast Branding on Public Pages' => 
      array (
        0 => 'Dölj AzuraCast Branding på offentliga sidor',
      ),
      'If selected, this will remove the AzuraCast branding from public-facing pages.' => 
      array (
        0 => 'Om vald, kommer detta att ta bort AzuraCast branding från offentliga sidor.',
      ),
      'Homepage Redirect URL' => 
      array (
        0 => 'URL för omdirigering',
      ),
      'If a visitor is not signed in and visits the AzuraCast homepage, you can automatically redirect them to the URL specified here. Leave blank to redirect them to the login screen by default.' => 
      array (
        0 => 'Om en besökare inte är inloggad och besöker AzuraCasts hemsida, kan du automatiskt omdirigera dem till den URL som anges här. Lämna tomt för att omdirigera dem till inloggningsskärmen som standard.',
      ),
      'Custom CSS for Public Pages' => 
      array (
        0 => '',
      ),
      'This CSS will be applied to the station public pages and login page.' => 
      array (
        0 => '',
      ),
      'Custom JS for Public Pages' => 
      array (
        0 => '',
      ),
      'This javascript code will be applied to the station public pages and login page.' => 
      array (
        0 => '',
      ),
      'Custom CSS for Internal Pages' => 
      array (
        0 => '',
      ),
      'This CSS will be applied to the main management pages, like this one.' => 
      array (
        0 => '',
      ),
      'Seek' => 
      array (
        0 => 'Sök',
      ),
      'Create Account' => 
      array (
        0 => 'Skapa konto',
      ),
      'Create Station' => 
      array (
        0 => '',
      ),
      'AzuraCast First-Time Setup' => 
      array (
        0 => '',
      ),
      'Welcome to AzuraCast!' => 
      array (
        0 => 'Välkommen till AzuraCast!',
      ),
      'Let\'s get started by creating your Super Administrator account.' => 
      array (
        0 => '',
      ),
      'This account will have full access to the system, and you\'ll automatically be logged in to it for the rest of setup.' => 
      array (
        0 => '',
      ),
      'E-mail Address' => 
      array (
        0 => 'E-postadress',
      ),
      'Create a New Radio Station' => 
      array (
        0 => '',
      ),
      'Continue the setup process by creating your first radio station below. You can edit any of these details later.' => 
      array (
        0 => 'Fortsätt installationsprocessen genom att skapa din första radiostation nedan. Du kan redigera någon av dessa uppgifter senare.',
      ),
      'Create and Continue' => 
      array (
        0 => '',
      ),
      'Customize AzuraCast Settings' => 
      array (
        0 => '',
      ),
      'Complete the setup process by providing some information about your broadcast environment. These settings can be changed later from the administration panel.' => 
      array (
        0 => '',
      ),
      'Save and Continue' => 
      array (
        0 => '',
      ),
      'An error occurred and your request could not be completed.' => 
      array (
        0 => 'Ett fel uppstod och din begäran kunde inte slutföras.',
      ),
      'Error' => 
      array (
        0 => '',
      ),
      'Success' => 
      array (
        0 => '',
      ),
      'Please wait...' => 
      array (
        0 => 'Vänligen vänta...',
      ),
      'Delete Record?' => 
      array (
        0 => '',
      ),
      'The locale to use for CLI commands.' => 
      array (
        0 => '',
      ),
      'The application environment.' => 
      array (
        0 => '',
      ),
      'Manually modify the logging level.' => 
      array (
        0 => '',
      ),
      'This allows you to log debug-level errors temporarily (for problem-solving) or reduce the volume of logs that are produced by your installation, without needing to modify whether your installation is a production or development instance.' => 
      array (
        0 => '',
      ),
      'Composer Plugin Mode' => 
      array (
        0 => '',
      ),
      'Enable the composer "merge" functionality to combine the main application\'s composer.json file with any plugin composer files. This can have performance implications, so you should only use it if you use one or more plugins with their own Composer dependencies.' => 
      array (
        0 => '',
      ),
      'Minimum Port for Station Port Assignment' => 
      array (
        0 => '',
      ),
      'Modify this if your stations are listening on nonstandard ports.' => 
      array (
        0 => '',
      ),
      'Maximum Port for Station Port Assignment' => 
      array (
        0 => '',
      ),
      'MariaDB Host' => 
      array (
        0 => '',
      ),
      'Do not modify this after installation.' => 
      array (
        0 => '',
      ),
      'MariaDB Port' => 
      array (
        0 => '',
      ),
      'MariaDB Username' => 
      array (
        0 => '',
      ),
      'MariaDB Password' => 
      array (
        0 => '',
      ),
      'MariaDB Database Name' => 
      array (
        0 => '',
      ),
      'Auto-generate Random MariaDB Root Password' => 
      array (
        0 => '',
      ),
      'MariaDB Root Password' => 
      array (
        0 => '',
      ),
      'Enable MariaDB Slow Query Log' => 
      array (
        0 => '',
      ),
      'Log slower queries to diagnose possible database issues. Only turn this on if needed.' => 
      array (
        0 => '',
      ),
      'MariaDB Maximum Connections' => 
      array (
        0 => '',
      ),
      'Set the amount of allowed connections to the database. This value should be increased if you are seeing the "Too many connections" error in the logs.' => 
      array (
        0 => '',
      ),
      'Enable Redis' => 
      array (
        0 => '',
      ),
      'Disable to use a flatfile cache instead of Redis.' => 
      array (
        0 => '',
      ),
      'Redis Host' => 
      array (
        0 => '',
      ),
      'Redis Port' => 
      array (
        0 => '',
      ),
      'Redis Database Index' => 
      array (
        0 => '',
      ),
      'PHP Maximum POST File Size' => 
      array (
        0 => '',
      ),
      'PHP Memory Limit' => 
      array (
        0 => '',
      ),
      'PHP Script Maximum Execution Time' => 
      array (
        0 => '',
      ),
      '(in seconds)' => 
      array (
        0 => '',
      ),
      'Short Sync Task Execution Time' => 
      array (
        0 => '',
      ),
      'The maximum execution time (and lock timeout) for the 15-second, 1-minute and 5-minute synchronization tasks.' => 
      array (
        0 => '',
      ),
      'Long Sync Task Execution Time' => 
      array (
        0 => '',
      ),
      'The maximum execution time (and lock timeout) for the 1-hour synchronization task.' => 
      array (
        0 => '',
      ),
      'Maximum PHP-FPM Worker Processes' => 
      array (
        0 => '',
      ),
      'Enable Performance Profiling Extension' => 
      array (
        0 => '',
      ),
      'Profiling data can be viewed by visiting %s.' => 
      array (
        0 => '',
      ),
      'Profile Performance on All Requests' => 
      array (
        0 => '',
      ),
      'This will have a significant performance impact on your installation.' => 
      array (
        0 => '',
      ),
      'Profiling Extension HTTP Key' => 
      array (
        0 => '',
      ),
      'The value for the "SPX_KEY" parameter for viewing profiling pages.' => 
      array (
        0 => '',
      ),
      'Profiling Extension IP Allow List' => 
      array (
        0 => '',
      ),
      '(Docker Compose) All Docker containers are prefixed by this name. Do not change this after installation.' => 
      array (
        0 => '',
      ),
      '(Docker Compose) The amount of time to wait before a Docker Compose operation fails. Increase this on lower performance computers.' => 
      array (
        0 => '',
      ),
      'AzuraCast Release Channel' => 
      array (
        0 => '',
      ),
      'HTTP Port' => 
      array (
        0 => '',
      ),
      'The main port AzuraCast listens to for insecure HTTP connections.' => 
      array (
        0 => '',
      ),
      'HTTPS Port' => 
      array (
        0 => '',
      ),
      'The main port AzuraCast listens to for secure HTTPS connections.' => 
      array (
        0 => '',
      ),
      'SFTP Port' => 
      array (
        0 => '',
      ),
      'The port AzuraCast listens to for SFTP file management connections.' => 
      array (
        0 => '',
      ),
      'Station Ports' => 
      array (
        0 => '',
      ),
      'The ports AzuraCast should listen to for station broadcasts and incoming DJ connections.' => 
      array (
        0 => '',
      ),
      'Docker User UID' => 
      array (
        0 => '',
      ),
      'Set the UID of the user running inside the Docker containers. Matching this with your host UID can fix permission issues.' => 
      array (
        0 => '',
      ),
      'Docker User GID' => 
      array (
        0 => '',
      ),
      'Set the GID of the user running inside the Docker containers. Matching this with your host GID can fix permission issues.' => 
      array (
        0 => '',
      ),
      'Advanced: Use Privileged Docker Settings' => 
      array (
        0 => '',
      ),
      'LetsEncrypt Domain Name(s)' => 
      array (
        0 => '',
      ),
      'Domain name (example.com) or names (example.com,foo.bar) to use with LetsEncrypt.' => 
      array (
        0 => '',
      ),
      'LetsEncrypt E-mail Address' => 
      array (
        0 => '',
      ),
      'Optionally provide an e-mail address for updates from LetsEncrypt.' => 
      array (
        0 => '',
      ),
      'This file was automatically generated by AzuraCast.' => 
      array (
        0 => '',
      ),
      'You can modify it as necessary. To apply changes, restart the Docker containers.' => 
      array (
        0 => '',
      ),
      'Remove the leading "#" symbol from lines to uncomment them.' => 
      array (
        0 => '',
      ),
      'Valid options: %s' => 
      array (
        0 => '',
      ),
      'Default: %s' => 
      array (
        0 => '',
      ),
      'Additional Environment Variables' => 
      array (
        0 => '',
      ),
      'AzuraCast Installer' => 
      array (
        0 => '',
      ),
      'Welcome to AzuraCast! Complete the initial server setup by answering a few questions.' => 
      array (
        0 => '',
      ),
      'AzuraCast Updater' => 
      array (
        0 => '',
      ),
      'Change installation settings?' => 
      array (
        0 => '',
      ),
      'AzuraCast is currently configured to listen on the following ports:' => 
      array (
        0 => '',
      ),
      'HTTP Port: %d' => 
      array (
        0 => '',
      ),
      'HTTPS Port: %d' => 
      array (
        0 => '',
      ),
      'SFTP Port: %d' => 
      array (
        0 => '',
      ),
      'Radio Ports: %s' => 
      array (
        0 => '',
      ),
      'Customize ports used for AzuraCast?' => 
      array (
        0 => '',
      ),
      'Set up LetsEncrypt?' => 
      array (
        0 => '',
      ),
      'Writing configuration files...' => 
      array (
        0 => '',
      ),
      'Server configuration complete!' => 
      array (
        0 => '',
      ),
      'This product includes GeoLite2 data created by MaxMind, available from %s.' => 
      array (
        0 => '',
      ),
      'IP Geolocation by DB-IP' => 
      array (
        0 => '',
      ),
      'GeoLite database not configured for this installation. See System Administration for instructions.' => 
      array (
        0 => '',
      ),
      'Welcome to the AzuraCast Liquidsoap configuration editor.' => 
      array (
        0 => 'Välkommen till konfigurationsredigeraren AzuraCast Liquidsoap.',
      ),
      'Using this page, you can customize several sections of the Liquidsoap configuration.' => 
      array (
        0 => '',
      ),
      'The non-editable sections are automatically generated by AzuraCast.' => 
      array (
        0 => 'De icke-redigerbara sektionerna genereras automatiskt av AzuraCast.',
      ),
      '%s is not recognized as a service.' => 
      array (
        0 => '%s känns inte igen som en tjänst.',
      ),
      'It may not be registered with Supervisor yet. Restarting broadcasting may help.' => 
      array (
        0 => '',
      ),
      '%s cannot start' => 
      array (
        0 => '%s kan inte starta',
      ),
      'It is already running.' => 
      array (
        0 => 'Den är redan igång.',
      ),
      '%s cannot stop' => 
      array (
        0 => '%s kan inte stoppas',
      ),
      'It is not running.' => 
      array (
        0 => 'Den körs inte.',
      ),
      '%s encountered an error' => 
      array (
        0 => '%s stötte på ett fel',
      ),
      'Check the log for details.' => 
      array (
        0 => '',
      ),
      'Select...' => 
      array (
        0 => '',
      ),
      'This feature is not currently supported on this station.' => 
      array (
        0 => 'Denna funktion stöds för närvarande inte på den här stationen.',
      ),
      'Now Playing Data' => 
      array (
        0 => 'Nu spelas Data',
      ),
      '1-Minute Sync' => 
      array (
        0 => '1-minuts synkronisering',
      ),
      'Song Requests Queue' => 
      array (
        0 => 'Kö för låtönskningar',
      ),
      '5-Minute Sync' => 
      array (
        0 => '5-minuters synkronisering',
      ),
      'Check Media Folders' => 
      array (
        0 => 'Kontrollera mediamappar',
      ),
      '1-Hour Sync' => 
      array (
        0 => '1-Timmes synkronisering',
      ),
      'Analytics/Statistics' => 
      array (
        0 => 'Analytiker/Statistik',
      ),
      'Cleanup' => 
      array (
        0 => 'Rensa',
      ),
      'Installation Not Recently Backed Up' => 
      array (
        0 => 'Installationen är inte nyligen säkerhetskopierad',
      ),
      'This installation has not been backed up in the last two weeks.' => 
      array (
        0 => '',
      ),
      'Update Instructions' => 
      array (
        0 => '',
      ),
      'AzuraCast <a href="%s" target="_blank">version %s</a> is now available.' => 
      array (
        0 => 'Azuracast <a href="%s" target="_blank">version%s</a> är nu tillgänglig.',
      ),
      'You are currently running version %s. Updating is highly recommended.' => 
      array (
        0 => 'Du kör för närvarande version %s. Vi rekommenderar starkt att du uppdaterar.',
      ),
      'New AzuraCast Release Version Available' => 
      array (
        0 => 'Ny AzuraCast version tillgänglig',
      ),
      'Your installation is currently %d update(s) behind the latest version.' => 
      array (
        0 => 'Du ligger för närvarande %d uppdatering(är) bakom den senaste versionen.',
      ),
      'View the changelog for full details.' => 
      array (
        0 => '',
      ),
      'You should update to take advantage of bug and security fixes.' => 
      array (
        0 => 'Du bör uppdatera för att dra nytta av fel- och säkerhetsrättelser.',
      ),
      'New AzuraCast Updates Available' => 
      array (
        0 => 'Nya AzuraCast-uppdateringar tillgängliga',
      ),
      'Synchronized Task Not Recently Run' => 
      array (
        0 => '',
      ),
      'The "%s" synchronization task has not run recently. This may indicate an error with your installation.' => 
      array (
        0 => '',
      ),
      'Manually Run Task' => 
      array (
        0 => '',
      ),
      'The performance profiling extension is currently enabled on this installation.' => 
      array (
        0 => '',
      ),
      'You can track the execution time and memory usage of any AzuraCast page or application from the profiler page.' => 
      array (
        0 => '',
      ),
      'Profiler Control Panel' => 
      array (
        0 => '',
      ),
      'Performance profiling is currently enabled for all requests.' => 
      array (
        0 => '',
      ),
      'This can have an adverse impact on system performance. You should disable this when possible.' => 
      array (
        0 => '',
      ),
      'You should update your <code>docker-compose.yml</code> file to reflect the newest changes.' => 
      array (
        0 => '',
      ),
      'If you manually maintain this file, review the <a href="%s" target="_blank">latest version of the file</a> and make any changes needed.' => 
      array (
        0 => '',
      ),
      'Otherwise, update your installation and answer "Y" when prompted to update the file.' => 
      array (
        0 => '',
      ),
      'Your <code>docker-compose.yml</code> file is out of date!' => 
      array (
        0 => 'Din <code>docker-compose.yml</code> fil är föråldrad!',
      ),
      'You must be logged in to access this page.' => 
      array (
        0 => '',
      ),
      'You do not have permission to access this portion of the site.' => 
      array (
        0 => '',
      ),
      'All Permissions' => 
      array (
        0 => 'Alla behörigheter',
      ),
      'View Administration Page' => 
      array (
        0 => 'Visa administrationssida',
      ),
      'View System Logs' => 
      array (
        0 => 'Visa systemloggar',
      ),
      'Administer Settings' => 
      array (
        0 => 'Inställningar för administratör',
      ),
      'Administer API Keys' => 
      array (
        0 => 'Administrera API-Nycklar',
      ),
      'Administer Stations' => 
      array (
        0 => 'Administrera stationer',
      ),
      'Administer Custom Fields' => 
      array (
        0 => 'Administrera anpassade fält',
      ),
      'Administer Backups' => 
      array (
        0 => 'Administrera säkerhetskopior',
      ),
      'Administer Storage Locations' => 
      array (
        0 => '',
      ),
      'View Station Page' => 
      array (
        0 => 'Visa Stationssida',
      ),
      'View Station Reports' => 
      array (
        0 => 'Visa Station Rapporter',
      ),
      'View Station Logs' => 
      array (
        0 => 'Visa stationsloggar',
      ),
      'Manage Station Profile' => 
      array (
        0 => 'Hantera Station Profil',
      ),
      'Manage Station Broadcasting' => 
      array (
        0 => 'Hantera Stationssändning',
      ),
      'Manage Station Streamers' => 
      array (
        0 => 'Hantera Station Streamers',
      ),
      'Manage Station Mount Points' => 
      array (
        0 => '',
      ),
      'Manage Station Remote Relays' => 
      array (
        0 => '',
      ),
      'Manage Station Media' => 
      array (
        0 => '',
      ),
      'Manage Station Automation' => 
      array (
        0 => '',
      ),
      'Manage Station Web Hooks' => 
      array (
        0 => '',
      ),
      'Manage Station Podcasts' => 
      array (
        0 => '',
      ),
      'Imported locale: %s' => 
      array (
        0 => '',
      ),
      'The account associated with e-mail address "%s" has been set as an administrator' => 
      array (
        0 => '',
      ),
      'Account not found.' => 
      array (
        0 => '',
      ),
      'Fixtures loaded.' => 
      array (
        0 => '',
      ),
      'Configuration successfully written.' => 
      array (
        0 => '',
      ),
      'AzuraCast Backup' => 
      array (
        0 => '',
      ),
      'Please wait while a backup is generated...' => 
      array (
        0 => '',
      ),
      'Creating temporary directories...' => 
      array (
        0 => '',
      ),
      'Directory "%s" was not created' => 
      array (
        0 => 'Katalog "%s" skapades inte',
      ),
      'Backing up MariaDB...' => 
      array (
        0 => '',
      ),
      'Creating backup archive...' => 
      array (
        0 => '',
      ),
      'Cleaning up temporary files...' => 
      array (
        0 => '',
      ),
      'Backup complete in %.2f seconds.' => 
      array (
        0 => '',
      ),
      'Backup path %s not found!' => 
      array (
        0 => '',
      ),
      'AzuraCast Setup' => 
      array (
        0 => '',
      ),
      'Welcome to AzuraCast. Please wait while some key dependencies of AzuraCast are set up...' => 
      array (
        0 => 'Välkommen till AzuraCast. Vänta medan några nyckelberoenden för AzuraCast är inställda...',
      ),
      'Installing Data Fixtures' => 
      array (
        0 => '',
      ),
      'Refreshing All Stations' => 
      array (
        0 => '',
      ),
      'AzuraCast is now updated to the latest version!' => 
      array (
        0 => '',
      ),
      'AzuraCast installation complete!' => 
      array (
        0 => '',
      ),
      'Visit %s to complete setup.' => 
      array (
        0 => '',
      ),
      'Initialize AzuraCast' => 
      array (
        0 => '',
      ),
      'Initializing essential settings...' => 
      array (
        0 => '',
      ),
      'Environment: %s' => 
      array (
        0 => '',
      ),
      'Installation Method: %s' => 
      array (
        0 => '',
      ),
      'Running Database Migrations' => 
      array (
        0 => '',
      ),
      'Generating Database Proxy Classes' => 
      array (
        0 => '',
      ),
      'Reload System Data' => 
      array (
        0 => '',
      ),
      'AzuraCast is now initialized.' => 
      array (
        0 => '',
      ),
      'AzuraCast Settings' => 
      array (
        0 => '',
      ),
      'Setting Key' => 
      array (
        0 => '',
      ),
      'Setting Value' => 
      array (
        0 => '',
      ),
      'The port %s is in use by another station.' => 
      array (
        0 => 'Porten %s används av en annan station.',
      ),
      'This value is already used.' => 
      array (
        0 => '',
      ),
      'Storage location %s could not be validated: %s' => 
      array (
        0 => '',
      ),
      'Storage location %s already exists.' => 
      array (
        0 => '',
      ),
      'Search engine crawlers are not permitted to use this feature.' => 
      array (
        0 => '',
      ),
      'This station does not accept requests currently.' => 
      array (
        0 => 'Denna station accepterar inte önskningar för närvarande.',
      ),
      'The song ID you specified could not be found in the station.' => 
      array (
        0 => '',
      ),
      'The song ID you specified cannot be requested for this station.' => 
      array (
        0 => '',
      ),
      'You have submitted a request too recently! Please wait before submitting another one.' => 
      array (
        0 => '',
      ),
      'Duplicate request: this song was already requested and will play soon.' => 
      array (
        0 => '',
      ),
      'This song or artist has been played too recently. Wait a while before requesting it again.' => 
      array (
        0 => '',
      ),
      'Changes saved successfully.' => 
      array (
        0 => 'Ändringar har sparats.',
      ),
      'Record created successfully.' => 
      array (
        0 => '',
      ),
      'Record updated successfully.' => 
      array (
        0 => '',
      ),
      'Record deleted successfully.' => 
      array (
        0 => 'Posten har tagits bort.',
      ),
      'Record not found' => 
      array (
        0 => '',
      ),
      'The uploaded file exceeds the upload_max_filesize directive in php.ini.' => 
      array (
        0 => '',
      ),
      'The uploaded file exceeds the MAX_FILE_SIZE directive from the HTML form.' => 
      array (
        0 => '',
      ),
      'The uploaded file was only partially uploaded.' => 
      array (
        0 => '',
      ),
      'No file was uploaded.' => 
      array (
        0 => '',
      ),
      'No temporary directory is available.' => 
      array (
        0 => '',
      ),
      'Could not write to filesystem.' => 
      array (
        0 => '',
      ),
      'Upload halted by a PHP extension.' => 
      array (
        0 => '',
      ),
      'Unspecified error.' => 
      array (
        0 => '',
      ),
      'Playlist: %s' => 
      array (
        0 => '',
      ),
      'Streamer: %s' => 
      array (
        0 => '',
      ),
      'Edit Liquidsoap Configuration' => 
      array (
        0 => 'Redigera Liquidsoap konfiguration',
      ),
      'Streamers enabled!' => 
      array (
        0 => 'Streamare aktiverade!',
      ),
      'You can now set up streamer (DJ) accounts.' => 
      array (
        0 => 'Du kan nu ställa in streamer(DJ)-konton.',
      ),
      'Record not found.' => 
      array (
        0 => 'Posten hittades inte.',
      ),
      'Profile' => 
      array (
        0 => 'Profil',
      ),
      'Automated assignment complete!' => 
      array (
        0 => '',
      ),
      'Automated assignment error' => 
      array (
        0 => '',
      ),
      'Statistics Overview' => 
      array (
        0 => 'Statistisk översikt',
      ),
      'SoundExchange Report' => 
      array (
        0 => 'SoundExchange rapport',
      ),
      'No episodes found.' => 
      array (
        0 => '',
      ),
      'Episode not found.' => 
      array (
        0 => '',
      ),
      'Logged in successfully.' => 
      array (
        0 => 'Inloggad framgångsrikt.',
      ),
      'Login unsuccessful' => 
      array (
        0 => 'Inloggningen misslyckades',
      ),
      'Your credentials could not be verified.' => 
      array (
        0 => 'Dina uppgifter kunde inte verifieras.',
      ),
      'Too many forgot password attempts' => 
      array (
        0 => '',
      ),
      'You have attempted to reset your password too many times. Please wait 30 seconds and try again.' => 
      array (
        0 => '',
      ),
      'Account Recovery Link' => 
      array (
        0 => '',
      ),
      'Account recovery e-mail sent.' => 
      array (
        0 => '',
      ),
      'If the e-mail address you provided is in the system, check your inbox for a password reset message.' => 
      array (
        0 => '',
      ),
      'Invalid token specified.' => 
      array (
        0 => '',
      ),
      'Logged in using account recovery token' => 
      array (
        0 => '',
      ),
      'Your password has been updated.' => 
      array (
        0 => '',
      ),
      'Too many login attempts' => 
      array (
        0 => 'För många inloggningsförsök',
      ),
      'You have attempted to log in too many times. Please wait 30 seconds and try again.' => 
      array (
        0 => 'Du har försökt att logga in för många gånger. Vänligen vänta 30 sekunder och försök igen.',
      ),
      'Complete the setup process to get started.' => 
      array (
        0 => 'Slutför installationsprocessen för att komma igång.',
      ),
      'API Key not found.' => 
      array (
        0 => 'API-nyckel hittades inte.',
      ),
      'API Key updated.' => 
      array (
        0 => 'API-nyckel uppdaterad.',
      ),
      'Edit API Key' => 
      array (
        0 => 'Redigera API-nyckel',
      ),
      'Add API Key' => 
      array (
        0 => 'Lägg till API-nyckel',
      ),
      'API Key deleted.' => 
      array (
        0 => 'API-nyckel borttagen.',
      ),
      'Profile saved!' => 
      array (
        0 => 'Profil sparad!',
      ),
      'The token you supplied is invalid. Please try again.' => 
      array (
        0 => 'Den token du angav är ogiltig. Försök igen.',
      ),
      'Two-factor authentication enabled.' => 
      array (
        0 => 'Tvåfaktorsautentisering aktiverad.',
      ),
      'Two-factor authentication disabled.' => 
      array (
        0 => 'Tvåfaktorsautentisering inaktiverad.',
      ),
      'Set Up AzuraCast' => 
      array (
        0 => '',
      ),
      'Setup has already been completed!' => 
      array (
        0 => 'Installationen har redan slutförts!',
      ),
      'Dashboard' => 
      array (
        0 => '',
      ),
      'AzuraCast User' => 
      array (
        0 => '',
      ),
      'This station does not support on-demand streaming.' => 
      array (
        0 => 'Denna station stöder inte on-demand streaming.',
      ),
      'Playlist successfully imported; %d of %d files were successfully matched.' => 
      array (
        0 => 'Spellistan importerades; %d av %d filer matchades framgångsrikt.',
      ),
      'This playlist is not a sequential playlist.' => 
      array (
        0 => 'Denna spellista är inte en sekventiell spellista.',
      ),
      'Playlist reshuffled.' => 
      array (
        0 => 'Spellista omfördelad.',
      ),
      'Playlist not found.' => 
      array (
        0 => 'Spellistan hittades inte.',
      ),
      'Playlist enabled.' => 
      array (
        0 => 'Spellista aktiverad.',
      ),
      'Playlist disabled.' => 
      array (
        0 => 'Spellista inaktiverad.',
      ),
      'This station is out of available storage space.' => 
      array (
        0 => 'Denna station har slut på tillgängligt lagringsutrymme.',
      ),
      'No directory specified' => 
      array (
        0 => '',
      ),
      'File not specified.' => 
      array (
        0 => 'Fil ej angiven.',
      ),
      'New path not specified.' => 
      array (
        0 => 'Ingen ny sökväg angiven.',
      ),
      'File Not Processed: %s' => 
      array (
        0 => '',
      ),
      'File Processing' => 
      array (
        0 => '',
      ),
      'Station restarted.' => 
      array (
        0 => 'Stationen startades om.',
      ),
      'Frontend stopped.' => 
      array (
        0 => 'Frontend stoppad.',
      ),
      'Frontend started.' => 
      array (
        0 => 'Frontend startad.',
      ),
      'Frontend restarted.' => 
      array (
        0 => 'Frontend startades om.',
      ),
      'Song skipped.' => 
      array (
        0 => 'Låten hoppades över.',
      ),
      'Streamer disconnected.' => 
      array (
        0 => 'Streamer/DJ frånkopplad.',
      ),
      'Backend stopped.' => 
      array (
        0 => 'Backend stoppad.',
      ),
      'Backend started.' => 
      array (
        0 => 'Backend startad.',
      ),
      'Backend restarted.' => 
      array (
        0 => 'Backend startades om.',
      ),
      'Web hook not found.' => 
      array (
        0 => '',
      ),
      'Web hook enabled.' => 
      array (
        0 => 'Web Hook aktiverad.',
      ),
      'Web hook disabled.' => 
      array (
        0 => '',
      ),
      'Podcast not found!' => 
      array (
        0 => '',
      ),
      'No recording available.' => 
      array (
        0 => 'Ingen inspelning tillgänglig.',
      ),
      'All Stations' => 
      array (
        0 => 'Alla stationer',
      ),
      'You cannot remove yourself.' => 
      array (
        0 => 'Du kan inte ta bort dig själv.',
      ),
      'Create a new storage location based on the base directory.' => 
      array (
        0 => '',
      ),
      'Liquidsoap Log' => 
      array (
        0 => 'Liquidsoap Logg',
      ),
      'Liquidsoap Configuration' => 
      array (
        0 => 'Liquidsoap konfiguration',
      ),
      'Icecast Access Log' => 
      array (
        0 => 'Icecast Access Logg',
      ),
      'Icecast Error Log' => 
      array (
        0 => 'Icecast fellogg',
      ),
      'Icecast Configuration' => 
      array (
        0 => 'Icecast konfiguration',
      ),
      'SHOUTcast Log' => 
      array (
        0 => 'Logg för SHOUTcast',
      ),
      'SHOUTcast Configuration' => 
      array (
        0 => 'Konfiguration för SHOUTcast',
      ),
      'User updated.' => 
      array (
        0 => 'Användare uppdaterad.',
      ),
      'User added.' => 
      array (
        0 => 'Användare tillagd.',
      ),
      'Another user already exists with this e-mail address. Please update the e-mail address.' => 
      array (
        0 => 'En annan användare finns redan med denna e-postadress. Vänligen uppdatera e-postadressen.',
      ),
      'Edit User' => 
      array (
        0 => 'Redigera användare',
      ),
      'Add User' => 
      array (
        0 => 'Lägg till användare',
      ),
      'You cannot delete your own account.' => 
      array (
        0 => 'Du kan inte ta bort ditt eget konto.',
      ),
      'User deleted.' => 
      array (
        0 => 'Användare borttagen.',
      ),
      'User not found.' => 
      array (
        0 => 'Användaren hittades inte.',
      ),
      'AzuraCast Application Log' => 
      array (
        0 => 'AzuraCast-applikationslogg',
      ),
      'Nginx Access Log' => 
      array (
        0 => 'Nginx åtkomstlogg',
      ),
      'Nginx Error Log' => 
      array (
        0 => 'Nginx fellogg',
      ),
      'PHP Application Log' => 
      array (
        0 => 'PHP-applikationslogg',
      ),
      'Supervisord Log' => 
      array (
        0 => 'Handledningslogg',
      ),
      'Album Artist Sort Order' => 
      array (
        0 => '',
      ),
      'Album Sort Order' => 
      array (
        0 => '',
      ),
      'Band' => 
      array (
        0 => 'Band',
      ),
      'Bpm' => 
      array (
        0 => 'Bpm',
      ),
      'Comment' => 
      array (
        0 => 'Kommentar',
      ),
      'Commercial Information' => 
      array (
        0 => 'Kommersiell information',
      ),
      'Composer' => 
      array (
        0 => 'Kompositör',
      ),
      'Composer Sort Order' => 
      array (
        0 => 'Sorteringsordning för kompositörer',
      ),
      'Conductor' => 
      array (
        0 => 'Dirigent',
      ),
      'Content Group Description' => 
      array (
        0 => 'Innehållsgruppens beskrivning',
      ),
      'Copyright' => 
      array (
        0 => 'Upphovsrätt',
      ),
      'Copyright Message' => 
      array (
        0 => 'Meddelande om upphovsrätt',
      ),
      'Encoded By' => 
      array (
        0 => '',
      ),
      'Encoder Settings' => 
      array (
        0 => '',
      ),
      'Encoding Time' => 
      array (
        0 => '',
      ),
      'File Owner' => 
      array (
        0 => '',
      ),
      'File Type' => 
      array (
        0 => '',
      ),
      'Initial Key' => 
      array (
        0 => '',
      ),
      'Internet Radio Station Name' => 
      array (
        0 => '',
      ),
      'Internet Radio Station Owner' => 
      array (
        0 => '',
      ),
      'Involved People List' => 
      array (
        0 => 'Medverkande personlista',
      ),
      'Linked Information' => 
      array (
        0 => 'Länkad information',
      ),
      'Lyricist' => 
      array (
        0 => 'Låttext',
      ),
      'Media Type' => 
      array (
        0 => 'Typ av media',
      ),
      'Mood' => 
      array (
        0 => '',
      ),
      'Music CD Identifier' => 
      array (
        0 => '',
      ),
      'Musician Credits List' => 
      array (
        0 => '',
      ),
      'Original Album' => 
      array (
        0 => 'Ursprungligt album',
      ),
      'Original Artist' => 
      array (
        0 => 'Ursprunglig artist',
      ),
      'Original Filename' => 
      array (
        0 => 'Ursprungligt filnamn',
      ),
      'Original Lyricist' => 
      array (
        0 => 'Ursprunglig text',
      ),
      'Original Release Time' => 
      array (
        0 => 'Ursprunglig releasetid',
      ),
      'Original Year' => 
      array (
        0 => 'Ursprungligt år',
      ),
      'Part Of A Compilation' => 
      array (
        0 => '',
      ),
      'Part Of A Set' => 
      array (
        0 => '',
      ),
      'Performer Sort Order' => 
      array (
        0 => '',
      ),
      'Playlist Delay' => 
      array (
        0 => '',
      ),
      'Produced Notice' => 
      array (
        0 => '',
      ),
      'Publisher' => 
      array (
        0 => '',
      ),
      'Recording Time' => 
      array (
        0 => '',
      ),
      'Release Time' => 
      array (
        0 => '',
      ),
      'Remixer' => 
      array (
        0 => '',
      ),
      'Set Subtitle' => 
      array (
        0 => '',
      ),
      'Subtitle' => 
      array (
        0 => '',
      ),
      'Tagging Time' => 
      array (
        0 => '',
      ),
      'Terms Of Use' => 
      array (
        0 => '',
      ),
      'Title Sort Order' => 
      array (
        0 => 'Sortera efter titel',
      ),
      'Track Number' => 
      array (
        0 => 'Spårnummer',
      ),
      'Unsynchronised Lyric' => 
      array (
        0 => 'Osynkroniserad text',
      ),
      'URL Artist' => 
      array (
        0 => 'URL Artist',
      ),
      'URL File' => 
      array (
        0 => 'URL fil',
      ),
      'URL Payment' => 
      array (
        0 => 'URL Betalning',
      ),
      'URL Publisher' => 
      array (
        0 => '',
      ),
      'URL Source' => 
      array (
        0 => '',
      ),
      'URL Station' => 
      array (
        0 => '',
      ),
      'URL User' => 
      array (
        0 => '',
      ),
      'Year' => 
      array (
        0 => 'År',
      ),
      'Run Synchronized Task' => 
      array (
        0 => '',
      ),
      'Debug Output' => 
      array (
        0 => 'Debug Output',
      ),
      'Configure Backups' => 
      array (
        0 => 'Konfigurera säkerhetskopior',
      ),
      'Run Manual Backup' => 
      array (
        0 => 'Kör manuell säkerhetskopiering',
      ),
      'Backup deleted.' => 
      array (
        0 => 'Säkerhetskopia borttagen.',
      ),
      'Backup not found.' => 
      array (
        0 => 'Säkerhetskopian hittades inte.',
      ),
      'Are you sure?' => 
      array (
        0 => '',
      ),
      'Enter a password to continue.' => 
      array (
        0 => '',
      ),
      'No problems detected.' => 
      array (
        0 => '',
      ),
      'Generate the translation locale file.' => 
      array (
        0 => '',
      ),
      'Convert translated locale files into PHP arrays.' => 
      array (
        0 => '',
      ),
      'Ensure key settings are initialized within AzuraCast.' => 
      array (
        0 => '',
      ),
      'Migrate existing configuration to new INI format if any exists.' => 
      array (
        0 => '',
      ),
      'Install fixtures for demo / local development.' => 
      array (
        0 => '',
      ),
      'Run all general AzuraCast setup steps.' => 
      array (
        0 => '',
      ),
      'Run one or more scheduled synchronization tasks.' => 
      array (
        0 => '',
      ),
      'Process the message queue.' => 
      array (
        0 => '',
      ),
      'Clear the contents of the message queue.' => 
      array (
        0 => '',
      ),
      'List all settings in the AzuraCast settings database.' => 
      array (
        0 => '',
      ),
      'Back up the AzuraCast database and statistics (and optionally media).' => 
      array (
        0 => '',
      ),
      'System Maintenance' => 
      array (
        0 => '',
      ),
      'System Logs' => 
      array (
        0 => '',
      ),
      'System Debugger' => 
      array (
        0 => '',
      ),
      'Users' => 
      array (
        0 => '',
      ),
      'User Accounts' => 
      array (
        0 => '',
      ),
      'API Keys' => 
      array (
        0 => '',
      ),
      'Connected AzuraRelays' => 
      array (
        0 => '',
      ),
      'Install SHOUTcast' => 
      array (
        0 => 'Installera SHOUTcast',
      ),
      'Start Station' => 
      array (
        0 => '',
      ),
      'Ready to start broadcasting? Click to start your station.' => 
      array (
        0 => '',
      ),
      'Restart broadcasting? This will disconnect any current listeners.' => 
      array (
        0 => '',
      ),
      'Restart to Apply Changes' => 
      array (
        0 => '',
      ),
      'Click to restart your station and apply configuration changes.' => 
      array (
        0 => '',
      ),
      'Podcasts (Beta)' => 
      array (
        0 => '',
      ),
      'Reports' => 
      array (
        0 => 'Rapporter',
      ),
      'Duplicate Songs' => 
      array (
        0 => '',
      ),
      'Unprocessable Files' => 
      array (
        0 => '',
      ),
      'SoundExchange Royalties' => 
      array (
        0 => '',
      ),
      'Utilities' => 
      array (
        0 => 'Verktyg',
      ),
      'Automated Assignment' => 
      array (
        0 => '',
      ),
      'Log Viewer' => 
      array (
        0 => '',
      ),
      'Restart Broadcasting' => 
      array (
        0 => '',
      ),
      'Enable Automated Assignment' => 
      array (
        0 => '',
      ),
      'Allow the system to periodically automatically assign songs to playlists based on their performance. This process will run in the background, and will only run if this option is set to "Enabled" and at least one playlist is set to "Include in Automated Assignment".' => 
      array (
        0 => '',
      ),
      'Days Between Automated Assignments' => 
      array (
        0 => '',
      ),
      'Based on this setting, the system will automatically reassign songs every (this) days using data from the previous (this) days.' => 
      array (
        0 => '',
      ),
      '%d days' => 
      array (
        0 => '%d dagar',
      ),
      'Use Browser Default' => 
      array (
        0 => 'Använd webbläsarens standard',
      ),
      'Reset Password' => 
      array (
        0 => 'Återställ lösenord',
      ),
      'Leave these fields blank to continue using your current password.' => 
      array (
        0 => 'Lämna dessa fält tomma för att fortsätta använda ditt nuvarande lösenord.',
      ),
      'Current Password' => 
      array (
        0 => 'Nuvarande lösenord',
      ),
      'Confirm New Password' => 
      array (
        0 => 'Bekräfta nytt lösenord',
      ),
      'Customization' => 
      array (
        0 => 'Anpassning',
      ),
      'Site Theme' => 
      array (
        0 => 'Tema för sidan',
      ),
      'Describe the use-case for this API key for future reference.' => 
      array (
        0 => 'Beskriv användningsfallet för denna API-nyckel för framtida referens.',
      ),
      'Storage Location' => 
      array (
        0 => '',
      ),
      'Backup Filename' => 
      array (
        0 => '',
      ),
      'This will be the file name for your backup, include the file type (.zip or .rar) you wish to use.' => 
      array (
        0 => '',
      ),
      'Exclude Media from Backup' => 
      array (
        0 => '',
      ),
      'This will produce a significantly smaller backup, but you should make sure to back up your media elsewhere. Note that only locally stored media will be backed up.' => 
      array (
        0 => '',
      ),
      'Yes' => 
      array (
        0 => 'Ja',
      ),
      'No' => 
      array (
        0 => 'Nej',
      ),
      'Run Automatic Nightly Backups' => 
      array (
        0 => '',
      ),
      'Enable to have AzuraCast automatically run nightly backups at the time specified.' => 
      array (
        0 => '',
      ),
      'Scheduled Backup Time' => 
      array (
        0 => '',
      ),
      'The time (in UTC) to run the automated backup, if enabled.' => 
      array (
        0 => '',
      ),
      'Exclude Media from Backups' => 
      array (
        0 => '',
      ),
      'Excluding media from automated backups will save space, but you should make sure to back up your media elsewhere. Note that only locally stored media will be backed up.' => 
      array (
        0 => '',
      ),
      'Number of Backup Copies to Keep' => 
      array (
        0 => '',
      ),
      'Copies older than the specified number of days will automatically be deleted. Set to zero to disable automatic deletion.' => 
      array (
        0 => '',
      ),
      'Attempt to Automatically Retrieve ISRC When Missing' => 
      array (
        0 => '',
      ),
      'If enabled, AzuraCast will connect to the MusicBrainz database to attempt to find an ISRC for any files where one is missing. Disabling this may improve performance.' => 
      array (
        0 => '',
      ),
      'Roles' => 
      array (
        0 => 'Roller',
      ),
      'Code from Authenticator App' => 
      array (
        0 => 'Kod från Autentiseringsapp',
      ),
      'Enter the current code provided by your authenticator app to verify that it\'s working correctly.' => 
      array (
        0 => 'Ange den aktuella koden som tillhandahålls av din autentiseringsapp för att verifiera att den fungerar korrekt.',
      ),
      'Verify Authenticator' => 
      array (
        0 => 'Verifiera autentiserare',
      ),
      'Any time the currently playing song changes' => 
      array (
        0 => '',
      ),
      'Any time the listener count increases' => 
      array (
        0 => '',
      ),
      'Any time the listener count decreases' => 
      array (
        0 => '',
      ),
      'Any time a live streamer/DJ connects to the stream' => 
      array (
        0 => '',
      ),
      'Any time a live streamer/DJ disconnects from the stream' => 
      array (
        0 => '',
      ),
      'When the station broadcast goes offline.' => 
      array (
        0 => '',
      ),
      'When the station broadcast comes online.' => 
      array (
        0 => '',
      ),
      'Generic Web Hook' => 
      array (
        0 => '',
      ),
      'Automatically send a message to any URL when your station data changes.' => 
      array (
        0 => '',
      ),
      'Send E-mail' => 
      array (
        0 => '',
      ),
      'Send an e-mail to specified address(es).' => 
      array (
        0 => '',
      ),
      'TuneIn AIR' => 
      array (
        0 => '',
      ),
      'Send song metadata changes to TuneIn.' => 
      array (
        0 => '',
      ),
      'Discord Webhook' => 
      array (
        0 => '',
      ),
      'Automatically send a customized message to your Discord server.' => 
      array (
        0 => '',
      ),
      'Telegram Chat Message' => 
      array (
        0 => '',
      ),
      'Use the Telegram Bot API to send a message to a channel.' => 
      array (
        0 => '',
      ),
      'Twitter Post' => 
      array (
        0 => '',
      ),
      'Automatically send a tweet.' => 
      array (
        0 => '',
      ),
      'Google Analytics Integration' => 
      array (
        0 => '',
      ),
      'Send stream listener details to Google Analytics.' => 
      array (
        0 => '',
      ),
      'Matomo Analytics Integration' => 
      array (
        0 => '',
      ),
      'Send stream listener details to Matomo Analytics.' => 
      array (
        0 => '',
      ),
      'Account Recovery' => 
      array (
        0 => '',
      ),
      'An account recovery link has been requested for your account on "%s".' => 
      array (
        0 => '',
      ),
      'Click the link below to log in to your account.' => 
      array (
        0 => '',
      ),
      'Skip to main content' => 
      array (
        0 => '',
      ),
      'Toggle Sidebar' => 
      array (
        0 => '',
      ),
      'Toggle Menu' => 
      array (
        0 => '',
      ),
      'System Administration' => 
      array (
        0 => '',
      ),
      'Switch Theme' => 
      array (
        0 => '',
      ),
      'My API Keys' => 
      array (
        0 => '',
      ),
      'Help' => 
      array (
        0 => '',
      ),
      'End Session' => 
      array (
        0 => '',
      ),
      'Sign Out' => 
      array (
        0 => '',
      ),
      'Powered by %s' => 
      array (
        0 => 'Drivs av %s',
      ),
      'Like our software? <a href="%s" target="_blank">Donate to support AzuraCast!</a>' => 
      array (
        0 => 'Gillar du vår programvara? <a href="%s" target="_blank">Donera för att stödja AzuraCast!</a>',
      ),
      'Errors were encountered when trying to save changes:' => 
      array (
        0 => '',
      ),
      'General' => 
      array (
        0 => '',
      ),
      'Details' => 
      array (
        0 => '',
      ),
      'Server Status' => 
      array (
        0 => '',
      ),
      'CPU Load' => 
      array (
        0 => '',
      ),
      'Current' => 
      array (
        0 => '',
      ),
      '15-Minute Average' => 
      array (
        0 => '',
      ),
      'Memory' => 
      array (
        0 => '',
      ),
      '%s of %s Used' => 
      array (
        0 => '',
      ),
      'Disk Space' => 
      array (
        0 => '',
      ),
      'Synchronization Tasks' => 
      array (
        0 => '',
      ),
      'Last run: %s' => 
      array (
        0 => '',
      ),
      'Run Task' => 
      array (
        0 => '',
      ),
      'API Key' => 
      array (
        0 => '',
      ),
      'Owner' => 
      array (
        0 => '',
      ),
      'Revoke' => 
      array (
        0 => '',
      ),
      'Clear Cache' => 
      array (
        0 => '',
      ),
      'Clearing the application cache may log you out of your session.' => 
      array (
        0 => '',
      ),
      'Clear All Message Queues' => 
      array (
        0 => '',
      ),
      'This will clear any pending unprocessed messages in all message queues.' => 
      array (
        0 => '',
      ),
      'Message Queues' => 
      array (
        0 => '',
      ),
      '%d queued messages' => 
      array (
        0 => '',
      ),
      'Station-Specific Debugging' => 
      array (
        0 => '',
      ),
      'Rebuild AutoDJ Queue' => 
      array (
        0 => '',
      ),
      'Run Test' => 
      array (
        0 => '',
      ),
      'Send Liquidsoap Telnet Command' => 
      array (
        0 => '',
      ),
      'Command' => 
      array (
        0 => '',
      ),
      'Execute Command' => 
      array (
        0 => '',
      ),
      'Run Synchronization Task' => 
      array (
        0 => '',
      ),
      'Debug Home' => 
      array (
        0 => '',
      ),
      'The synchronization task is running in the background. The log below will update automatically.' => 
      array (
        0 => '',
      ),
      'Log In' => 
      array (
        0 => 'Logga in',
      ),
      'Delete user "%s"?' => 
      array (
        0 => '',
      ),
      '(You)' => 
      array (
        0 => '',
      ),
      'Because you are running Docker, some system logs can only be accessed from a shell session on the host computer. You can run <code>%s</code> to access container logs from the terminal.' => 
      array (
        0 => '',
      ),
      'Logs by Station' => 
      array (
        0 => '',
      ),
      'Relay' => 
      array (
        0 => '',
      ),
      'Is Public' => 
      array (
        0 => '',
      ),
      'First Connected' => 
      array (
        0 => '',
      ),
      'Latest Update' => 
      array (
        0 => '',
      ),
      'Backups Home' => 
      array (
        0 => '',
      ),
      'The backup process is running in the background. The log below will update automatically.' => 
      array (
        0 => '',
      ),
      'Automatic Backups' => 
      array (
        0 => '',
      ),
      'Never run' => 
      array (
        0 => '',
      ),
      'Configure' => 
      array (
        0 => '',
      ),
      'Most Recent Backup Log' => 
      array (
        0 => '',
      ),
      'Restoring Backups' => 
      array (
        0 => '',
      ),
      'To restore a backup from your host computer, run:' => 
      array (
        0 => '',
      ),
      'Note that restoring a backup will clear your existing database. Never restore backup files from untrusted users.' => 
      array (
        0 => '',
      ),
      'Backup' => 
      array (
        0 => '',
      ),
      'Last Modified' => 
      array (
        0 => '',
      ),
      'Delete backup "%s"?' => 
      array (
        0 => '',
      ),
      'Report Not Available' => 
      array (
        0 => '',
      ),
      'This report is not available for this station, because the system administrator has chosen not to collect detailed IP-based listener information.' => 
      array (
        0 => '',
      ),
      'Station Broadcasting Disabled' => 
      array (
        0 => 'Stationssändning inaktiverad',
      ),
      'Your station is currently not enabled for broadcasting. You can still manage media, playlists, and other station settings. To re-enable broadcasting, <a href="%s">edit your station profile</a>.' => 
      array (
        0 => 'Din station är för närvarande inte aktiverad för sändning. Du kan fortfarande hantera medier, spellistor och andra kanalinställningar. För att återaktivera sändning, <a href="%s">redigera din station profil</a>.',
      ),
      'Available Logs' => 
      array (
        0 => 'Tillgängliga loggar',
      ),
      'Station Time' => 
      array (
        0 => '',
      ),
      'Automated Playlist Assignment' => 
      array (
        0 => '',
      ),
      'Based on the previous performance of your station\'s songs, %s can automatically distribute songs evenly among your playlists, placing the highest performing songs in the highest-weighted playlists.' => 
      array (
        0 => '',
      ),
      'Once you have configured automated assignment, click the button below to run the automated assignment process. This process will not run at all unless you have selected "Enable" below.' => 
      array (
        0 => '',
      ),
      'Run Automated Assignment' => 
      array (
        0 => '',
      ),
      'Configure Automated Assignment' => 
      array (
        0 => '',
      ),
      'Streamer accounts are currently disabled for this station. To enable streamer accounts, click the button below.' => 
      array (
        0 => '',
      ),
      'Enable Streaming' => 
      array (
        0 => '',
      ),
      'Two-Factor Authentication' => 
      array (
        0 => 'Tvåfaktorsautentisering',
      ),
      'Two-factor authentication improves the security of your account by requiring a second one-time access code in addition to your password when you log in.' => 
      array (
        0 => 'Tvåfaktorsautentisering förbättrar säkerheten för ditt konto genom att kräva en andra engångskod utöver ditt lösenord när du loggar in.',
      ),
      'Disable Two-Factor' => 
      array (
        0 => 'Inaktivera tvåfaktorsfaktor',
      ),
      'Enable Two-Factor' => 
      array (
        0 => 'Aktivera tvåfaktorsfaktor',
      ),
      'Enable Two-Factor Authentication' => 
      array (
        0 => 'Aktivera tvåfaktorsautentisering',
      ),
      'Step 1: Scan QR Code' => 
      array (
        0 => 'Steg 1: Skanna QR-koden',
      ),
      'From your smartphone, scan the code to the right using an authentication app of your choice (FreeOTP, Authy, etc).' => 
      array (
        0 => 'Från din smartphone, skanna koden till höger med hjälp av en autentiseringsapp som du väljer (FreeOTP, Authy, etc).',
      ),
      'Step 2: Verify Generated Code' => 
      array (
        0 => 'Steg 2: Verifiera genererad kod',
      ),
      'To verify that the code was set up correctly, enter the 6-digit code the app shows you.' => 
      array (
        0 => 'För att verifiera att koden är korrekt inställd, ange den 6-siffriga koden som appen visar dig.',
      ),
      'QR-Code' => 
      array (
        0 => 'QR-kod',
      ),
      'No entries found.' => 
      array (
        0 => '',
      ),
      'View Details' => 
      array (
        0 => '',
      ),
      'New Key Generated' => 
      array (
        0 => '',
      ),
      '<b>Important: copy the key below before continuing!</b> You will not be able to retrieve it again.' => 
      array (
        0 => '',
      ),
      'Your full API key is below:' => 
      array (
        0 => '',
      ),
      'When making API calls, you can pass this value in the "X-API-Key" header to authenticate as yourself. You can only perform the actions your user account is allowed to perform.' => 
      array (
        0 => '',
      ),
      'Continue' => 
      array (
        0 => '',
      ),
      'API keys can be used to access some system functionality without needing to log in. All of the keys
            you create share your permissions in the system. For more information, see the <a href="%s">API documentation</a>.' => 
      array (
        0 => '',
      ),
      'Key Identifier' => 
      array (
        0 => '',
      ),
      'Enter Two-Factor Code' => 
      array (
        0 => '',
      ),
      'Your account uses a two-factor security code. Enter the code your device is currently showing below.' => 
      array (
        0 => '',
      ),
      'Security Code' => 
      array (
        0 => '',
      ),
      'Sign in' => 
      array (
        0 => 'Logga in',
      ),
      'Forgot Password' => 
      array (
        0 => '',
      ),
      'name@example.com' => 
      array (
        0 => '',
      ),
      'Send Recovery E-mail' => 
      array (
        0 => '',
      ),
      'Welcome!' => 
      array (
        0 => 'Välkommen!',
      ),
      'Welcome to %s!' => 
      array (
        0 => 'Välkommen till %s!',
      ),
      'Enter your password' => 
      array (
        0 => 'Ange ditt lösenord',
      ),
      'Remember me' => 
      array (
        0 => '',
      ),
      'Please log in to continue.' => 
      array (
        0 => 'Logga in för att fortsätta.',
      ),
      'Forgot your password?' => 
      array (
        0 => '',
      ),
      'This installation\'s administrator has not configured this functionality.' => 
      array (
        0 => '',
      ),
      'Contact an administrator to reset your password following the instructions in our documentation:' => 
      array (
        0 => '',
      ),
      'Password Reset Instructions' => 
      array (
        0 => '',
      ),
      'Recover Account' => 
      array (
        0 => '',
      ),
      'Choose a new password for your account.' => 
      array (
        0 => '',
      ),
      'Automatically scroll to the bottom of the log' => 
      array (
        0 => '',
      ),
      'Need Help?' => 
      array (
        0 => '',
      ),
      'You can find answers for many common questions in our <a href="%s" target="_blank">support documents</a>.' => 
      array (
        0 => '',
      ),
      'If you\'re experiencing a bug or error, you can submit a GitHub issue using the link below.' => 
      array (
        0 => '',
      ),
      'Your current installation type is <b>%s</b>. Be sure to include this when creating a new issue.' => 
      array (
        0 => '',
      ),
      'Add New GitHub Issue' => 
      array (
        0 => '',
      ),
    ),
  ),
);