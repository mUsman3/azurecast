<?php return array (
  'domain' => NULL,
  'plural-forms' => 'nplurals=4; plural=((n%10==1 && n%100!=11) ? 0 : ((n%10 >= 2 && n%10 <=4 && (n%100 < 12 || n%100 > 14)) ? 1 : ((n%10 == 0 || (n%10 >= 5 && n%10 <=9)) || (n%100 >= 11 && n%100 <= 14)) ? 2 : 3));',
  'messages' => 
  array (
    '' => 
    array (
      '' => 
      array (
        0 => 'Project-Id-Version: azuracast
Report-Msgid-Bugs-To: 
Last-Translator: 
Language-Team: Russian
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
POT-Creation-Date: 2021-10-27T06:14:10+00:00
PO-Revision-Date: 2021-10-27 07:09
Language: ru_RU
Plural-Forms: nplurals=4; plural=((n%10==1 && n%100!=11) ? 0 : ((n%10 >= 2 && n%10 <=4 && (n%100 < 12 || n%100 > 14)) ? 1 : ((n%10 == 0 || (n%10 >= 5 && n%10 <=9)) || (n%100 >= 11 && n%100 <= 14)) ? 2 : 3));
X-Crowdin-Project: azuracast
X-Crowdin-Project-ID: 217396
X-Crowdin-Language: ru
X-Crowdin-File: /main/resources/locale/default.pot
X-Crowdin-File-ID: 4
',
      ),
      'Avatars are retrieved based on your e-mail address from the %{service} service. Click to manage your %{service} settings.' => 
      array (
        0 => 'Аватары получены на основе вашего адреса электронной почты от службы %{service}. Нажмите для управления настройками %{service}.',
      ),
      'Drag file(s) here to upload or' => 
      array (
        0 => 'Перетащите файл(ы) сюда для загрузки или',
      ),
      'Select File' => 
      array (
        0 => 'Выбрать файл',
      ),
      'Today' => 
      array (
        0 => 'Сегодня',
      ),
      'Yesterday' => 
      array (
        0 => 'Вчера',
      ),
      'Last 7 Days' => 
      array (
        0 => 'Последние 7 дней',
      ),
      'Last 14 Days' => 
      array (
        0 => 'Последние 14 Дней',
      ),
      'Last 30 Days' => 
      array (
        0 => 'Последние 30 дней',
      ),
      'This Month' => 
      array (
        0 => 'Текущий месяц',
      ),
      'Last Month' => 
      array (
        0 => 'Прошлый месяц',
      ),
      'Volume' => 
      array (
        0 => 'Громкость',
      ),
      'Waveform Zoom' => 
      array (
        0 => 'Зум Формы Сигнала',
      ),
      'Mute' => 
      array (
        0 => 'Откл. звук',
      ),
      'Full Volume' => 
      array (
        0 => 'Полная Громкость',
      ),
      'Edit Record' => 
      array (
        0 => 'Редактировать запись',
      ),
      'Add Record' => 
      array (
        0 => 'Добавить запись',
      ),
      'Copy to Clipboard' => 
      array (
        0 => 'Копировать в буфер обмена',
      ),
      'Close' => 
      array (
        0 => 'Закрыть',
      ),
      'Save Changes' => 
      array (
        0 => 'Сохранить',
      ),
      'Refresh rows' => 
      array (
        0 => 'Обновить строки',
      ),
      'Rows per page' => 
      array (
        0 => 'Строк на страницу',
      ),
      'Select displayed fields' => 
      array (
        0 => 'Выбрать отображаемые поля',
      ),
      'Select all visible rows' => 
      array (
        0 => 'Выбрать все видимые строки',
      ),
      'Select' => 
      array (
        0 => 'Выбрать',
      ),
      'Deselect' => 
      array (
        0 => 'Отменить выбор',
      ),
      'Search' => 
      array (
        0 => 'Поиск',
      ),
      'No records to display.' => 
      array (
        0 => 'Нет записей для отображения.',
      ),
      'Loading...' => 
      array (
        0 => 'Загрузка...',
      ),
      'Stop' => 
      array (
        0 => 'Остановить',
      ),
      'Play' => 
      array (
        0 => 'Воспроизведение',
      ),
      'Listeners' => 
      array (
        0 => 'Слушатели',
      ),
      'Log View' => 
      array (
        0 => 'Просмотр Журнала',
      ),
      'Average Listeners' => 
      array (
        0 => 'В среднем слушателей',
      ),
      'Unique Listeners' => 
      array (
        0 => 'Уникальные Слушатели',
      ),
      'Hide Charts' => 
      array (
        0 => 'Скрыть Диаграммы',
      ),
      'Show Charts' => 
      array (
        0 => 'Показать диаграммы',
      ),
      'My Account' => 
      array (
        0 => 'Мой аккаунт',
      ),
      'Administration' => 
      array (
        0 => 'Администрирование',
      ),
      'Listeners Per Station' => 
      array (
        0 => 'Слушателей на станции',
      ),
      'Station Overview' => 
      array (
        0 => 'Обзор станций',
      ),
      'Manage Stations' => 
      array (
        0 => 'Управление станциями',
      ),
      'Station Name' => 
      array (
        0 => 'Название Станции',
      ),
      'Now Playing' => 
      array (
        0 => 'Сейчас играет',
      ),
      'Public Page' => 
      array (
        0 => 'Публичная страница',
      ),
      'Manage' => 
      array (
        0 => 'Управлять',
      ),
      'Username' => 
      array (
        0 => 'Логин',
      ),
      'New Password' => 
      array (
        0 => 'Новый Пароль',
      ),
      'Password' => 
      array (
        0 => 'Пароль',
      ),
      'Leave blank to use the current password.' => 
      array (
        0 => 'Оставьте поле пустым, чтобы использовать текущий пароль.',
      ),
      'SSH Public Keys' => 
      array (
        0 => 'Публичные ключи SSH',
      ),
      'Optionally supply SSH public keys this user can use to connect instead of a password. Enter one key per line.' => 
      array (
        0 => 'Дополнительно укажите публичные ключи SSH, которые пользователь может использовать для подключения вместо пароля. Введите по одному ключу на строку.',
      ),
      'Edit SFTP User' => 
      array (
        0 => 'Изменить пользователя SFTP',
      ),
      'Add SFTP User' => 
      array (
        0 => 'Добавить пользователя SFTP',
      ),
      'Reorder Playlist' => 
      array (
        0 => 'Перестроить Плейлист',
      ),
      'Down' => 
      array (
        0 => 'Вниз',
      ),
      'Up' => 
      array (
        0 => 'Вверх',
      ),
      'Playlist order set.' => 
      array (
        0 => 'Порядок плейлиста установлен.',
      ),
      'Title' => 
      array (
        0 => 'Заголовок',
      ),
      'Artist' => 
      array (
        0 => 'Исполнитель',
      ),
      'Album' => 
      array (
        0 => 'Альбом',
      ),
      'Actions' => 
      array (
        0 => 'Действие',
      ),
      'Advanced' => 
      array (
        0 => 'Продвинутое',
      ),
      'Warning' => 
      array (
        0 => 'Предупреждение',
      ),
      'If any of these options are enabled, this playlist will be managed directly via Liquidsoap instead of via AzuraCast. This can have unintended effects and should only be used when you are comfortable with the results.' => 
      array (
        0 => 'Если какой-либо из этих параметров включен, этот плейлист будет управляться напрямую через Liquidsoap, а не через AzuraCast. Это может иметь непреднамеренные эффекты и должно использоваться только тогда, когда вы довольны результатами.',
      ),
      'Advanced Manual AutoDJ Scheduling Options' => 
      array (
        0 => 'Расширенные Настройки Планирования АвтоДиджея Вручную',
      ),
      'Control how this playlist is handled by the AutoDJ software.' => 
      array (
        0 => 'Управляйте тем, как этот плейлист обрабатывается программным обеспечением АвтоДиджея.',
      ),
      'Interrupt other songs to play at scheduled time.' => 
      array (
        0 => 'Прервать другие песни, чтобы играть в запланированное время.',
      ),
      'Only loop through playlist once.' => 
      array (
        0 => 'Воспроизводить плейлист только один цикл.',
      ),
      'Only play one track at scheduled time.' => 
      array (
        0 => 'Воспроизвести только один трек в запланированное время.',
      ),
      'Merge playlist to play as a single track.' => 
      array (
        0 => 'Объединить плейлист, чтобы играть как один трек.',
      ),
      'Low' => 
      array (
        0 => 'Редко',
      ),
      'Default' => 
      array (
        0 => 'По умолчанию',
      ),
      'High' => 
      array (
        0 => 'Часто',
      ),
      'Basic Info' => 
      array (
        0 => 'Основная информация',
      ),
      'Playlist Name' => 
      array (
        0 => 'Название Плейлиста',
      ),
      'Playlist Weight' => 
      array (
        0 => 'Вес плейлиста',
      ),
      'Higher weight playlists are played more frequently compared to other lower-weight playlists.' => 
      array (
        0 => 'Плейлисты с более высоким весом чаще воспроизводятся по сравнению с другими плейлистами с более низким весом.',
      ),
      'Is Enabled' => 
      array (
        0 => 'Включен',
      ),
      'If disabled, the playlist will not be included in radio playback, but can still be managed.' => 
      array (
        0 => 'Если отключено, плейлист не будет включён в воспроизведение радио, но его всё ещё можно будет настраивать.',
      ),
      'Avoid Duplicate Artists/Titles' => 
      array (
        0 => 'Избегать Дубликатов Исполнителей/Названий',
      ),
      'Whether the AutoDJ should attempt to avoid duplicate artists and track titles when playing media from this playlist.' => 
      array (
        0 => 'Должен ли АвтоДиджей отслеживать и пытаться избегать дублирования исполнителей и названий треков при воспроизведении медиафайлов из этого плейлиста.',
      ),
      'Include in On-Demand Player' => 
      array (
        0 => 'Включить проигрывание по запросу',
      ),
      'If this station has on-demand streaming and downloading enabled, only songs that are in playlists with this setting enabled will be visible.' => 
      array (
        0 => 'Если на этой станции включено прослушивание и загрузка по запросу, то будут видны только те песни, которые находятся в плейлистах с включенным этим параметром.',
      ),
      'Playlist Type' => 
      array (
        0 => 'Тип Плейлиста',
      ),
      'General Rotation' => 
      array (
        0 => 'Обычная ротация',
      ),
      'Standard playlist, shuffles with other standard playlists based on weight.' => 
      array (
        0 => 'Стандартный плейлист, перемешивается с другими стандартными плейлистами на основе веса.',
      ),
      'Once per x Songs' => 
      array (
        0 => 'Через каждые x песен',
      ),
      'Play exactly once every $x songs.' => 
      array (
        0 => 'Играет один раз через каждые $x песен.',
      ),
      'Once per x Minutes' => 
      array (
        0 => 'Через каждые x минут',
      ),
      'Play exactly once every $x minutes.' => 
      array (
        0 => 'Играет один раз через каждые $x минут.',
      ),
      'Once per Hour' => 
      array (
        0 => 'Один раз в час',
      ),
      'Play once per hour at the specified minute.' => 
      array (
        0 => 'Играет один раз в час в указанную минуту.',
      ),
      'Manually define how this playlist is used in Liquidsoap configuration.' => 
      array (
        0 => 'Установите вручную, как этот плейлист используется в конфигурации Liquidsoap.',
      ),
      'Learn about Advanced Playlists' => 
      array (
        0 => 'Узнайте о продвинутых плейлистах',
      ),
      'Include in Automated Assignment' => 
      array (
        0 => 'Включить в Автоматическое Назначение',
      ),
      'If auto-assignment is enabled, use this playlist as one of the targets for songs to be redistributed into. This will overwrite the existing contents of this playlist.' => 
      array (
        0 => 'Если автоматическое назначение включено, этот плейлист используется как одна из целей для перераспределения песен. Это перезапишет существующее содержимое этого плейлиста.',
      ),
      'Number of Songs Between Plays' => 
      array (
        0 => 'Количество песен между воспроизведением',
      ),
      'This playlist will play every $x songs, where $x is specified below.' => 
      array (
        0 => 'Этот плейлист будет проигрываться через каждые $x песен, где $x указан ниже.',
      ),
      'Number of Minutes Between Plays' => 
      array (
        0 => 'Количество минут между воспроизведениями',
      ),
      'This playlist will play every $x minutes, where $x is specified below.' => 
      array (
        0 => 'Этот плейлист будет проигрываться через каждые $x минут, где $x указан ниже.',
      ),
      'Minute of Hour to Play' => 
      array (
        0 => 'Минута Часа для Воспроизведения',
      ),
      'Specify the minute of every hour that this playlist should play.' => 
      array (
        0 => 'Укажите минуту в которую каждый час должен начать играть этот плейлист.',
      ),
      'Monday' => 
      array (
        0 => 'Понедельник',
      ),
      'Tuesday' => 
      array (
        0 => 'Вторник',
      ),
      'Wednesday' => 
      array (
        0 => 'Среда',
      ),
      'Thursday' => 
      array (
        0 => 'Четверг',
      ),
      'Friday' => 
      array (
        0 => 'Пятница',
      ),
      'Saturday' => 
      array (
        0 => 'Суббота',
      ),
      'Sunday' => 
      array (
        0 => 'Воскресенье',
      ),
      'Schedule' => 
      array (
        0 => 'Расписание',
      ),
      'Not Scheduled' => 
      array (
        0 => 'Не запланировано',
      ),
      'This playlist currently has no scheduled times. It will play at all times. To add a new scheduled time, click the button below.' => 
      array (
        0 => 'Этот плейлист в настоящий момент не имеет запланированного времени. Он будет проигрываться постоянно. Чтобы добавить новое запланированное время, нажмите кнопку ниже.',
      ),
      'Scheduled Time #%{num}' => 
      array (
        0 => 'Запланированное время #%{num}',
      ),
      'Remove' => 
      array (
        0 => 'Удалить',
      ),
      'Start Time' => 
      array (
        0 => 'Время начала',
      ),
      'To play once per day, set the start and end times to the same value.' => 
      array (
        0 => 'Чтобы играть один раз в день, установите одинаковое время начала и окончания.',
      ),
      'End Time' => 
      array (
        0 => 'Время завершения',
      ),
      'If the end time is before the start time, the playlist will play overnight.' => 
      array (
        0 => 'Если время окончания до времени начала, плейлист будет воспроизводиться в том числе и ночью.',
      ),
      'Station Time Zone' => 
      array (
        0 => 'Часовой пояс станции',
      ),
      'This station\'s time zone is currently %{tz}.' => 
      array (
        0 => 'Часовой пояс этой станции в настоящее время %{tz}.',
      ),
      'Start Date' => 
      array (
        0 => 'Дата начала',
      ),
      'To set this schedule to run only within a certain date range, specify a start and end date.' => 
      array (
        0 => 'Чтобы настроить запуск этого расписания только в определенном диапазоне дат, укажите дату начала и окончания.',
      ),
      'Start/end date cannot be used on playlists with advanced settings!' => 
      array (
        0 => 'Дата начала/окончания не может быть использована в плейлисте с расширенными настройками!',
      ),
      'End Date' => 
      array (
        0 => 'Дата завершения',
      ),
      'Loop Once' => 
      array (
        0 => '',
      ),
      'Scheduled Play Days of Week' => 
      array (
        0 => 'Запланированные дни недели для воспроизведения',
      ),
      'Leave blank to play on every day of the week.' => 
      array (
        0 => 'Оставьте пустым, чтобы воспроизводилось каждый день недели.',
      ),
      'Add Schedule Item' => 
      array (
        0 => 'Добавить элемент расписания',
      ),
      'Source' => 
      array (
        0 => 'Источник',
      ),
      'Song-Based Playlist' => 
      array (
        0 => 'Плейлист с базовыми песнями',
      ),
      'A playlist containing media files hosted on this server.' => 
      array (
        0 => 'Плейлист содержит медиафайлы, размещенные на этом сервере.',
      ),
      'Remote URL Playlist' => 
      array (
        0 => 'Отдалённый URL-адрес Плейлиста',
      ),
      'A playlist that instructs the station to play from a remote URL.' => 
      array (
        0 => 'Плейлист, который указывает станции для воспроизведения с отдалённого URL-адреса.',
      ),
      'Song Playback Order' => 
      array (
        0 => 'Порядок воспроизведения песни',
      ),
      'Shuffled' => 
      array (
        0 => 'Перетасованный',
      ),
      'The full playlist is shuffled and then played through in the shuffled order.' => 
      array (
        0 => 'Весь плейлист перемешивается и проигрывается в перетасованном порядке.',
      ),
      'Random' => 
      array (
        0 => 'Случайно',
      ),
      'A completely random track is picked for playback every time the queue is populated.' => 
      array (
        0 => 'При каждом заполнении очереди для воспроизведения выбирается полностью случайный трек.',
      ),
      'Sequential' => 
      array (
        0 => 'Последовательно',
      ),
      'The order of the playlist is manually specified and followed by the AutoDJ.' => 
      array (
        0 => 'Порядок плейлиста определяется вручную, а затем сопровождается АвтоДиджеем.',
      ),
      'If requests are enabled for your station, users will be able to request media that is on this playlist.' => 
      array (
        0 => 'Если запросы включены для вашей станции, пользователи смогут заказать песни, которые находятся в этом плейлисте.',
      ),
      'Allow Requests from This Playlist' => 
      array (
        0 => 'Разрешить запросы из этого плейлиста',
      ),
      'Enable this setting to prevent metadata from being sent to the AutoDJ for files in this playlist. This is useful if the playlist contains jingles or bumpers.' => 
      array (
        0 => 'Включите эту настройку, чтобы не допустить отправки метаданных в АвтоДиджей для файлов в этом плейлисте. Это полезно, если в плейлисте содержатся джинглы или бамперы.',
      ),
      'Hide Metadata from Listeners ("Jingle Mode")' => 
      array (
        0 => 'Скрыть метаданные от слушателей ("Режим Джингла")',
      ),
      'Remote URL' => 
      array (
        0 => 'Отдалённый URL-адрес',
      ),
      'Remote URL Type' => 
      array (
        0 => 'Тип отдалённого URL-адреса',
      ),
      'Direct Stream URL' => 
      array (
        0 => 'URL-адрес Потока',
      ),
      'Playlist (M3U/PLS) URL' => 
      array (
        0 => 'URL-адрес плейлиста (M3U/PLS)',
      ),
      'Remote Playback Buffer (Seconds)' => 
      array (
        0 => 'Буфер отдалённого воспроизведения (в секундах)',
      ),
      'The length of playback time that Liquidsoap should buffer when playing this remote playlist. Shorter times may lead to intermittent playback on unstable connections.' => 
      array (
        0 => 'Длина времени воспроизведения, которое Liquidsoap должен буферизовать при воспроизведении этого отдалённого плейлиста. Малое время может привести к прерыванию воспроизведения при нестабильных соединениях.',
      ),
      'Import from PLS/M3U' => 
      array (
        0 => 'Импорт из PLS/M3U',
      ),
      'Select PLS/M3U File to Import' => 
      array (
        0 => 'Выберите файл PLS/M3U для импорта',
      ),
      'AzuraCast will scan the uploaded file for matches in this station\'s music library. Media should already be uploaded before running this step. You can re-run this tool as many times as needed.' => 
      array (
        0 => 'AzuraCast просканирует загруженный файл на совпадения в музыкальной библиотеке этой станции. Медиафайлы уже должны быть загружены перед выполнением этого шага. Вы можете повторно запускать этот инструмент столько раз, сколько необходимо.',
      ),
      'Duplicate Playlist' => 
      array (
        0 => 'Копировать Плейлист',
      ),
      '%{name} - Copy' => 
      array (
        0 => '%{name} - Копировать',
      ),
      'New Playlist Name' => 
      array (
        0 => 'Название Плейлиста',
      ),
      'Customize Copy' => 
      array (
        0 => 'Настройки копирования',
      ),
      'Copy associated media and folders.' => 
      array (
        0 => 'Копировать связанные файлы и папки.',
      ),
      'Copy scheduled playback times.' => 
      array (
        0 => 'Скопировать запланированное время воспроизведения.',
      ),
      'Playback Queue' => 
      array (
        0 => 'Очередь Воспроизведения',
      ),
      'Playlist queue cleared.' => 
      array (
        0 => 'Очередь воспроизведения очищена.',
      ),
      'This queue contains the remaining tracks in the order they will be queued by the AzuraCast AutoDJ (if the tracks are eligible to be played).' => 
      array (
        0 => 'Эта очередь содержит треки в том порядке, в котором они будут поставлены в очередь АвтоДиджея AzuraCast (если эти треки имеют право на воспроизведение).',
      ),
      'Clear Queue' => 
      array (
        0 => 'Очистить очередь',
      ),
      'Edit Playlist' => 
      array (
        0 => 'Редактирование Плейлиста',
      ),
      'Add Playlist' => 
      array (
        0 => 'Добавить плейлист',
      ),
      'Edit Station Profile' => 
      array (
        0 => 'Редактировать профиль станции',
      ),
      'Song Title' => 
      array (
        0 => 'Название песни',
      ),
      'Cued On' => 
      array (
        0 => 'В Очереди',
      ),
      'Delete Queue Item?' => 
      array (
        0 => '',
      ),
      'Clear Upcoming Song Queue?' => 
      array (
        0 => '',
      ),
      'Clear' => 
      array (
        0 => 'Очистить',
      ),
      'Upcoming Song Queue' => 
      array (
        0 => 'Песни стоящие в очереди',
      ),
      'Clear Upcoming Song Queue' => 
      array (
        0 => '',
      ),
      'Logs' => 
      array (
        0 => 'Журналы',
      ),
      'Delete' => 
      array (
        0 => 'Удалить',
      ),
      'Listener Request' => 
      array (
        0 => 'Запрос слушателя',
      ),
      'Playlist:' => 
      array (
        0 => 'Плейлист:',
      ),
      'Remote Station Type' => 
      array (
        0 => 'Тип отдалённой станции',
      ),
      'Display Name' => 
      array (
        0 => 'Отображаемое Имя',
      ),
      'The display name assigned to this relay when viewing it on administrative or public pages. Leave blank to automatically generate one.' => 
      array (
        0 => 'Отображаемое название, назначенное этому ретранслятору при просмотре его на административных или публичных страницах. Оставьте поле пустым, чтобы автоматически сгенерировать его.',
      ),
      'Remote Station Listening URL' => 
      array (
        0 => 'URL-адрес подключения к отдалённой станции',
      ),
      'Example: if the remote radio URL is http://station.example.com:8000/radio.mp3, enter "http://station.example.com:8000".' => 
      array (
        0 => 'Пример: если URL-адрес отдалённого радио http://station.example.com:8000/radio.mp3, введите "http://station.example.com:8000".',
      ),
      'Remote Station Listening Mountpoint/SID' => 
      array (
        0 => 'Точка подключения отдалённой станции /SID',
      ),
      'Specify a mountpoint (i.e. "/radio.mp3") or a Shoutcast SID (i.e. "2") to specify a specific stream to use for statistics or broadcasting.' => 
      array (
        0 => 'Укажите точку подключения (т.е. "/radio.mp3") или идентификатор Shoutcast SID (т.е. "2") чтобы указать конкретный поток для использования в статистике или вещании.',
      ),
      'Remote Station Administrator Password' => 
      array (
        0 => 'Пароль администратора отдалённой станции',
      ),
      'To retrieve detailed unique listeners and client details, an administrator password is often required.' => 
      array (
        0 => 'Для получения подробных уникальных данных о слушателях и пользователях зачастую требуется пароль администратора.',
      ),
      'Show on Public Pages' => 
      array (
        0 => 'Показать на публичных страницах',
      ),
      'Enable to allow listeners to select this relay on this station\'s public pages.' => 
      array (
        0 => 'Разрешить слушателям выбирать эту точку подключения на публичных страницах этой станции.',
      ),
      'AutoDJ' => 
      array (
        0 => 'АвтоДиджей',
      ),
      'Broadcast AutoDJ to Remote Station' => 
      array (
        0 => 'Вещание АвтоДиджея на отдалённую станцию',
      ),
      'If enabled, the AutoDJ on this installation will automatically play music to this mount point.' => 
      array (
        0 => 'Если включено, АвтоДиджей в этой установке будет автоматически воспроизводить музыку до этой точки подключения.',
      ),
      'AutoDJ Format' => 
      array (
        0 => 'Формат АвтоДиджея',
      ),
      'AutoDJ Bitrate (kbps)' => 
      array (
        0 => 'Битрейт АвтоДиджея (kbps)',
      ),
      'Remote Station Source Port' => 
      array (
        0 => 'Порт источника отдалённой станции',
      ),
      'If the port you broadcast to is different from the one you listed in the URL above, specify the source port here.' => 
      array (
        0 => 'Если порт, на который осуществляется трансляция, отличается от указанного в URL-адресе выше, укажите здесь исходный порт.',
      ),
      'Remote Station Source Mountpoint/SID' => 
      array (
        0 => 'Точка подключения отдалённой станции/SID',
      ),
      'If the mountpoint (i.e. /radio.mp3) or Shoutcast SID (i.e. 2) you broadcast to is different from the one listed above, specify the source mount point here.' => 
      array (
        0 => '',
      ),
      'Remote Station Source Username' => 
      array (
        0 => 'Логин Источника Отдалённой Станции',
      ),
      'If you are broadcasting using AutoDJ, enter the source username here. This may be blank.' => 
      array (
        0 => 'Если вы транслируете с помощью АвтоДиджея, введите имя источника здесь. Оно может быть пустым.',
      ),
      'Remote Station Source Password' => 
      array (
        0 => 'Пароль источника отдалённой станции',
      ),
      'If you are broadcasting using AutoDJ, enter the source password here.' => 
      array (
        0 => 'Если вы транслируете с помощью АвтоДиджея, введите пароль источника здесь.',
      ),
      'Publish to "Yellow Pages" Directories' => 
      array (
        0 => 'Опубликовать в каталоге "Желтые страницы"',
      ),
      'Enable to advertise this relay on "Yellow Pages" public radio directories.' => 
      array (
        0 => '',
      ),
      'Edit Remote Relay' => 
      array (
        0 => 'Редактирование Отдалённого Ретранслятора',
      ),
      'Add Remote Relay' => 
      array (
        0 => 'Добавить Отдалённый Ретранслятор',
      ),
      'Playlist' => 
      array (
        0 => 'Плейлист',
      ),
      'Scheduling' => 
      array (
        0 => 'Расписание',
      ),
      '# Songs' => 
      array (
        0 => '# Песни',
      ),
      'All Playlists' => 
      array (
        0 => 'Все плейлисты',
      ),
      'Schedule View' => 
      array (
        0 => 'Просмотр расписания',
      ),
      'More' => 
      array (
        0 => 'Больше',
      ),
      'Reorder' => 
      array (
        0 => 'Пересортировать',
      ),
      'Reshuffle' => 
      array (
        0 => 'Перетасовка',
      ),
      'Duplicate' => 
      array (
        0 => 'Копировать',
      ),
      'Disable' => 
      array (
        0 => 'Отключить',
      ),
      'Enable' => 
      array (
        0 => 'Включить',
      ),
      'Disabled' => 
      array (
        0 => 'Отключено',
      ),
      'Weight' => 
      array (
        0 => 'Вес',
      ),
      'Once per %{songs} Songs' => 
      array (
        0 => 'Через каждые %{songs} песен',
      ),
      'Once per %{minutes} Minutes' => 
      array (
        0 => 'Через каждые %{minutes} минут',
      ),
      'Once per Hour (at %{minute})' => 
      array (
        0 => 'Один раз в час (в %{minute})',
      ),
      'Custom' => 
      array (
        0 => 'Продвинутое',
      ),
      'Delete Playlist?' => 
      array (
        0 => '',
      ),
      'Playlists' => 
      array (
        0 => 'Плейлисты',
      ),
      'Edit' => 
      array (
        0 => 'Редактировать',
      ),
      'Export %{format}' => 
      array (
        0 => 'Экспорт %{format}',
      ),
      'Song-based' => 
      array (
        0 => 'Базовые песни',
      ),
      'Jingle Mode' => 
      array (
        0 => 'Режим Джингла',
      ),
      'On-Demand' => 
      array (
        0 => 'С Запросом',
      ),
      'Auto-Assigned' => 
      array (
        0 => 'Автоматическое назначение',
      ),
      'Name' => 
      array (
        0 => 'Имя/Название',
      ),
      'Delete Remote Relay?' => 
      array (
        0 => '',
      ),
      'Remote Relays' => 
      array (
        0 => 'Отдалённая Трансляция',
      ),
      'Remote relays let you work with broadcasting software outside this server. Any relay you include here will be included in your station\'s statistics. You can also broadcast from this server to remote relays.' => 
      array (
        0 => 'Отдалённые ретрансляторы позволяют работать с вещательным программным обеспечением вне этого сервера. Любой ретранслятор, который вы включаете здесь, будет включен в статистику вашей станции. Вы также можете транслировать с этого сервера на отдалённые ретрансляторы.',
      ),
      'Enabled' => 
      array (
        0 => 'Включено',
      ),
      'Mount Point URL' => 
      array (
        0 => 'URL точки подключения',
      ),
      'You can set a custom URL for this stream that AzuraCast will use when referring to it. Leave empty to use the default value.' => 
      array (
        0 => 'Вы можете задать пользовательский URL для этого потока, который AzuraCast будет использовать в ссылке на него. Оставьте пустым, чтобы использовать значение по умолчанию.',
      ),
      'Custom Frontend Configuration' => 
      array (
        0 => 'Пользовательская Конфигурация Интерфейса',
      ),
      'You can include any special mount point settings here, in either JSON { key: \'value\' } format or XML <key>value</key>' => 
      array (
        0 => '',
      ),
      'This name should always begin with a slash (/), and must be a valid URL, such as /autodj.mp3' => 
      array (
        0 => 'Это имя всегда должно начинаться с косой черты (/), и должно быть корректным URL-адресом, например /autodj.mp3',
      ),
      'The display name assigned to this mount point when viewing it on administrative or public pages. Leave blank to automatically generate one.' => 
      array (
        0 => 'Отображаемое название, назначенное этой точке подключения при просмотре его на административных или публичных страницах. Оставьте пустым, чтобы автоматически сгенерировать его.',
      ),
      'Enable to allow listeners to select this mount point on this station\'s public pages.' => 
      array (
        0 => 'Разрешить слушателям выбрать эту точку подключения на публичных страницах этой станции.',
      ),
      'Set as Default Mount Point' => 
      array (
        0 => 'Установить как точку подключения по умолчанию',
      ),
      'If this mount is the default, it will be played on the radio preview and the public radio page in this system.' => 
      array (
        0 => 'Если это подключение установлено по умолчанию, оно будет воспроизводиться на предварительном просмотре радио и на публичной странице радио в этой системе.',
      ),
      'Relay Stream URL' => 
      array (
        0 => 'Ретрансляция потока (URL-адрес)',
      ),
      'Enter the full URL of another stream to relay its broadcast through this mount point.' => 
      array (
        0 => 'Введите полный URL-адрес другого потока, чтобы передать его трансляцию через эту точку подключения.',
      ),
      'Enable to advertise this mount point on "Yellow Pages" public radio directories.' => 
      array (
        0 => 'Включите, чтобы рекламировать эту точку подключения на "Жёлтых страницах" публичных радио каталогах.',
      ),
      'Max Listener Duration' => 
      array (
        0 => 'Макс. Время Прослушивания',
      ),
      'Set the length of time (seconds) a listener will stay connected to the stream. If set to 0, listeners can stay connected infinitely.' => 
      array (
        0 => 'Установите время (в секундах), в течение которого слушатель будет оставаться подключенным к потоку. Если установлено значение 0, слушатели могут оставаться подключенными бесконечно.',
      ),
      'YP Directory Authorization Hash' => 
      array (
        0 => 'Хэш авторизации в каталогах "Желтых Страниц"',
      ),
      'Fallback Mount' => 
      array (
        0 => 'Резервная Точка Подключения',
      ),
      'If this mount point is not playing audio, listeners will automatically be redirected to this mount point. The default is /error.mp3, a repeating error message.' => 
      array (
        0 => 'Если эта точка подключения не воспроизводит аудио, слушатели будут автоматически перенаправлены на эту (резервную) точку подключения. По умолчанию используется повторяющееся сообщение об ошибке /error.mp3.',
      ),
      'Enable AutoDJ' => 
      array (
        0 => 'Включить АвтоДиджей',
      ),
      'If enabled, the AutoDJ will automatically play music to this mount point.' => 
      array (
        0 => 'Если включено, АвтоДиджей автоматически воспроизводит музыку в этой точке подключения.',
      ),
      'Intro' => 
      array (
        0 => 'Интро',
      ),
      'Select Intro File' => 
      array (
        0 => 'Выберите Интро файл',
      ),
      'This introduction file should exactly match the bitrate and format of the mount point itself.' => 
      array (
        0 => 'Этот интро файл должен точно соответствовать битрейту и формату самой точки подключения.',
      ),
      'Current Intro File' => 
      array (
        0 => 'Текущий Интро файл',
      ),
      'Download' => 
      array (
        0 => 'Скачать',
      ),
      'Clear File' => 
      array (
        0 => '',
      ),
      'There is no existing intro file associated with this mount point.' => 
      array (
        0 => 'С этой точкой подключения не связан ни один интро файл.',
      ),
      'Edit Mount Point' => 
      array (
        0 => 'Редактирование Точки Подключения',
      ),
      'Add Mount Point' => 
      array (
        0 => 'Добавить Точку Подключения',
      ),
      'Delete SFTP User?' => 
      array (
        0 => '',
      ),
      'SFTP Users' => 
      array (
        0 => 'Пользователи SFTP',
      ),
      'Connection Information' => 
      array (
        0 => 'Сведения о подключении',
      ),
      'Server:' => 
      array (
        0 => '',
      ),
      'You may need to connect directly to your IP address:' => 
      array (
        0 => '',
      ),
      'Port:' => 
      array (
        0 => '',
      ),
      'Web Hook Details' => 
      array (
        0 => 'Подробности веб-хука',
      ),
      'Web hooks automatically send a HTTP POST request to the URL you specify to notify it any time one of the triggers you specify occurs on your station.' => 
      array (
        0 => '',
      ),
      'The body of the POST message is the exact same as the NowPlaying API response for your station.' => 
      array (
        0 => '',
      ),
      'NowPlaying API Response' => 
      array (
        0 => '',
      ),
      'In order to process quickly, web hooks have a short timeout, so the responding service should be optimized to handle the request in under 2 seconds.' => 
      array (
        0 => '',
      ),
      'Web Hook URL' => 
      array (
        0 => 'URL веб-хука',
      ),
      'The URL that will receive the POST messages any time an event is triggered.' => 
      array (
        0 => 'URL, который будет получать POST сообщения в любое время, когда событие будет запущено.',
      ),
      'Optional: HTTP Basic Authentication Username' => 
      array (
        0 => 'При необходимости: имя пользователя базовой аутентификации HTTP',
      ),
      'If your web hook requires HTTP basic authentication, provide the username here.' => 
      array (
        0 => 'Если ваш веб-хук требует базовой аутентификации HTTP, укажите имя пользователя здесь.',
      ),
      'Optional: HTTP Basic Authentication Password' => 
      array (
        0 => 'При необходимости: пароль базовой аутентификации HTTP',
      ),
      'If your web hook requires HTTP basic authentication, provide the password here.' => 
      array (
        0 => 'Если ваш веб-хук требует базовой аутентификации HTTP, введите пароль здесь.',
      ),
      'Matomo Installation Base URL' => 
      array (
        0 => 'URL-адрес базовой установки Matomo',
      ),
      'The full base URL of your Matomo installation.' => 
      array (
        0 => 'Полный базовый URL-адрес вашей установки Matomo.',
      ),
      'Matomo Site ID' => 
      array (
        0 => 'ID сайта Matomo',
      ),
      'The numeric site ID for this site.' => 
      array (
        0 => 'Цифровой ID для этого сайта.',
      ),
      'Matomo API Token' => 
      array (
        0 => 'Токен API Matomo',
      ),
      'Optionally supply an API token to allow IP address overriding.' => 
      array (
        0 => 'При необходимости укажите токен API, позволяющий переопределять IP-адрес.',
      ),
      'Discord Web Hook URL' => 
      array (
        0 => 'URL веб-хука Discord',
      ),
      'This URL is provided within the Discord application.' => 
      array (
        0 => 'Этот URL-адрес предоставлен в приложении Discord.',
      ),
      'Main Message Content' => 
      array (
        0 => 'Содержание Основного Сообщения',
      ),
      'Description' => 
      array (
        0 => 'Описание',
      ),
      'URL' => 
      array (
        0 => 'URL-адрес',
      ),
      'Author Name' => 
      array (
        0 => 'Имя автора',
      ),
      'Thumbnail Image URL' => 
      array (
        0 => 'URL изображения эскиза',
      ),
      'Footer Text' => 
      array (
        0 => 'Текст внизу страницы',
      ),
      'Web Hook Name' => 
      array (
        0 => 'Название веб-хука',
      ),
      'Choose a name for this webhook that will help you distinguish it from others. This will only be shown on the administration page.' => 
      array (
        0 => 'Выберите название для этого веб-хука, которое поможет вам отличить его от других. Оно будет показано только на странице администрирования.',
      ),
      'Web Hook Triggers' => 
      array (
        0 => 'Триггеры веб-хука',
      ),
      'This web hook will only run when the selected event(s) occur on this specific station.' => 
      array (
        0 => '',
      ),
      'Message Customization Tips' => 
      array (
        0 => '',
      ),
      'Variables are in the form of:' => 
      array (
        0 => '',
      ),
      'All values in the NowPlaying API response are available for use. Any empty fields are ignored.' => 
      array (
        0 => '',
      ),
      'TuneIn Station ID' => 
      array (
        0 => 'ID станции TuneIn',
      ),
      'The station ID will be a numeric string that starts with the letter S.' => 
      array (
        0 => 'ID станции будет числовой строкой, которая начинается с буквы S.',
      ),
      'TuneIn Partner ID' => 
      array (
        0 => 'ID партнера TuneIn',
      ),
      'TuneIn Partner Key' => 
      array (
        0 => 'Ключ партнера TuneIn',
      ),
      'Markdown' => 
      array (
        0 => '',
      ),
      'HTML' => 
      array (
        0 => '',
      ),
      'Bot Token' => 
      array (
        0 => 'Токен бота',
      ),
      'See the Telegram Documentation for more details.' => 
      array (
        0 => '',
      ),
      'Chat ID' => 
      array (
        0 => 'Чат ID',
      ),
      'Unique identifier for the target chat or username of the target channel (in the format @channelusername).' => 
      array (
        0 => 'Уникальный идентификатор для назначенного чата или имя пользователя назначенного канала (в формате @channelusername).',
      ),
      'Custom API Base URL' => 
      array (
        0 => 'Базовый URL Пользовательского API',
      ),
      'Leave blank to use the default Telegram API URL (recommended).' => 
      array (
        0 => '',
      ),
      'Message parsing mode' => 
      array (
        0 => 'Режим парсинга сообщений',
      ),
      'See the Telegram documentation for more details.' => 
      array (
        0 => '',
      ),
      'GA Property Tracking ID' => 
      array (
        0 => 'ID отслеживания GA',
      ),
      'The property ID used to track live listeners.' => 
      array (
        0 => 'Идентификатор (ID) используемый для отслеживания подключенных слушателей.',
      ),
      'Message Recipient(s)' => 
      array (
        0 => 'Получатель(и) Сообщения',
      ),
      'E-mail addresses can be separated by commas.' => 
      array (
        0 => 'Адреса электронной почты можно разделять запятыми.',
      ),
      'Message Subject' => 
      array (
        0 => 'Тема Сообщения',
      ),
      'Message Body' => 
      array (
        0 => 'Текст сообщения',
      ),
      'Select Web Hook Type' => 
      array (
        0 => '',
      ),
      '%{ seconds } seconds' => 
      array (
        0 => '',
      ),
      '%{ minutes } minutes' => 
      array (
        0 => '',
      ),
      'No Limit' => 
      array (
        0 => 'Без ограничения',
      ),
      'Twitter Account Details' => 
      array (
        0 => 'Детали аккаунта Twitter',
      ),
      'Steps for configuring a Twitter application:' => 
      array (
        0 => '',
      ),
      'Create a new app on the Twitter Applications site. Use this installation\'s base URL as the application URL.' => 
      array (
        0 => '',
      ),
      'Twitter Applications' => 
      array (
        0 => '',
      ),
      'In the newly created application, click the "Keys and Access Tokens" tab.' => 
      array (
        0 => '',
      ),
      'At the bottom of the page, click "Create my access token".' => 
      array (
        0 => '',
      ),
      'Once these steps are completed, enter the information from the "Keys and Access Tokens" page into the fields below.' => 
      array (
        0 => '',
      ),
      'Consumer Key (API Key)' => 
      array (
        0 => 'Ключ клиента (API ключ)',
      ),
      'Consumer Secret (API Secret)' => 
      array (
        0 => 'Секрет клиента (API Секрет)',
      ),
      'Access Token' => 
      array (
        0 => 'Токен Доступа',
      ),
      'Access Token Secret' => 
      array (
        0 => 'Секрет Токена Доступа',
      ),
      'Only Send One Tweet Every...' => 
      array (
        0 => 'Отправлять только один твит каждые...',
      ),
      'Edit Web Hook' => 
      array (
        0 => 'Изменить веб-хук',
      ),
      'Add Web Hook' => 
      array (
        0 => 'Добавить Веб-хук',
      ),
      'Powered by AzuraCast' => 
      array (
        0 => '',
      ),
      'Now playing on %{ station }:' => 
      array (
        0 => '',
      ),
      'Now playing on %{ station }: %{ title } by %{ artist }! Tune in now.' => 
      array (
        0 => '',
      ),
      'Now playing on %{ station }: %{ title } by %{ artist }! Tune in now: %{ url }' => 
      array (
        0 => '',
      ),
      'Disable song requests?' => 
      array (
        0 => 'Отключить запросы на песни?',
      ),
      'Enable song requests?' => 
      array (
        0 => 'Включить запросы на песни?',
      ),
      'Song Requests' => 
      array (
        0 => 'Запросы песен',
      ),
      'View' => 
      array (
        0 => 'Посмотреть',
      ),
      'Streams' => 
      array (
        0 => 'Потоки Вещания',
      ),
      'Local Streams' => 
      array (
        0 => 'Локальные потоки',
      ),
      'Unique' => 
      array (
        0 => 'Уникальных',
      ),
      'Download PLS' => 
      array (
        0 => 'Скачать PLS',
      ),
      'Download M3U' => 
      array (
        0 => 'Скачать M3U',
      ),
      '%{listeners} Listener' => 
      array (
        0 => '%{listeners} Слушатель',
        1 => '%{listeners} Слушателя',
        2 => '%{listeners} Слушателей',
        3 => '%{listeners} Слушателей',
      ),
      'On the Air' => 
      array (
        0 => 'В эфире',
      ),
      'Playing Next' => 
      array (
        0 => 'Следующее Играет',
      ),
      'Live' => 
      array (
        0 => 'Прямая трансляция',
      ),
      'Skip Song' => 
      array (
        0 => 'Пропустить песню',
      ),
      'Disconnect Streamer' => 
      array (
        0 => 'Отключить радиоведущего',
      ),
      'Disable streamers?' => 
      array (
        0 => 'Отключить радиоведущих?',
      ),
      'Enable streamers?' => 
      array (
        0 => 'Включить радиоведущих?',
      ),
      'Streamers/DJs' => 
      array (
        0 => 'Ведущие/Диджеи',
      ),
      'Edit Profile' => 
      array (
        0 => 'Редактировать профиль',
      ),
      'Disable public pages?' => 
      array (
        0 => 'Отключить публичные страницы?',
      ),
      'Enable public pages?' => 
      array (
        0 => 'Включить публичные страницы?',
      ),
      'Public Pages' => 
      array (
        0 => 'Публичные страницы',
      ),
      'Web DJ' => 
      array (
        0 => 'Веб Диджей',
      ),
      'On-Demand Media' => 
      array (
        0 => 'Медиафайлы по Запросу',
      ),
      'Podcasts' => 
      array (
        0 => 'Подкасты',
      ),
      'Embed Widgets' => 
      array (
        0 => 'Встраивание Виджета',
      ),
      'Broadcasting Service' => 
      array (
        0 => 'Сервис Вещания',
      ),
      'Administration URL' => 
      array (
        0 => 'URL Управления',
      ),
      'Administrator Password' => 
      array (
        0 => 'Пароль Администратора',
      ),
      'Source Password' => 
      array (
        0 => 'Пароль Source',
      ),
      'Relay Password' => 
      array (
        0 => 'Пароль Relay',
      ),
      'Restart' => 
      array (
        0 => 'Перезапустить',
      ),
      'Start' => 
      array (
        0 => 'Запустить',
      ),
      'Radio Player' => 
      array (
        0 => 'Радио Плеер',
      ),
      'History' => 
      array (
        0 => 'Играло Ранее',
      ),
      'Requests' => 
      array (
        0 => 'Запросы',
      ),
      'Light' => 
      array (
        0 => 'Светлая',
      ),
      'Dark' => 
      array (
        0 => 'Тёмная',
      ),
      'Widget Type' => 
      array (
        0 => 'Тип Виджета',
      ),
      'Theme' => 
      array (
        0 => 'Тема',
      ),
      'Customize' => 
      array (
        0 => 'Настроить',
      ),
      'Embed Code' => 
      array (
        0 => 'Код вставки',
      ),
      'Preview' => 
      array (
        0 => 'Предпросмотр',
      ),
      'Scheduled' => 
      array (
        0 => 'Запланированное',
      ),
      'Streamer/DJ' => 
      array (
        0 => 'Ведущий/Диджей',
      ),
      'Now' => 
      array (
        0 => 'Сейчас',
      ),
      'AutoDJ Disabled' => 
      array (
        0 => 'АвтоДиджей Отключен',
      ),
      'AutoDJ has been disabled for this station. No music will automatically be played when a source is not live.' => 
      array (
        0 => 'АвтоДиджей отключен для этой станции. Музыка не будет автоматически воспроизводиться, если источник не находится в прямом эфире.',
      ),
      '%{numSongs} uploaded song' => 
      array (
        0 => '%{numSongs} загруженный трек',
        1 => '%{numSongs} загруженных трека',
        2 => '%{numSongs} загруженных треков',
        3 => '%{numSongs} загруженных треков',
      ),
      '%{numPlaylists} playlist' => 
      array (
        0 => '%{numPlaylists} плейлист',
        1 => '%{numPlaylists} плейлиста',
        2 => '%{numPlaylists} плейлистов',
        3 => '%{numPlaylists} плейлистов',
      ),
      'LiquidSoap is currently shuffling from %{songs} and %{playlists}.' => 
      array (
        0 => 'LiquidSoap сейчас перемешивает %{songs} и %{playlists}.',
      ),
      'AutoDJ Service' => 
      array (
        0 => 'Сервис АвтоДиджея',
      ),
      'Running' => 
      array (
        0 => 'Работает',
      ),
      'Not Running' => 
      array (
        0 => 'Остановлено',
      ),
      'Delete Mount Point?' => 
      array (
        0 => 'Удалить точку подключения?',
      ),
      'Mount Points' => 
      array (
        0 => 'Точки Подключения',
      ),
      'Mount points are how listeners connect and listen to your station. Each mount point can be a different audio format or quality. Using mount points, you can set up a high-quality stream for broadband listeners and a mobile stream for phone users.' => 
      array (
        0 => 'Точки подключения - это то, как слушатели подключаются и слушают вашу станцию. Каждая точка подключения может иметь свой аудиоформат или качество. Используя точки подключения, вы можете настроить высококачественный поток для слушателей с широкополосным интернетом и мобильный поток для пользователей телефонов.',
      ),
      'Default Mount' => 
      array (
        0 => 'Подключение по умолчанию',
      ),
      'Genre' => 
      array (
        0 => 'Жанр',
      ),
      'Length' => 
      array (
        0 => 'Длина',
      ),
      'Size' => 
      array (
        0 => 'Размер',
      ),
      'Modified' => 
      array (
        0 => 'Изменено',
      ),
      'Album Art' => 
      array (
        0 => 'Обложка Альбома',
      ),
      'Rename' => 
      array (
        0 => 'Переименовать',
      ),
      'View tracks in playlist' => 
      array (
        0 => 'Просмотр треков в плейлисте',
      ),
      '%{spaceUsed} of %{spaceTotal} Used (%{filesCount} Files)' => 
      array (
        0 => '',
      ),
      '%{spaceUsed} Used (%{filesCount} Files)' => 
      array (
        0 => '',
      ),
      'Music Files' => 
      array (
        0 => 'Музыкальные файлы',
      ),
      'You can also upload files in bulk via SFTP.' => 
      array (
        0 => 'Вы также можете загружать файлы оптом через SFTP.',
      ),
      'Manage SFTP Accounts' => 
      array (
        0 => 'Управление учетными записями SFTP',
      ),
      'Directory' => 
      array (
        0 => 'Папка',
      ),
      'Move %{ num } File(s) to' => 
      array (
        0 => 'Перенести %{ num } файл(ов) в',
      ),
      'Files moved:' => 
      array (
        0 => 'Файлы перемещены:',
      ),
      'Back' => 
      array (
        0 => 'Назад',
      ),
      'Move to Directory' => 
      array (
        0 => 'Перенести в папку',
      ),
      'Home' => 
      array (
        0 => 'Главная',
      ),
      'Basic Information' => 
      array (
        0 => 'Основная информация',
      ),
      'File Name' => 
      array (
        0 => 'Название Файла',
      ),
      'The relative path of the file in the station\'s media directory.' => 
      array (
        0 => 'Относительный путь к файлу в медиакаталоге станции.',
      ),
      'Song Artist' => 
      array (
        0 => 'Исполнитель',
      ),
      'Song Genre' => 
      array (
        0 => 'Жанр Песни',
      ),
      'Song Album' => 
      array (
        0 => 'Альбом песни',
      ),
      'Song Lyrics' => 
      array (
        0 => 'Текст песни',
      ),
      'ISRC' => 
      array (
        0 => 'ISRC',
      ),
      'International Standard Recording Code, used for licensing reports.' => 
      array (
        0 => 'Международный стандартный код записи, используемый для получения лицензионных отчетов.',
      ),
      'Visual Cue Editor' => 
      array (
        0 => 'Визуальный Редактор',
      ),
      'Set cue and fade points using the visual editor. The timestamps will be saved to the corresponding fields in the advanced playback settings.' => 
      array (
        0 => 'Установите метки нарастания и затухания звука с помощью визуального редактора. Метки времени будут сохранены в соответствующих полях в расширенных настройках воспроизведения.',
      ),
      'Set Cue In' => 
      array (
        0 => 'Отметить Начало Трека',
      ),
      'Set Cue Out' => 
      array (
        0 => 'Отметить Конец Трека',
      ),
      'Set Overlap' => 
      array (
        0 => 'Метка Нахлёста',
      ),
      'Set Fade In' => 
      array (
        0 => 'Метка Постепенного Появления',
      ),
      'Set Fade Out' => 
      array (
        0 => 'Метка Постепенного Затухания',
      ),
      'Custom Fields' => 
      array (
        0 => 'Настраиваемые поля',
      ),
      'Delete Album Art' => 
      array (
        0 => 'Удалить обложку альбома',
      ),
      'Replace Album Cover Art' => 
      array (
        0 => 'Заменить обложку альбома',
      ),
      'Song Length' => 
      array (
        0 => 'Длина песни',
      ),
      'Amplify: Amplification (dB)' => 
      array (
        0 => 'Усиление: Звукоусиление (дБ)',
      ),
      'The volume in decibels to amplify the track with. Leave blank to use the system default.' => 
      array (
        0 => 'Громкость в децибелах для усиления трека. Оставьте поле пустым, чтобы использовать настройки по умолчанию.',
      ),
      'Custom Fading: Overlap Time (seconds)' => 
      array (
        0 => 'Настраиваемое Совмещение: Время Нахлёста (в секундах)',
      ),
      'The time that this song should overlap its surrounding songs when fading. Leave blank to use the system default.' => 
      array (
        0 => 'Время, в течении которого песня должна смешиваться с окружающими её песнями когда она заканчивается. Оставьте поле пустым, чтобы использовать настройки системы по умолчанию.',
      ),
      'Custom Fading: Fade-In Time (seconds)' => 
      array (
        0 => 'Настраиваемое появление: время нарастания (в секундах)',
      ),
      'The time period that the song should fade in. Leave blank to use the system default.' => 
      array (
        0 => 'Период времени, в течение которого песня должна постепенно появиться. Оставьте поле пустым, чтобы использовать настройки системы по умолчанию.',
      ),
      'Custom Fading: Fade-Out Time (seconds)' => 
      array (
        0 => 'Настраиваемое завершение: время затухания (в секундах)',
      ),
      'The time period that the song should fade out. Leave blank to use the system default.' => 
      array (
        0 => 'Период времени, в течение которого песня должна постепенно исчезнуть. Оставьте поле пустым, чтобы использовать настройки системы по умолчанию.',
      ),
      'Custom Cues: Cue-In Point (seconds)' => 
      array (
        0 => 'Пользовательская Метка: Отметить Начало Песни (в секундах)',
      ),
      'Seconds from the start of the song that the AutoDJ should start playing.' => 
      array (
        0 => 'Секунды с начала песни, с которой АвтоДиджей должен начать воспроизведение.',
      ),
      'Custom Cues: Cue-Out Point (seconds)' => 
      array (
        0 => 'Пользовательская Метка: Отметить Конец Песни (в секундах)',
      ),
      'Seconds from the start of the song that the AutoDJ should stop playing.' => 
      array (
        0 => 'Через сколько секунд с начала песни АвтоДиджей должен прекратить воспроизведение.',
      ),
      'Rename File/Directory' => 
      array (
        0 => 'Переименовать Файл/Папку',
      ),
      'New File Name' => 
      array (
        0 => 'Новое название файла',
      ),
      'Set or clear playlists from the selected media' => 
      array (
        0 => 'Выбрать или очистить плейлисты для выбранных файлов',
      ),
      'New Playlist' => 
      array (
        0 => 'Новый Плейлист',
      ),
      'Queue the selected media to play next' => 
      array (
        0 => 'Запланировать выбранные файлы для проигрывания следующими',
      ),
      'Analyze and reprocess the selected media' => 
      array (
        0 => 'Анализ и повторная обработка выбранных медиафайлов',
      ),
      'The request could not be processed.' => 
      array (
        0 => 'Запрос не может быть обработан.',
      ),
      'Files queued for playback:' => 
      array (
        0 => 'Очередь файлов на воспроизведение:',
      ),
      'Files marked for reprocessing:' => 
      array (
        0 => 'Файлы, отмеченные для повторной обработки:',
      ),
      'Delete %{ num } media files?' => 
      array (
        0 => 'Удалить %{ num } медиафайл(ов)?',
      ),
      'Files removed:' => 
      array (
        0 => 'Файлы удалены:',
      ),
      'Playlists updated for selected files:' => 
      array (
        0 => 'Плейлисты обновлены выбранными файлами:',
      ),
      'Playlists cleared for selected files:' => 
      array (
        0 => 'Плейлисты очищены от выбранных файлов:',
      ),
      'No files selected.' => 
      array (
        0 => 'Файлы не выбраны.',
      ),
      'Save' => 
      array (
        0 => 'Сохранить',
      ),
      'Move' => 
      array (
        0 => 'Переместить',
      ),
      'Queue' => 
      array (
        0 => 'В Очередь',
      ),
      'Reprocess' => 
      array (
        0 => 'Повторная обработка',
      ),
      'New Folder' => 
      array (
        0 => 'Новая папка',
      ),
      'Edit Media' => 
      array (
        0 => 'Редактирование Медиафайла',
      ),
      'New Directory' => 
      array (
        0 => 'Новая Папка',
      ),
      'New directory created.' => 
      array (
        0 => 'Новая папка создана.',
      ),
      'Directory Name' => 
      array (
        0 => 'Название папки',
      ),
      'Create Directory' => 
      array (
        0 => 'Создать папку',
      ),
      'Artwork' => 
      array (
        0 => 'Обложка',
      ),
      'Select PNG/JPG artwork file' => 
      array (
        0 => 'Выберите PNG/JPG файл обложки',
      ),
      'Artwork must be a minimum size of 1400 x 1400 pixels and a maximum size of 3000 x 3000 pixels for Apple Podcasts.' => 
      array (
        0 => 'Изображение должно иметь минимальный размер 1400 x 1400 пикселей и максимальный размер 3000 x 3000 пикселей для подкастов Apple.',
      ),
      'Clear Artwork' => 
      array (
        0 => 'Удалить Обложку',
      ),
      'Edit Episode' => 
      array (
        0 => 'Редактировать эпизод',
      ),
      'Add Episode' => 
      array (
        0 => 'Добавить эпизод',
      ),
      'Edit Podcast' => 
      array (
        0 => 'Редактировать подкаст',
      ),
      'Add Podcast' => 
      array (
        0 => 'Добавить подкаст',
      ),
      'Podcast Title' => 
      array (
        0 => 'Название подкаста',
      ),
      'Website' => 
      array (
        0 => 'Веб-сайт',
      ),
      'Typically the home page of a podcast.' => 
      array (
        0 => 'Обычно это домашняя страница подкаста.',
      ),
      'The description of your podcast. The typical maximum amount of text allowed for this is 4000 characters.' => 
      array (
        0 => 'Описание вашего подкаста. Максимально допустимое количество текста составляет 4000 символов.',
      ),
      'Language' => 
      array (
        0 => 'Язык',
      ),
      'The language spoken on the podcast.' => 
      array (
        0 => 'Язык, на котором говорят в подкасте.',
      ),
      'Author' => 
      array (
        0 => 'Автор',
      ),
      'The contact person of the podcast. May be required in order to list the podcast on services like Apple Podcasts, Spotify, Google Podcasts, etc.' => 
      array (
        0 => 'Контактное лицо подкаста. Может потребоваться для размещения подкастов в таких сервисах, как Apple Podcasts, Spotify, Google Podcasts и т. д.',
      ),
      'E-Mail' => 
      array (
        0 => 'E-Mail',
      ),
      'The email of the podcast contact. May be required in order to list the podcast on services like Apple Podcasts, Spotify, Google Podcasts, etc.' => 
      array (
        0 => 'Электронная почта контакта подкаста. Может потребоваться для размещения подкастов в таких сервисах, как Apple Podcasts, Spotify, Google Podcasts и т. д.',
      ),
      'Categories' => 
      array (
        0 => 'Категории',
      ),
      'Select the category/categories that best reflects the content of your podcast.' => 
      array (
        0 => 'Выберите категорию/категории, которые наилучшим образом отражают содержание вашего подкаста.',
      ),
      'Art' => 
      array (
        0 => 'Обложка',
      ),
      'Podcast' => 
      array (
        0 => 'Подкаст',
      ),
      '# Episodes' => 
      array (
        0 => '# Эпизоды',
      ),
      'All Podcasts' => 
      array (
        0 => 'Все подкасты',
      ),
      'Delete Podcast?' => 
      array (
        0 => '',
      ),
      'RSS Feed' => 
      array (
        0 => 'RSS-канал',
      ),
      'Episodes' => 
      array (
        0 => 'Эпизоды',
      ),
      'Episode' => 
      array (
        0 => 'Эпизод',
      ),
      'File' => 
      array (
        0 => 'Файл',
      ),
      'Explicit' => 
      array (
        0 => 'Откровенный',
      ),
      'Delete Episode?' => 
      array (
        0 => '',
      ),
      'Typically a website with content about the episode.' => 
      array (
        0 => 'Обычно это веб-сайт с материалами об эпизоде.',
      ),
      'The description of the episode. The typical maximum amount of text allowed for this is 4000 characters.' => 
      array (
        0 => 'Описание эпизода. Максимальное допустимое количество текста составляет 4000 символов.',
      ),
      'Publish Date' => 
      array (
        0 => 'Дата публикации',
      ),
      'The date when the episode should be published.' => 
      array (
        0 => 'Дата, когда эпизод должен быть опубликован.',
      ),
      'Publish Time' => 
      array (
        0 => 'Время публикации',
      ),
      'The time when the episode should be published (according to the stations timezone).' => 
      array (
        0 => 'Время, когда эпизод должен быть опубликован (в соответствии с часовым поясом станций).',
      ),
      'Contains explicit content' => 
      array (
        0 => 'Содержит откровенный контент',
      ),
      'Indicates the presence of explicit content (explicit language or adult content). Apple Podcasts displays an Explicit parental advisory graphic for your episode if turned on. Episodes containing explicit material aren’t available in some Apple Podcasts territories.' => 
      array (
        0 => 'Указывает на наличие откровенного содержания (ненормативная лексика или содержание только для взрослых). Apple Podcasts отображает графику с явными советами для родителей для вашего эпизода, если он включен. Эпизоды, содержащие откровенный материал, недоступны на некоторых территориях Apple Podcasts.',
      ),
      'Media' => 
      array (
        0 => 'Медиа',
      ),
      'Select Media File' => 
      array (
        0 => 'Выбрать медиа файл',
      ),
      'Podcast media should be in the MP3 or M4A (AAC) format for the greatest compatibility.' => 
      array (
        0 => 'Носители подкастов должны быть в формате MP3 или M4A (AAC) для максимальной совместимости.',
      ),
      'Current Podcast Media' => 
      array (
        0 => 'Текущий медиа-подкаст',
      ),
      'Clear Media' => 
      array (
        0 => '',
      ),
      'There is no existing media associated with this episode.' => 
      array (
        0 => 'С этим эпизодом не связаны никакие медиа.',
      ),
      'Notes' => 
      array (
        0 => 'Заметки',
      ),
      'Account List' => 
      array (
        0 => 'Список Аккаунтов',
      ),
      'Delete Streamer?' => 
      array (
        0 => '',
      ),
      'Streamer/DJ Accounts' => 
      array (
        0 => 'Аккаунты Ведущих/Диджеев',
      ),
      'Add Streamer' => 
      array (
        0 => 'Добавить радиоведущего',
      ),
      'Broadcasts' => 
      array (
        0 => 'Вещание',
      ),
      'Icecast Clients' => 
      array (
        0 => '',
      ),
      'You may need to connect directly via your IP address:' => 
      array (
        0 => '',
      ),
      'Mount Name:' => 
      array (
        0 => '',
      ),
      'SHOUTcast Clients' => 
      array (
        0 => '',
      ),
      'For some clients, use port:' => 
      array (
        0 => '',
      ),
      'Password:' => 
      array (
        0 => '',
      ),
      'or' => 
      array (
        0 => 'или',
      ),
      'Setup instructions for broadcasting software are available on the AzuraCast wiki.' => 
      array (
        0 => '',
      ),
      'AzuraCast Wiki' => 
      array (
        0 => '',
      ),
      'Streamer Username' => 
      array (
        0 => 'Логин Радиоведущего',
      ),
      'The streamer will use this username to connect to the radio server.' => 
      array (
        0 => 'Радиоведущий будет использовать этот логин для подключения к радиосерверу.',
      ),
      'Streamer password' => 
      array (
        0 => 'Пароль радиоведущего',
      ),
      'The streamer will use this password to connect to the radio server.' => 
      array (
        0 => 'Радиоведущий будет использовать этот пароль для подключения к радиосерверу.',
      ),
      'Streamer Display Name' => 
      array (
        0 => 'Отображаемое имя радиоведущего',
      ),
      'This is the informal display name that will be shown in API responses if the streamer/DJ is live.' => 
      array (
        0 => 'Это неофициальное отображаемое имя, которое будет отображаться в ответах API, если Ведущий/Диджей находится в прямом эфире.',
      ),
      'Comments' => 
      array (
        0 => 'Комментарии',
      ),
      'Internal notes or comments about the user, visible only on this control panel.' => 
      array (
        0 => 'Внутренние заметки или комментарии о пользователе, видимые только на этой панели управления.',
      ),
      'Account is Active' => 
      array (
        0 => 'Аккаунт активен',
      ),
      'Enable to allow this account to log in and stream.' => 
      array (
        0 => 'Включите, чтобы разрешить этому аккаунту входить в систему и осуществлять трансляцию.',
      ),
      'Enforce Schedule Times' => 
      array (
        0 => 'Принудительно запланированное время',
      ),
      'If enabled, this streamer will only be able to connect during their scheduled broadcast times.' => 
      array (
        0 => 'Если включено, этот радиоведущий сможет подключаться только во время запланированного вещания.',
      ),
      'This streamer is not scheduled to play at any times.' => 
      array (
        0 => 'У этого радиоведущего не планируется трансляция в любое время.',
      ),
      'If the end time is before the start time, the schedule entry will continue overnight.' => 
      array (
        0 => 'Если время окончания раньше времени начала, запись по расписанию будет продолжаться в том числе и ночью.',
      ),
      'Streamer Broadcasts' => 
      array (
        0 => 'Вещание Радиоведущего',
      ),
      'Play/Pause' => 
      array (
        0 => 'Пуск/Пауза',
      ),
      'Delete Broadcast?' => 
      array (
        0 => '',
      ),
      'Edit Streamer' => 
      array (
        0 => 'Редактировать Радиоведущего',
      ),
      'Hour' => 
      array (
        0 => 'Час',
      ),
      'IP' => 
      array (
        0 => 'IP адрес',
      ),
      'Time' => 
      array (
        0 => 'Время',
      ),
      'Time (sec)' => 
      array (
        0 => 'Время (в секундах)',
      ),
      'User Agent' => 
      array (
        0 => 'Идентификатор пользователя',
      ),
      'Stream' => 
      array (
        0 => 'Поток',
      ),
      'Location' => 
      array (
        0 => 'Местоположение',
      ),
      'Live Listeners' => 
      array (
        0 => 'Живые слушатели',
      ),
      'Download CSV' => 
      array (
        0 => 'Скачать CSV',
      ),
      'for selected period' => 
      array (
        0 => 'за выбранный период',
      ),
      'Total Listener Hours' => 
      array (
        0 => 'Всего Часов Прослушивания',
      ),
      'Mobile Device' => 
      array (
        0 => 'Мобильное устройство',
      ),
      'Desktop Device' => 
      array (
        0 => 'Устройство рабочего стола',
      ),
      'Unknown' => 
      array (
        0 => 'Неизвестно',
      ),
      'Local' => 
      array (
        0 => 'Локально',
      ),
      'Remote' => 
      array (
        0 => 'Отдалённо',
      ),
      'Filename' => 
      array (
        0 => 'Название файла',
      ),
      'Length Text' => 
      array (
        0 => 'Длина текста',
      ),
      'Playlist(s)' => 
      array (
        0 => 'Плейлист(ы)',
      ),
      'Joins' => 
      array (
        0 => 'Подключено',
      ),
      'Losses' => 
      array (
        0 => 'Потеряно',
      ),
      'Total' => 
      array (
        0 => 'Всего',
      ),
      'Num Plays' => 
      array (
        0 => '',
      ),
      'Play %' => 
      array (
        0 => 'Играет %',
      ),
      'Ratio' => 
      array (
        0 => 'Коэффициент',
      ),
      'Song Listener Impact' => 
      array (
        0 => 'Влияние песни на слушателя',
      ),
      'Date Requested' => 
      array (
        0 => 'Дата запроса',
      ),
      'Date Played' => 
      array (
        0 => 'Дата проигрывания',
      ),
      'Requester IP' => 
      array (
        0 => 'IP заказавшего',
      ),
      'Delete Request?' => 
      array (
        0 => '',
      ),
      'Clear All Pending Requests?' => 
      array (
        0 => '',
      ),
      'Clear Pending Requests' => 
      array (
        0 => 'Очистить ожидающие запросы',
      ),
      'Not Played' => 
      array (
        0 => 'Не сыграно',
      ),
      'Listeners by Day' => 
      array (
        0 => 'Слушателей по дням',
      ),
      'Listeners by Day of Week' => 
      array (
        0 => 'Слушателей по дням недели',
      ),
      'Listeners by Hour' => 
      array (
        0 => 'Слушателей по часам',
      ),
      'Best Performing Songs' => 
      array (
        0 => 'Лучшие Проигранные Песни',
      ),
      'in the last 48 hours' => 
      array (
        0 => 'за последние 48 часов',
      ),
      'Change' => 
      array (
        0 => 'Изменение',
      ),
      'Song' => 
      array (
        0 => 'Композиция',
      ),
      'Worst Performing Songs' => 
      array (
        0 => 'Худшие Проигранные Песни',
      ),
      'Most Played Songs' => 
      array (
        0 => 'Самые Популярные Песни',
      ),
      'in the last month' => 
      array (
        0 => 'за последний месяц',
      ),
      'Plays' => 
      array (
        0 => 'Играло',
      ),
      'Date/Time' => 
      array (
        0 => 'Дата/Время',
      ),
      'Song Playback Timeline' => 
      array (
        0 => 'Хронология проигрывания песен',
      ),
      'Live Streamer:' => 
      array (
        0 => 'Cтример Онлайн:',
      ),
      'Name/Type' => 
      array (
        0 => '',
      ),
      'Triggers' => 
      array (
        0 => 'Триггеры',
      ),
      'Delete Web Hook?' => 
      array (
        0 => '',
      ),
      'Web Hooks' => 
      array (
        0 => 'Веб-хуки',
      ),
      'Web hooks let you connect to external web services and broadcast changes to your station to them.' => 
      array (
        0 => 'Веб-хуки позволяют вам подключиться к внешним веб-сервисам и транслировать изменения на вашу станцию.',
      ),
      'Test' => 
      array (
        0 => 'Проверить',
      ),
      'Song History' => 
      array (
        0 => 'Играло ранее',
      ),
      'Request Song' => 
      array (
        0 => 'Запрос Песни',
      ),
      'Request a Song' => 
      array (
        0 => 'Запросить Песню',
      ),
      'Microphone' => 
      array (
        0 => 'Микрофон',
      ),
      'Cue' => 
      array (
        0 => 'Реплика',
      ),
      'Microphone Source' => 
      array (
        0 => 'Источник Микрофона',
      ),
      'Stop Streaming' => 
      array (
        0 => 'Остановить Вещание',
      ),
      'Start Streaming' => 
      array (
        0 => 'Начать Вещание',
      ),
      'Metadata updated!' => 
      array (
        0 => '',
      ),
      'Settings' => 
      array (
        0 => 'Настройки',
      ),
      'Metadata' => 
      array (
        0 => 'Метаданные',
      ),
      'Encoder' => 
      array (
        0 => 'Кодировщик',
      ),
      'MP3' => 
      array (
        0 => 'MP3',
      ),
      'Raw' => 
      array (
        0 => 'Исходное',
      ),
      'Sample Rate' => 
      array (
        0 => 'Частота Дискретизации',
      ),
      'Bit Rate' => 
      array (
        0 => 'Битрейт',
      ),
      'DJ Credentials' => 
      array (
        0 => 'Учётные Данные Диджея',
      ),
      'Use Asynchronous Worker' => 
      array (
        0 => 'Использовать Асинхронную Работу',
      ),
      'Update Metadata' => 
      array (
        0 => 'Обновить Метаданные',
      ),
      'Mixer' => 
      array (
        0 => 'Микшер',
      ),
      'Playlist 1' => 
      array (
        0 => 'Плейлист 1',
      ),
      'Playlist 2' => 
      array (
        0 => 'Плейлист 2',
      ),
      'Unknown Title' => 
      array (
        0 => 'Неизвестное название',
      ),
      'Unknown Artist' => 
      array (
        0 => 'Неизвестный Исполнитель',
      ),
      'Add Files to Playlist' => 
      array (
        0 => 'Добавить в плейлист',
      ),
      'Continuous Play' => 
      array (
        0 => 'Непрерывное Воспроизведение',
      ),
      'Repeat Playlist' => 
      array (
        0 => 'Повторять плейлист',
      ),
      'Request' => 
      array (
        0 => 'Запрос',
      ),
      'This field is required.' => 
      array (
        0 => 'Это поле обязательно к заполнению.',
      ),
      'This field must have at least %{ min } letters.' => 
      array (
        0 => 'В этом поле должно быть не менее %{ min } букв.',
      ),
      'This field must have at most %{ max } letters.' => 
      array (
        0 => 'В этом поле должно быть не больше %{ max } букв.',
      ),
      'This field must be between %{ min } and %{ max }.' => 
      array (
        0 => 'В этом поле должно быть между %{ min } и %{ max }.',
      ),
      'This field must only contain alphabetic characters.' => 
      array (
        0 => 'Это поле должно содержать только алфавитные символы.',
      ),
      'This field must only contain alphanumeric characters.' => 
      array (
        0 => 'Это поле должно содержать только буквенно-цифровые символы.',
      ),
      'This field must only contain numeric characters.' => 
      array (
        0 => 'Это поле должно содержать только числовые символы.',
      ),
      'This field must be a valid integer.' => 
      array (
        0 => 'В этом поле должно быть цельное число.',
      ),
      'This field must be a valid decimal number.' => 
      array (
        0 => 'В этом поле должно быть допустимое десятичное число.',
      ),
      'This field must be a valid e-mail address.' => 
      array (
        0 => 'В этом поле должен быть действительный адрес электронной почты.',
      ),
      'This field must be a valid IP address.' => 
      array (
        0 => 'В этом поле должен быть действительный IP-адрес.',
      ),
      'This field must be a valid URL.' => 
      array (
        0 => 'В этом поле должен быть действующий URL-адрес.',
      ),
      'This password is too common or insecure.' => 
      array (
        0 => '',
      ),
      'Global Permissions' => 
      array (
        0 => '',
      ),
      'Role Name' => 
      array (
        0 => 'Имя роли',
      ),
      'Users with this role will have these permissions across the entire installation.' => 
      array (
        0 => '',
      ),
      'Station Permissions' => 
      array (
        0 => '',
      ),
      'Users with this role will have these permissions for this single station.' => 
      array (
        0 => '',
      ),
      'Add Station' => 
      array (
        0 => 'Добавить станцию',
      ),
      'Edit Role' => 
      array (
        0 => '',
      ),
      'Add Role' => 
      array (
        0 => '',
      ),
      'User' => 
      array (
        0 => 'Пользователь',
      ),
      'Operation' => 
      array (
        0 => '',
      ),
      'Identifier' => 
      array (
        0 => 'Обозначение',
      ),
      'Target' => 
      array (
        0 => 'Цель',
      ),
      'Insert' => 
      array (
        0 => 'Вставить',
      ),
      'Update' => 
      array (
        0 => 'Обновить',
      ),
      'Audit Log' => 
      array (
        0 => 'Журнал Изменений',
      ),
      'N/A' => 
      array (
        0 => '',
      ),
      'Changes' => 
      array (
        0 => 'Изменения',
      ),
      'Field' => 
      array (
        0 => 'Поле',
      ),
      'Previous' => 
      array (
        0 => 'Было',
      ),
      'Updated' => 
      array (
        0 => 'Стало',
      ),
      'Broadcasting' => 
      array (
        0 => 'Вещание',
      ),
      'Only connect to a remote server.' => 
      array (
        0 => '',
      ),
      'Use Icecast 2.4 on this server.' => 
      array (
        0 => '',
      ),
      'Use SHOUTcast DNAS 2 on this server.' => 
      array (
        0 => '',
      ),
      'This software delivers your broadcast to the listening audience.' => 
      array (
        0 => 'Это программное обеспечение доставляет вашу трансляцию для слушателей.',
      ),
      'SHOUTcast License ID' => 
      array (
        0 => '',
      ),
      'SHOUTcast User ID' => 
      array (
        0 => '',
      ),
      'Customize Source Password' => 
      array (
        0 => 'Настроить Source Пароль',
      ),
      'Leave blank to automatically generate a new password.' => 
      array (
        0 => 'Оставьте поле пустым, чтобы автоматически генерировать новый пароль.',
      ),
      'Customize Administrator Password' => 
      array (
        0 => 'Настроить Пароль Администратора',
      ),
      'Customize Broadcasting Port' => 
      array (
        0 => 'Настроить порт вещания',
      ),
      'No other program can be using this port. Leave blank to automatically assign a port.' => 
      array (
        0 => 'Никакая другая программа не может использовать этот порт. Оставьте поле пустым, чтобы автоматически назначить порт.',
      ),
      'Maximum Listeners' => 
      array (
        0 => 'Максимальное количество слушателей',
      ),
      'Maximum number of total listeners across all streams. Leave blank to use the default.' => 
      array (
        0 => '',
      ),
      'Banned IP Addresses' => 
      array (
        0 => 'Заблокированные IP адреса',
      ),
      'List one IP address or group (in CIDR format) per line.' => 
      array (
        0 => 'Укажите один IP-адрес или группу (в формате CIDR) на строку.',
      ),
      'Allowed IP Addresses' => 
      array (
        0 => 'Разрешенные IP-адреса',
      ),
      'Banned Countries' => 
      array (
        0 => 'Заблокированные Страны',
      ),
      'Select the countries that are not allowed to connect to the streams.' => 
      array (
        0 => 'Выберите страны, которым запрещено подключаться к потокам.',
      ),
      'Clear List' => 
      array (
        0 => '',
      ),
      'Custom Configuration' => 
      array (
        0 => 'Пользовательская настройка',
      ),
      'This code will be included in the frontend configuration. Allowed formats are:' => 
      array (
        0 => '',
      ),
      'Station Profile' => 
      array (
        0 => 'Профиль станции',
      ),
      'Web Site URL' => 
      array (
        0 => 'URL веб-сайта',
      ),
      'Note: This should be the public-facing homepage of the radio station, not the AzuraCast URL. It will be included in broadcast details.' => 
      array (
        0 => 'Примечание. Это должна быть общедоступная домашняя страница радиостанции, а не URL-адрес AzuraCast. Она будет включена в подробности вещания.',
      ),
      'Time Zone' => 
      array (
        0 => 'Часовой пояс',
      ),
      'Scheduled playlists and other timed items will be controlled by this time zone.' => 
      array (
        0 => 'Запланированные плейлисты и другие синхронизированные элементы будут контролироваться этим часовым поясом.',
      ),
      'Default Album Art URL' => 
      array (
        0 => 'URL обложки альбома по умолчанию',
      ),
      'If a song has no album art, this URL will be listed instead. Leave blank to use the standard placeholder art.' => 
      array (
        0 => 'Если у песни нет обложки альбома, то будет показано изображение поэтому URL-адресу. Оставьте пустым, чтобы использовать стандартное заменяющее изображение.',
      ),
      'URL Stub' => 
      array (
        0 => 'Заглушка URL-адреса',
      ),
      'Optionally specify a short URL-friendly name, such as "my_station_name", that will be used in this station\'s URLs. Leave this field blank to automatically create one based on the station name.' => 
      array (
        0 => '',
      ),
      'Number of Visible Recent Songs' => 
      array (
        0 => '',
      ),
      'Customize the number of songs that will appear in the "Song History" section for this station and in all public APIs.' => 
      array (
        0 => 'Настройте количество песен, которые будут отображаться в разделе «История песен» для этой станции и во всех общедоступных API.',
      ),
      'Enable Public Pages' => 
      array (
        0 => '',
      ),
      'Show the station in public pages and general API results.' => 
      array (
        0 => 'Показывать станцию на публичных страницах и общих результатах API.',
      ),
      'On-Demand Streaming' => 
      array (
        0 => '',
      ),
      'Enable On-Demand Streaming' => 
      array (
        0 => 'Включить трансляцию по требованию',
      ),
      'If enabled, music from playlists with on-demand streaming enabled will be available to stream via a specialized public page.' => 
      array (
        0 => '',
      ),
      'Enable Downloads on On-Demand Page' => 
      array (
        0 => 'Включить загрузки на странице по требованию',
      ),
      'If enabled, a download button will also be present on the public "On-Demand" page.' => 
      array (
        0 => '',
      ),
      'Use Liquidsoap on this server.' => 
      array (
        0 => '',
      ),
      'Do not use an AutoDJ service.' => 
      array (
        0 => '',
      ),
      'Smart Mode' => 
      array (
        0 => 'Умный Режим',
      ),
      'Normal Mode' => 
      array (
        0 => 'Обычный Режим',
      ),
      'Disable Crossfading' => 
      array (
        0 => 'Отключить Кроссфейдинг',
      ),
      'This software shuffles from playlists of music constantly and plays when no other radio source is available.' => 
      array (
        0 => 'Это программное обеспечение постоянно проигрывает и перетасовывает музыку из плейлистов, когда другой источник радио недоступен.',
      ),
      'Crossfade Method' => 
      array (
        0 => 'Режим кроссфейда',
      ),
      'Choose a method to use when transitioning from one song to another. Smart Mode considers the volume of the two tracks when fading for a smoother effect, but requires more CPU resources.' => 
      array (
        0 => 'Выберите метод, который будет использоваться при переходе от одной песни к другой. Умный режим учитывает громкость двух дорожек при нахлёсте, для более плавного эффекта, но требует больше ресурсов процессора.',
      ),
      'Crossfade Duration (Seconds)' => 
      array (
        0 => 'Продолжительность кроссфейда (секунды)',
      ),
      'Number of seconds to overlap songs.' => 
      array (
        0 => 'Продолжительность нахлёста песен в секундах.',
      ),
      'Apply Compression and Normalization' => 
      array (
        0 => 'Применить Сжатие и Нормализацию',
      ),
      'Compress and normalize your station\'s audio, producing a more uniform and "full" sound.' => 
      array (
        0 => 'Сжимайте и нормализуйте звук вашей станции, создавая более равномерный и "полный" звук.',
      ),
      'Some stream licensing providers may have specific rules regarding song requests. Check your local regulations for more information.' => 
      array (
        0 => '',
      ),
      'Allow Song Requests' => 
      array (
        0 => 'Разрешить заказ песен',
      ),
      'Enable listeners to request a song for play on your station. Only songs that are already in your playlists are requestable.' => 
      array (
        0 => 'Включение этого параметра позволяет слушателям заказать песню для воспроизведения на вашей станции. Запрошены могут быть только те песни, которые находятся в ваших плейлистах.',
      ),
      'Request Minimum Delay (Minutes)' => 
      array (
        0 => 'Запрос минимальной задержки (минут)',
      ),
      'If requests are enabled, this specifies the minimum delay (in minutes) between a request being submitted and being played. If set to zero, a minor delay of 15 seconds is applied to prevent request floods.' => 
      array (
        0 => '',
      ),
      'Request Last Played Threshold (Minutes)' => 
      array (
        0 => 'Запрос последнего игрового порога (минуты)',
      ),
      'This specifies the minimum time (in minutes) between a song playing on the radio and being available to request again. Set to 0 for no threshold.' => 
      array (
        0 => '',
      ),
      'Streamers / DJs' => 
      array (
        0 => '',
      ),
      'Allow Streamers / DJs' => 
      array (
        0 => 'Разрешить стримеры / ди-джеи',
      ),
      'If enabled, streamers (or DJs) will be able to connect directly to your stream and broadcast live music that interrupts the AutoDJ stream.' => 
      array (
        0 => 'Если включено, стримеры (или диджеи) смогут напрямую подключаться к вашему потоку и транслировать живую музыку, которая прерывает поток АвтоДиджея.',
      ),
      'Record Live Broadcasts' => 
      array (
        0 => 'Запись Прямых Трансляций',
      ),
      'If enabled, AzuraCast will automatically record any live broadcasts made to this station to per-broadcast recordings.' => 
      array (
        0 => 'Если эта функция включена, AzuraCast будет автоматически записывать все трансляции прямого эфира на эту станцию.',
      ),
      'Live Broadcast Recording Format' => 
      array (
        0 => 'Формат Записи Прямого Эфира',
      ),
      'Live Broadcast Recording Bitrate (kbps)' => 
      array (
        0 => 'Битрейт записи прямого эфира (кбит/с)',
      ),
      'Deactivate Streamer on Disconnect (Seconds)' => 
      array (
        0 => 'Отключение стримера при разъединении (в секундах)',
      ),
      'This is the number of seconds until a streamer who has been manually disconnected can reconnect to the stream. Set to 0 to allow the streamer to immediately reconnect.' => 
      array (
        0 => '',
      ),
      'Customize DJ/Streamer Port' => 
      array (
        0 => 'Настроить порт Диджей/Стример',
      ),
      'Note: the port after this one will automatically be used for legacy connections.' => 
      array (
        0 => '',
      ),
      'DJ/Streamer Buffer Time (Seconds)' => 
      array (
        0 => 'Время буфера Диджей/Стример (в секундах)',
      ),
      'The number of seconds of signal to store in case of interruption. Set to the lowest value that your DJs can use without stream interruptions.' => 
      array (
        0 => 'Количество секунд сохраняемого сигнала в случае прерывания. Установите минимальное значение, которое ваши Диджеи могут использовать без прерывания потока.',
      ),
      'Customize DJ/Streamer Mount Point' => 
      array (
        0 => 'Настройка Точки Подключения Диджеев/Стримеров',
      ),
      'If your streaming software requires a specific mount point path, specify it here. Otherwise, use the default.' => 
      array (
        0 => 'Если программное обеспечение для вещания потока требует определенного пути точки подключения, укажите его здесь. В противном случае, используйте по умолчанию.',
      ),
      'Advanced Configuration' => 
      array (
        0 => 'Расширенная настройка',
      ),
      'Customize Internal Request Processing Port' => 
      array (
        0 => 'Настройка Внутреннего Порта Обработки Запросов',
      ),
      'This port is not used by any external process. Only modify this port if the assigned port is in use. Leave blank to automatically assign a port.' => 
      array (
        0 => 'Этот порт не используется никаким внешним процессом. Изменяйте этот порт, только если назначенный порт используется. Оставьте пустым, чтобы автоматически назначить порт.',
      ),
      'Use Replaygain Metadata' => 
      array (
        0 => 'Использование метаданных Replaygain',
      ),
      'Instruct Liquidsoap to use any replaygain metadata associated with a song to control its volume level.' => 
      array (
        0 => 'Инструкция для Liquidsoap о использовании любых метаданных replaygain, связанных с песней, для управления уровнем громкости.',
      ),
      'AutoDJ Queue Length' => 
      array (
        0 => 'Длина очереди АвтоДиджея',
      ),
      'This determines how many songs in advance the AutoDJ will automatically fill the queue.' => 
      array (
        0 => '',
      ),
      'Manual AutoDJ Mode' => 
      array (
        0 => 'Ручной Режим АвтоДиджея',
      ),
      'This mode disables AzuraCast\'s AutoDJ management, using Liquidsoap itself to manage song playback. "Next Song" and some other features will not be available.' => 
      array (
        0 => 'Этот режим отключает АвтоДиджея AzuraCast, использующем в управлении Liquidsoap, который управляет воспроизведением песен. "Следующая песня" и некоторые другие функции не будут доступны.',
      ),
      'Character Set Encoding' => 
      array (
        0 => 'Кодировка набора символов',
      ),
      'For most cases, use the default UTF-8 encoding. The older ISO-8859-1 encoding can be used if accepting connections from SHOUTcast 1 DJs or using other legacy software.' => 
      array (
        0 => 'Для большинства случаев используйте кодировку UTF-8 по умолчанию. При приеме соединений из SHOUTcast 1 DJs или с другими устаревшими программами можно использовать старую кодировку ISO-8859-1.',
      ),
      'Duplicate Prevention Time Range (Minutes)' => 
      array (
        0 => 'Диапазон времени предотвращения дублирования (в минутах)',
      ),
      'This specifies the time range (in minutes) of the song history that the duplicate song prevention algorithm should take into account.' => 
      array (
        0 => 'Определяет временной диапазон истории песен (в минутах), который должен учитывать алгоритм предотвращения дублирования песен.',
      ),
      'Enable Broadcasting' => 
      array (
        0 => 'Включить трансляцию',
      ),
      'If disabled, the station will not broadcast or shuffle its AutoDJ.' => 
      array (
        0 => 'Если отключено, станция не будет транслировать или перетасовывать свой АвтоДиджей.',
      ),
      'Base Station Directory' => 
      array (
        0 => 'Базовая папка станции',
      ),
      'The parent directory where station playlist and configuration files are stored. Leave blank to use default directory.' => 
      array (
        0 => 'Родительская папка, где хранятся плейлисты и конфигурационные файлы. Оставьте пустым, чтобы использовать папку по умолчанию.',
      ),
      'Media Storage Location' => 
      array (
        0 => 'Место хранения медиафайлов',
      ),
      'Live Recordings Storage Location' => 
      array (
        0 => 'Место хранения Live записей',
      ),
      'Podcasts Storage Location' => 
      array (
        0 => 'Место Хранения Подкастов',
      ),
      'Clone Station' => 
      array (
        0 => '',
      ),
      '%{station} - Copy' => 
      array (
        0 => '',
      ),
      'Edit Station' => 
      array (
        0 => 'Редактировать Станцию',
      ),
      'Share Media Storage Location' => 
      array (
        0 => 'Поделиться местоположением медиафайлов',
      ),
      'Share Recordings Storage Location' => 
      array (
        0 => 'Поделиться местоположением записей эфира',
      ),
      'Share Podcasts Storage Location' => 
      array (
        0 => 'Поделиться местоположением подкастов',
      ),
      'User Permissions' => 
      array (
        0 => 'Права доступа пользователя',
      ),
      'New Station Name' => 
      array (
        0 => 'Название новой станции',
      ),
      'New Station Description' => 
      array (
        0 => 'Описание новой станции',
      ),
      'Copy to New Station' => 
      array (
        0 => '',
      ),
      'Permissions' => 
      array (
        0 => 'Права',
      ),
      'Delete Role?' => 
      array (
        0 => '',
      ),
      'Roles & Permissions' => 
      array (
        0 => '',
      ),
      'AzuraCast uses a role-based access control system. Roles are given permissions to certain sections of the site, then users are assigned into those roles.' => 
      array (
        0 => '',
      ),
      'Global' => 
      array (
        0 => 'Основное',
      ),
      'Storage Adapter' => 
      array (
        0 => 'Способ Хранения',
      ),
      'Local Filesystem' => 
      array (
        0 => 'Локальная файловая система',
      ),
      'Remote: S3 Compatible' => 
      array (
        0 => 'Дистанционно: Совместимость с S3',
      ),
      'Remote: Dropbox' => 
      array (
        0 => 'Дистанционно: Dropbox',
      ),
      'Path/Suffix' => 
      array (
        0 => 'Путь/Окончание',
      ),
      'For local filesystems, this is the base path of the directory. For remote filesystems, this is the folder prefix.' => 
      array (
        0 => 'Для локальных файловых систем это базовый путь каталога. Для дистанционных файловых систем это префикс папки.',
      ),
      'Storage Quota' => 
      array (
        0 => 'Квота Хранилища',
      ),
      'Set a maximum disk space that this storage location can use. Specify the size with unit, i.e. "8 GB". Units are measured in 1024 bytes. Leave blank to default to the available space on the disk.' => 
      array (
        0 => 'Установите максимальное дисковое пространство, которое может использовать это место хранения. Укажите размер с единицей измерения, то есть "8 GB" или "500 MB". Единица измерения - 1024 байта. Оставьте поле пустым по умолчанию, чтобы использовать всё доступное пространство на диске.',
      ),
      'Access Key ID' => 
      array (
        0 => 'ID ключа доступа',
      ),
      'Secret Key' => 
      array (
        0 => 'Секретный ключ',
      ),
      'Endpoint' => 
      array (
        0 => 'Конечная точка',
      ),
      'Bucket Name' => 
      array (
        0 => 'Название сегмента',
      ),
      'Region' => 
      array (
        0 => 'Регион',
      ),
      'API Version' => 
      array (
        0 => 'Версия API',
      ),
      'Dropbox Generated Access Token' => 
      array (
        0 => 'Токен доступа созданный Dropbox',
      ),
      'Learn More about Dropbox Auth Tokens' => 
      array (
        0 => 'Узнайте больше о токенах авторизации Dropbox',
      ),
      'Edit Storage Location' => 
      array (
        0 => 'Изменить Место Хранения',
      ),
      'Add Storage Location' => 
      array (
        0 => 'Добавить Место Хранения',
      ),
      'GeoLite version "%{ version }" is currently installed.' => 
      array (
        0 => '',
      ),
      'Install GeoLite IP Database' => 
      array (
        0 => 'Установка Базы Данных GeoLite IP',
      ),
      'IP Geolocation is used to guess the approximate location of your listeners based on the IP address they connect with. Use the free built-in IP Geolocation library or enter a license key on this page to use MaxMind GeoLite.' => 
      array (
        0 => '',
      ),
      'Instructions' => 
      array (
        0 => 'Инструкции',
      ),
      'AzuraCast ships with a built-in free IP geolocation database. You may prefer to use the MaxMind GeoLite service instead to achieve more accurate results. Using MaxMind GeoLite requires a license key, but once the key is provided, we will automatically keep the database updated.' => 
      array (
        0 => '',
      ),
      'To download the GeoLite database:' => 
      array (
        0 => '',
      ),
      'Create an account on the MaxMind developer site.' => 
      array (
        0 => '',
      ),
      'MaxMind Developer Site' => 
      array (
        0 => '',
      ),
      'Visit the "My License Key" page under the "Services" section.' => 
      array (
        0 => 'Посетите страницу "My License Key" в разделе "Services".',
      ),
      'Click "Generate new license key".' => 
      array (
        0 => 'Нажмите "Generate new license key".',
      ),
      'Paste the generated license key into the field on this page.' => 
      array (
        0 => 'Вставьте сгенерированный лицензионный ключ в поле на этой странице.',
      ),
      'Current Installed Version' => 
      array (
        0 => 'Текущая установленная версия',
      ),
      'GeoLite is not currently installed on this installation.' => 
      array (
        0 => 'GeoLite в настоящее время здесь не установлен.',
      ),
      'MaxMind License Key' => 
      array (
        0 => 'Лицензионный ключ MaxMind',
      ),
      'Remove Key' => 
      array (
        0 => '',
      ),
      'Delete Station?' => 
      array (
        0 => '',
      ),
      'Stations' => 
      array (
        0 => 'Станции',
      ),
      'Clone' => 
      array (
        0 => 'Клонировать',
      ),
      'Field Name' => 
      array (
        0 => 'Название поля',
      ),
      'This will be used as the label when editing individual songs, and will show in API results.' => 
      array (
        0 => 'Это будет использоваться как метка при редактировании отдельных песен и будет отображаться в результатах API.',
      ),
      'Programmatic Name' => 
      array (
        0 => 'Программируемое Название',
      ),
      'Optionally specify an API-friendly name, such as "field_name". Leave this field blank to automatically create one based on the name.' => 
      array (
        0 => '',
      ),
      'Automatically Set from ID3v2 Value' => 
      array (
        0 => 'Автоматически устанавливать из значения ID3v2',
      ),
      'Optionally select an ID3v2 metadata field that, if present, will be used to set this field\'s value.' => 
      array (
        0 => 'При необходимости выберите поле метаданных ID3v2, которое, если оно существует, будет использоваться для установки этого значения поля.',
      ),
      'Edit Custom Field' => 
      array (
        0 => 'Редактирование настраиваемого поля',
      ),
      'Add Custom Field' => 
      array (
        0 => 'Добавить Настраиваемое Поле',
      ),
      'Adapter' => 
      array (
        0 => 'Подключено',
      ),
      'Station(s)' => 
      array (
        0 => 'Станция(и)',
      ),
      'Station Media' => 
      array (
        0 => 'Медиафайлы Станции',
      ),
      'Station Recordings' => 
      array (
        0 => 'Запись эфира',
      ),
      'Station Podcasts' => 
      array (
        0 => 'Станция подкастов',
      ),
      'Backups' => 
      array (
        0 => 'Резервные копии',
      ),
      'Applying changes...' => 
      array (
        0 => 'Применение изменений...',
      ),
      'Delete Storage Location?' => 
      array (
        0 => '',
      ),
      'Storage Locations' => 
      array (
        0 => 'Места Хранения',
      ),
      'SHOUTcast version "%{ version }" is currently installed.' => 
      array (
        0 => '',
      ),
      'Install SHOUTcast 2 DNAS' => 
      array (
        0 => '',
      ),
      'SHOUTcast 2 DNAS is not free software, and its restrictive license does not allow AzuraCast to distribute the SHOUTcast binary.' => 
      array (
        0 => '',
      ),
      'In order to install SHOUTcast:' => 
      array (
        0 => '',
      ),
      'Download the Linux x64 binary from the SHOUTcast Radio Manager:' => 
      array (
        0 => '',
      ),
      'SHOUTcast Radio Manager' => 
      array (
        0 => '',
      ),
      'The file name should look like:' => 
      array (
        0 => '',
      ),
      'Upload the file on this page to automatically extract it into the proper directory.' => 
      array (
        0 => '',
      ),
      'SHOUTcast 2 DNAS is not currently installed on this installation.' => 
      array (
        0 => '',
      ),
      'Services' => 
      array (
        0 => 'Сервисы',
      ),
      'Stable' => 
      array (
        0 => 'Стабильный',
      ),
      'Rolling Release' => 
      array (
        0 => 'Временные Релизы',
      ),
      'AzuraCast Update Checks' => 
      array (
        0 => 'Проверка Обновлений AzuraCast',
      ),
      'Current Release Channel' => 
      array (
        0 => 'Текущий Канал Релизов',
      ),
      'Learn more about release channels in the AzuraCast docs.' => 
      array (
        0 => '',
      ),
      'Show Update Announcements' => 
      array (
        0 => 'Показать уведомления об обновлениях',
      ),
      'Show new releases within your update channel on the AzuraCast homepage.' => 
      array (
        0 => 'Показывать новые релизы в вашем канале обновления на главной странице AzuraCast.',
      ),
      'E-mail Delivery Service' => 
      array (
        0 => 'Служба доставки электронной почты',
      ),
      'Used for "Forgot Password" functionality, web hooks and other functions.' => 
      array (
        0 => 'Используется для функции "Забыли пароль", веб-хуков и других функций.',
      ),
      'Enable Mail Delivery' => 
      array (
        0 => 'Включить доставку почты',
      ),
      'Sender Name' => 
      array (
        0 => 'Имя Отправителя',
      ),
      'Sender E-mail Address' => 
      array (
        0 => 'E-mail Отправителя',
      ),
      'SMTP Host' => 
      array (
        0 => 'SMTP Хост',
      ),
      'SMTP Port' => 
      array (
        0 => 'SMTP Порт',
      ),
      'Use Secure (TLS) SMTP Connection' => 
      array (
        0 => 'Использовать безопасное (TLS) SMTP соединение',
      ),
      'Usually enabled for port 465, disabled for ports 587 or 25.' => 
      array (
        0 => 'Обычно включен для порта 465, отключен для портов 587 или 25.',
      ),
      'SMTP Username' => 
      array (
        0 => 'Имя пользователя SMTP',
      ),
      'SMTP Password' => 
      array (
        0 => 'Пароль SMTP',
      ),
      'Avatar Services' => 
      array (
        0 => 'Аватар Сервисы',
      ),
      'Avatar Service' => 
      array (
        0 => 'Аватар Сервис',
      ),
      'Default Avatar URL' => 
      array (
        0 => 'URL аватара по умолчанию',
      ),
      'Album Art Services' => 
      array (
        0 => 'Сервис Обложек Альбомов',
      ),
      'Check Web Services for Album Art for "Now Playing" Tracks' => 
      array (
        0 => 'Проверить веб-сервисы на наличие обложек альбомов для треков "Сейчас Играет"',
      ),
      'Check Web Services for Album Art When Uploading Media' => 
      array (
        0 => 'Проверить веб-сервисы на наличие обложки альбома при загрузке медиафайла',
      ),
      'Last.fm API Key' => 
      array (
        0 => 'Ключ API Last.fm',
      ),
      'This service can provide album art for tracks where none is available locally.' => 
      array (
        0 => '',
      ),
      'Apply for an API key at Last.fm' => 
      array (
        0 => '',
      ),
      'Last 60 Days' => 
      array (
        0 => 'Последние 60 дней',
      ),
      'Last Year' => 
      array (
        0 => 'Прошлый год',
      ),
      'Last 2 Years' => 
      array (
        0 => 'Последние 2 года',
      ),
      'Indefinitely' => 
      array (
        0 => 'Неопределенный',
      ),
      'Site Base URL' => 
      array (
        0 => 'Базовый URL-АДРЕС сайта',
      ),
      'The base URL where this service is located. Use either the external IP address or fully-qualified domain name (if one exists) pointing to this server.' => 
      array (
        0 => 'Базовый URL-адрес, где находится эта служба. Используйте либо внешний IP-адрес, либо полное доменное имя (если оно существует), указывающее на этот сервер.',
      ),
      'AzuraCast Instance Name' => 
      array (
        0 => 'Имя экземпляра IvaCom Radio Control',
      ),
      'This name will appear as a sub-header next to the AzuraCast logo, to help identify this server.' => 
      array (
        0 => 'Это имя появится в виде подзаголовка рядом с логотипом  IvaCom Radio Control, чтобы помочь идентифицировать этот сервер.',
      ),
      'Prefer Browser URL (If Available)' => 
      array (
        0 => 'Предпочтительный URL-адрес в браузере (если доступно)',
      ),
      'If this setting is set to "Yes", the browser URL will be used instead of the base URL when it\'s available. Set to "No" to always use the base URL.' => 
      array (
        0 => 'При выборе этого параметра, браузером будет использоваться URL-адрес по умолчанию, вместо указанного выше базового URL-адреса. Если не выбран этот параметр, то постоянно используется базовый URL-адрес.',
      ),
      'Use Web Proxy for Radio' => 
      array (
        0 => 'Использовать веб-прокси для радио',
      ),
      'By default, radio stations broadcast on their own ports (i.e. 8000). If you\'re using a service like CloudFlare or accessing your radio station by SSL, you should enable this feature, which routes all radio through the web ports (80 and 443).' => 
      array (
        0 => 'По умолчанию радиостанции транслируются на своих портах (т. Е. 8000). Если вы используете службу CloudFlare или получаете доступ к своей радиостанции по протоколу SSL, вы должны включить эту функцию, которая маршрутизирует все радио через веб-порты (80 и 443).',
      ),
      'Days of Playback History to Keep' => 
      array (
        0 => 'Количество дней для хранения истории проигранного',
      ),
      'Set longer to preserve more playback history and listener metadata for stations. Set shorter to save disk space.' => 
      array (
        0 => '',
      ),
      'Use WebSockets for Now Playing Updates' => 
      array (
        0 => 'Использовать WebSockets для обновления проигрываемого',
      ),
      'Enables or disables the use of the newer and faster WebSocket-based system for receiving live updates on public players. You may need to disable this if you encounter problems with it.' => 
      array (
        0 => 'Включает или отключает использование новой и более быстрой системы на основе WebSocket для получения обновлений в режиме реального времени на общедоступных проигрывателях. Если возникают проблемы при использовании этой функции, вы можете её отключить.',
      ),
      'Enable Advanced Features' => 
      array (
        0 => 'Включить Расширенные Функции',
      ),
      'Enable certain advanced features in the web interface, including advanced playlist configuration, station port assignment, changing base media directories and other functionality that should only be used by users who are comfortable with advanced functionality.' => 
      array (
        0 => 'Включите некоторые дополнительные функции в веб-интерфейсе, включая расширенную конфигурацию плейлистов, назначение порта станции, изменение базовых папок медиафайлов и другие функции, которые должны использоваться только теми пользователями, которые знакомы с расширенными настройками.',
      ),
      'Security & Privacy' => 
      array (
        0 => '',
      ),
      'Privacy' => 
      array (
        0 => 'Конфиденциальность',
      ),
      'Listener Analytics Collection' => 
      array (
        0 => 'Коллекция аналитики слушателя',
      ),
      'Aggregate listener statistics are used to show station reports across the system. IP-based listener statistics are used to view live listener tracking and may be required for royalty reports.' => 
      array (
        0 => 'Собираемая статистика слушателей используется для отображения отчетов о станциях в системе. Статистика слушателей на основе IP-адреса используется для просмотра отслеживания живых слушателей и может потребоваться для роялти отчетов.',
      ),
      'Full:' => 
      array (
        0 => '',
      ),
      'Collect aggregate listener statistics and IP-based listener statistics' => 
      array (
        0 => '',
      ),
      'Limited:' => 
      array (
        0 => '',
      ),
      'Only collect aggregate listener statistics' => 
      array (
        0 => '',
      ),
      'None:' => 
      array (
        0 => '',
      ),
      'Do not collect any listener analytics' => 
      array (
        0 => '',
      ),
      'Security' => 
      array (
        0 => 'Безопасность',
      ),
      'Always Use HTTPS' => 
      array (
        0 => 'Всегда использовать HTTPS',
      ),
      'Set to "Yes" to always use "https://" secure URLs, and to automatically redirect to the secure URL when an insecure URL is visited.' => 
      array (
        0 => 'Установите "Да" для того, чтобы всегда использовать "https://" безопасные URL, и автоматически перенаправлять на безопасный URL, когда посещается небезопасный URL.',
      ),
      'API "Access-Control-Allow-Origin" Header' => 
      array (
        0 => '',
      ),
      'Set to * to allow all sources, or specify a list of origins separated by a comma (,).' => 
      array (
        0 => '',
      ),
      'Learn more about this header.' => 
      array (
        0 => '',
      ),
      'Auto-Assign Value' => 
      array (
        0 => '',
      ),
      'None' => 
      array (
        0 => 'Не выбрано',
      ),
      'Delete Custom Field?' => 
      array (
        0 => '',
      ),
      'Create custom fields to store extra metadata about each media file uploaded to your station libraries.' => 
      array (
        0 => '',
      ),
      'Changes saved.' => 
      array (
        0 => 'Изменения сохранены.',
      ),
      'System Settings' => 
      array (
        0 => 'Настройки системы',
      ),
      'Browser Icon' => 
      array (
        0 => 'Иконка браузера',
      ),
      'Public Page Background' => 
      array (
        0 => 'Фон публичной страницы',
      ),
      'Default Album Art' => 
      array (
        0 => 'Обложка альбома по умолчанию',
      ),
      'Custom Branding' => 
      array (
        0 => 'Индивидуальный брендинг',
      ),
      'Upload Custom Assets' => 
      array (
        0 => 'Загрузка Пользовательских Ресурсов',
      ),
      'Clear Image' => 
      array (
        0 => '',
      ),
      'Prefer System Default' => 
      array (
        0 => 'Использовать системные по умолчанию',
      ),
      'Branding Settings' => 
      array (
        0 => 'Настройки Бренда',
      ),
      'Base Theme for Public Pages' => 
      array (
        0 => 'Базовая тема для публичных страниц',
      ),
      'Select a theme to use as a base for station public pages and the login page.' => 
      array (
        0 => 'Выберите тему для использования в качестве основной для публичных страниц станции и страницы входа.',
      ),
      'Hide Album Art on Public Pages' => 
      array (
        0 => 'Скрыть обложку альбома на публичных страницах',
      ),
      'If selected, album art will not display on public-facing radio pages.' => 
      array (
        0 => 'Если выбрано, то обложка альбома не будет отображаться на публичных страницах радио.',
      ),
      'Hide AzuraCast Branding on Public Pages' => 
      array (
        0 => 'Скрыть бренд AzuraCast на публичных страницах',
      ),
      'If selected, this will remove the AzuraCast branding from public-facing pages.' => 
      array (
        0 => 'Если выбрано, то будет удалён бренд AzuraCast с публично расположенных страниц.',
      ),
      'Homepage Redirect URL' => 
      array (
        0 => 'URL перенаправления главной страницы',
      ),
      'If a visitor is not signed in and visits the AzuraCast homepage, you can automatically redirect them to the URL specified here. Leave blank to redirect them to the login screen by default.' => 
      array (
        0 => 'Если посетитель не авторизован и посещает главную страницу AzuraCast, вы можете автоматически перенаправить его на указанный здесь URL. Оставьте пустым, чтобы перенаправить его на страницу входа по умолчанию.',
      ),
      'Custom CSS for Public Pages' => 
      array (
        0 => 'Пользовательский CSS для публичных страниц',
      ),
      'This CSS will be applied to the station public pages and login page.' => 
      array (
        0 => 'Этот CSS будет применен к публичным страницам станции и странице входа.',
      ),
      'Custom JS for Public Pages' => 
      array (
        0 => 'Пользовательский JS для публичных страниц',
      ),
      'This javascript code will be applied to the station public pages and login page.' => 
      array (
        0 => 'Этот код javascript будет применен к публичным страницам станции и странице входа.',
      ),
      'Custom CSS for Internal Pages' => 
      array (
        0 => 'Пользовательский CSS для внутренних страниц',
      ),
      'This CSS will be applied to the main management pages, like this one.' => 
      array (
        0 => 'Этот CSS будет применен к основным страницам управления, таким как эта.',
      ),
      'Seek' => 
      array (
        0 => 'Найти',
      ),
      'Create Account' => 
      array (
        0 => 'Создать аккаунт',
      ),
      'Create Station' => 
      array (
        0 => 'Создать станцию',
      ),
      'AzuraCast First-Time Setup' => 
      array (
        0 => 'Первоначальная Настройка AzuraCast',
      ),
      'Welcome to AzuraCast!' => 
      array (
        0 => 'Добро пожаловать в AzuraCast!',
      ),
      'Let\'s get started by creating your Super Administrator account.' => 
      array (
        0 => 'Давайте начнем с создания вашей учетной записи Супер Администратор.',
      ),
      'This account will have full access to the system, and you\'ll automatically be logged in to it for the rest of setup.' => 
      array (
        0 => 'Эта учётная запись будет иметь полный доступ к системе, и вы автоматически войдете в систему для остальной настройки.',
      ),
      'E-mail Address' => 
      array (
        0 => 'E-mail адрес',
      ),
      'Create a New Radio Station' => 
      array (
        0 => 'Создать Новую Радиостанцию',
      ),
      'Continue the setup process by creating your first radio station below. You can edit any of these details later.' => 
      array (
        0 => 'Продолжите процесс настройки, создав свою первую радиостанцию ниже. Вы можете изменить любую из этих деталей позже.',
      ),
      'Create and Continue' => 
      array (
        0 => '',
      ),
      'Customize AzuraCast Settings' => 
      array (
        0 => 'Настройка Параметров AzuraCast',
      ),
      'Complete the setup process by providing some information about your broadcast environment. These settings can be changed later from the administration panel.' => 
      array (
        0 => 'Завершите процесс установки, предоставив некоторую информацию о вашей среде вещания. Эти настройки можно изменить позже на панели администрирования.',
      ),
      'Save and Continue' => 
      array (
        0 => '',
      ),
      'An error occurred and your request could not be completed.' => 
      array (
        0 => 'Произошла ошибка и ваш запрос не может быть завершен.',
      ),
      'Error' => 
      array (
        0 => '',
      ),
      'Success' => 
      array (
        0 => '',
      ),
      'Please wait...' => 
      array (
        0 => 'Пожалуйста, подождите...',
      ),
      'Delete Record?' => 
      array (
        0 => '',
      ),
      'The locale to use for CLI commands.' => 
      array (
        0 => 'Языковой стандарт, используемый для команд CLI.',
      ),
      'The application environment.' => 
      array (
        0 => 'Среда приложения.',
      ),
      'Manually modify the logging level.' => 
      array (
        0 => 'Вручную измените уровень ведения журнала.',
      ),
      'This allows you to log debug-level errors temporarily (for problem-solving) or reduce the volume of logs that are produced by your installation, without needing to modify whether your installation is a production or development instance.' => 
      array (
        0 => 'Это позволяет вам временно регистрировать ошибки уровня отладки (для решения проблем) или уменьшать объем журналов, создаваемых вашей установкой, без необходимости изменять, независимо от того, является ли ваша установка производственным или разрабатываемым экземпляром.',
      ),
      'Composer Plugin Mode' => 
      array (
        0 => 'Режим плагина Composer',
      ),
      'Enable the composer "merge" functionality to combine the main application\'s composer.json file with any plugin composer files. This can have performance implications, so you should only use it if you use one or more plugins with their own Composer dependencies.' => 
      array (
        0 => 'Включите функцию "слияние" Composer, чтобы объединить файл composer.json основного приложения с любыми файлами плагина Composer. Это может повлиять на производительность, поэтому вам следует использовать его только в том случае, если вы используете один или несколько плагинов с их собственными зависимостями от Composer.',
      ),
      'Minimum Port for Station Port Assignment' => 
      array (
        0 => 'Минимальный порт для назначения порта станции',
      ),
      'Modify this if your stations are listening on nonstandard ports.' => 
      array (
        0 => 'Измените это, если ваши станции прослушивают нестандартные порты.',
      ),
      'Maximum Port for Station Port Assignment' => 
      array (
        0 => 'Максимальный порт для назначения порта станции',
      ),
      'MariaDB Host' => 
      array (
        0 => 'Хост MariaDB',
      ),
      'Do not modify this after installation.' => 
      array (
        0 => 'Не изменяйте это после установки.',
      ),
      'MariaDB Port' => 
      array (
        0 => 'Порт MariaDB',
      ),
      'MariaDB Username' => 
      array (
        0 => 'Имя пользователя MariaDB',
      ),
      'MariaDB Password' => 
      array (
        0 => 'Пароль MariaDB',
      ),
      'MariaDB Database Name' => 
      array (
        0 => 'Название базы данных MariaDB',
      ),
      'Auto-generate Random MariaDB Root Password' => 
      array (
        0 => 'Автоматическое создание случайного Root пароля MariaDB',
      ),
      'MariaDB Root Password' => 
      array (
        0 => 'Пароль Root пользователя MariaDB',
      ),
      'Enable MariaDB Slow Query Log' => 
      array (
        0 => 'Включить журнал медленных запросов MariaDB',
      ),
      'Log slower queries to diagnose possible database issues. Only turn this on if needed.' => 
      array (
        0 => 'Регистрируйте более медленные запросы, чтобы диагностировать возможные проблемы с базой данных. Включайте это только при необходимости.',
      ),
      'MariaDB Maximum Connections' => 
      array (
        0 => 'MariaDB Максимум соединений',
      ),
      'Set the amount of allowed connections to the database. This value should be increased if you are seeing the "Too many connections" error in the logs.' => 
      array (
        0 => 'Установите количество разрешенных подключений к базе данных. Это значение следует увеличить, если вы видите в журналах ошибку «Слишком много подключений».',
      ),
      'Enable Redis' => 
      array (
        0 => 'Включить Redis',
      ),
      'Disable to use a flatfile cache instead of Redis.' => 
      array (
        0 => 'Отключить использование кэша flatfile вместо Redis.',
      ),
      'Redis Host' => 
      array (
        0 => 'Хост Redis',
      ),
      'Redis Port' => 
      array (
        0 => 'Порт Redis',
      ),
      'Redis Database Index' => 
      array (
        0 => 'Индекс базы данных Redis',
      ),
      'PHP Maximum POST File Size' => 
      array (
        0 => 'Максимальный размер POST файла PHP',
      ),
      'PHP Memory Limit' => 
      array (
        0 => 'Лимит памяти PHP',
      ),
      'PHP Script Maximum Execution Time' => 
      array (
        0 => 'Максимальное время выполнения PHP скрипта',
      ),
      '(in seconds)' => 
      array (
        0 => '(в секундах)',
      ),
      'Short Sync Task Execution Time' => 
      array (
        0 => 'Краткое время выполнения задачи синхронизации',
      ),
      'The maximum execution time (and lock timeout) for the 15-second, 1-minute and 5-minute synchronization tasks.' => 
      array (
        0 => 'Максимальное время выполнения (и время блокировки) для 15-секундных, 1-минутных и 5-минутных задач синхронизации.',
      ),
      'Long Sync Task Execution Time' => 
      array (
        0 => 'Длительное время выполнения задачи синхронизации',
      ),
      'The maximum execution time (and lock timeout) for the 1-hour synchronization task.' => 
      array (
        0 => 'Максимальное время выполнения (и время блокировки) для 1-часовой задачи синхронизации.',
      ),
      'Maximum PHP-FPM Worker Processes' => 
      array (
        0 => 'Максимальное количество рабочих процессов PHP-FPM',
      ),
      'Enable Performance Profiling Extension' => 
      array (
        0 => 'Включить расширение профилирования производительности',
      ),
      'Profiling data can be viewed by visiting %s.' => 
      array (
        0 => 'Данные профилирования можно просмотреть, посетив %s.',
      ),
      'Profile Performance on All Requests' => 
      array (
        0 => 'Производительность профиля по всем запросам',
      ),
      'This will have a significant performance impact on your installation.' => 
      array (
        0 => 'Это существенно повлияет на производительность вашей установки.',
      ),
      'Profiling Extension HTTP Key' => 
      array (
        0 => 'HTTP-ключ расширения профилирования',
      ),
      'The value for the "SPX_KEY" parameter for viewing profiling pages.' => 
      array (
        0 => 'Значение параметра «SPX_KEY» для просмотра страниц профилирования.',
      ),
      'Profiling Extension IP Allow List' => 
      array (
        0 => 'Список разрешенных IP-адресов расширения профилирования',
      ),
      '(Docker Compose) All Docker containers are prefixed by this name. Do not change this after installation.' => 
      array (
        0 => '(Docker Compose) Все контейнеры Docker имеют префикс этого имени. Не меняйте это после установки.',
      ),
      '(Docker Compose) The amount of time to wait before a Docker Compose operation fails. Increase this on lower performance computers.' => 
      array (
        0 => '(Docker Compose) Время ожидания до завершения операции Docker Compose. Увеличьте это значение на компьютерах с низкой производительностью.',
      ),
      'AzuraCast Release Channel' => 
      array (
        0 => 'Текущий Канал Релизов',
      ),
      'HTTP Port' => 
      array (
        0 => 'HTTP порт',
      ),
      'The main port AzuraCast listens to for insecure HTTP connections.' => 
      array (
        0 => 'Основной порт AzuraCast прослушивает небезопасные HTTP соединения.',
      ),
      'HTTPS Port' => 
      array (
        0 => 'HTTPS порт',
      ),
      'The main port AzuraCast listens to for secure HTTPS connections.' => 
      array (
        0 => 'Основной порт AzuraCast прослушивает безопасные HTTPS соединения.',
      ),
      'SFTP Port' => 
      array (
        0 => 'SFTP порт',
      ),
      'The port AzuraCast listens to for SFTP file management connections.' => 
      array (
        0 => 'Порт AzuraCast прослушивает соединения для управления файлами SFTP.',
      ),
      'Station Ports' => 
      array (
        0 => 'Порты Станции',
      ),
      'The ports AzuraCast should listen to for station broadcasts and incoming DJ connections.' => 
      array (
        0 => 'Порты, которые AzuraCast должен прослушивать для вещания станций и входящих подключений Диджеев.',
      ),
      'Docker User UID' => 
      array (
        0 => 'UID пользователя Docker',
      ),
      'Set the UID of the user running inside the Docker containers. Matching this with your host UID can fix permission issues.' => 
      array (
        0 => 'Установите UID пользователя, работающего внутри контейнеров Docker. Сопоставление этого идентификатора с UID вашего хоста может решить проблемы с правами доступа.',
      ),
      'Docker User GID' => 
      array (
        0 => 'GID пользователя Docker',
      ),
      'Set the GID of the user running inside the Docker containers. Matching this with your host GID can fix permission issues.' => 
      array (
        0 => 'Установите GID пользователя, работающего внутри контейнеров Docker. Сопоставление этого идентификатора с GID вашего хоста может решить проблемы с правами доступа.',
      ),
      'Advanced: Use Privileged Docker Settings' => 
      array (
        0 => 'Дополнительно: Используйте Привилегированные Настройки Docker',
      ),
      'LetsEncrypt Domain Name(s)' => 
      array (
        0 => 'Доменное имя(имена) LetsEncrypt',
      ),
      'Domain name (example.com) or names (example.com,foo.bar) to use with LetsEncrypt.' => 
      array (
        0 => 'Имя домена (example.com) или имена (example.com, foo.bar) для использования с LetsEncrypt.',
      ),
      'LetsEncrypt E-mail Address' => 
      array (
        0 => 'Email адрес для LetsEncrypt',
      ),
      'Optionally provide an e-mail address for updates from LetsEncrypt.' => 
      array (
        0 => 'При необходимости укажите адрес электронной почты для обновлений от LetsEncrypt.',
      ),
      'This file was automatically generated by AzuraCast.' => 
      array (
        0 => 'Этот файл был автоматически создан AzuraCast.',
      ),
      'You can modify it as necessary. To apply changes, restart the Docker containers.' => 
      array (
        0 => 'Вы можете изменить его по мере необходимости. Чтобы применить изменения, перезапустите контейнеры Docker.',
      ),
      'Remove the leading "#" symbol from lines to uncomment them.' => 
      array (
        0 => 'Удалите начальный символ «#» из строк, чтобы раскомментировать их.',
      ),
      'Valid options: %s' => 
      array (
        0 => 'Допустимые варианты: %s',
      ),
      'Default: %s' => 
      array (
        0 => 'По умолчанию: %s',
      ),
      'Additional Environment Variables' => 
      array (
        0 => 'Дополнительные переменные среды',
      ),
      'AzuraCast Installer' => 
      array (
        0 => 'Установщик AzuraCast',
      ),
      'Welcome to AzuraCast! Complete the initial server setup by answering a few questions.' => 
      array (
        0 => 'Добро пожаловать в AzuraCast! Завершите первоначальную настройку сервера, ответив на несколько вопросов.',
      ),
      'AzuraCast Updater' => 
      array (
        0 => 'Обновления AzuraCast',
      ),
      'Change installation settings?' => 
      array (
        0 => 'Изменить параметры установки?',
      ),
      'AzuraCast is currently configured to listen on the following ports:' => 
      array (
        0 => 'В данный момент AzuraCast настроен для прослушивания следующих портов:',
      ),
      'HTTP Port: %d' => 
      array (
        0 => 'HTTP порт: %d',
      ),
      'HTTPS Port: %d' => 
      array (
        0 => 'HTTPS порт: %d',
      ),
      'SFTP Port: %d' => 
      array (
        0 => 'SFTP порт: %d',
      ),
      'Radio Ports: %s' => 
      array (
        0 => 'Радио порты: %s',
      ),
      'Customize ports used for AzuraCast?' => 
      array (
        0 => 'Настроить порты, используемые для AzuraCast?',
      ),
      'Set up LetsEncrypt?' => 
      array (
        0 => 'Настроить LetsEncrypt?',
      ),
      'Writing configuration files...' => 
      array (
        0 => 'Запись файлов конфигурации...',
      ),
      'Server configuration complete!' => 
      array (
        0 => 'Настройка сервера завершена!',
      ),
      'This product includes GeoLite2 data created by MaxMind, available from %s.' => 
      array (
        0 => 'Этот продукт включает данные GeoLite2, созданный MaxMind, доступные от %s.',
      ),
      'IP Geolocation by DB-IP' => 
      array (
        0 => 'Геолокация IP по DB-IP',
      ),
      'GeoLite database not configured for this installation. See System Administration for instructions.' => 
      array (
        0 => 'База данных GeoLite не настроена для этой установки. Смотрите инструкции в управлении системой.',
      ),
      'Welcome to the AzuraCast Liquidsoap configuration editor.' => 
      array (
        0 => 'Добро пожаловать в редактор конфигурации AzuraCast Liquidsoap.',
      ),
      'Using this page, you can customize several sections of the Liquidsoap configuration.' => 
      array (
        0 => 'Используя эту страницу, вы можете настроить несколько разделов конфигурации Liquidsoap.',
      ),
      'The non-editable sections are automatically generated by AzuraCast.' => 
      array (
        0 => 'Не редактируемые разделы автоматически создаются AzuraCast.',
      ),
      '%s is not recognized as a service.' => 
      array (
        0 => '%s не распознан как сервис.',
      ),
      'It may not be registered with Supervisor yet. Restarting broadcasting may help.' => 
      array (
        0 => 'Возможно еще не зарегистрирован Руководитель. Перезапуск трансляции может помочь.',
      ),
      '%s cannot start' => 
      array (
        0 => '%s не удается запустить',
      ),
      'It is already running.' => 
      array (
        0 => 'Он уже работает.',
      ),
      '%s cannot stop' => 
      array (
        0 => '%s не может остановиться',
      ),
      'It is not running.' => 
      array (
        0 => 'Он не запущен.',
      ),
      '%s encountered an error' => 
      array (
        0 => '%s столкнулся с ошибкой',
      ),
      'Check the log for details.' => 
      array (
        0 => 'Проверьте журнал для подробностей.',
      ),
      'Select...' => 
      array (
        0 => 'Выбрать...',
      ),
      'This feature is not currently supported on this station.' => 
      array (
        0 => 'Эта функция в данный момент не поддерживается на этой станции.',
      ),
      'Now Playing Data' => 
      array (
        0 => 'Сейчас проигрывается',
      ),
      '1-Minute Sync' => 
      array (
        0 => '1-минутная синхронизация',
      ),
      'Song Requests Queue' => 
      array (
        0 => 'Очередь запросов песен',
      ),
      '5-Minute Sync' => 
      array (
        0 => '5-ти минутная синхронизация',
      ),
      'Check Media Folders' => 
      array (
        0 => 'Проверка папок мультимедиа',
      ),
      '1-Hour Sync' => 
      array (
        0 => 'Часовая синхронизация',
      ),
      'Analytics/Statistics' => 
      array (
        0 => 'Аналитика/статистика',
      ),
      'Cleanup' => 
      array (
        0 => 'Очистка',
      ),
      'Installation Not Recently Backed Up' => 
      array (
        0 => 'Резервная копия установки давняя',
      ),
      'This installation has not been backed up in the last two weeks.' => 
      array (
        0 => 'Резервное копирование этой установки не выполнялось в течение последних двух недель.',
      ),
      'Update Instructions' => 
      array (
        0 => 'Инструкции по обновлению',
      ),
      'AzuraCast <a href="%s" target="_blank">version %s</a> is now available.' => 
      array (
        0 => 'Доступна <a href="%s" target="_blank">версия %s</a> AzuraCast.',
      ),
      'You are currently running version %s. Updating is highly recommended.' => 
      array (
        0 => 'В настоящее время вы используете версию %s. Рекомендуем обновиться.',
      ),
      'New AzuraCast Release Version Available' => 
      array (
        0 => 'Доступна новая версия релиза AzuraCast',
      ),
      'Your installation is currently %d update(s) behind the latest version.' => 
      array (
        0 => 'Ваша установка сейчас отстает от последней версии на %d обновлени(я).',
      ),
      'View the changelog for full details.' => 
      array (
        0 => 'Посмотрите список изменений для детальной информации.',
      ),
      'You should update to take advantage of bug and security fixes.' => 
      array (
        0 => 'Вы должны обновиться, чтобы воспользоваться исправлениями ошибок и безопасности.',
      ),
      'New AzuraCast Updates Available' => 
      array (
        0 => 'Доступны новые обновления AzuraCast',
      ),
      'Synchronized Task Not Recently Run' => 
      array (
        0 => 'Задача синхронизации не запущена',
      ),
      'The "%s" synchronization task has not run recently. This may indicate an error with your installation.' => 
      array (
        0 => 'Задача синхронизации "%s" в последнее время не запускалась. Это может указывать на ошибку при установке.',
      ),
      'Manually Run Task' => 
      array (
        0 => 'Запуск Задачи Вручную',
      ),
      'The performance profiling extension is currently enabled on this installation.' => 
      array (
        0 => 'Расширение профилирования производительности в настоящее время включено в этой установке.',
      ),
      'You can track the execution time and memory usage of any AzuraCast page or application from the profiler page.' => 
      array (
        0 => 'Вы можете отслеживать время выполнения и использование памяти любой страницы или приложения AzuraCast со страницы профилирования.',
      ),
      'Profiler Control Panel' => 
      array (
        0 => 'Панель управления профилирования',
      ),
      'Performance profiling is currently enabled for all requests.' => 
      array (
        0 => 'Профилирование производительности в настоящее время включено для всех запросов.',
      ),
      'This can have an adverse impact on system performance. You should disable this when possible.' => 
      array (
        0 => 'Это может отрицательно сказаться на производительности системы. Вы должны отключить это, когда это возможно.',
      ),
      'You should update your <code>docker-compose.yml</code> file to reflect the newest changes.' => 
      array (
        0 => 'Вам следует обновить файл <code> docker-compose.yml </code>, чтобы отразить последние изменения.',
      ),
      'If you manually maintain this file, review the <a href="%s" target="_blank">latest version of the file</a> and make any changes needed.' => 
      array (
        0 => 'Если вы вручную обслуживаете этот файл, просмотрите <a href="%s" target="_blank">последнюю версию файла</a> и внесите необходимые изменения.',
      ),
      'Otherwise, update your installation and answer "Y" when prompted to update the file.' => 
      array (
        0 => 'В противном случае, обновите установку и ответьте "Y" при появлении запроса на обновление файла.',
      ),
      'Your <code>docker-compose.yml</code> file is out of date!' => 
      array (
        0 => 'Ваш файл <code>docker-compose.yml</code> устарел!',
      ),
      'You must be logged in to access this page.' => 
      array (
        0 => 'Вы должны войти в систему для доступа к этой странице.',
      ),
      'You do not have permission to access this portion of the site.' => 
      array (
        0 => 'У вас нет прав на доступ к этой части сайта.',
      ),
      'All Permissions' => 
      array (
        0 => 'Все права доступа',
      ),
      'View Administration Page' => 
      array (
        0 => 'Просмотр Страниц Администрирования',
      ),
      'View System Logs' => 
      array (
        0 => 'Просмотр системных журналов',
      ),
      'Administer Settings' => 
      array (
        0 => 'Управление Настройками',
      ),
      'Administer API Keys' => 
      array (
        0 => 'Управление API Ключами',
      ),
      'Administer Stations' => 
      array (
        0 => 'Управление Станциями',
      ),
      'Administer Custom Fields' => 
      array (
        0 => 'Управление Настраиваемыми Полями',
      ),
      'Administer Backups' => 
      array (
        0 => 'Управление Резервными Копиями',
      ),
      'Administer Storage Locations' => 
      array (
        0 => 'Управление Местами Хранения',
      ),
      'View Station Page' => 
      array (
        0 => 'Просмотр Страниц Станции',
      ),
      'View Station Reports' => 
      array (
        0 => 'Просмотр отчётов станции',
      ),
      'View Station Logs' => 
      array (
        0 => 'Просмотр журналов станции',
      ),
      'Manage Station Profile' => 
      array (
        0 => 'Управление Профилем Станции',
      ),
      'Manage Station Broadcasting' => 
      array (
        0 => 'Управление Вещанием Станции',
      ),
      'Manage Station Streamers' => 
      array (
        0 => 'Управление Ведущими Станции',
      ),
      'Manage Station Mount Points' => 
      array (
        0 => 'Управление Точками Подключения Станции',
      ),
      'Manage Station Remote Relays' => 
      array (
        0 => 'Управление Ретрансляторами Станции',
      ),
      'Manage Station Media' => 
      array (
        0 => 'Управление Медиафайлами Станции',
      ),
      'Manage Station Automation' => 
      array (
        0 => 'Управление Автоматизацией Станции',
      ),
      'Manage Station Web Hooks' => 
      array (
        0 => 'Управление Веб-хуками Станции',
      ),
      'Manage Station Podcasts' => 
      array (
        0 => 'Управление подкастами станции',
      ),
      'Imported locale: %s' => 
      array (
        0 => 'Импорт локализации: %s',
      ),
      'The account associated with e-mail address "%s" has been set as an administrator' => 
      array (
        0 => 'Учетная запись, связанная с адресом электронной почты "%s" была установлена как администратор',
      ),
      'Account not found.' => 
      array (
        0 => 'Аккаунт не найден.',
      ),
      'Fixtures loaded.' => 
      array (
        0 => 'Модификатор загружен.',
      ),
      'Configuration successfully written.' => 
      array (
        0 => 'Конфигурация успешно записана.',
      ),
      'AzuraCast Backup' => 
      array (
        0 => 'Резервная копия AzuraCast',
      ),
      'Please wait while a backup is generated...' => 
      array (
        0 => 'Пожалуйста, подождите, пока будет создана резервная копия...',
      ),
      'Creating temporary directories...' => 
      array (
        0 => 'Создание временных каталогов...',
      ),
      'Directory "%s" was not created' => 
      array (
        0 => 'Папка "%s" не была создана',
      ),
      'Backing up MariaDB...' => 
      array (
        0 => 'Резервное копирование MariaDB...',
      ),
      'Creating backup archive...' => 
      array (
        0 => 'Создание архива резервной копии...',
      ),
      'Cleaning up temporary files...' => 
      array (
        0 => 'Очистка временных файлов...',
      ),
      'Backup complete in %.2f seconds.' => 
      array (
        0 => 'Резервное копирование завершено за %.2f секунд.',
      ),
      'Backup path %s not found!' => 
      array (
        0 => 'Путь резервной копии %s не найден!',
      ),
      'AzuraCast Setup' => 
      array (
        0 => 'Настройка AzuraCast',
      ),
      'Welcome to AzuraCast. Please wait while some key dependencies of AzuraCast are set up...' => 
      array (
        0 => 'Добро пожаловать в AzuraCast. Пожалуйста, подождите, пока настраиваются некоторые ключевые зависимости AzuraCast...',
      ),
      'Installing Data Fixtures' => 
      array (
        0 => 'Установка модификатора данных',
      ),
      'Refreshing All Stations' => 
      array (
        0 => 'Обновление всех станций',
      ),
      'AzuraCast is now updated to the latest version!' => 
      array (
        0 => 'AzuraCast теперь обновлен до последней версии!',
      ),
      'AzuraCast installation complete!' => 
      array (
        0 => 'Установка AzuraCast завершена!',
      ),
      'Visit %s to complete setup.' => 
      array (
        0 => 'Посетите %s для завершения установки.',
      ),
      'Initialize AzuraCast' => 
      array (
        0 => 'Инициализация AzuraCast',
      ),
      'Initializing essential settings...' => 
      array (
        0 => 'Инициализация основных настроек...',
      ),
      'Environment: %s' => 
      array (
        0 => 'Окружающая среда: %s',
      ),
      'Installation Method: %s' => 
      array (
        0 => 'Способ установки: %s',
      ),
      'Running Database Migrations' => 
      array (
        0 => 'Запуск миграции базы данных',
      ),
      'Generating Database Proxy Classes' => 
      array (
        0 => 'Создание Прокси-Классов Базы Данных',
      ),
      'Reload System Data' => 
      array (
        0 => 'Перезагрузить системные данные',
      ),
      'AzuraCast is now initialized.' => 
      array (
        0 => 'AzuraCast инициализирован.',
      ),
      'AzuraCast Settings' => 
      array (
        0 => 'Настройки AzuraCast',
      ),
      'Setting Key' => 
      array (
        0 => 'Ключ настройки',
      ),
      'Setting Value' => 
      array (
        0 => 'Заданное значение',
      ),
      'The port %s is in use by another station.' => 
      array (
        0 => 'Порт %s уже используется другой станцией.',
      ),
      'This value is already used.' => 
      array (
        0 => 'Это значение уже используется.',
      ),
      'Storage location %s could not be validated: %s' => 
      array (
        0 => 'Место хранения %s не может быть проверено: %s',
      ),
      'Storage location %s already exists.' => 
      array (
        0 => 'Место хранения %s уже существует.',
      ),
      'Search engine crawlers are not permitted to use this feature.' => 
      array (
        0 => 'Поисковые роботы не могут использовать эту функцию.',
      ),
      'This station does not accept requests currently.' => 
      array (
        0 => 'Эта станция не принимает запросы в настоящее время.',
      ),
      'The song ID you specified could not be found in the station.' => 
      array (
        0 => 'Указанный вами идентификатор песни не найден на станции.',
      ),
      'The song ID you specified cannot be requested for this station.' => 
      array (
        0 => 'Указанный идентификатор песни не может быть запрошен для этой станции.',
      ),
      'You have submitted a request too recently! Please wait before submitting another one.' => 
      array (
        0 => 'Вы недавно отправили запрос! Пожалуйста, подождите, прежде чем отправить ещё один.',
      ),
      'Duplicate request: this song was already requested and will play soon.' => 
      array (
        0 => 'Дубликат запроса: эта песня уже была запрошена и скоро будет играть.',
      ),
      'This song or artist has been played too recently. Wait a while before requesting it again.' => 
      array (
        0 => 'Эта песня или исполнитель проигрывалась совсем недавно. Подождите некоторое время, прежде чем запросить её снова.',
      ),
      'Changes saved successfully.' => 
      array (
        0 => 'Изменения успешно сохранены.',
      ),
      'Record created successfully.' => 
      array (
        0 => '',
      ),
      'Record updated successfully.' => 
      array (
        0 => '',
      ),
      'Record deleted successfully.' => 
      array (
        0 => 'Запись успешно удалена.',
      ),
      'Record not found' => 
      array (
        0 => 'Запись не найдена',
      ),
      'The uploaded file exceeds the upload_max_filesize directive in php.ini.' => 
      array (
        0 => 'Загружаемый файл превышает директиву upload_max_filesize в php.ini.',
      ),
      'The uploaded file exceeds the MAX_FILE_SIZE directive from the HTML form.' => 
      array (
        0 => 'Загружаемый файл превышает директиву MAX_FILE_SIZE из HTML-формы.',
      ),
      'The uploaded file was only partially uploaded.' => 
      array (
        0 => 'Загружаемый файл был загружен только частично.',
      ),
      'No file was uploaded.' => 
      array (
        0 => 'Файл не загружен.',
      ),
      'No temporary directory is available.' => 
      array (
        0 => 'Временный каталог недоступен.',
      ),
      'Could not write to filesystem.' => 
      array (
        0 => 'Не удалось выполнить запись в файловую систему.',
      ),
      'Upload halted by a PHP extension.' => 
      array (
        0 => 'Загрузка остановлена расширением PHP.',
      ),
      'Unspecified error.' => 
      array (
        0 => 'Неопределенная ошибка.',
      ),
      'Playlist: %s' => 
      array (
        0 => '',
      ),
      'Streamer: %s' => 
      array (
        0 => '',
      ),
      'Edit Liquidsoap Configuration' => 
      array (
        0 => 'Редактирование конфигурации Liquidsoap',
      ),
      'Streamers enabled!' => 
      array (
        0 => 'Радиоведущие включены!',
      ),
      'You can now set up streamer (DJ) accounts.' => 
      array (
        0 => 'Теперь вы можете настроить учетные записи ведущих (Диджеев).',
      ),
      'Record not found.' => 
      array (
        0 => 'Запись не найдена.',
      ),
      'Profile' => 
      array (
        0 => 'Профиль',
      ),
      'Automated assignment complete!' => 
      array (
        0 => 'Автоматизированное задание завершено!',
      ),
      'Automated assignment error' => 
      array (
        0 => 'Ошибка автоматического назначения',
      ),
      'Statistics Overview' => 
      array (
        0 => 'Статистика',
      ),
      'SoundExchange Report' => 
      array (
        0 => 'Отчёт SoundExchange',
      ),
      'No episodes found.' => 
      array (
        0 => 'Эпизоды не найдены.',
      ),
      'Episode not found.' => 
      array (
        0 => 'Эпизод не найден.',
      ),
      'Logged in successfully.' => 
      array (
        0 => 'Успешный вход в систему.',
      ),
      'Login unsuccessful' => 
      array (
        0 => 'Неудачный вход',
      ),
      'Your credentials could not be verified.' => 
      array (
        0 => 'Ваши учетные данные не могут быть проверены.',
      ),
      'Too many forgot password attempts' => 
      array (
        0 => 'Слишком много попыток восстановления пароля',
      ),
      'You have attempted to reset your password too many times. Please wait 30 seconds and try again.' => 
      array (
        0 => 'Вы слишком много раз пытались сбросить свой пароль. Пожалуйста, подождите 30 секунд и повторите попытку.',
      ),
      'Account Recovery Link' => 
      array (
        0 => 'Ссылка для восстановления учётной записи',
      ),
      'Account recovery e-mail sent.' => 
      array (
        0 => 'Отправлено письмо для восстановления учётной записи.',
      ),
      'If the e-mail address you provided is in the system, check your inbox for a password reset message.' => 
      array (
        0 => 'Если указанный вами адрес электронной почты присутствует в системе, проверьте почтовый ящик на наличие сообщения для сброса пароля.',
      ),
      'Invalid token specified.' => 
      array (
        0 => 'Указан недопустимый токен.',
      ),
      'Logged in using account recovery token' => 
      array (
        0 => 'Вход выполнен с помощью токена восстановления учётной записи',
      ),
      'Your password has been updated.' => 
      array (
        0 => 'Ваш пароль был обновлён.',
      ),
      'Too many login attempts' => 
      array (
        0 => 'Слишком много попыток входа',
      ),
      'You have attempted to log in too many times. Please wait 30 seconds and try again.' => 
      array (
        0 => 'Вы попытались войти слишком много раз. Пожалуйста, подождите 30 секунд и повторите попытку.',
      ),
      'Complete the setup process to get started.' => 
      array (
        0 => 'Завершите процесс установки, чтобы начать.',
      ),
      'API Key not found.' => 
      array (
        0 => 'API ключ не найден.',
      ),
      'API Key updated.' => 
      array (
        0 => 'API ключ обновлён.',
      ),
      'Edit API Key' => 
      array (
        0 => 'Редактировать API ключ',
      ),
      'Add API Key' => 
      array (
        0 => 'Добавить API ключ',
      ),
      'API Key deleted.' => 
      array (
        0 => 'API ключ удалён.',
      ),
      'Profile saved!' => 
      array (
        0 => 'Профиль сохранен!',
      ),
      'The token you supplied is invalid. Please try again.' => 
      array (
        0 => 'Указанный токен является ошибочным. Пожалуйста, попробуйте еще раз.',
      ),
      'Two-factor authentication enabled.' => 
      array (
        0 => 'Двухфакторная аутентификация включена.',
      ),
      'Two-factor authentication disabled.' => 
      array (
        0 => 'Двухфакторная аутентификация отключена.',
      ),
      'Set Up AzuraCast' => 
      array (
        0 => '',
      ),
      'Setup has already been completed!' => 
      array (
        0 => 'Программа установки завершена!',
      ),
      'Dashboard' => 
      array (
        0 => 'Панель управления',
      ),
      'AzuraCast User' => 
      array (
        0 => 'Пользователь AzuraCast',
      ),
      'This station does not support on-demand streaming.' => 
      array (
        0 => 'Эта станция не поддерживает вещание по требованию.',
      ),
      'Playlist successfully imported; %d of %d files were successfully matched.' => 
      array (
        0 => 'Плейлист успешно импортирован; %d из %d файлов успешно совпадают.',
      ),
      'This playlist is not a sequential playlist.' => 
      array (
        0 => 'Этот плейлист не является последовательным.',
      ),
      'Playlist reshuffled.' => 
      array (
        0 => 'Плейлист перетасован.',
      ),
      'Playlist not found.' => 
      array (
        0 => 'Плейлист не найден.',
      ),
      'Playlist enabled.' => 
      array (
        0 => 'Плейлист включен.',
      ),
      'Playlist disabled.' => 
      array (
        0 => 'Плейлист отключен.',
      ),
      'This station is out of available storage space.' => 
      array (
        0 => 'На этой станции нет свободного места для хранения.',
      ),
      'No directory specified' => 
      array (
        0 => 'Папка не указана',
      ),
      'File not specified.' => 
      array (
        0 => 'Файл не указан.',
      ),
      'New path not specified.' => 
      array (
        0 => 'Новый путь не указан.',
      ),
      'File Not Processed: %s' => 
      array (
        0 => 'Файл не обработан: %s',
      ),
      'File Processing' => 
      array (
        0 => 'Обработка файла',
      ),
      'Station restarted.' => 
      array (
        0 => 'Станция перезапущена.',
      ),
      'Frontend stopped.' => 
      array (
        0 => 'Интерфейс остановлен.',
      ),
      'Frontend started.' => 
      array (
        0 => 'Интерфейс запущен.',
      ),
      'Frontend restarted.' => 
      array (
        0 => 'Интерфейс перезапущен.',
      ),
      'Song skipped.' => 
      array (
        0 => 'Композиция пропущена.',
      ),
      'Streamer disconnected.' => 
      array (
        0 => 'Радиоведущий отключен.',
      ),
      'Backend stopped.' => 
      array (
        0 => 'Системный сервис остановлен.',
      ),
      'Backend started.' => 
      array (
        0 => 'Системный сервис запущен.',
      ),
      'Backend restarted.' => 
      array (
        0 => 'Системный сервис перезапущен.',
      ),
      'Web hook not found.' => 
      array (
        0 => '',
      ),
      'Web hook enabled.' => 
      array (
        0 => 'Веб-хук включен.',
      ),
      'Web hook disabled.' => 
      array (
        0 => '',
      ),
      'Podcast not found!' => 
      array (
        0 => 'Подкаст не найден!',
      ),
      'No recording available.' => 
      array (
        0 => 'Нет доступных записей.',
      ),
      'All Stations' => 
      array (
        0 => 'Все станции',
      ),
      'You cannot remove yourself.' => 
      array (
        0 => 'Вы не можете удалить себя.',
      ),
      'Create a new storage location based on the base directory.' => 
      array (
        0 => 'Создать новое место хранения на основе базового каталога.',
      ),
      'Liquidsoap Log' => 
      array (
        0 => 'Liquidsoap - Журнал',
      ),
      'Liquidsoap Configuration' => 
      array (
        0 => 'Liquidsoap - Настройки',
      ),
      'Icecast Access Log' => 
      array (
        0 => 'Icecast - Журнал доступа',
      ),
      'Icecast Error Log' => 
      array (
        0 => 'Icecast - Журнал ошибок',
      ),
      'Icecast Configuration' => 
      array (
        0 => 'Icecast - Настройки',
      ),
      'SHOUTcast Log' => 
      array (
        0 => 'SHOUTcast - Журнал',
      ),
      'SHOUTcast Configuration' => 
      array (
        0 => 'SHOUTcast - Настройки',
      ),
      'User updated.' => 
      array (
        0 => 'Пользователь обновлен.',
      ),
      'User added.' => 
      array (
        0 => 'Пользователь добавлен.',
      ),
      'Another user already exists with this e-mail address. Please update the e-mail address.' => 
      array (
        0 => 'Другой пользователь уже существует с этим адресом электронной почты. Пожалуйста, обновите адрес электронной почты.',
      ),
      'Edit User' => 
      array (
        0 => 'Редактирование Пользователя',
      ),
      'Add User' => 
      array (
        0 => 'Добавить Пользователя',
      ),
      'You cannot delete your own account.' => 
      array (
        0 => 'Вы не можете удалить свой собственный аккаунт.',
      ),
      'User deleted.' => 
      array (
        0 => 'Пользователь удалён.',
      ),
      'User not found.' => 
      array (
        0 => 'Пользователь не найден.',
      ),
      'AzuraCast Application Log' => 
      array (
        0 => 'AzuraCast - Журнал',
      ),
      'Nginx Access Log' => 
      array (
        0 => 'Nginx - Журнал доступа',
      ),
      'Nginx Error Log' => 
      array (
        0 => 'Nginx - Журнал ошибок',
      ),
      'PHP Application Log' => 
      array (
        0 => 'PHP - Журнал',
      ),
      'Supervisord Log' => 
      array (
        0 => 'Supervisord - Журнал',
      ),
      'Album Artist Sort Order' => 
      array (
        0 => 'Порядок сортировки исполнителя альбома',
      ),
      'Album Sort Order' => 
      array (
        0 => 'Порядок сортировки альбомов',
      ),
      'Band' => 
      array (
        0 => 'Группа',
      ),
      'Bpm' => 
      array (
        0 => 'Bpm',
      ),
      'Comment' => 
      array (
        0 => 'Комментарий',
      ),
      'Commercial Information' => 
      array (
        0 => 'Коммерческая информация',
      ),
      'Composer' => 
      array (
        0 => 'Композитор',
      ),
      'Composer Sort Order' => 
      array (
        0 => 'Порядок сортировки композитора',
      ),
      'Conductor' => 
      array (
        0 => 'Дирижёр',
      ),
      'Content Group Description' => 
      array (
        0 => 'Описание Группы Содержимого',
      ),
      'Copyright' => 
      array (
        0 => 'Авторские права',
      ),
      'Copyright Message' => 
      array (
        0 => 'Сообщение об авторских правах',
      ),
      'Encoded By' => 
      array (
        0 => 'Кодирование',
      ),
      'Encoder Settings' => 
      array (
        0 => 'Настройки кодера',
      ),
      'Encoding Time' => 
      array (
        0 => 'Время кодирования',
      ),
      'File Owner' => 
      array (
        0 => 'Владелец файла',
      ),
      'File Type' => 
      array (
        0 => 'Тип файла',
      ),
      'Initial Key' => 
      array (
        0 => 'Первичный Ключ',
      ),
      'Internet Radio Station Name' => 
      array (
        0 => 'Название интернет-радиостанции',
      ),
      'Internet Radio Station Owner' => 
      array (
        0 => 'Владелец интернет-радиостанции',
      ),
      'Involved People List' => 
      array (
        0 => 'Список участников',
      ),
      'Linked Information' => 
      array (
        0 => 'Связанная информация',
      ),
      'Lyricist' => 
      array (
        0 => 'Автор текстов',
      ),
      'Media Type' => 
      array (
        0 => 'Тип медиа',
      ),
      'Mood' => 
      array (
        0 => 'Настроение',
      ),
      'Music CD Identifier' => 
      array (
        0 => 'Идентификатор CD',
      ),
      'Musician Credits List' => 
      array (
        0 => 'Список Заслуг Музыкантов',
      ),
      'Original Album' => 
      array (
        0 => 'Первоначальный Альбом',
      ),
      'Original Artist' => 
      array (
        0 => 'Первоначальный Исполнитель',
      ),
      'Original Filename' => 
      array (
        0 => 'Первоначальное Название Файла',
      ),
      'Original Lyricist' => 
      array (
        0 => 'Первоначальный Автор Текстов',
      ),
      'Original Release Time' => 
      array (
        0 => 'Первоначальное Время Выпуска',
      ),
      'Original Year' => 
      array (
        0 => 'Первоначальный Год',
      ),
      'Part Of A Compilation' => 
      array (
        0 => 'Часть Компиляции',
      ),
      'Part Of A Set' => 
      array (
        0 => 'Часть Набора',
      ),
      'Performer Sort Order' => 
      array (
        0 => 'Порядок сортировки исполнителя',
      ),
      'Playlist Delay' => 
      array (
        0 => 'Задержка воспроизведения',
      ),
      'Produced Notice' => 
      array (
        0 => 'Оповещение о создании',
      ),
      'Publisher' => 
      array (
        0 => 'Издатель',
      ),
      'Recording Time' => 
      array (
        0 => 'Время записи',
      ),
      'Release Time' => 
      array (
        0 => 'Время Выпуска',
      ),
      'Remixer' => 
      array (
        0 => 'Ремиксер',
      ),
      'Set Subtitle' => 
      array (
        0 => 'Установленные субтитры',
      ),
      'Subtitle' => 
      array (
        0 => 'Субтитры',
      ),
      'Tagging Time' => 
      array (
        0 => 'Время Тегирования',
      ),
      'Terms Of Use' => 
      array (
        0 => 'Условия использования',
      ),
      'Title Sort Order' => 
      array (
        0 => 'Сортировка по названию',
      ),
      'Track Number' => 
      array (
        0 => 'Номер трека',
      ),
      'Unsynchronised Lyric' => 
      array (
        0 => 'Несинхронизированный текст',
      ),
      'URL Artist' => 
      array (
        0 => 'Ссылка на Исполнителя',
      ),
      'URL File' => 
      array (
        0 => 'Ссылка на Файл',
      ),
      'URL Payment' => 
      array (
        0 => 'Ссылка на оплату',
      ),
      'URL Publisher' => 
      array (
        0 => 'Ссылка на Издателя',
      ),
      'URL Source' => 
      array (
        0 => 'Ссылка на Первоисточник',
      ),
      'URL Station' => 
      array (
        0 => 'Ссылка на Станцию',
      ),
      'URL User' => 
      array (
        0 => 'Ссылка на Пользователя',
      ),
      'Year' => 
      array (
        0 => 'Год',
      ),
      'Run Synchronized Task' => 
      array (
        0 => 'Выполнение Задачи Синхронизации',
      ),
      'Debug Output' => 
      array (
        0 => 'Отладочный вывод',
      ),
      'Configure Backups' => 
      array (
        0 => 'Настройка резервных копий',
      ),
      'Run Manual Backup' => 
      array (
        0 => 'Запуск Резервного Копирования Вручную',
      ),
      'Backup deleted.' => 
      array (
        0 => 'Резервная копия удалена.',
      ),
      'Backup not found.' => 
      array (
        0 => 'Резервная копия не найдена.',
      ),
      'Are you sure?' => 
      array (
        0 => 'Вы уверены?',
      ),
      'Enter a password to continue.' => 
      array (
        0 => 'Введите пароль, чтобы продолжить.',
      ),
      'No problems detected.' => 
      array (
        0 => 'Проблем не обнаружено.',
      ),
      'Generate the translation locale file.' => 
      array (
        0 => 'Создание файла локализации перевода.',
      ),
      'Convert translated locale files into PHP arrays.' => 
      array (
        0 => 'Преобразование переведенных файлов локализации в PHP массивы.',
      ),
      'Ensure key settings are initialized within AzuraCast.' => 
      array (
        0 => 'Убедитесь, что ключевые настройки инициализированы в AzuraCast.',
      ),
      'Migrate existing configuration to new INI format if any exists.' => 
      array (
        0 => 'Перенос существующей конфигурации в новый формат INI, если таковой существует.',
      ),
      'Install fixtures for demo / local development.' => 
      array (
        0 => 'Установка модификатора для демонстрации / локальной разработки.',
      ),
      'Run all general AzuraCast setup steps.' => 
      array (
        0 => 'Выполните все действия по установке AzuraCast.',
      ),
      'Run one or more scheduled synchronization tasks.' => 
      array (
        0 => 'Выполните одну или несколько запланированных задач синхронизации.',
      ),
      'Process the message queue.' => 
      array (
        0 => 'Обработать очередь сообщений.',
      ),
      'Clear the contents of the message queue.' => 
      array (
        0 => 'Очистить содержимое очереди сообщений.',
      ),
      'List all settings in the AzuraCast settings database.' => 
      array (
        0 => 'Список всех параметров в базе данных настроек AzuraCast.',
      ),
      'Back up the AzuraCast database and statistics (and optionally media).' => 
      array (
        0 => 'Резервное копирование базы данных и статистики AzuraCast (и при необходимости медиафайлов).',
      ),
      'System Maintenance' => 
      array (
        0 => 'Система',
      ),
      'System Logs' => 
      array (
        0 => 'Системные журналы',
      ),
      'System Debugger' => 
      array (
        0 => 'Системный отладчик',
      ),
      'Users' => 
      array (
        0 => 'Пользователи',
      ),
      'User Accounts' => 
      array (
        0 => 'Учетные записи пользователей',
      ),
      'API Keys' => 
      array (
        0 => 'Ключи API',
      ),
      'Connected AzuraRelays' => 
      array (
        0 => 'Подключение AzuraRelays',
      ),
      'Install SHOUTcast' => 
      array (
        0 => 'Установка SHOUTcast',
      ),
      'Start Station' => 
      array (
        0 => 'Запуск Станции',
      ),
      'Ready to start broadcasting? Click to start your station.' => 
      array (
        0 => 'Готовы начать вещание? Нажмите, чтобы запустить станцию.',
      ),
      'Restart broadcasting? This will disconnect any current listeners.' => 
      array (
        0 => 'Перезапустить вещание? Это отключит любых текущих слушателей.',
      ),
      'Restart to Apply Changes' => 
      array (
        0 => 'Перезапустить для Применения',
      ),
      'Click to restart your station and apply configuration changes.' => 
      array (
        0 => 'Нажмите, чтобы перезагрузить станцию и применить изменения конфигурации.',
      ),
      'Podcasts (Beta)' => 
      array (
        0 => 'Подкасты (бета)',
      ),
      'Reports' => 
      array (
        0 => 'Отчеты',
      ),
      'Duplicate Songs' => 
      array (
        0 => 'Дубликаты песен',
      ),
      'Unprocessable Files' => 
      array (
        0 => 'Необработанные файлы',
      ),
      'SoundExchange Royalties' => 
      array (
        0 => 'Роялти SoundExchange',
      ),
      'Utilities' => 
      array (
        0 => 'Инструменты',
      ),
      'Automated Assignment' => 
      array (
        0 => 'Автоматическое назначение',
      ),
      'Log Viewer' => 
      array (
        0 => 'Просмотр журналов',
      ),
      'Restart Broadcasting' => 
      array (
        0 => 'Перезапустить вещание',
      ),
      'Enable Automated Assignment' => 
      array (
        0 => 'Включить Автоматическое Назначение',
      ),
      'Allow the system to periodically automatically assign songs to playlists based on their performance. This process will run in the background, and will only run if this option is set to "Enabled" and at least one playlist is set to "Include in Automated Assignment".' => 
      array (
        0 => 'Разрешить системе периодически автоматически назначать песни для плейлистов на основе их производительности. Этот процесс будет работать в фоновом режиме и будет выполняться только в том случае, если для этой опции установлено значение «Включено», и хотя бы для одного плейлиста установлено значение «Включить в Автоматическое Назначение».',
      ),
      'Days Between Automated Assignments' => 
      array (
        0 => 'Дни Между Автоматическими Назначениями',
      ),
      'Based on this setting, the system will automatically reassign songs every (this) days using data from the previous (this) days.' => 
      array (
        0 => 'Исходя из этого параметра, система будет автоматически переназначать песни каждый (этот) день, используя данные из предыдущих (этих) дней.',
      ),
      '%d days' => 
      array (
        0 => '%d дней',
      ),
      'Use Browser Default' => 
      array (
        0 => 'Использовать по умолчанию',
      ),
      'Reset Password' => 
      array (
        0 => 'Сброс Пароля',
      ),
      'Leave these fields blank to continue using your current password.' => 
      array (
        0 => 'Оставьте эти поля пустыми, чтобы продолжить использовать текущий пароль.',
      ),
      'Current Password' => 
      array (
        0 => 'Текущий пароль',
      ),
      'Confirm New Password' => 
      array (
        0 => 'Подтвердите новый пароль',
      ),
      'Customization' => 
      array (
        0 => 'Настройка',
      ),
      'Site Theme' => 
      array (
        0 => 'Тема сайта',
      ),
      'Describe the use-case for this API key for future reference.' => 
      array (
        0 => 'Опишите вариант использования этого ключа API для будущего ориентира.',
      ),
      'Storage Location' => 
      array (
        0 => 'Места Хранения',
      ),
      'Backup Filename' => 
      array (
        0 => 'Название файла резервной копии',
      ),
      'This will be the file name for your backup, include the file type (.zip or .rar) you wish to use.' => 
      array (
        0 => 'Это будет название файла для вашей резервной копии, включая тип файла (.zip или .rar), который вы хотите использовать.',
      ),
      'Exclude Media from Backup' => 
      array (
        0 => 'Исключить медиафайлы из резервной копии',
      ),
      'This will produce a significantly smaller backup, but you should make sure to back up your media elsewhere. Note that only locally stored media will be backed up.' => 
      array (
        0 => 'Исключение медиафайлов позволит создать резервную копию значительно меньшего размера, но убедитесь, что резервная копия ваших медиафайлов имеется в другом месте. Заметьте, что будет выполнено резервное копирование только локально хранящихся медиафайлов.',
      ),
      'Yes' => 
      array (
        0 => 'Да',
      ),
      'No' => 
      array (
        0 => 'Нет',
      ),
      'Run Automatic Nightly Backups' => 
      array (
        0 => 'Запустить автоматическое ночное резервное копирование',
      ),
      'Enable to have AzuraCast automatically run nightly backups at the time specified.' => 
      array (
        0 => 'Включите, чтобы AzuraCast автоматически запускал ночное резервное копирование в указанное время.',
      ),
      'Scheduled Backup Time' => 
      array (
        0 => 'Запланированное время резервного копирования',
      ),
      'The time (in UTC) to run the automated backup, if enabled.' => 
      array (
        0 => 'Время (в UTC) для запуска автоматического резервного копирования, если включено.',
      ),
      'Exclude Media from Backups' => 
      array (
        0 => 'Исключить медиафайлы из резервных копий',
      ),
      'Excluding media from automated backups will save space, but you should make sure to back up your media elsewhere. Note that only locally stored media will be backed up.' => 
      array (
        0 => 'Исключение медиафайлов из автоматического резервного копирования позволит сэкономить место, но вы должны сделать резервную копию медиафайлов в другом месте. Заметьте, что будет выполнено резервное копирование только локально хранящихся медиафайлов.',
      ),
      'Number of Backup Copies to Keep' => 
      array (
        0 => 'Количество резервных копий для сохранения',
      ),
      'Copies older than the specified number of days will automatically be deleted. Set to zero to disable automatic deletion.' => 
      array (
        0 => 'Копии старше указанного количества дней будут автоматически удалены. Установите ноль, чтобы отключить автоматическое удаление.',
      ),
      'Attempt to Automatically Retrieve ISRC When Missing' => 
      array (
        0 => 'Если отсутствует, попытка автоматического получения ISRC',
      ),
      'If enabled, AzuraCast will connect to the MusicBrainz database to attempt to find an ISRC for any files where one is missing. Disabling this may improve performance.' => 
      array (
        0 => 'Если этот параметр включен, AzuraCast будет подключаться к базе данных MusicBrainz, чтобы попытаться найти ISRC для любых файлов, где он отсутствует. Отключение этой опции может повысить производительность.',
      ),
      'Roles' => 
      array (
        0 => 'Роли',
      ),
      'Code from Authenticator App' => 
      array (
        0 => 'Код из приложения Аутентификации',
      ),
      'Enter the current code provided by your authenticator app to verify that it\'s working correctly.' => 
      array (
        0 => 'Введите текущий код, предоставленный вашим приложением-аутентификатором, чтобы убедиться, что он работает правильно.',
      ),
      'Verify Authenticator' => 
      array (
        0 => 'Проверка подлинности',
      ),
      'Any time the currently playing song changes' => 
      array (
        0 => 'Каждый раз, когда текущая играющая песня меняется',
      ),
      'Any time the listener count increases' => 
      array (
        0 => 'Каждый раз, когда количество слушателей увеличивается',
      ),
      'Any time the listener count decreases' => 
      array (
        0 => 'Каждый раз, когда количество слушателей уменьшается',
      ),
      'Any time a live streamer/DJ connects to the stream' => 
      array (
        0 => 'Каждый раз, когда Ведущий/Диджей для эфира подключается к потоку',
      ),
      'Any time a live streamer/DJ disconnects from the stream' => 
      array (
        0 => 'Каждый раз, когда Ведущий/Диджей отключается от потока',
      ),
      'When the station broadcast goes offline.' => 
      array (
        0 => 'Когда радиостанция переходит в офлайн.',
      ),
      'When the station broadcast comes online.' => 
      array (
        0 => 'Когда радиостанция выходит в эфир.',
      ),
      'Generic Web Hook' => 
      array (
        0 => 'Универсальный веб-хук',
      ),
      'Automatically send a message to any URL when your station data changes.' => 
      array (
        0 => 'Автоматическая отправка сообщения на любой URL-адрес при изменении данных станции.',
      ),
      'Send E-mail' => 
      array (
        0 => 'Отправить E-mail',
      ),
      'Send an e-mail to specified address(es).' => 
      array (
        0 => 'Отправить письмо на указанный адрес(ы).',
      ),
      'TuneIn AIR' => 
      array (
        0 => 'TuneIn AIR',
      ),
      'Send song metadata changes to TuneIn.' => 
      array (
        0 => 'Отправить изменения метаданных песни в TuneIn.',
      ),
      'Discord Webhook' => 
      array (
        0 => 'URL веб-хука Discord',
      ),
      'Automatically send a customized message to your Discord server.' => 
      array (
        0 => 'Автоматически отправить настраиваемое сообщение на ваш сервер Discord.',
      ),
      'Telegram Chat Message' => 
      array (
        0 => 'Сообщение чата Telegram',
      ),
      'Use the Telegram Bot API to send a message to a channel.' => 
      array (
        0 => 'Используйте Telegram Bot API для отправки сообщения на канал.',
      ),
      'Twitter Post' => 
      array (
        0 => 'Пост в Твиттере',
      ),
      'Automatically send a tweet.' => 
      array (
        0 => 'Автоматически отправлять твит.',
      ),
      'Google Analytics Integration' => 
      array (
        0 => 'Интеграция с Google Analytics',
      ),
      'Send stream listener details to Google Analytics.' => 
      array (
        0 => 'Отправьте сведения о слушателе потока в Google Analytics.',
      ),
      'Matomo Analytics Integration' => 
      array (
        0 => 'Интеграция с Matomo Analytics',
      ),
      'Send stream listener details to Matomo Analytics.' => 
      array (
        0 => 'Отправка информации о слушателе потока в Matomo Analytics.',
      ),
      'Account Recovery' => 
      array (
        0 => 'Восстановление Учётной Записи',
      ),
      'An account recovery link has been requested for your account on "%s".' => 
      array (
        0 => 'Ссылка на восстановление учетной записи была запрошена для вашей учетной записи на "%s".',
      ),
      'Click the link below to log in to your account.' => 
      array (
        0 => 'Нажмите на ссылку ниже, чтобы войти в свою учётную запись.',
      ),
      'Skip to main content' => 
      array (
        0 => 'Перейти к основному содержанию',
      ),
      'Toggle Sidebar' => 
      array (
        0 => 'Переключить боковую панель',
      ),
      'Toggle Menu' => 
      array (
        0 => 'Переключить Меню',
      ),
      'System Administration' => 
      array (
        0 => 'Администрирование',
      ),
      'Switch Theme' => 
      array (
        0 => 'Сменить Тему',
      ),
      'My API Keys' => 
      array (
        0 => 'Мои API ключи',
      ),
      'Help' => 
      array (
        0 => 'Помощь',
      ),
      'End Session' => 
      array (
        0 => 'Выйти',
      ),
      'Sign Out' => 
      array (
        0 => 'Выйти',
      ),
      'Powered by %s' => 
      array (
        0 => 'Разработано %s',
      ),
      'Like our software? <a href="%s" target="_blank">Donate to support AzuraCast!</a>' => 
      array (
        0 => 'Понравилось наше программное обеспечение? <a href="%s" target="_blank">Пожертвуйте, на поддержку AzuraCast!</a>',
      ),
      'Errors were encountered when trying to save changes:' => 
      array (
        0 => 'При попытке сохранить изменения произошли ошибки:',
      ),
      'General' => 
      array (
        0 => 'Главная',
      ),
      'Details' => 
      array (
        0 => 'Подробности',
      ),
      'Server Status' => 
      array (
        0 => 'Статус Сервера',
      ),
      'CPU Load' => 
      array (
        0 => 'Загрузка ЦП',
      ),
      'Current' => 
      array (
        0 => 'Текущее',
      ),
      '15-Minute Average' => 
      array (
        0 => 'Среднее за 15 минут',
      ),
      'Memory' => 
      array (
        0 => 'Память',
      ),
      '%s of %s Used' => 
      array (
        0 => 'Используется %s из %s',
      ),
      'Disk Space' => 
      array (
        0 => 'Место на диске',
      ),
      'Synchronization Tasks' => 
      array (
        0 => 'Задачи синхронизации',
      ),
      'Last run: %s' => 
      array (
        0 => 'Последний запуск: %s',
      ),
      'Run Task' => 
      array (
        0 => 'Выполнить задачу',
      ),
      'API Key' => 
      array (
        0 => 'Ключ API',
      ),
      'Owner' => 
      array (
        0 => 'Владелец',
      ),
      'Revoke' => 
      array (
        0 => 'Отменить',
      ),
      'Clear Cache' => 
      array (
        0 => 'Очистить кэш',
      ),
      'Clearing the application cache may log you out of your session.' => 
      array (
        0 => 'Очистка кэша приложения может привести к выходу из сеанса.',
      ),
      'Clear All Message Queues' => 
      array (
        0 => 'Очистить все очереди сообщений',
      ),
      'This will clear any pending unprocessed messages in all message queues.' => 
      array (
        0 => 'Очистка всех ожидающих необработанных сообщений в очереди сообщений.',
      ),
      'Message Queues' => 
      array (
        0 => 'Очереди сообщений',
      ),
      '%d queued messages' => 
      array (
        0 => '%d сообщений в очереди',
      ),
      'Station-Specific Debugging' => 
      array (
        0 => 'Отладка для конкретной станции',
      ),
      'Rebuild AutoDJ Queue' => 
      array (
        0 => 'Перестроить очередь АвтоДиджея',
      ),
      'Run Test' => 
      array (
        0 => 'Выполнить Задачу',
      ),
      'Send Liquidsoap Telnet Command' => 
      array (
        0 => 'Отправить команду Liquidsoap Telnet',
      ),
      'Command' => 
      array (
        0 => 'Команда',
      ),
      'Execute Command' => 
      array (
        0 => 'Выполнить команду',
      ),
      'Run Synchronization Task' => 
      array (
        0 => 'Выполнение Задачи Синхронизации',
      ),
      'Debug Home' => 
      array (
        0 => 'Страница отладки',
      ),
      'The synchronization task is running in the background. The log below will update automatically.' => 
      array (
        0 => 'Задача синхронизации выполняется в фоновом режиме. Журнал ниже будет обновляться автоматически.',
      ),
      'Log In' => 
      array (
        0 => 'Войти',
      ),
      'Delete user "%s"?' => 
      array (
        0 => 'Удалить пользователя "%s"?',
      ),
      '(You)' => 
      array (
        0 => '(Вы)',
      ),
      'Because you are running Docker, some system logs can only be accessed from a shell session on the host computer. You can run <code>%s</code> to access container logs from the terminal.' => 
      array (
        0 => 'Поскольку вы используете Docker, доступ к некоторым системным журналам возможен только с shell session на компьютере хоста. Вы можете запустить <code>%s</code> для доступа к журналам контейнеров из терминала.',
      ),
      'Logs by Station' => 
      array (
        0 => 'Системные Журналы Станций',
      ),
      'Relay' => 
      array (
        0 => 'Ретранслятор',
      ),
      'Is Public' => 
      array (
        0 => 'Публичный',
      ),
      'First Connected' => 
      array (
        0 => 'Первое Подключение',
      ),
      'Latest Update' => 
      array (
        0 => 'Последнее Обновление',
      ),
      'Backups Home' => 
      array (
        0 => 'Резервные копии Главная',
      ),
      'The backup process is running in the background. The log below will update automatically.' => 
      array (
        0 => 'Процесс резервного копирования выполняется в фоновом режиме. Журнал ниже будет обновляться автоматически.',
      ),
      'Automatic Backups' => 
      array (
        0 => 'Автоматическое Резервное Копирование',
      ),
      'Never run' => 
      array (
        0 => 'Никогда не запускалось',
      ),
      'Configure' => 
      array (
        0 => 'Настроить',
      ),
      'Most Recent Backup Log' => 
      array (
        0 => 'Журнал Последнего Резервного Копирования',
      ),
      'Restoring Backups' => 
      array (
        0 => 'Восстановление резервных копий',
      ),
      'To restore a backup from your host computer, run:' => 
      array (
        0 => 'Чтобы восстановить резервную копию на вашем сервере, выполните:',
      ),
      'Note that restoring a backup will clear your existing database. Never restore backup files from untrusted users.' => 
      array (
        0 => 'Обратите внимание, что восстановление резервной копии очистит вашу существующую базу данных. Никогда не восстанавливайте файлы резервных копий от ненадежных пользователей.',
      ),
      'Backup' => 
      array (
        0 => 'Резервная копия',
      ),
      'Last Modified' => 
      array (
        0 => 'Последнее Изменение',
      ),
      'Delete backup "%s"?' => 
      array (
        0 => 'Удалить резервную копию "%s"?',
      ),
      'Report Not Available' => 
      array (
        0 => 'Отчет недоступен',
      ),
      'This report is not available for this station, because the system administrator has chosen not to collect detailed IP-based listener information.' => 
      array (
        0 => 'Этот отчет недоступен для этой станции, поскольку системный администратор решил не собирать подробную информацию о слушателе на основе IP-адреса.',
      ),
      'Station Broadcasting Disabled' => 
      array (
        0 => 'Вещание станции отключено',
      ),
      'Your station is currently not enabled for broadcasting. You can still manage media, playlists, and other station settings. To re-enable broadcasting, <a href="%s">edit your station profile</a>.' => 
      array (
        0 => 'Ваша станция в настоящее время не включена для вещания. Вы можете управлять медиафайлами, плейлистами и другими настройками станции. Чтобы включить вещание, <a href="%s">отредактируйте профиль станции</a>.',
      ),
      'Available Logs' => 
      array (
        0 => 'Доступные журналы',
      ),
      'Station Time' => 
      array (
        0 => 'Время станции',
      ),
      'Automated Playlist Assignment' => 
      array (
        0 => 'Автоматическое Назначение Плейлистам',
      ),
      'Based on the previous performance of your station\'s songs, %s can automatically distribute songs evenly among your playlists, placing the highest performing songs in the highest-weighted playlists.' => 
      array (
        0 => 'Основываясь на предыдущем исполнении песен вашей станции, %s может автоматически распределять песни равномерно между вашими плейлистами, помещая песни с самыми высокими показателями в плейлисты с наибольшим весом.',
      ),
      'Once you have configured automated assignment, click the button below to run the automated assignment process. This process will not run at all unless you have selected "Enable" below.' => 
      array (
        0 => 'После настройки автоматического назначения нажмите кнопку ниже, чтобы запустить процесс автоматического назначения. Этот процесс не будет выполняться вообще, если вы не выбрали "включить" ниже.',
      ),
      'Run Automated Assignment' => 
      array (
        0 => 'Запустить автоматическое назначение',
      ),
      'Configure Automated Assignment' => 
      array (
        0 => 'Настройка Автоматического Назначения',
      ),
      'Streamer accounts are currently disabled for this station. To enable streamer accounts, click the button below.' => 
      array (
        0 => 'Аккаунты радиоведущих в данный момент отключены для этой станции. Чтобы включить их, нажмите на кнопку ниже.',
      ),
      'Enable Streaming' => 
      array (
        0 => 'Включить трансляцию',
      ),
      'Two-Factor Authentication' => 
      array (
        0 => 'Двухфакторная аутентификация',
      ),
      'Two-factor authentication improves the security of your account by requiring a second one-time access code in addition to your password when you log in.' => 
      array (
        0 => 'Двухфакторная проверка подлинности повышает безопасность вашей учетной записи, требуя второй разовый код доступа в дополнение к вашему паролю при входе в систему.',
      ),
      'Disable Two-Factor' => 
      array (
        0 => 'Отключить Двухфакторную',
      ),
      'Enable Two-Factor' => 
      array (
        0 => 'Включить Двухфакторную',
      ),
      'Enable Two-Factor Authentication' => 
      array (
        0 => 'Включить двухфакторную аутентификацию',
      ),
      'Step 1: Scan QR Code' => 
      array (
        0 => 'Шаг 1: Сканировать QR-код',
      ),
      'From your smartphone, scan the code to the right using an authentication app of your choice (FreeOTP, Authy, etc).' => 
      array (
        0 => 'С вашего смартфона, сканируйте код справа, используя приложение аутентификации по вашему выбору (FreeOTP, Authy и т.д.).',
      ),
      'Step 2: Verify Generated Code' => 
      array (
        0 => 'Шаг 2: Подтвердить сгенерированный код',
      ),
      'To verify that the code was set up correctly, enter the 6-digit code the app shows you.' => 
      array (
        0 => 'Чтобы проверить правильность установки кода, введите 6-значный код, который приложение покажет вам.',
      ),
      'QR-Code' => 
      array (
        0 => 'QR-код',
      ),
      'No entries found.' => 
      array (
        0 => 'Записей не найдено.',
      ),
      'View Details' => 
      array (
        0 => 'Подробности',
      ),
      'New Key Generated' => 
      array (
        0 => 'Создан новый ключ',
      ),
      '<b>Important: copy the key below before continuing!</b> You will not be able to retrieve it again.' => 
      array (
        0 => '<b>Важно: скопируйте ключ ниже перед продолжением!</b> Вы не сможете его снова получить.',
      ),
      'Your full API key is below:' => 
      array (
        0 => 'Ваш полный API ключ ниже:',
      ),
      'When making API calls, you can pass this value in the "X-API-Key" header to authenticate as yourself. You can only perform the actions your user account is allowed to perform.' => 
      array (
        0 => 'При вызове API вы можете передать это значение в заголовке "X-API-Key", чтобы аутентифицировать себя. Вы можете выполнять только те действия, которые разрешено выполнять вашей учетной записи.',
      ),
      'Continue' => 
      array (
        0 => 'Продолжить',
      ),
      'API keys can be used to access some system functionality without needing to log in. All of the keys
            you create share your permissions in the system. For more information, see the <a href="%s">API documentation</a>.' => 
      array (
        0 => 'Ключи API можно использовать для доступа к некоторым функциям системы без необходимости входа в систему. Все ключи
            которые вы создаете получают ваши права доступа в системе. Для получения дополнительной информации смотрите <a href="%s">документацию по API</a>.',
      ),
      'Key Identifier' => 
      array (
        0 => 'Идентификатор ключа',
      ),
      'Enter Two-Factor Code' => 
      array (
        0 => 'Введите двухфакторный код',
      ),
      'Your account uses a two-factor security code. Enter the code your device is currently showing below.' => 
      array (
        0 => 'Ваш аккаунт использует двухфакторный код безопасности. Введите код, который ваше устройство в настоящее время показывает ниже.',
      ),
      'Security Code' => 
      array (
        0 => 'Код безопасности',
      ),
      'Sign in' => 
      array (
        0 => 'Войти',
      ),
      'Forgot Password' => 
      array (
        0 => 'Забыл Пароль',
      ),
      'name@example.com' => 
      array (
        0 => 'name@example.com',
      ),
      'Send Recovery E-mail' => 
      array (
        0 => 'Отправить письмо для восстановления',
      ),
      'Welcome!' => 
      array (
        0 => 'Добро пожаловать!',
      ),
      'Welcome to %s!' => 
      array (
        0 => 'Добро пожаловать в %s!',
      ),
      'Enter your password' => 
      array (
        0 => 'Введите свой пароль',
      ),
      'Remember me' => 
      array (
        0 => 'Запомнить меня',
      ),
      'Please log in to continue.' => 
      array (
        0 => 'Пожалуйста, войдите чтобы продолжить.',
      ),
      'Forgot your password?' => 
      array (
        0 => 'Забыли пароль?',
      ),
      'This installation\'s administrator has not configured this functionality.' => 
      array (
        0 => 'Администратор установки не настроил эту функцию.',
      ),
      'Contact an administrator to reset your password following the instructions in our documentation:' => 
      array (
        0 => 'Обратитесь к администратору, чтобы сбросить пароль, следуя инструкциям в нашей документации:',
      ),
      'Password Reset Instructions' => 
      array (
        0 => 'Инструкции по сбросу пароля',
      ),
      'Recover Account' => 
      array (
        0 => 'Восстановление Учётной Записи',
      ),
      'Choose a new password for your account.' => 
      array (
        0 => 'Выберите новый пароль для своей учётной записи.',
      ),
      'Automatically scroll to the bottom of the log' => 
      array (
        0 => 'Автоматическая прокрутка до нижней части журнала',
      ),
      'Need Help?' => 
      array (
        0 => 'Нужна помощь?',
      ),
      'You can find answers for many common questions in our <a href="%s" target="_blank">support documents</a>.' => 
      array (
        0 => 'Вы можете найти ответы на многие распространенные вопросы в наших <a href="%s" target="_blank">документах поддержки</a>.',
      ),
      'If you\'re experiencing a bug or error, you can submit a GitHub issue using the link below.' => 
      array (
        0 => 'Если вы столкнулись с неполадкой или ошибкой, вы можете отправить запрос на GitHub с помощью ссылки ниже.',
      ),
      'Your current installation type is <b>%s</b>. Be sure to include this when creating a new issue.' => 
      array (
        0 => 'Ваш текущий тип установки <b>%s</b>. Обязательно включите это при создании нового запроса.',
      ),
      'Add New GitHub Issue' => 
      array (
        0 => 'Новый запрос на GitHub',
      ),
    ),
  ),
);