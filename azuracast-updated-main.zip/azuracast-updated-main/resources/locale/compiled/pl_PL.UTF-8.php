<?php return array (
  'domain' => NULL,
  'plural-forms' => 'nplurals=4; plural=(n==1 ? 0 : (n%10>=2 && n%10<=4) && (n%100<12 || n%100>14) ? 1 : n!=1 && (n%10>=0 && n%10<=1) || (n%10>=5 && n%10<=9) || (n%100>=12 && n%100<=14) ? 2 : 3);',
  'messages' => 
  array (
    '' => 
    array (
      '' => 
      array (
        0 => 'Project-Id-Version: azuracast
Report-Msgid-Bugs-To: 
Last-Translator: 
Language-Team: Polish
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
POT-Creation-Date: 2021-10-27T06:14:10+00:00
PO-Revision-Date: 2021-10-27 07:09
Language: pl_PL
Plural-Forms: nplurals=4; plural=(n==1 ? 0 : (n%10>=2 && n%10<=4) && (n%100<12 || n%100>14) ? 1 : n!=1 && (n%10>=0 && n%10<=1) || (n%10>=5 && n%10<=9) || (n%100>=12 && n%100<=14) ? 2 : 3);
X-Crowdin-Project: azuracast
X-Crowdin-Project-ID: 217396
X-Crowdin-Language: pl
X-Crowdin-File: /main/resources/locale/default.pot
X-Crowdin-File-ID: 4
',
      ),
      'Avatars are retrieved based on your e-mail address from the %{service} service. Click to manage your %{service} settings.' => 
      array (
        0 => 'Awatary są pobierane na podstawie Twojego adresu e-mail z usługi %{service}. Kliknij, aby zarządzać ustawieniami %{service}.',
      ),
      'Drag file(s) here to upload or' => 
      array (
        0 => 'Przeciągnij plik(i) tutaj, aby przesłać lub',
      ),
      'Select File' => 
      array (
        0 => 'Wybierz plik',
      ),
      'Today' => 
      array (
        0 => 'Dziś',
      ),
      'Yesterday' => 
      array (
        0 => 'Wczoraj',
      ),
      'Last 7 Days' => 
      array (
        0 => 'Ostatnie 7 dni',
      ),
      'Last 14 Days' => 
      array (
        0 => 'Ostatnie 14 dni',
      ),
      'Last 30 Days' => 
      array (
        0 => 'Ostatnie 30 dni',
      ),
      'This Month' => 
      array (
        0 => 'W tym miesiącu',
      ),
      'Last Month' => 
      array (
        0 => 'Ostatni miesiąc',
      ),
      'Volume' => 
      array (
        0 => 'Głośność',
      ),
      'Waveform Zoom' => 
      array (
        0 => 'Powiększenie Fali Dźwiękowej',
      ),
      'Mute' => 
      array (
        0 => 'Wycisz',
      ),
      'Full Volume' => 
      array (
        0 => 'Pełna głośność',
      ),
      'Edit Record' => 
      array (
        0 => 'Edytuj wpis',
      ),
      'Add Record' => 
      array (
        0 => 'Dodaj wpis',
      ),
      'Copy to Clipboard' => 
      array (
        0 => 'Skopiuj do schowka',
      ),
      'Close' => 
      array (
        0 => 'Zamknij',
      ),
      'Save Changes' => 
      array (
        0 => 'Zapisz zmiany',
      ),
      'Refresh rows' => 
      array (
        0 => 'Odśwież wiersze',
      ),
      'Rows per page' => 
      array (
        0 => 'Wierszy na stronę',
      ),
      'Select displayed fields' => 
      array (
        0 => 'Wybierz wyświetlane pola',
      ),
      'Select all visible rows' => 
      array (
        0 => 'Zaznacz wszystkie widoczne wiersze',
      ),
      'Select' => 
      array (
        0 => 'Wybierz',
      ),
      'Deselect' => 
      array (
        0 => 'Odznacz',
      ),
      'Search' => 
      array (
        0 => 'Szukaj',
      ),
      'No records to display.' => 
      array (
        0 => 'Brak rekordów do wyświetlenia.',
      ),
      'Loading...' => 
      array (
        0 => 'Ładowanie...',
      ),
      'Stop' => 
      array (
        0 => 'Zatrzymaj',
      ),
      'Play' => 
      array (
        0 => 'Odtwórz',
      ),
      'Listeners' => 
      array (
        0 => 'Słuchacze',
      ),
      'Log View' => 
      array (
        0 => 'Podgląd dziennika',
      ),
      'Average Listeners' => 
      array (
        0 => 'Średnia słuchaczy',
      ),
      'Unique Listeners' => 
      array (
        0 => 'Unikalni słuchacze',
      ),
      'Hide Charts' => 
      array (
        0 => 'Ukryj wykresy',
      ),
      'Show Charts' => 
      array (
        0 => 'Pokaż wykresy',
      ),
      'My Account' => 
      array (
        0 => 'Moje konto',
      ),
      'Administration' => 
      array (
        0 => 'Administracja',
      ),
      'Listeners Per Station' => 
      array (
        0 => 'Słuchaczy na stacji',
      ),
      'Station Overview' => 
      array (
        0 => 'Przegląd stacji',
      ),
      'Manage Stations' => 
      array (
        0 => 'Zarządzanie stacjami',
      ),
      'Station Name' => 
      array (
        0 => 'Nazwa stacji',
      ),
      'Now Playing' => 
      array (
        0 => 'Teraz
Odtwarzane',
      ),
      'Public Page' => 
      array (
        0 => 'Strona Publiczna',
      ),
      'Manage' => 
      array (
        0 => 'Zarządzanie',
      ),
      'Username' => 
      array (
        0 => 'Nazwa użytkownika',
      ),
      'New Password' => 
      array (
        0 => 'Nowe Hasło',
      ),
      'Password' => 
      array (
        0 => 'Hasło',
      ),
      'Leave blank to use the current password.' => 
      array (
        0 => 'Pozostaw puste, aby użyć bieżącego hasła.',
      ),
      'SSH Public Keys' => 
      array (
        0 => 'Klucze Publiczne SSH',
      ),
      'Optionally supply SSH public keys this user can use to connect instead of a password. Enter one key per line.' => 
      array (
        0 => 'Opcjonalnie podaj klucze publiczne SSH, jakich ten użytkownik może używać do łączenia się zamiast hasła. Wprowadź każdy klucz w osobnej linii.',
      ),
      'Edit SFTP User' => 
      array (
        0 => 'Edytuj Użytkownika SFTP',
      ),
      'Add SFTP User' => 
      array (
        0 => 'Dodaj Użytkownika SFTP',
      ),
      'Reorder Playlist' => 
      array (
        0 => 'Zmień kolejność playlisty',
      ),
      'Down' => 
      array (
        0 => 'W dół',
      ),
      'Up' => 
      array (
        0 => 'W górę',
      ),
      'Playlist order set.' => 
      array (
        0 => 'Kolejność playlisty ustawiona.',
      ),
      'Title' => 
      array (
        0 => 'Tytuł',
      ),
      'Artist' => 
      array (
        0 => 'Wykonawca',
      ),
      'Album' => 
      array (
        0 => 'Album',
      ),
      'Actions' => 
      array (
        0 => 'Opcje',
      ),
      'Advanced' => 
      array (
        0 => 'Zaawansowane',
      ),
      'Warning' => 
      array (
        0 => 'Ostrzeżenie',
      ),
      'If any of these options are enabled, this playlist will be managed directly via Liquidsoap instead of via AzuraCast. This can have unintended effects and should only be used when you are comfortable with the results.' => 
      array (
        0 => 'Jeśli którakolwiek z tych opcji jest włączona, ta playlista będzie zarządzana bezpośrednio przez Liquidsoap zamiast przez AzuraCast. Może to mieć niezamierzone działanie i powinno być stosowane tylko wtedy, gdy wyniki są wygodne.',
      ),
      'Advanced Manual AutoDJ Scheduling Options' => 
      array (
        0 => 'Zaawansowane ręczne opcje planowania AutoDJ',
      ),
      'Control how this playlist is handled by the AutoDJ software.' => 
      array (
        0 => 'Kontroluj, jak ta lista odtwarzania jest obsługiwana przez oprogramowanie AutoDJ.',
      ),
      'Interrupt other songs to play at scheduled time.' => 
      array (
        0 => 'Przerywaj inne utwory, by odtworzyć w ustalonym czasie.',
      ),
      'Only loop through playlist once.' => 
      array (
        0 => 'Tylko jeden raz przez playlistę.',
      ),
      'Only play one track at scheduled time.' => 
      array (
        0 => 'Odtwarzaj tylko jeden utwór w zaplanowanym czasie.',
      ),
      'Merge playlist to play as a single track.' => 
      array (
        0 => 'Scal playlistę aby grać jako pojedynczy utwór.',
      ),
      'Low' => 
      array (
        0 => 'Niski',
      ),
      'Default' => 
      array (
        0 => 'Domyślny',
      ),
      'High' => 
      array (
        0 => 'Wysoki',
      ),
      'Basic Info' => 
      array (
        0 => 'Podstawowe informacje',
      ),
      'Playlist Name' => 
      array (
        0 => 'Nazwa listy odtwarzania',
      ),
      'Playlist Weight' => 
      array (
        0 => 'Waga listy odtwarzania',
      ),
      'Higher weight playlists are played more frequently compared to other lower-weight playlists.' => 
      array (
        0 => 'Większa waga playlist jest odtwarzana częściej niż inne mniejsze playlisty.',
      ),
      'Is Enabled' => 
      array (
        0 => 'Jest włączony',
      ),
      'If disabled, the playlist will not be included in radio playback, but can still be managed.' => 
      array (
        0 => 'Jeśli wyłączone, playlista nie będzie uwzględniona w odtwarzaniu radiowym, ale nadal może być zarządzana.',
      ),
      'Avoid Duplicate Artists/Titles' => 
      array (
        0 => 'Unikaj duplikowanych artystów/tytułów',
      ),
      'Whether the AutoDJ should attempt to avoid duplicate artists and track titles when playing media from this playlist.' => 
      array (
        0 => 'Czy AutoDJ powinien próbować uniknąć duplikowania artystów i tytułów podczas odtwarzania multimediów z tej listy odtwarzania.',
      ),
      'Include in On-Demand Player' => 
      array (
        0 => 'Dołącz do odtwarzacza na żądanie',
      ),
      'If this station has on-demand streaming and downloading enabled, only songs that are in playlists with this setting enabled will be visible.' => 
      array (
        0 => 'Jeśli ta stacja ma włączone strumieniowanie i pobieranie na żądanie to widoczne będą tylko utwory, które znajdują się na playlistach z tym ustawieniem.',
      ),
      'Playlist Type' => 
      array (
        0 => 'Typ listy odtwarzania',
      ),
      'General Rotation' => 
      array (
        0 => 'Ogólna rotacja',
      ),
      'Standard playlist, shuffles with other standard playlists based on weight.' => 
      array (
        0 => 'Standardowa playlista, losowanie z innymi standardowymi playlistami na podstawie wagi.',
      ),
      'Once per x Songs' => 
      array (
        0 => 'Raz na x utworów',
      ),
      'Play exactly once every $x songs.' => 
      array (
        0 => 'Odtwarzaj dokładnie co $x piosenek.',
      ),
      'Once per x Minutes' => 
      array (
        0 => 'Raz na x minut',
      ),
      'Play exactly once every $x minutes.' => 
      array (
        0 => 'Odtwarzaj dokładnie raz na $x minut.',
      ),
      'Once per Hour' => 
      array (
        0 => 'Raz na godzinę',
      ),
      'Play once per hour at the specified minute.' => 
      array (
        0 => 'Odtwarzaj raz na godzinę w określonej minucie.',
      ),
      'Manually define how this playlist is used in Liquidsoap configuration.' => 
      array (
        0 => 'Ręcznie zdefiniuj jak ta playlista jest używana w konfiguracji Liquidsoap.',
      ),
      'Learn about Advanced Playlists' => 
      array (
        0 => 'Dowiedz się więcej o Zaawansowanych playlistach',
      ),
      'Include in Automated Assignment' => 
      array (
        0 => 'Uwzględnij w automatycznym przypisaniu',
      ),
      'If auto-assignment is enabled, use this playlist as one of the targets for songs to be redistributed into. This will overwrite the existing contents of this playlist.' => 
      array (
        0 => 'Jeśli automatyczne przypisanie jest włączone, użyj tej listy odtwarzania jako jednego z celów dla piosenek do redystrybucji. Spowoduje to nadpisanie istniejącej zawartości tej playlisty.',
      ),
      'Number of Songs Between Plays' => 
      array (
        0 => 'Liczba utworów między odtworzeniami dżingli',
      ),
      'This playlist will play every $x songs, where $x is specified below.' => 
      array (
        0 => 'Ta playlista będzie odtwarzana co $x piosenek, gdzie $x jest określone poniżej.',
      ),
      'Number of Minutes Between Plays' => 
      array (
        0 => 'Liczba minut między odtwarzaniem',
      ),
      'This playlist will play every $x minutes, where $x is specified below.' => 
      array (
        0 => 'Ta lista odtwarzania będzie odtwarzana co $x minut, gdzie $x jest określona poniżej.',
      ),
      'Minute of Hour to Play' => 
      array (
        0 => 'Odtwarzanie w podanej minucie godziny',
      ),
      'Specify the minute of every hour that this playlist should play.' => 
      array (
        0 => 'Określ minutę każdej godziny, kiedy ta playlista ma być odtwarzana.',
      ),
      'Monday' => 
      array (
        0 => 'Poniedziałek',
      ),
      'Tuesday' => 
      array (
        0 => 'Wtorek',
      ),
      'Wednesday' => 
      array (
        0 => 'Środa',
      ),
      'Thursday' => 
      array (
        0 => 'Czwartek',
      ),
      'Friday' => 
      array (
        0 => 'Piątek',
      ),
      'Saturday' => 
      array (
        0 => 'Sobota',
      ),
      'Sunday' => 
      array (
        0 => 'Niedziela',
      ),
      'Schedule' => 
      array (
        0 => 'Harmonogram',
      ),
      'Not Scheduled' => 
      array (
        0 => 'Nie zaplanowane',
      ),
      'This playlist currently has no scheduled times. It will play at all times. To add a new scheduled time, click the button below.' => 
      array (
        0 => 'Ta playlista nie ma obecnie zaplanowanych czasów odtwarzania. Będzie grać przez cały czas. Aby dodać nowy zaplanowany czas, kliknij przycisk poniżej.',
      ),
      'Scheduled Time #%{num}' => 
      array (
        0 => 'Zaplanowany czas #%{num}',
      ),
      'Remove' => 
      array (
        0 => 'Usuń',
      ),
      'Start Time' => 
      array (
        0 => 'Czas rozpoczęcia',
      ),
      'To play once per day, set the start and end times to the same value.' => 
      array (
        0 => 'Aby odtwarzać raz dziennie, ustaw godziny początkowe i końcowe na tę samą wartość.',
      ),
      'End Time' => 
      array (
        0 => 'Czas zakończenia',
      ),
      'If the end time is before the start time, the playlist will play overnight.' => 
      array (
        0 => 'Jeśli czas zakończenia jest przed godziną początkową, playlista będzie odtwarzana w ciągu nocy.',
      ),
      'Station Time Zone' => 
      array (
        0 => 'Strefa czasowa stacji',
      ),
      'This station\'s time zone is currently %{tz}.' => 
      array (
        0 => 'Strefa czasowa tej stacji to obecnie %{tz}.',
      ),
      'Start Date' => 
      array (
        0 => 'Data rozpoczęcia',
      ),
      'To set this schedule to run only within a certain date range, specify a start and end date.' => 
      array (
        0 => 'Aby ustawić ten harmonogram do uruchomienia tylko w określonym przedziale dat, określ datę rozpoczęcia i zakończenia.',
      ),
      'Start/end date cannot be used on playlists with advanced settings!' => 
      array (
        0 => 'Data rozpoczęcia/zakończenia nie może być użyta na playlistach z zaawansowanymi ustawieniami!',
      ),
      'End Date' => 
      array (
        0 => 'Data zakończenia',
      ),
      'Loop Once' => 
      array (
        0 => 'Zapętl raz',
      ),
      'Scheduled Play Days of Week' => 
      array (
        0 => 'Zaplanuj granie w dni tygodnia',
      ),
      'Leave blank to play on every day of the week.' => 
      array (
        0 => 'Pozostaw puste, aby grać każdego dnia tygodnia.',
      ),
      'Add Schedule Item' => 
      array (
        0 => 'Dodaj element harmonogramu',
      ),
      'Source' => 
      array (
        0 => 'Źródło',
      ),
      'Song-Based Playlist' => 
      array (
        0 => 'Lista odtwarzania oparta na utworach',
      ),
      'A playlist containing media files hosted on this server.' => 
      array (
        0 => 'Lista odtwarzania zawiera pliki multimedialne hostowane na tym serwerze.',
      ),
      'Remote URL Playlist' => 
      array (
        0 => 'URL zdalnej listy odtwarzania',
      ),
      'A playlist that instructs the station to play from a remote URL.' => 
      array (
        0 => 'Playlista, która nakazuje stacji odtwarzać z zewnętrznego URL\'a.',
      ),
      'Song Playback Order' => 
      array (
        0 => 'Kolejność odtwarzania utworu',
      ),
      'Shuffled' => 
      array (
        0 => 'Losowane',
      ),
      'The full playlist is shuffled and then played through in the shuffled order.' => 
      array (
        0 => 'Pełna playlista jest przetasowana, a następnie odtwarzana w porządku losowym.',
      ),
      'Random' => 
      array (
        0 => 'Losowo',
      ),
      'A completely random track is picked for playback every time the queue is populated.' => 
      array (
        0 => 'Całkowicie losowy utwór jest wybierany do odtworzenia za każdym razem, gdy kolejka jest wypełniona.',
      ),
      'Sequential' => 
      array (
        0 => 'Sekwencyjny',
      ),
      'The order of the playlist is manually specified and followed by the AutoDJ.' => 
      array (
        0 => 'Kolejność playlisty jest określona ręcznie i następuje przez AutoDJ.',
      ),
      'If requests are enabled for your station, users will be able to request media that is on this playlist.' => 
      array (
        0 => 'Jeśli żądania są włączone dla Twojej stacji, użytkownicy będą mogli żądać mediów, które znajdują się na tej playliście.',
      ),
      'Allow Requests from This Playlist' => 
      array (
        0 => 'Zezwalaj na żądania z tej playlisty',
      ),
      'Enable this setting to prevent metadata from being sent to the AutoDJ for files in this playlist. This is useful if the playlist contains jingles or bumpers.' => 
      array (
        0 => 'Włącz to ustawienie, aby zapobiec wysyłaniu metadanych do autopilota dla plików na tej liście odtwarzania. Jest to przydatne, jeśli playlista zawiera dżingle lub przerywniki.',
      ),
      'Hide Metadata from Listeners ("Jingle Mode")' => 
      array (
        0 => 'Ukryj metadane przed słuchaczami („Tryb Jingle Mode”)',
      ),
      'Remote URL' => 
      array (
        0 => 'Zdalny URL',
      ),
      'Remote URL Type' => 
      array (
        0 => 'Typ zdalnego adresu URL',
      ),
      'Direct Stream URL' => 
      array (
        0 => 'Bezpośredni adres URL strumienia',
      ),
      'Playlist (M3U/PLS) URL' => 
      array (
        0 => 'URL playlisty (M3U/PLS)',
      ),
      'Remote Playback Buffer (Seconds)' => 
      array (
        0 => 'Bufor zdalnego odtwarzania (w sekundach)',
      ),
      'The length of playback time that Liquidsoap should buffer when playing this remote playlist. Shorter times may lead to intermittent playback on unstable connections.' => 
      array (
        0 => 'Długość czasu odtwarzania, który Liquidsoap powinien buforować podczas odtwarzania tej zdalnej playlisty. Krótsze czasy mogą prowadzić do przerywanego odtwarzania na niestabilnych połączeniach.',
      ),
      'Import from PLS/M3U' => 
      array (
        0 => 'Importuj z PLS/M3U',
      ),
      'Select PLS/M3U File to Import' => 
      array (
        0 => 'Wybierz plik PLS/M3U do importu',
      ),
      'AzuraCast will scan the uploaded file for matches in this station\'s music library. Media should already be uploaded before running this step. You can re-run this tool as many times as needed.' => 
      array (
        0 => 'AzuraCast zeskanuje przesłany plik w poszukiwaniu meczy w bibliotece muzycznej tej stacji. Media powinny być już przesłane przed uruchomieniem tego kroku. Możesz ponownie uruchomić to narzędzie tyle razy, ile potrzebuje.',
      ),
      'Duplicate Playlist' => 
      array (
        0 => 'Duplikuj playlistę',
      ),
      '%{name} - Copy' => 
      array (
        0 => '%{name} - Kopia',
      ),
      'New Playlist Name' => 
      array (
        0 => 'Nazwa Nowej Playlisty',
      ),
      'Customize Copy' => 
      array (
        0 => 'Dostosuj kopię',
      ),
      'Copy associated media and folders.' => 
      array (
        0 => 'Skopiuj powiązane multimedia i foldery.',
      ),
      'Copy scheduled playback times.' => 
      array (
        0 => 'Skopiuj zaplanowane czasy odtwarzania.',
      ),
      'Playback Queue' => 
      array (
        0 => 'Kolejka odtwarzania',
      ),
      'Playlist queue cleared.' => 
      array (
        0 => 'Kolejka playlisty wyczyszczona.',
      ),
      'This queue contains the remaining tracks in the order they will be queued by the AzuraCast AutoDJ (if the tracks are eligible to be played).' => 
      array (
        0 => 'Ta kolejka zawiera pozostałe utwory w kolejności, w której zostaną umieszczone w kolejce przez autopilota AzuraCast (jeśli utwory kwalifikują się do odtworzenia).',
      ),
      'Clear Queue' => 
      array (
        0 => 'Wyczyść kolejkę',
      ),
      'Edit Playlist' => 
      array (
        0 => 'Edytuj playlistę',
      ),
      'Add Playlist' => 
      array (
        0 => 'Dodaj playlistę',
      ),
      'Edit Station Profile' => 
      array (
        0 => 'Edytuj profil stacji',
      ),
      'Song Title' => 
      array (
        0 => 'Tytuł utworu',
      ),
      'Cued On' => 
      array (
        0 => 'Ukoczony na',
      ),
      'Delete Queue Item?' => 
      array (
        0 => 'Usunąć element kolejki?',
      ),
      'Clear Upcoming Song Queue?' => 
      array (
        0 => 'Wyczyścić kolejkę następnych utworów?',
      ),
      'Clear' => 
      array (
        0 => 'Wyczyść',
      ),
      'Upcoming Song Queue' => 
      array (
        0 => 'Następna piosenka w kolejce',
      ),
      'Clear Upcoming Song Queue' => 
      array (
        0 => 'Wyczyść kolejkę następnych utworów',
      ),
      'Logs' => 
      array (
        0 => 'Logi',
      ),
      'Delete' => 
      array (
        0 => 'Usuń',
      ),
      'Listener Request' => 
      array (
        0 => 'Żądania słuchaczy',
      ),
      'Playlist:' => 
      array (
        0 => 'Lista odtwarzania:',
      ),
      'Remote Station Type' => 
      array (
        0 => 'Typ zdalnej stacji',
      ),
      'Display Name' => 
      array (
        0 => 'Nazwa wyśwetlana',
      ),
      'The display name assigned to this relay when viewing it on administrative or public pages. Leave blank to automatically generate one.' => 
      array (
        0 => 'Nazwa wyświetlana przypisana do tego relaya przy wyświetlaniu w panelu administracyjnym lub na stronach publicznych. Pozostaw puste, aby wygenerować automatycznie.',
      ),
      'Remote Station Listening URL' => 
      array (
        0 => 'URL do słuchania stacji zdalnej',
      ),
      'Example: if the remote radio URL is http://station.example.com:8000/radio.mp3, enter "http://station.example.com:8000".' => 
      array (
        0 => 'Przykład: jeśli zdalnym adresem URL radia jest http://station.example.com:8000/radio.mp3, wprowadź http://station.example.com:8000.',
      ),
      'Remote Station Listening Mountpoint/SID' => 
      array (
        0 => 'Punkt montowania/SID odsłuchu zdalnej stacji',
      ),
      'Specify a mountpoint (i.e. "/radio.mp3") or a Shoutcast SID (i.e. "2") to specify a specific stream to use for statistics or broadcasting.' => 
      array (
        0 => 'Podaj punkt montowania (np. "/radio.mp3") lub Shoutcast SID (np. "2"), aby określić strumień do wykorzystania w statystykach lub nadawaniu.',
      ),
      'Remote Station Administrator Password' => 
      array (
        0 => 'Hasło zdalnego administratora stacji',
      ),
      'To retrieve detailed unique listeners and client details, an administrator password is often required.' => 
      array (
        0 => 'Aby pobrać szczegółowe unikalne słuchacze i dane klienta, często wymagane jest hasło administratora.',
      ),
      'Show on Public Pages' => 
      array (
        0 => 'Pokaż na publicznych stronach',
      ),
      'Enable to allow listeners to select this relay on this station\'s public pages.' => 
      array (
        0 => 'Włącz, aby pozwolić słuchaczom wybrać ten relay na stronach publicznych tej stacji.',
      ),
      'AutoDJ' => 
      array (
        0 => 'AutoDJ',
      ),
      'Broadcast AutoDJ to Remote Station' => 
      array (
        0 => 'Nadawaj autopilota na zewnętrzną stację',
      ),
      'If enabled, the AutoDJ on this installation will automatically play music to this mount point.' => 
      array (
        0 => 'Jeśli włączone, autopilot w tej instalacji będzie automatycznie odtwarzał muzykę na ten punkt montowania.',
      ),
      'AutoDJ Format' => 
      array (
        0 => 'Format AutoDJ\'a',
      ),
      'AutoDJ Bitrate (kbps)' => 
      array (
        0 => 'Bitrate AutoDJ (kbps)',
      ),
      'Remote Station Source Port' => 
      array (
        0 => 'Port źródłowy zdalnej stacji',
      ),
      'If the port you broadcast to is different from the one you listed in the URL above, specify the source port here.' => 
      array (
        0 => 'Jeśli port, na którym nadajesz, różni się od tego podanego w powyższym URL, podaj tutaj port źródłowy.',
      ),
      'Remote Station Source Mountpoint/SID' => 
      array (
        0 => 'Punkt montowania lub SID źródła zdalnej stacji',
      ),
      'If the mountpoint (i.e. /radio.mp3) or Shoutcast SID (i.e. 2) you broadcast to is different from the one listed above, specify the source mount point here.' => 
      array (
        0 => '',
      ),
      'Remote Station Source Username' => 
      array (
        0 => 'Nazwa użytkownika zdalnej stacji',
      ),
      'If you are broadcasting using AutoDJ, enter the source username here. This may be blank.' => 
      array (
        0 => 'Jeśli nadajesz z wykorzystaniem autopilota, podaj tutaj nazwę użytkownika źródła. Możesz zostawić puste.',
      ),
      'Remote Station Source Password' => 
      array (
        0 => 'Hasło źródła stacji zdalnej',
      ),
      'If you are broadcasting using AutoDJ, enter the source password here.' => 
      array (
        0 => 'Jeśli nadajesz z wykorzystaniem autopilota, podaj tutaj hasło źródła.',
      ),
      'Publish to "Yellow Pages" Directories' => 
      array (
        0 => 'Opublikuj w katalogach "Yellow Pages"',
      ),
      'Enable to advertise this relay on "Yellow Pages" public radio directories.' => 
      array (
        0 => 'Włącz, aby reklamować ten relay w publicznych katalogach radiowych "Yellow Pages".',
      ),
      'Edit Remote Relay' => 
      array (
        0 => 'Edytuj zdalny relay',
      ),
      'Add Remote Relay' => 
      array (
        0 => 'Dodaj zdalny relay',
      ),
      'Playlist' => 
      array (
        0 => 'Lista odtwarzania',
      ),
      'Scheduling' => 
      array (
        0 => 'Planowanie',
      ),
      '# Songs' => 
      array (
        0 => '# Utwory',
      ),
      'All Playlists' => 
      array (
        0 => 'Wszystkie playlisty',
      ),
      'Schedule View' => 
      array (
        0 => 'Widok harmonogramu',
      ),
      'More' => 
      array (
        0 => 'Więcej',
      ),
      'Reorder' => 
      array (
        0 => 'Zmień kolejność',
      ),
      'Reshuffle' => 
      array (
        0 => 'Przetasuj ponownie',
      ),
      'Duplicate' => 
      array (
        0 => 'Duplikuj',
      ),
      'Disable' => 
      array (
        0 => 'Dezaktywuj',
      ),
      'Enable' => 
      array (
        0 => 'Aktywuj',
      ),
      'Disabled' => 
      array (
        0 => 'Nieaktywne',
      ),
      'Weight' => 
      array (
        0 => 'Waga',
      ),
      'Once per %{songs} Songs' => 
      array (
        0 => 'Raz na %{songs} utworów',
      ),
      'Once per %{minutes} Minutes' => 
      array (
        0 => 'Raz na %{minutes} minut',
      ),
      'Once per Hour (at %{minute})' => 
      array (
        0 => 'Raz na godzinę (w %{minute})',
      ),
      'Custom' => 
      array (
        0 => 'Niestandardowe',
      ),
      'Delete Playlist?' => 
      array (
        0 => 'Usunąć playlistę?',
      ),
      'Playlists' => 
      array (
        0 => 'Listy odtwarzania',
      ),
      'Edit' => 
      array (
        0 => 'Edytuj',
      ),
      'Export %{format}' => 
      array (
        0 => 'Eksportuj %{format}',
      ),
      'Song-based' => 
      array (
        0 => 'Oparte na utworach',
      ),
      'Jingle Mode' => 
      array (
        0 => 'Tryb Dżingla',
      ),
      'On-Demand' => 
      array (
        0 => 'Na żądanie',
      ),
      'Auto-Assigned' => 
      array (
        0 => 'Automatycznie przypisany',
      ),
      'Name' => 
      array (
        0 => 'Nazwa',
      ),
      'Delete Remote Relay?' => 
      array (
        0 => 'Usunąć zdalny relay?',
      ),
      'Remote Relays' => 
      array (
        0 => 'Zdalne relaye',
      ),
      'Remote relays let you work with broadcasting software outside this server. Any relay you include here will be included in your station\'s statistics. You can also broadcast from this server to remote relays.' => 
      array (
        0 => 'Zdalne relaye pozwalają na pracę z oprogramowaniem nadawczym poza niniejszym serwerem. Każdy podany tutaj relay będzie ujęty w statystykach Twojej stacji. Możesz również nadawać z tego serwera na zewnętrzne relaye.',
      ),
      'Enabled' => 
      array (
        0 => 'Aktywny',
      ),
      'Mount Point URL' => 
      array (
        0 => 'URL punktu montowania',
      ),
      'You can set a custom URL for this stream that AzuraCast will use when referring to it. Leave empty to use the default value.' => 
      array (
        0 => 'Można ustawić niestandardowy adres URL dla tego strumienia, który AzuraCast będzie używany przy odwoływaniu się do niego. Pozostaw puste, aby użyć wartości domyślnej.',
      ),
      'Custom Frontend Configuration' => 
      array (
        0 => 'Niestandardowa konfiguracja Frontend',
      ),
      'You can include any special mount point settings here, in either JSON { key: \'value\' } format or XML <key>value</key>' => 
      array (
        0 => '',
      ),
      'This name should always begin with a slash (/), and must be a valid URL, such as /autodj.mp3' => 
      array (
        0 => 'Tą nazwę zawsze należy zaczynać ukośnikiem (/) i musi być prawidłowym adresem URL, np. /autodj.mp3',
      ),
      'The display name assigned to this mount point when viewing it on administrative or public pages. Leave blank to automatically generate one.' => 
      array (
        0 => 'Nazwa wyświetlana jest przypisana do tego punktu montowania podczas wyświetlania jej na podstronach panelu administracyjnego lub na stronach publicznych. Pozostaw puste, aby wygenerować ją automatycznie.',
      ),
      'Enable to allow listeners to select this mount point on this station\'s public pages.' => 
      array (
        0 => 'Włącz, aby zezwolić słuchaczom na wybieranie tego punktu montowania na publicznych stronach tej stacji.',
      ),
      'Set as Default Mount Point' => 
      array (
        0 => 'Ustaw jako domyślny punkt montowania',
      ),
      'If this mount is the default, it will be played on the radio preview and the public radio page in this system.' => 
      array (
        0 => 'Jeśli ten punkt jest domyślny, utwory będą grane w podglądzie radia oraz na publicznej stronie radia tego systemu.',
      ),
      'Relay Stream URL' => 
      array (
        0 => 'Adres URL przekazania strumienia',
      ),
      'Enter the full URL of another stream to relay its broadcast through this mount point.' => 
      array (
        0 => 'Wprowadź pełny adres URL innego strumienia do przekazywania jego nadawanych przez ten punkt instancji.',
      ),
      'Enable to advertise this mount point on "Yellow Pages" public radio directories.' => 
      array (
        0 => 'Włącz rozgłaszanie tego punktu montowania w publicznych katalogach stacji radiowych "Yellow Pages".',
      ),
      'Max Listener Duration' => 
      array (
        0 => 'Maksymalny czas słuchania dla pojedynczego słuchacza',
      ),
      'Set the length of time (seconds) a listener will stay connected to the stream. If set to 0, listeners can stay connected infinitely.' => 
      array (
        0 => 'Ustaw maksymalny czas podłączenia słuchacza do strumienia (w sekundach). Jeśli ustawione na 0, słuchacze mogą pozostawać podłączeni przez nieograniczony czas.',
      ),
      'YP Directory Authorization Hash' => 
      array (
        0 => 'Hash autoryzacji katalogu YP',
      ),
      'Fallback Mount' => 
      array (
        0 => 'Rezerwowy Punkt Montowania',
      ),
      'If this mount point is not playing audio, listeners will automatically be redirected to this mount point. The default is /error.mp3, a repeating error message.' => 
      array (
        0 => 'Jeśli ten punkt instalacji nie odtwarzania dźwięku, słuchacz będzie automatycznie przekierowany na ten punkt instalacji. Wartością domyślną jest /error.mp3, wraz z powtarzanym komunikacie o błędzie.',
      ),
      'Enable AutoDJ' => 
      array (
        0 => 'Włącz AutoDJ\'a',
      ),
      'If enabled, the AutoDJ will automatically play music to this mount point.' => 
      array (
        0 => 'Jeśli włączone, autopilot będzie automatycznie odtwarzał muzykę na ten punkt montowania.',
      ),
      'Intro' => 
      array (
        0 => 'Intro',
      ),
      'Select Intro File' => 
      array (
        0 => 'Wybierz plik intra',
      ),
      'This introduction file should exactly match the bitrate and format of the mount point itself.' => 
      array (
        0 => 'Plik intra powinien mieć dokładnie taki sam bitrate i format, co punkt montowania.',
      ),
      'Current Intro File' => 
      array (
        0 => 'Bieżący plik intra',
      ),
      'Download' => 
      array (
        0 => 'Pobierz',
      ),
      'Clear File' => 
      array (
        0 => 'Wyczyść plik',
      ),
      'There is no existing intro file associated with this mount point.' => 
      array (
        0 => 'Brak pliku intra powiązanego z tym punktem montowania.',
      ),
      'Edit Mount Point' => 
      array (
        0 => 'Edytuj punkt montowania',
      ),
      'Add Mount Point' => 
      array (
        0 => 'Dodaj punkt montowania',
      ),
      'Delete SFTP User?' => 
      array (
        0 => 'Usunąć użytkownika SFTP?',
      ),
      'SFTP Users' => 
      array (
        0 => 'Użytkownicy SFTP',
      ),
      'Connection Information' => 
      array (
        0 => 'Informacje o połączeniu',
      ),
      'Server:' => 
      array (
        0 => 'Serwer:',
      ),
      'You may need to connect directly to your IP address:' => 
      array (
        0 => 'Możesz potrzebować połączenia bezpośrednio z Twoim adresem IP:',
      ),
      'Port:' => 
      array (
        0 => 'Port:',
      ),
      'Web Hook Details' => 
      array (
        0 => 'Szczegóły webhook\'a',
      ),
      'Web hooks automatically send a HTTP POST request to the URL you specify to notify it any time one of the triggers you specify occurs on your station.' => 
      array (
        0 => 'Webhooki automatycznie wysyłają żądanie POST HTTP na wskazany adres URL, aby powiadomić go w dowolnym momencie o jednym z podanych przez Ciebie wyzwalaczy.',
      ),
      'The body of the POST message is the exact same as the NowPlaying API response for your station.' => 
      array (
        0 => 'Treść wiadomości POST jest dokładnie taka sama jak odpowiedź API NowPlaying dla Twojej stacji.',
      ),
      'NowPlaying API Response' => 
      array (
        0 => 'Odpowiedź NowPlaying API',
      ),
      'In order to process quickly, web hooks have a short timeout, so the responding service should be optimized to handle the request in under 2 seconds.' => 
      array (
        0 => 'W celu szybkiego przetworzenia, webhooki mają krótki limit czasu, tak więc usługa odpowiadająca powinna być zoptymalizowana, aby obsłużyć żądanie w ciągu 2 sekund.',
      ),
      'Web Hook URL' => 
      array (
        0 => 'URL webhook\'a',
      ),
      'The URL that will receive the POST messages any time an event is triggered.' => 
      array (
        0 => 'URL, który będzie odbierał wiadomość POST za każdym razem, gdy zdarzenie będzie wywoływane.',
      ),
      'Optional: HTTP Basic Authentication Username' => 
      array (
        0 => 'Opcjonalne: Nazwa użytkownika podstawowego uwierzytelnienia HTTP',
      ),
      'If your web hook requires HTTP basic authentication, provide the username here.' => 
      array (
        0 => 'Jeśli Twój webhook wymaga podstawowego uwierzytelnienia HTTP, podaj tutaj nazwę użytkownika.',
      ),
      'Optional: HTTP Basic Authentication Password' => 
      array (
        0 => 'Opcjonalnie: Hasło uwierzytelniania podstawowego HTTP',
      ),
      'If your web hook requires HTTP basic authentication, provide the password here.' => 
      array (
        0 => 'Jeśli Twój webhook wymaga podstawowego uwierzytelnienia, podaj tutaj hasło.',
      ),
      'Matomo Installation Base URL' => 
      array (
        0 => 'Podstawowy URL instalacji Matomo',
      ),
      'The full base URL of your Matomo installation.' => 
      array (
        0 => 'Pełny podstawowy adres URL Twojej instalacji Matomo.',
      ),
      'Matomo Site ID' => 
      array (
        0 => 'ID strony w Matomo',
      ),
      'The numeric site ID for this site.' => 
      array (
        0 => 'Numeryczny identyfikator witryny dla tej witryny.',
      ),
      'Matomo API Token' => 
      array (
        0 => 'Token API Matomo',
      ),
      'Optionally supply an API token to allow IP address overriding.' => 
      array (
        0 => 'Opcjonalnie podaj token API, aby umożliwić nadpisywanie adresu IP.',
      ),
      'Discord Web Hook URL' => 
      array (
        0 => 'URL webhook\'a Discorda',
      ),
      'This URL is provided within the Discord application.' => 
      array (
        0 => 'Ten URL jest podany w aplikacji Discord.',
      ),
      'Main Message Content' => 
      array (
        0 => 'Zawartość wiadomości',
      ),
      'Description' => 
      array (
        0 => 'Opis',
      ),
      'URL' => 
      array (
        0 => 'URL',
      ),
      'Author Name' => 
      array (
        0 => 'Nazwa autora',
      ),
      'Thumbnail Image URL' => 
      array (
        0 => 'Adres URL miniatury obrazu',
      ),
      'Footer Text' => 
      array (
        0 => 'Tekst stopki',
      ),
      'Web Hook Name' => 
      array (
        0 => 'Nazwa webhooka',
      ),
      'Choose a name for this webhook that will help you distinguish it from others. This will only be shown on the administration page.' => 
      array (
        0 => 'Wybierz dla tego webhook\'a nazwę, która pomoże Ci odróżnić go od innych. Będzie ona wyświetlana tylko na stronie panelu administracji.',
      ),
      'Web Hook Triggers' => 
      array (
        0 => 'Wyzwalacze webhook\'a',
      ),
      'This web hook will only run when the selected event(s) occur on this specific station.' => 
      array (
        0 => 'Ten webhook zostanie uruchomiony tylko wtedy, gdy wybrane zdarzenie(a) wystąpi(ą) na tej konkretnej stacji.',
      ),
      'Message Customization Tips' => 
      array (
        0 => 'Porady dotyczące dostosowania wiadomości',
      ),
      'Variables are in the form of:' => 
      array (
        0 => 'Zmienne mają postać:',
      ),
      'All values in the NowPlaying API response are available for use. Any empty fields are ignored.' => 
      array (
        0 => 'Wszystkie wartości w odpowiedzi API NowPlaying są dostępne do użycia. Wszelkie puste pola są ignorowane.',
      ),
      'TuneIn Station ID' => 
      array (
        0 => 'ID stacji w TuneIn',
      ),
      'The station ID will be a numeric string that starts with the letter S.' => 
      array (
        0 => 'Identyfikator stacji będzie ciągiem liczbowym, zaczynającym się na literę S.',
      ),
      'TuneIn Partner ID' => 
      array (
        0 => 'ID Partnera w TuneIn',
      ),
      'TuneIn Partner Key' => 
      array (
        0 => 'Klucz Partnera w TuneIn',
      ),
      'Markdown' => 
      array (
        0 => 'Markdown',
      ),
      'HTML' => 
      array (
        0 => 'HTML',
      ),
      'Bot Token' => 
      array (
        0 => 'Token bota',
      ),
      'See the Telegram Documentation for more details.' => 
      array (
        0 => 'Więcej szczegółów znajduje się w dokumentacji Telegramu.',
      ),
      'Chat ID' => 
      array (
        0 => 'Chat ID',
      ),
      'Unique identifier for the target chat or username of the target channel (in the format @channelusername).' => 
      array (
        0 => 'Unikalny identyfikator docelowego czata lub nazwa użytkownika na docelowym kanale (w formacie @nazwa_użytkownika_lub_kanału).',
      ),
      'Custom API Base URL' => 
      array (
        0 => 'Własny bazowy URL API',
      ),
      'Leave blank to use the default Telegram API URL (recommended).' => 
      array (
        0 => 'Pozostaw puste, aby użyć domyślnego adresu API Telegram (zalecane).',
      ),
      'Message parsing mode' => 
      array (
        0 => 'Tryb przetwarzania wiadomości',
      ),
      'See the Telegram documentation for more details.' => 
      array (
        0 => 'Więcej szczegółów znajduje się w dokumentacji Telegramu.',
      ),
      'GA Property Tracking ID' => 
      array (
        0 => 'Identyfikator śledzenia własności GA',
      ),
      'The property ID used to track live listeners.' => 
      array (
        0 => 'Identyfikator własności używany do śledzenia aktualnie podłączonych słuchaczy.',
      ),
      'Message Recipient(s)' => 
      array (
        0 => 'Odbiorca(y) wiadomości',
      ),
      'E-mail addresses can be separated by commas.' => 
      array (
        0 => 'Adresy e-mail można rozdzielić przecinkami.',
      ),
      'Message Subject' => 
      array (
        0 => 'Temat wiadomości',
      ),
      'Message Body' => 
      array (
        0 => 'Treść wiadomości',
      ),
      'Select Web Hook Type' => 
      array (
        0 => 'Wybierz typ webhooka',
      ),
      '%{ seconds } seconds' => 
      array (
        0 => '%{ seconds } sekund',
      ),
      '%{ minutes } minutes' => 
      array (
        0 => '%{ minutes } minut',
      ),
      'No Limit' => 
      array (
        0 => 'Bez limitu',
      ),
      'Twitter Account Details' => 
      array (
        0 => 'Dane konta na Twitterze',
      ),
      'Steps for configuring a Twitter application:' => 
      array (
        0 => 'Etapy konfiguracji aplikacji Twittera:',
      ),
      'Create a new app on the Twitter Applications site. Use this installation\'s base URL as the application URL.' => 
      array (
        0 => 'Utwórz nową aplikację na stronie Twitter Applications (Aplikacje Twittera). Użyj podstawowego adresu URL tej instalacji jako adresu URL aplikacji.',
      ),
      'Twitter Applications' => 
      array (
        0 => 'Aplikacje Twittera',
      ),
      'In the newly created application, click the "Keys and Access Tokens" tab.' => 
      array (
        0 => 'W nowo utworzonej aplikacji kliknij zakładkę "Klucze i tokeny dostępu".',
      ),
      'At the bottom of the page, click "Create my access token".' => 
      array (
        0 => 'Na dole strony kliknij "Utwórz mój token dostępu".',
      ),
      'Once these steps are completed, enter the information from the "Keys and Access Tokens" page into the fields below.' => 
      array (
        0 => 'Kiedy te kroki zostaną ukończone, wprowadź informacje ze strony "Klucze i Tokeny dostępu" do pól poniżej.',
      ),
      'Consumer Key (API Key)' => 
      array (
        0 => 'Klucz konsumenta (consumer key) (klucz API)',
      ),
      'Consumer Secret (API Secret)' => 
      array (
        0 => 'Klucz tajny (consumer secret) (klucz tajny API)',
      ),
      'Access Token' => 
      array (
        0 => 'Token dostępu',
      ),
      'Access Token Secret' => 
      array (
        0 => 'Tajny token dostępu',
      ),
      'Only Send One Tweet Every...' => 
      array (
        0 => 'Wysyłaj tylko jednego tweeta co...',
      ),
      'Edit Web Hook' => 
      array (
        0 => 'Edytuj webhook',
      ),
      'Add Web Hook' => 
      array (
        0 => 'Dodaj webhook',
      ),
      'Powered by AzuraCast' => 
      array (
        0 => 'Wspierane przez AzuraCast',
      ),
      'Now playing on %{ station }:' => 
      array (
        0 => 'Teraz odtwarzane na %{ station }:',
      ),
      'Now playing on %{ station }: %{ title } by %{ artist }! Tune in now.' => 
      array (
        0 => 'Teraz odtwarzane w %{ station }: %{ title } z repertuaru %{ artist }! Włącz teraz.',
      ),
      'Now playing on %{ station }: %{ title } by %{ artist }! Tune in now: %{ url }' => 
      array (
        0 => 'Teraz odtwarzane na %{ station }: %{ title } z repertuaru %{ artist }! Włącz teraz: %{ url }',
      ),
      'Disable song requests?' => 
      array (
        0 => 'Wyłączyć prośby o utwory?',
      ),
      'Enable song requests?' => 
      array (
        0 => 'Włączyć prośby o utwory?',
      ),
      'Song Requests' => 
      array (
        0 => 'Żądanie piosenki',
      ),
      'View' => 
      array (
        0 => 'Wyświetl',
      ),
      'Streams' => 
      array (
        0 => 'Strumienie',
      ),
      'Local Streams' => 
      array (
        0 => 'Strumienie lokalne',
      ),
      'Unique' => 
      array (
        0 => 'Unikalne',
      ),
      'Download PLS' => 
      array (
        0 => 'Pobierz plik .PLS',
      ),
      'Download M3U' => 
      array (
        0 => 'Pobierz plik .M3U',
      ),
      '%{listeners} Listener' => 
      array (
        0 => '%{listeners} słuchacz',
        1 => '%{listeners} słuchaczy',
        2 => '%{listeners} słuchaczy',
        3 => '%{listeners} słuchaczy',
      ),
      'On the Air' => 
      array (
        0 => 'W eterze',
      ),
      'Playing Next' => 
      array (
        0 => 'Następne w kolejce',
      ),
      'Live' => 
      array (
        0 => 'Na żywo',
      ),
      'Skip Song' => 
      array (
        0 => 'Pomiń utwór',
      ),
      'Disconnect Streamer' => 
      array (
        0 => 'Odłącz Streamera',
      ),
      'Disable streamers?' => 
      array (
        0 => 'Wyłączyć streamerów?',
      ),
      'Enable streamers?' => 
      array (
        0 => 'Włączyć streamerów?',
      ),
      'Streamers/DJs' => 
      array (
        0 => 'Streamerzy/DJe',
      ),
      'Edit Profile' => 
      array (
        0 => 'Edytuj profil',
      ),
      'Disable public pages?' => 
      array (
        0 => 'Wyłączyć strony publiczne?',
      ),
      'Enable public pages?' => 
      array (
        0 => 'Włączyć strony publiczne?',
      ),
      'Public Pages' => 
      array (
        0 => 'Strony publiczne',
      ),
      'Web DJ' => 
      array (
        0 => 'Web DJ',
      ),
      'On-Demand Media' => 
      array (
        0 => 'Media na żądanie',
      ),
      'Podcasts' => 
      array (
        0 => 'Podcasty',
      ),
      'Embed Widgets' => 
      array (
        0 => 'Osadź widżety',
      ),
      'Broadcasting Service' => 
      array (
        0 => 'Usługa nadawania',
      ),
      'Administration URL' => 
      array (
        0 => 'Adres URL administracyjny',
      ),
      'Administrator Password' => 
      array (
        0 => 'Hasło administratora',
      ),
      'Source Password' => 
      array (
        0 => 'Hasło źródłowe',
      ),
      'Relay Password' => 
      array (
        0 => 'Hasło relaya',
      ),
      'Restart' => 
      array (
        0 => 'Uruchom ponownie',
      ),
      'Start' => 
      array (
        0 => 'Uruchom',
      ),
      'Radio Player' => 
      array (
        0 => 'Odtwarzacz radiowy',
      ),
      'History' => 
      array (
        0 => 'Historia',
      ),
      'Requests' => 
      array (
        0 => 'Żądania',
      ),
      'Light' => 
      array (
        0 => 'Jasny',
      ),
      'Dark' => 
      array (
        0 => 'Ciemny',
      ),
      'Widget Type' => 
      array (
        0 => 'Typ widżetu',
      ),
      'Theme' => 
      array (
        0 => 'Motyw',
      ),
      'Customize' => 
      array (
        0 => 'Dostosuj',
      ),
      'Embed Code' => 
      array (
        0 => 'Kod osadzania',
      ),
      'Preview' => 
      array (
        0 => 'Podgląd',
      ),
      'Scheduled' => 
      array (
        0 => 'Zaplanowane',
      ),
      'Streamer/DJ' => 
      array (
        0 => 'Streamer/DJ',
      ),
      'Now' => 
      array (
        0 => 'Teraz',
      ),
      'AutoDJ Disabled' => 
      array (
        0 => 'AutoDJ wyłączony',
      ),
      'AutoDJ has been disabled for this station. No music will automatically be played when a source is not live.' => 
      array (
        0 => 'AutoDJ został wyłączony dla tej stacji. Żadna muzyka nie będzie odtwarzana automatycznie, gdy źródło nie będzie aktywne.',
      ),
      '%{numSongs} uploaded song' => 
      array (
        0 => '%{numSongs} przesłany utwór',
        1 => '%{numSongs} przesłane utwory',
        2 => '%{numSongs} przesłanych utworów',
        3 => '%{numSongs} przesłanych utworów',
      ),
      '%{numPlaylists} playlist' => 
      array (
        0 => '%{numPlaylists} playlista',
        1 => '%{numPlaylists} playlisty',
        2 => '%{numPlaylists} playlist',
        3 => '%{numPlaylists} playlisty',
      ),
      'LiquidSoap is currently shuffling from %{songs} and %{playlists}.' => 
      array (
        0 => 'Obecnie LiquidSoap losuje spośród %{songs} i %{playlists}.',
      ),
      'AutoDJ Service' => 
      array (
        0 => 'Usługa autopilota',
      ),
      'Running' => 
      array (
        0 => 'Uruchomione',
      ),
      'Not Running' => 
      array (
        0 => 'Nie uruchomiono',
      ),
      'Delete Mount Point?' => 
      array (
        0 => 'Usunąć punkt montowania?',
      ),
      'Mount Points' => 
      array (
        0 => 'Punkty montowania',
      ),
      'Mount points are how listeners connect and listen to your station. Each mount point can be a different audio format or quality. Using mount points, you can set up a high-quality stream for broadband listeners and a mobile stream for phone users.' => 
      array (
        0 => 'Punkty montowania umożliwiają słuchaczom połączenie się i słuchanie stacji. Każdy punkt może mieć inny format i jakość dźwięku. Wykorzystując punkty montowania, możesz ustawić wysokiej jakości strumień dla użytkowników szerokopasmowego Internetu oraz strumień mobilny dla słuchających w smartfonach.',
      ),
      'Default Mount' => 
      array (
        0 => 'Domyślna instancja',
      ),
      'Genre' => 
      array (
        0 => 'Gatunek',
      ),
      'Length' => 
      array (
        0 => 'Długość',
      ),
      'Size' => 
      array (
        0 => 'Rozmiar',
      ),
      'Modified' => 
      array (
        0 => 'Zmodyfikowano',
      ),
      'Album Art' => 
      array (
        0 => 'Okładka albumu',
      ),
      'Rename' => 
      array (
        0 => 'Zmień nazwę',
      ),
      'View tracks in playlist' => 
      array (
        0 => 'Zobacz utwory na liście odtwarzania',
      ),
      '%{spaceUsed} of %{spaceTotal} Used (%{filesCount} Files)' => 
      array (
        0 => '%{spaceUsed} z %{spaceTotal} Użyto (%{filesCount} plików)',
      ),
      '%{spaceUsed} Used (%{filesCount} Files)' => 
      array (
        0 => '%{spaceUsed} Użyto (%{filesCount} plików)',
      ),
      'Music Files' => 
      array (
        0 => 'Pliki muzyczne',
      ),
      'You can also upload files in bulk via SFTP.' => 
      array (
        0 => 'Możesz również przesyłać pliki zbiorowo za pośrednictwem SFTP.',
      ),
      'Manage SFTP Accounts' => 
      array (
        0 => 'Zarządzaj kontami SFTP',
      ),
      'Directory' => 
      array (
        0 => 'Katalog',
      ),
      'Move %{ num } File(s) to' => 
      array (
        0 => 'Przenieś %{ num } plik(i) do',
      ),
      'Files moved:' => 
      array (
        0 => 'Przeniesione pliki:',
      ),
      'Back' => 
      array (
        0 => 'Wstecz',
      ),
      'Move to Directory' => 
      array (
        0 => 'Przenieś do katalogu',
      ),
      'Home' => 
      array (
        0 => 'Strona główna',
      ),
      'Basic Information' => 
      array (
        0 => 'Podstawowe Informacje',
      ),
      'File Name' => 
      array (
        0 => 'Nazwa pliku',
      ),
      'The relative path of the file in the station\'s media directory.' => 
      array (
        0 => 'Ścieżka względna pliku w katalogu multimediów stacji.',
      ),
      'Song Artist' => 
      array (
        0 => 'Artysta',
      ),
      'Song Genre' => 
      array (
        0 => 'Gatunek utworu',
      ),
      'Song Album' => 
      array (
        0 => 'Album piosenki',
      ),
      'Song Lyrics' => 
      array (
        0 => 'Tekst utworu',
      ),
      'ISRC' => 
      array (
        0 => 'ISRC',
      ),
      'International Standard Recording Code, used for licensing reports.' => 
      array (
        0 => 'Międzynarodowy kod ISRC, używany dla licencjonowanych raportów.',
      ),
      'Visual Cue Editor' => 
      array (
        0 => 'Wizualny edytor wskaźników',
      ),
      'Set cue and fade points using the visual editor. The timestamps will be saved to the corresponding fields in the advanced playback settings.' => 
      array (
        0 => 'Ustaw punkty wskaźników i przenikania za pomocą edytora wizualnego. Znaczniki czasu zostaną zapisane w odpowiednich polach w zaawansowanych ustawieniach odtwarzania.',
      ),
      'Set Cue In' => 
      array (
        0 => 'Ustaw wskaźnik początku',
      ),
      'Set Cue Out' => 
      array (
        0 => 'Ustaw wskaźnik końca',
      ),
      'Set Overlap' => 
      array (
        0 => 'Ustaw nakładkę',
      ),
      'Set Fade In' => 
      array (
        0 => 'Ustaw płynny początek',
      ),
      'Set Fade Out' => 
      array (
        0 => 'Ustaw płynne zakończenie',
      ),
      'Custom Fields' => 
      array (
        0 => 'Niestandardowe pola',
      ),
      'Delete Album Art' => 
      array (
        0 => 'Usuń okładkę albumu',
      ),
      'Replace Album Cover Art' => 
      array (
        0 => 'Zastąp okładkę albumu',
      ),
      'Song Length' => 
      array (
        0 => 'Długość utworu',
      ),
      'Amplify: Amplification (dB)' => 
      array (
        0 => 'Wzmocnij głośność: Wzmocnienie (dB)',
      ),
      'The volume in decibels to amplify the track with. Leave blank to use the system default.' => 
      array (
        0 => 'Głośność w decybelach, aby zwiększyć głośność utworu. Pozostaw puste, aby użyć domyślnego ustawienia systemu.',
      ),
      'Custom Fading: Overlap Time (seconds)' => 
      array (
        0 => 'Niestandardowe zanikanie: Czas nakładania się (sekundy)',
      ),
      'The time that this song should overlap its surrounding songs when fading. Leave blank to use the system default.' => 
      array (
        0 => 'Czas, w którym ta piosenka powinna płynnie nakładać się na jej otaczające piosenki. Pozostaw puste, aby użyć domyślnego ustawienia systemu.',
      ),
      'Custom Fading: Fade-In Time (seconds)' => 
      array (
        0 => 'Niestandardowe zanikanie: Czas płynnego rozpoczęcia (sekundy)',
      ),
      'The time period that the song should fade in. Leave blank to use the system default.' => 
      array (
        0 => 'Czas, w którym piosenka powinna płynnie się zaczynać. Pozostaw puste, aby użyć domyślnego ustawienia systemu.',
      ),
      'Custom Fading: Fade-Out Time (seconds)' => 
      array (
        0 => 'Niestandardowe zanikanie: Czas płynnego zakończenia (sekundy)',
      ),
      'The time period that the song should fade out. Leave blank to use the system default.' => 
      array (
        0 => 'Czas, w którym piosenka powinna płynnie się kończyć. Pozostaw puste, aby użyć domyślnego ustawienia systemu.',
      ),
      'Custom Cues: Cue-In Point (seconds)' => 
      array (
        0 => 'Niestandardowe wskaźniki: Wskaźnik początkowy przycięcia (sekundy)',
      ),
      'Seconds from the start of the song that the AutoDJ should start playing.' => 
      array (
        0 => 'Sekund od początku utworu, który autopilot powinien zacząć odtwarzać.',
      ),
      'Custom Cues: Cue-Out Point (seconds)' => 
      array (
        0 => 'Niestandardowe wskaźniki: Wskaźnik końcowy przycięcia (sekundy)',
      ),
      'Seconds from the start of the song that the AutoDJ should stop playing.' => 
      array (
        0 => 'Sekund od początku utworu, który autopilot powinien przestać odtwarzać.',
      ),
      'Rename File/Directory' => 
      array (
        0 => 'Zmień nazwę pliku/katalogu',
      ),
      'New File Name' => 
      array (
        0 => 'Nazwa nowego pliku',
      ),
      'Set or clear playlists from the selected media' => 
      array (
        0 => 'Ustaw lub wyczyść listy odtwarzania z zaznaczonych mediów',
      ),
      'New Playlist' => 
      array (
        0 => 'Nowa lista odtwarzania',
      ),
      'Queue the selected media to play next' => 
      array (
        0 => 'Kolejka wybranych multimediów do odtworzenia',
      ),
      'Analyze and reprocess the selected media' => 
      array (
        0 => 'Analizuj i przetwarzaj wybrane media',
      ),
      'The request could not be processed.' => 
      array (
        0 => 'Nie udało się przetworzyć żądania.',
      ),
      'Files queued for playback:' => 
      array (
        0 => 'Pliki w kolejce do odtwarzania:',
      ),
      'Files marked for reprocessing:' => 
      array (
        0 => 'Pliki oznaczone do ponownego przetworzenia:',
      ),
      'Delete %{ num } media files?' => 
      array (
        0 => 'Usunąć %{ num } plików multimedialnych?',
      ),
      'Files removed:' => 
      array (
        0 => 'Pliki usunięte:',
      ),
      'Playlists updated for selected files:' => 
      array (
        0 => 'Listy odtwarzania zaktualizowane dla wybranych plików:',
      ),
      'Playlists cleared for selected files:' => 
      array (
        0 => 'Listy odtwarzania wyczyszczone dla wybranych plików:',
      ),
      'No files selected.' => 
      array (
        0 => 'Nie wybrano plików.',
      ),
      'Save' => 
      array (
        0 => 'Zapisz',
      ),
      'Move' => 
      array (
        0 => 'Przenieś',
      ),
      'Queue' => 
      array (
        0 => 'Kolejka',
      ),
      'Reprocess' => 
      array (
        0 => 'Przetwórz ponownie',
      ),
      'New Folder' => 
      array (
        0 => 'Nowy folder',
      ),
      'Edit Media' => 
      array (
        0 => 'Edytuj media',
      ),
      'New Directory' => 
      array (
        0 => 'Nowy katalog',
      ),
      'New directory created.' => 
      array (
        0 => 'Nowy katalog utworzony.',
      ),
      'Directory Name' => 
      array (
        0 => 'Nazwa katalogu',
      ),
      'Create Directory' => 
      array (
        0 => 'Utwórz katalog',
      ),
      'Artwork' => 
      array (
        0 => 'Okładka',
      ),
      'Select PNG/JPG artwork file' => 
      array (
        0 => 'Wybierz plik okładki PNG/JPG',
      ),
      'Artwork must be a minimum size of 1400 x 1400 pixels and a maximum size of 3000 x 3000 pixels for Apple Podcasts.' => 
      array (
        0 => 'Okładka musi mieć minimalny rozmiar 1400 x 1400 pikseli i maksymalny rozmiar 3000 x 3000 pikseli dla Apple Podcasts.',
      ),
      'Clear Artwork' => 
      array (
        0 => 'Usuń okładkę',
      ),
      'Edit Episode' => 
      array (
        0 => 'Edytuj odcinek',
      ),
      'Add Episode' => 
      array (
        0 => 'Dodaj odcinek',
      ),
      'Edit Podcast' => 
      array (
        0 => 'Edytuj Podcast',
      ),
      'Add Podcast' => 
      array (
        0 => 'Dodaj Podcast',
      ),
      'Podcast Title' => 
      array (
        0 => 'Tytuł Podcastu',
      ),
      'Website' => 
      array (
        0 => 'Strona internetowa',
      ),
      'Typically the home page of a podcast.' => 
      array (
        0 => 'Zazwyczaj strona główna podcastu.',
      ),
      'The description of your podcast. The typical maximum amount of text allowed for this is 4000 characters.' => 
      array (
        0 => 'Opis Twojego podcastu. Typowa maksymalna dozwolona długość tekstu wynosi 4000 znaków.',
      ),
      'Language' => 
      array (
        0 => 'Język',
      ),
      'The language spoken on the podcast.' => 
      array (
        0 => 'Język używany w podcaście.',
      ),
      'Author' => 
      array (
        0 => 'Autor',
      ),
      'The contact person of the podcast. May be required in order to list the podcast on services like Apple Podcasts, Spotify, Google Podcasts, etc.' => 
      array (
        0 => 'Osoba kontaktowa podcastu. Ta informacja może być wymagana, aby wyświetlić podcast w serwisach takich jak Apple Podcasts, Spotify, Google Podcasts, itp.',
      ),
      'E-Mail' => 
      array (
        0 => 'E-mail',
      ),
      'The email of the podcast contact. May be required in order to list the podcast on services like Apple Podcasts, Spotify, Google Podcasts, etc.' => 
      array (
        0 => 'E-mail kontaktowy do autora podcastu. Może być wymagany, aby wyświetlić podcasty w usługach takich jak Apple Podcasts, Spotify, Google Podcasts, itp.',
      ),
      'Categories' => 
      array (
        0 => 'Kategorie',
      ),
      'Select the category/categories that best reflects the content of your podcast.' => 
      array (
        0 => 'Wybierz kategorię/kategorie, które najlepiej odzwierciedlają zawartość podcastu.',
      ),
      'Art' => 
      array (
        0 => 'Okładka',
      ),
      'Podcast' => 
      array (
        0 => 'Podcast',
      ),
      '# Episodes' => 
      array (
        0 => '# Odcinki',
      ),
      'All Podcasts' => 
      array (
        0 => 'Wszystkie podcasty',
      ),
      'Delete Podcast?' => 
      array (
        0 => 'Usunąć Podcast?',
      ),
      'RSS Feed' => 
      array (
        0 => 'Kanał RSS',
      ),
      'Episodes' => 
      array (
        0 => 'Odcinki',
      ),
      'Episode' => 
      array (
        0 => 'Odcinek',
      ),
      'File' => 
      array (
        0 => 'Plik',
      ),
      'Explicit' => 
      array (
        0 => 'Wulgarne',
      ),
      'Delete Episode?' => 
      array (
        0 => 'Usunąć odcinek?',
      ),
      'Typically a website with content about the episode.' => 
      array (
        0 => 'Zwykle strona internetowa z treścią dotyczącą odcinka.',
      ),
      'The description of the episode. The typical maximum amount of text allowed for this is 4000 characters.' => 
      array (
        0 => 'Opis odcinka. Typowa maksymalna dozwolona długość tekstu wynosi 4000 znaków.',
      ),
      'Publish Date' => 
      array (
        0 => 'Data publikacji',
      ),
      'The date when the episode should be published.' => 
      array (
        0 => 'Planowana data publikacji odcinka.',
      ),
      'Publish Time' => 
      array (
        0 => 'Czas publikacji',
      ),
      'The time when the episode should be published (according to the stations timezone).' => 
      array (
        0 => 'Czas, w którym odcinek powinien być publikowany (zgodnie ze strefą czasową stacji).',
      ),
      'Contains explicit content' => 
      array (
        0 => 'Zawiera wulgarne treści',
      ),
      'Indicates the presence of explicit content (explicit language or adult content). Apple Podcasts displays an Explicit parental advisory graphic for your episode if turned on. Episodes containing explicit material aren’t available in some Apple Podcasts territories.' => 
      array (
        0 => 'Wskazuje na obecność nieodpowiednich treści (wulgarny język lub treści dla dorosłych). Jeśli jest to włączone, wówczas Apple Podcast wyświetli stosowną informację o treściach nieodpowiednich dla młodszych odbiorców. Odcinki zawierające materiały uznawane za nieodpowiednie nie są dostępne w Apple Podcasts na niektórych obszarach.',
      ),
      'Media' => 
      array (
        0 => 'Multimedia',
      ),
      'Select Media File' => 
      array (
        0 => 'Wybierz plik',
      ),
      'Podcast media should be in the MP3 or M4A (AAC) format for the greatest compatibility.' => 
      array (
        0 => 'Podcast powinien być w formacie MP3 lub M4A (AAC), aby zapewnić jak największą kompatybilność.',
      ),
      'Current Podcast Media' => 
      array (
        0 => 'Bieżące pliki podcastów',
      ),
      'Clear Media' => 
      array (
        0 => 'Usuń multimedia',
      ),
      'There is no existing media associated with this episode.' => 
      array (
        0 => 'Nie ma żadnych multimediów powiązanych z tym odcinkiem.',
      ),
      'Notes' => 
      array (
        0 => 'Notatki',
      ),
      'Account List' => 
      array (
        0 => 'Lista Kont',
      ),
      'Delete Streamer?' => 
      array (
        0 => 'Usunąć Streamera?',
      ),
      'Streamer/DJ Accounts' => 
      array (
        0 => 'Konta streamer/DJ',
      ),
      'Add Streamer' => 
      array (
        0 => 'Dodaj Streamera',
      ),
      'Broadcasts' => 
      array (
        0 => 'Transmisje',
      ),
      'Icecast Clients' => 
      array (
        0 => 'Klienty Icecast',
      ),
      'You may need to connect directly via your IP address:' => 
      array (
        0 => 'Być może musisz połączyć się bezpośrednio przez swój adres IP:',
      ),
      'Mount Name:' => 
      array (
        0 => 'Nazwa montowania:',
      ),
      'SHOUTcast Clients' => 
      array (
        0 => 'Klienty SHOUTcast',
      ),
      'For some clients, use port:' => 
      array (
        0 => 'Dla niektórych klientów użyj portu:',
      ),
      'Password:' => 
      array (
        0 => 'Hasło:',
      ),
      'or' => 
      array (
        0 => 'lub',
      ),
      'Setup instructions for broadcasting software are available on the AzuraCast wiki.' => 
      array (
        0 => 'Instrukcje dotyczące instalacji oprogramowania do nadawania są dostępne na wiki AzuraCast.',
      ),
      'AzuraCast Wiki' => 
      array (
        0 => 'AzuraCast Wiki',
      ),
      'Streamer Username' => 
      array (
        0 => 'Nazwa użytkownika Streamera',
      ),
      'The streamer will use this username to connect to the radio server.' => 
      array (
        0 => 'Streamer użyje tej nazwy użytkownika do łączenia się z serwerem radia.',
      ),
      'Streamer password' => 
      array (
        0 => 'Hasło streamera',
      ),
      'The streamer will use this password to connect to the radio server.' => 
      array (
        0 => 'Nadający użyje tego hasła, by połączyć się z serwerem radiowym.',
      ),
      'Streamer Display Name' => 
      array (
        0 => 'Nazwa wyświetlana prezentera',
      ),
      'This is the informal display name that will be shown in API responses if the streamer/DJ is live.' => 
      array (
        0 => 'Nieformalna nazwa wyświetlana, która będzie się ukazywała w odpowiedziach API jeśli prezenter będzie nadawał na żywo.',
      ),
      'Comments' => 
      array (
        0 => 'Komentarze',
      ),
      'Internal notes or comments about the user, visible only on this control panel.' => 
      array (
        0 => 'Wewnętrzne uwagi lub komentarze na temat użytkownika, widoczny tylko na panelu sterowania.',
      ),
      'Account is Active' => 
      array (
        0 => 'Konto jest aktywne',
      ),
      'Enable to allow this account to log in and stream.' => 
      array (
        0 => 'Włącz, aby pozwolić temu kontu na logowanie się i streamowanie.',
      ),
      'Enforce Schedule Times' => 
      array (
        0 => 'Wymuś czas harmonogramu',
      ),
      'If enabled, this streamer will only be able to connect during their scheduled broadcast times.' => 
      array (
        0 => 'Jeśli włączone, ten streamer będzie mógł połączyć się tylko podczas zaplanowanych czasów transmisji.',
      ),
      'This streamer is not scheduled to play at any times.' => 
      array (
        0 => 'Dla tego prezentera nie określono żadnych czasów adawania.',
      ),
      'If the end time is before the start time, the schedule entry will continue overnight.' => 
      array (
        0 => 'Jeśli czas zakończenia jest przed godziną rozpoczęcia, harmonogram będzie kontynuowany w ciągu nocy.',
      ),
      'Streamer Broadcasts' => 
      array (
        0 => 'Audycje Prezentera',
      ),
      'Play/Pause' => 
      array (
        0 => 'Odtwórz/Zatrzymaj',
      ),
      'Delete Broadcast?' => 
      array (
        0 => 'Usunąć transmisję?',
      ),
      'Edit Streamer' => 
      array (
        0 => 'Edytuj streamera',
      ),
      'Hour' => 
      array (
        0 => 'Godzina',
      ),
      'IP' => 
      array (
        0 => 'IP',
      ),
      'Time' => 
      array (
        0 => 'Czas',
      ),
      'Time (sec)' => 
      array (
        0 => 'Czas (s)',
      ),
      'User Agent' => 
      array (
        0 => 'Agent użytkownika',
      ),
      'Stream' => 
      array (
        0 => 'Strumień',
      ),
      'Location' => 
      array (
        0 => 'Lokalizacja',
      ),
      'Live Listeners' => 
      array (
        0 => 'Słuchacze na żywo',
      ),
      'Download CSV' => 
      array (
        0 => 'Pobierz CSV',
      ),
      'for selected period' => 
      array (
        0 => 'dla wybranego okresu',
      ),
      'Total Listener Hours' => 
      array (
        0 => 'Łącznie godziny słuchania',
      ),
      'Mobile Device' => 
      array (
        0 => 'Urządzenie mobilne',
      ),
      'Desktop Device' => 
      array (
        0 => 'Urządzenie stacjonarne',
      ),
      'Unknown' => 
      array (
        0 => 'Nieznany',
      ),
      'Local' => 
      array (
        0 => 'Lokalny',
      ),
      'Remote' => 
      array (
        0 => 'Zdalny',
      ),
      'Filename' => 
      array (
        0 => 'Nazwa pliku',
      ),
      'Length Text' => 
      array (
        0 => 'Długość tekstu',
      ),
      'Playlist(s)' => 
      array (
        0 => 'Playlista(y)',
      ),
      'Joins' => 
      array (
        0 => 'Dołącza',
      ),
      'Losses' => 
      array (
        0 => 'Straty',
      ),
      'Total' => 
      array (
        0 => 'Łącznie',
      ),
      'Num Plays' => 
      array (
        0 => 'Liczba odtworzeń',
      ),
      'Play %' => 
      array (
        0 => 'Odtwórz %',
      ),
      'Ratio' => 
      array (
        0 => 'Proporcja',
      ),
      'Song Listener Impact' => 
      array (
        0 => 'Wpływ słuchacza na utwór',
      ),
      'Date Requested' => 
      array (
        0 => 'Data żądania',
      ),
      'Date Played' => 
      array (
        0 => 'Data odtwarzania',
      ),
      'Requester IP' => 
      array (
        0 => 'Adres IP żądającego',
      ),
      'Delete Request?' => 
      array (
        0 => 'Usunąć żądanie?',
      ),
      'Clear All Pending Requests?' => 
      array (
        0 => 'Wyczyścić wszystkie oczekujące żądania?',
      ),
      'Clear Pending Requests' => 
      array (
        0 => 'Wyczyść oczekujące żądania',
      ),
      'Not Played' => 
      array (
        0 => 'Nie odtwarzane',
      ),
      'Listeners by Day' => 
      array (
        0 => 'Słuchacze według dnia',
      ),
      'Listeners by Day of Week' => 
      array (
        0 => 'Słuchaczy przez dzień tygodnia',
      ),
      'Listeners by Hour' => 
      array (
        0 => 'Słuchacze według godziny',
      ),
      'Best Performing Songs' => 
      array (
        0 => 'Najpopularniejsze Utwory',
      ),
      'in the last 48 hours' => 
      array (
        0 => 'w ciągu ostatnich 48 godzin',
      ),
      'Change' => 
      array (
        0 => 'Zmień',
      ),
      'Song' => 
      array (
        0 => 'Utwór',
      ),
      'Worst Performing Songs' => 
      array (
        0 => 'Najmniej popularne utwory',
      ),
      'Most Played Songs' => 
      array (
        0 => 'Najczęściej odtwarzane utwory',
      ),
      'in the last month' => 
      array (
        0 => 'w ostatnim miesiącu',
      ),
      'Plays' => 
      array (
        0 => 'Odtwarzaj',
      ),
      'Date/Time' => 
      array (
        0 => 'Data/Czas',
      ),
      'Song Playback Timeline' => 
      array (
        0 => 'Historia utworów',
      ),
      'Live Streamer:' => 
      array (
        0 => 'Nadający na żywo:',
      ),
      'Name/Type' => 
      array (
        0 => 'Nazwa/Typ',
      ),
      'Triggers' => 
      array (
        0 => 'Wyzwalacze',
      ),
      'Delete Web Hook?' => 
      array (
        0 => 'Usunąć webhook?',
      ),
      'Web Hooks' => 
      array (
        0 => 'Narzędzia dla stron www',
      ),
      'Web hooks let you connect to external web services and broadcast changes to your station to them.' => 
      array (
        0 => 'Webhooki pozwalają łączyć się z zewnętrznymi serwisami internetowymi i wysyłać do nich zmiany dotyczące Twojej stacji.',
      ),
      'Test' => 
      array (
        0 => 'Test',
      ),
      'Song History' => 
      array (
        0 => 'Historia utworów',
      ),
      'Request Song' => 
      array (
        0 => 'Żądanie utworu',
      ),
      'Request a Song' => 
      array (
        0 => 'Żądanie utworu',
      ),
      'Microphone' => 
      array (
        0 => 'Mikrofon',
      ),
      'Cue' => 
      array (
        0 => 'Kolejka',
      ),
      'Microphone Source' => 
      array (
        0 => 'Źródło mikrofonu',
      ),
      'Stop Streaming' => 
      array (
        0 => 'Zatrzymaj stream',
      ),
      'Start Streaming' => 
      array (
        0 => 'Rozpocznij stream',
      ),
      'Metadata updated!' => 
      array (
        0 => 'Metadane zaktualizowane!',
      ),
      'Settings' => 
      array (
        0 => 'Ustawienia',
      ),
      'Metadata' => 
      array (
        0 => 'Metadane',
      ),
      'Encoder' => 
      array (
        0 => 'Enkoder',
      ),
      'MP3' => 
      array (
        0 => 'MP3',
      ),
      'Raw' => 
      array (
        0 => 'Surowy',
      ),
      'Sample Rate' => 
      array (
        0 => 'Częstotliwość próbkowania',
      ),
      'Bit Rate' => 
      array (
        0 => 'Prędkość Bitowa',
      ),
      'DJ Credentials' => 
      array (
        0 => 'Dane logowania prezentera',
      ),
      'Use Asynchronous Worker' => 
      array (
        0 => 'Użyj pracownika asynchronicznego',
      ),
      'Update Metadata' => 
      array (
        0 => 'Aktualizuj metadane',
      ),
      'Mixer' => 
      array (
        0 => 'Mikser',
      ),
      'Playlist 1' => 
      array (
        0 => 'Lista odtwarzania 1',
      ),
      'Playlist 2' => 
      array (
        0 => 'Lista odtwarzania 2',
      ),
      'Unknown Title' => 
      array (
        0 => 'Nieznany tytuł',
      ),
      'Unknown Artist' => 
      array (
        0 => 'Nieznany wykonawca',
      ),
      'Add Files to Playlist' => 
      array (
        0 => 'Dodaj pliki do listy odtwarzania',
      ),
      'Continuous Play' => 
      array (
        0 => 'Odtwarzanie bez przerw',
      ),
      'Repeat Playlist' => 
      array (
        0 => 'Powtórz playlistę',
      ),
      'Request' => 
      array (
        0 => 'Żądanie',
      ),
      'This field is required.' => 
      array (
        0 => 'To pole jest wymagane.',
      ),
      'This field must have at least %{ min } letters.' => 
      array (
        0 => 'To pole musi mieć co najmniej %{ min } liter.',
      ),
      'This field must have at most %{ max } letters.' => 
      array (
        0 => 'To pole musi mieć maksymalnie %{ max } liter.',
      ),
      'This field must be between %{ min } and %{ max }.' => 
      array (
        0 => 'To pole musi zawierać się w przedziale od %{ min } do %{ max }.',
      ),
      'This field must only contain alphabetic characters.' => 
      array (
        0 => 'To pole może zawierać tylko znaki alfabetyczne.',
      ),
      'This field must only contain alphanumeric characters.' => 
      array (
        0 => 'To pole musi zawierać tylko znaki alfanumeryczne.',
      ),
      'This field must only contain numeric characters.' => 
      array (
        0 => 'To pole musi zawierać tylko znaki numeryczne.',
      ),
      'This field must be a valid integer.' => 
      array (
        0 => 'To pole musi zawierać poprawną liczbę całkowitą.',
      ),
      'This field must be a valid decimal number.' => 
      array (
        0 => 'To pole musi zawierać poprawną liczbę dziesiętną.',
      ),
      'This field must be a valid e-mail address.' => 
      array (
        0 => 'To pole musi zawierać poprawny adres e-mail.',
      ),
      'This field must be a valid IP address.' => 
      array (
        0 => 'To pole musi zawierać poprawny adres IP.',
      ),
      'This field must be a valid URL.' => 
      array (
        0 => 'To pole musi zawierać poprawny adres URL.',
      ),
      'This password is too common or insecure.' => 
      array (
        0 => '',
      ),
      'Global Permissions' => 
      array (
        0 => 'Uprawnienia globalne',
      ),
      'Role Name' => 
      array (
        0 => 'Nazwa roli',
      ),
      'Users with this role will have these permissions across the entire installation.' => 
      array (
        0 => 'Użytkownicy z tą rolą będą mieli te uprawnienia w całej instalacji.',
      ),
      'Station Permissions' => 
      array (
        0 => 'Uprawnienia stacji',
      ),
      'Users with this role will have these permissions for this single station.' => 
      array (
        0 => 'Użytkownicy z tą rolą będą mieli te uprawnienia w tej jednej stacji.',
      ),
      'Add Station' => 
      array (
        0 => 'Dodaj stację',
      ),
      'Edit Role' => 
      array (
        0 => 'Edytuj rolę',
      ),
      'Add Role' => 
      array (
        0 => 'Dodaj Rolę',
      ),
      'User' => 
      array (
        0 => 'Użytkownik',
      ),
      'Operation' => 
      array (
        0 => 'Operacja',
      ),
      'Identifier' => 
      array (
        0 => 'Identyfikator',
      ),
      'Target' => 
      array (
        0 => 'Cel',
      ),
      'Insert' => 
      array (
        0 => 'Wstaw',
      ),
      'Update' => 
      array (
        0 => 'Zaktualizuj',
      ),
      'Audit Log' => 
      array (
        0 => 'Dziennik audytu',
      ),
      'N/A' => 
      array (
        0 => 'Nie dotyczy',
      ),
      'Changes' => 
      array (
        0 => 'Zmiany',
      ),
      'Field' => 
      array (
        0 => 'Pole',
      ),
      'Previous' => 
      array (
        0 => 'Poprzedni',
      ),
      'Updated' => 
      array (
        0 => 'Zaktualizowano',
      ),
      'Broadcasting' => 
      array (
        0 => 'Nadawanie',
      ),
      'Only connect to a remote server.' => 
      array (
        0 => 'Połącz się tylko ze zdalnym serwerem.',
      ),
      'Use Icecast 2.4 on this server.' => 
      array (
        0 => 'Użyj Icecast 2.4 na tym serwerze.',
      ),
      'Use SHOUTcast DNAS 2 on this server.' => 
      array (
        0 => 'Użyj SHOUTcast DNAS 2 na tym serwerze.',
      ),
      'This software delivers your broadcast to the listening audience.' => 
      array (
        0 => 'To oprogramowanie wysyła sygnał Twojej stacji do słuchaczy.',
      ),
      'SHOUTcast License ID' => 
      array (
        0 => 'ID licencji SHOUTcast',
      ),
      'SHOUTcast User ID' => 
      array (
        0 => 'ID użytkownika SHOUTcast',
      ),
      'Customize Source Password' => 
      array (
        0 => 'Dostosuj hasło źródla',
      ),
      'Leave blank to automatically generate a new password.' => 
      array (
        0 => 'Pozostaw puste, aby automatycznie wygenerować nowe hasło.',
      ),
      'Customize Administrator Password' => 
      array (
        0 => 'Dostosuj hasło administratora',
      ),
      'Customize Broadcasting Port' => 
      array (
        0 => 'Dostosuj port nadawania',
      ),
      'No other program can be using this port. Leave blank to automatically assign a port.' => 
      array (
        0 => 'Żaden inny program nie może korzystać z tego portu. Pozostaw puste, aby automatycznie przypisać port.',
      ),
      'Maximum Listeners' => 
      array (
        0 => 'Maksymalna liczba słuchaczy',
      ),
      'Maximum number of total listeners across all streams. Leave blank to use the default.' => 
      array (
        0 => 'Maksymalna liczba wszystkich słuchaczy we wszystkich strumieniach. Pozostaw puste, aby użyć domyślnej wartości.',
      ),
      'Banned IP Addresses' => 
      array (
        0 => 'Zablokowane adresy IP',
      ),
      'List one IP address or group (in CIDR format) per line.' => 
      array (
        0 => 'Podaj jeden adres IP lub grupę (w formacie CIDR) na wiersz.',
      ),
      'Allowed IP Addresses' => 
      array (
        0 => 'Dozwolone adresy IP',
      ),
      'Banned Countries' => 
      array (
        0 => 'Zablokowane kraje',
      ),
      'Select the countries that are not allowed to connect to the streams.' => 
      array (
        0 => 'Wybierz kraje, które nie mogą łączyć się ze strumieniami.',
      ),
      'Clear List' => 
      array (
        0 => 'Wyczyść listę',
      ),
      'Custom Configuration' => 
      array (
        0 => 'Konfiguracja niestandardowa',
      ),
      'This code will be included in the frontend configuration. Allowed formats are:' => 
      array (
        0 => 'Ten kod zostanie dołączony do konfiguracji frontendu. Dozwolone formaty:',
      ),
      'Station Profile' => 
      array (
        0 => 'Profil stacji',
      ),
      'Web Site URL' => 
      array (
        0 => 'Adres URL strony www',
      ),
      'Note: This should be the public-facing homepage of the radio station, not the AzuraCast URL. It will be included in broadcast details.' => 
      array (
        0 => 'Uwaga: Powinna to być dostępna publicznie strona główna radiostacji, nie adres URL AzuraCast. Będzie ona zawarta w szczegółach nadawania.',
      ),
      'Time Zone' => 
      array (
        0 => 'Strefa czasowa',
      ),
      'Scheduled playlists and other timed items will be controlled by this time zone.' => 
      array (
        0 => 'Zaplanowane playlisty i inne elementy związane z czasem będą kontrolowane przez tę strefę czasową.',
      ),
      'Default Album Art URL' => 
      array (
        0 => 'URL domyślnej okładki',
      ),
      'If a song has no album art, this URL will be listed instead. Leave blank to use the standard placeholder art.' => 
      array (
        0 => 'Jeśli utwór nie posiada okładki, zamiast tego będzie wyświetlany niniejszy URL. Pozostaw puste, aby ustawić domyślną okładkę standardową.',
      ),
      'URL Stub' => 
      array (
        0 => 'Krótki URL',
      ),
      'Optionally specify a short URL-friendly name, such as "my_station_name", that will be used in this station\'s URLs. Leave this field blank to automatically create one based on the station name.' => 
      array (
        0 => 'Opcjonalnie można określić krótką nazwę przyjaznego adresu URL, taką jak "my_station_name", która będzie używana w adresach URL tej stacji. Pozostaw to pole puste, aby automatycznie utworzyć URL\'a w oparciu o nazwę stacji.',
      ),
      'Number of Visible Recent Songs' => 
      array (
        0 => 'Liczba widocznych ostatnio nadawanych utworów',
      ),
      'Customize the number of songs that will appear in the "Song History" section for this station and in all public APIs.' => 
      array (
        0 => 'Dostosuj liczbę utworów, które będą wyświetlane w sekcji "Historia Utworów" (Song History) dla tej stacji i wszystkich publicznych interfejsów API.',
      ),
      'Enable Public Pages' => 
      array (
        0 => 'Włącz strony publiczne',
      ),
      'Show the station in public pages and general API results.' => 
      array (
        0 => 'Umieść stację na stronach publicznych i w ogólnych wynikach API.',
      ),
      'On-Demand Streaming' => 
      array (
        0 => 'Strumieniowanie na żądanie',
      ),
      'Enable On-Demand Streaming' => 
      array (
        0 => 'Włącz streaming na żądanie',
      ),
      'If enabled, music from playlists with on-demand streaming enabled will be available to stream via a specialized public page.' => 
      array (
        0 => 'Jeśli włączone, muzyka z playlist z włączonym streamingiem na żądanie będzie dostępna do strumieniowania przez specjalną stronę publiczną.',
      ),
      'Enable Downloads on On-Demand Page' => 
      array (
        0 => 'Włącz pobieranie na stronie na żądanie',
      ),
      'If enabled, a download button will also be present on the public "On-Demand" page.' => 
      array (
        0 => 'Jeśli włączone, przycisk pobierania będzie również widoczny na publicznej stronie "Na Żądanie" (On-Demand).',
      ),
      'Use Liquidsoap on this server.' => 
      array (
        0 => 'Użyj Liquidsoap na tym serwerze.',
      ),
      'Do not use an AutoDJ service.' => 
      array (
        0 => 'Nie używaj usługi AutoDJ.',
      ),
      'Smart Mode' => 
      array (
        0 => 'Tryb inteligentny',
      ),
      'Normal Mode' => 
      array (
        0 => 'Tryb normalny',
      ),
      'Disable Crossfading' => 
      array (
        0 => 'Wyłącz przejścia',
      ),
      'This software shuffles from playlists of music constantly and plays when no other radio source is available.' => 
      array (
        0 => 'To oprogramowanie nieprzerwanie losuje utwory z playlisty i odtwarza je, gdy nie jest dostępne żadne inne źródło sygnału radia.',
      ),
      'Crossfade Method' => 
      array (
        0 => 'Metoda przejścia',
      ),
      'Choose a method to use when transitioning from one song to another. Smart Mode considers the volume of the two tracks when fading for a smoother effect, but requires more CPU resources.' => 
      array (
        0 => 'Wybierz metodę, jaką chcesz wykorzystywać do tworzenia przejść pomiędzy utworami. Tryb Inteligentny (Smart Mode), dla płynniejszego efektu, sprawdza głośność obydwu utworów, wymaga jednak większego użycia mocy obliczeniowej procesora.',
      ),
      'Crossfade Duration (Seconds)' => 
      array (
        0 => 'Czas trwania przejścia (w sekundach)',
      ),
      'Number of seconds to overlap songs.' => 
      array (
        0 => 'Długość nakładania się utworów w sekundach.',
      ),
      'Apply Compression and Normalization' => 
      array (
        0 => 'Zastosuj kompresję i normalizację',
      ),
      'Compress and normalize your station\'s audio, producing a more uniform and "full" sound.' => 
      array (
        0 => 'Kompresuj i normalizuj głośność swojej stacji, dając bardziej jednolity i "pełny" dźwięk.',
      ),
      'Some stream licensing providers may have specific rules regarding song requests. Check your local regulations for more information.' => 
      array (
        0 => 'Niektórzy dostawcy licencji na strumieniowanie mogą mieć szczegółowe zasady dotyczące żądań utworów. Aby uzyskać więcej informacji, sprawdź obowiązujące w twoim kraju przepisy.',
      ),
      'Allow Song Requests' => 
      array (
        0 => 'Zezwalaj na prośby o piosenki',
      ),
      'Enable listeners to request a song for play on your station. Only songs that are already in your playlists are requestable.' => 
      array (
        0 => 'Pozwól słuchaczom wysyłać prośby o piosenki. Można prosić tylko o utwory znajdujące się już w Twoich playlistach.',
      ),
      'Request Minimum Delay (Minutes)' => 
      array (
        0 => 'Minimalne opóźnienie między żądaniami (w minutach)',
      ),
      'If requests are enabled, this specifies the minimum delay (in minutes) between a request being submitted and being played. If set to zero, a minor delay of 15 seconds is applied to prevent request floods.' => 
      array (
        0 => 'Jeśli żądania są włączone, podana wartość określa minimalne opóźnienie (w minutach) pomiędzy żądaniem a odtwarzaniem. Jeśli ustawiono na zero, stosuje się niewielkie opóźnienie 15 sekund, aby zapobiec floodowaniu żądaniami.',
      ),
      'Request Last Played Threshold (Minutes)' => 
      array (
        0 => 'Próg żądań dla listy ostatnio odtwarzanych utworów (w minutach)',
      ),
      'This specifies the minimum time (in minutes) between a song playing on the radio and being available to request again. Set to 0 for no threshold.' => 
      array (
        0 => 'Określa minimalny czas (w minutach) między odtwarzaniem piosenki w radiu a ponownym żądaniem tej samej piosenki. Ustaw 0 dla braku progu.',
      ),
      'Streamers / DJs' => 
      array (
        0 => 'Streamerzy/DJe',
      ),
      'Allow Streamers / DJs' => 
      array (
        0 => 'Pozwól nadawać streamerom / DJ-om',
      ),
      'If enabled, streamers (or DJs) will be able to connect directly to your stream and broadcast live music that interrupts the AutoDJ stream.' => 
      array (
        0 => 'Jeśli włączone, prezenterzy będą mogli łączyć się bezpośrednio z Twoim strumieniem i nadawać utwory, przerywając tym samym strumień autopilota.',
      ),
      'Record Live Broadcasts' => 
      array (
        0 => 'Nagrywaj transmisje na żywo',
      ),
      'If enabled, AzuraCast will automatically record any live broadcasts made to this station to per-broadcast recordings.' => 
      array (
        0 => 'Jeśli opcja jest włączona, AzuraCast będzie automatycznie nagrywał wszystkie transmisje na żywo wykonane na tej stacji w celu nadawania nagrań.',
      ),
      'Live Broadcast Recording Format' => 
      array (
        0 => 'Format zapisu transmisji na żywo',
      ),
      'Live Broadcast Recording Bitrate (kbps)' => 
      array (
        0 => 'Bitrate nagrania transmisji na żywo (kbps)',
      ),
      'Deactivate Streamer on Disconnect (Seconds)' => 
      array (
        0 => 'Deaktywuj prezentera przy rozłączeniu (w sekundach)',
      ),
      'This is the number of seconds until a streamer who has been manually disconnected can reconnect to the stream. Set to 0 to allow the streamer to immediately reconnect.' => 
      array (
        0 => 'Jest to liczba sekund do momentu, gdy streamer, który został odłączony ręcznie, może ponownie połączyć się z strumieniem. Ustaw 0 aby umożliwić natychmiastowe ponowne połączenie streamera.',
      ),
      'Customize DJ/Streamer Port' => 
      array (
        0 => 'Dostosuj port prezentera',
      ),
      'Note: the port after this one will automatically be used for legacy connections.' => 
      array (
        0 => 'Uwaga: port następujący po tym porcie będzie automatycznie używany do połączeń przy pomocy starszego oprogramowania.',
      ),
      'DJ/Streamer Buffer Time (Seconds)' => 
      array (
        0 => 'Czas buforowania prezentera (w sekundach)',
      ),
      'The number of seconds of signal to store in case of interruption. Set to the lowest value that your DJs can use without stream interruptions.' => 
      array (
        0 => 'Długość sygnału w sekundach, jaka będzie przechowywana w razie usterki. Ustaw najniższa wartość, jaką mogą wykorzystywać Twoi prezenterzy w razie przerwania się strumienia.',
      ),
      'Customize DJ/Streamer Mount Point' => 
      array (
        0 => 'Dostosuj punkt montowania prezentera',
      ),
      'If your streaming software requires a specific mount point path, specify it here. Otherwise, use the default.' => 
      array (
        0 => 'Jeśli Twoje oprogramowanie nadawcze wymaga podania określonej ścieżki punktu montowania, podaj ją tutaj. W przeciwnym razie, użyj domyślnej.',
      ),
      'Advanced Configuration' => 
      array (
        0 => 'Konfiguracja zaawansowana',
      ),
      'Customize Internal Request Processing Port' => 
      array (
        0 => 'Dostosuj port wewnętrznego przetwarzania żądania',
      ),
      'This port is not used by any external process. Only modify this port if the assigned port is in use. Leave blank to automatically assign a port.' => 
      array (
        0 => 'Ten port nie jest wykorzystywany przez żaden proces zewnętrzny. Zmień port tylko wtedy, gdy ten przypisany jest już używany. Pozostaw puste, aby przypisać port automatycznie.',
      ),
      'Use Replaygain Metadata' => 
      array (
        0 => 'Użyj metadanych ReplayGain',
      ),
      'Instruct Liquidsoap to use any replaygain metadata associated with a song to control its volume level.' => 
      array (
        0 => 'Wymuś, aby Liquidsoap używało metadanych ReplayGain powiązanych z utworem, aby kontrolować jego głośność.',
      ),
      'AutoDJ Queue Length' => 
      array (
        0 => 'Długość kolejki AutoDJ',
      ),
      'This determines how many songs in advance the AutoDJ will automatically fill the queue.' => 
      array (
        0 => 'Ta wartość określa, ile piosenek z góry będzie automatycznie wypełniać kolejkę.',
      ),
      'Manual AutoDJ Mode' => 
      array (
        0 => 'Ręczny tryb AutoDJ',
      ),
      'This mode disables AzuraCast\'s AutoDJ management, using Liquidsoap itself to manage song playback. "Next Song" and some other features will not be available.' => 
      array (
        0 => 'Ten tryb wyłącza zarządzanie AutoDJ-em przez AzuraCast, używając samego Liquidsoap do zarządzania odtwarzaniem utworów. "Następna piosenka" i niektóre inne funkcje nie będą dostępne.',
      ),
      'Character Set Encoding' => 
      array (
        0 => 'Kodowanie znaków',
      ),
      'For most cases, use the default UTF-8 encoding. The older ISO-8859-1 encoding can be used if accepting connections from SHOUTcast 1 DJs or using other legacy software.' => 
      array (
        0 => 'W większości przypadków, używaj domyślnego kodowania UTF-8. Starsze kodowanie ISO-8859-1 może być wykorzystywane w razie przyjmowania połączeń od prezenterów korzystających z SHOUTcast 1 lub używających innego starego oprogramowania.',
      ),
      'Duplicate Prevention Time Range (Minutes)' => 
      array (
        0 => 'Zakres Czasu Zapobiegania Powtórzeniom (Minuty)',
      ),
      'This specifies the time range (in minutes) of the song history that the duplicate song prevention algorithm should take into account.' => 
      array (
        0 => 'Określa zakres czasowy (w minutach) w historii utworów, który powinien zostać uwzględniony przez algorytm zapobiegania powtórzeniom piosenek.',
      ),
      'Enable Broadcasting' => 
      array (
        0 => 'Włącz nadawanie',
      ),
      'If disabled, the station will not broadcast or shuffle its AutoDJ.' => 
      array (
        0 => 'Jeśli wyłączone, stacja nie będzie nadawała ani mieszała autopilota.',
      ),
      'Base Station Directory' => 
      array (
        0 => 'Podstawowy katalog stacji',
      ),
      'The parent directory where station playlist and configuration files are stored. Leave blank to use default directory.' => 
      array (
        0 => 'Katalog nadrzędny, w którym są przechowywane pliki listy odtwarzania i konfiguracji stacji. Pozostaw puste, aby użyć domyślnego katalogu.',
      ),
      'Media Storage Location' => 
      array (
        0 => 'Lokalizacja przechowywania mediów',
      ),
      'Live Recordings Storage Location' => 
      array (
        0 => 'Lokalizacja zapisu nagrań transmisji na żywo',
      ),
      'Podcasts Storage Location' => 
      array (
        0 => 'Lokalizacja Przechowywania Podcastów',
      ),
      'Clone Station' => 
      array (
        0 => 'Klonuj stację',
      ),
      '%{station} - Copy' => 
      array (
        0 => '%{station} - Kopia',
      ),
      'Edit Station' => 
      array (
        0 => 'Edytuj stację',
      ),
      'Share Media Storage Location' => 
      array (
        0 => 'Współdziel lokalizację przechowywania multimediów',
      ),
      'Share Recordings Storage Location' => 
      array (
        0 => 'Współdziel miejsce przechowywania nagrań',
      ),
      'Share Podcasts Storage Location' => 
      array (
        0 => 'Współdziel miejsce przechowywania podcastów',
      ),
      'User Permissions' => 
      array (
        0 => 'Uprawnienia użytkownika',
      ),
      'New Station Name' => 
      array (
        0 => 'Nazwa nowej stacji',
      ),
      'New Station Description' => 
      array (
        0 => 'Opis nowej stacji',
      ),
      'Copy to New Station' => 
      array (
        0 => 'Kopiuj do nowej stacji',
      ),
      'Permissions' => 
      array (
        0 => 'Uprawnienia',
      ),
      'Delete Role?' => 
      array (
        0 => 'Usunąć rolę?',
      ),
      'Roles & Permissions' => 
      array (
        0 => 'Role i uprawnienia',
      ),
      'AzuraCast uses a role-based access control system. Roles are given permissions to certain sections of the site, then users are assigned into those roles.' => 
      array (
        0 => 'AzuraCast używa systemu kontroli dostępu opartego na rolach. Zezwolenia dostępu do niektórych sekcji witryny są przypisywane rolom, a następnie użytkownicy są przypisani do tych ról.',
      ),
      'Global' => 
      array (
        0 => 'Globalne',
      ),
      'Storage Adapter' => 
      array (
        0 => 'Adapter pamięci',
      ),
      'Local Filesystem' => 
      array (
        0 => 'Lokalny system plików',
      ),
      'Remote: S3 Compatible' => 
      array (
        0 => 'Zdalne: Kompatybilny S3',
      ),
      'Remote: Dropbox' => 
      array (
        0 => 'Zdalny: Dropbox',
      ),
      'Path/Suffix' => 
      array (
        0 => 'Ścieżka/Sufix',
      ),
      'For local filesystems, this is the base path of the directory. For remote filesystems, this is the folder prefix.' => 
      array (
        0 => 'Dla lokalnych systemów plików, jest to bazowa ścieżka katalogu. Dla zdalnego systemu plików jest to prefiks folderu.',
      ),
      'Storage Quota' => 
      array (
        0 => 'Limit przestrzeni',
      ),
      'Set a maximum disk space that this storage location can use. Specify the size with unit, i.e. "8 GB". Units are measured in 1024 bytes. Leave blank to default to the available space on the disk.' => 
      array (
        0 => 'Ustaw maksymalną przestrzeń dyskową, z której może korzystać ta lokalizacja pamięci. Określ rozmiar z jednostką, np. "8 GB". Jednostki są mierzone w 1024 bajtach. Pozostaw puste do domyślnego miejsca na dysku.',
      ),
      'Access Key ID' => 
      array (
        0 => 'Identyfikator klucza dostępu',
      ),
      'Secret Key' => 
      array (
        0 => 'Tajny klucz',
      ),
      'Endpoint' => 
      array (
        0 => 'Punkt końcowy',
      ),
      'Bucket Name' => 
      array (
        0 => 'Nazwa koszyka',
      ),
      'Region' => 
      array (
        0 => 'Region',
      ),
      'API Version' => 
      array (
        0 => 'Wersja API',
      ),
      'Dropbox Generated Access Token' => 
      array (
        0 => 'Token dostępu wygenerowany przez Dropbox',
      ),
      'Learn More about Dropbox Auth Tokens' => 
      array (
        0 => 'Dowiedz się więcej o tokenach uwierzytelniania Dropboxa',
      ),
      'Edit Storage Location' => 
      array (
        0 => 'Edytuj lokalizację przechowywania',
      ),
      'Add Storage Location' => 
      array (
        0 => 'Dodaj lokalizację przechowywania',
      ),
      'GeoLite version "%{ version }" is currently installed.' => 
      array (
        0 => 'Obecnie zainstalowana wersja GeoLite to "%{ version }".',
      ),
      'Install GeoLite IP Database' => 
      array (
        0 => 'Zainstaluj bazę danych GeoLite IP',
      ),
      'IP Geolocation is used to guess the approximate location of your listeners based on the IP address they connect with. Use the free built-in IP Geolocation library or enter a license key on this page to use MaxMind GeoLite.' => 
      array (
        0 => 'Geolokalizacja IP jest używana do odgadnięcia przybliżonej lokalizacji słuchaczy w oparciu o adres IP, z którego się łączą. Użyj darmowej wbudowanej biblioteki Geolokalizacji IP lub wprowadź klucz licencyjny na tej stronie, aby użyć MaxMind GeoLite.',
      ),
      'Instructions' => 
      array (
        0 => 'Instrukcje',
      ),
      'AzuraCast ships with a built-in free IP geolocation database. You may prefer to use the MaxMind GeoLite service instead to achieve more accurate results. Using MaxMind GeoLite requires a license key, but once the key is provided, we will automatically keep the database updated.' => 
      array (
        0 => 'AzuraCast posiada wbudowaną darmową bazę geolokalizacji IP. Zamiast tego możesz korzystać z usługi MaxMind GeoLite aby uzyskać dokładniejsze wyniki. Korzystanie z MaxMind GeoLite wymaga klucza licencyjnego, ale gdy klucz zostanie dostarczony, będziemy automatycznie aktualizować bazę danych.',
      ),
      'To download the GeoLite database:' => 
      array (
        0 => 'Aby pobrać bazę danych GeoLite:',
      ),
      'Create an account on the MaxMind developer site.' => 
      array (
        0 => 'Utwórz konto na stronie developera w MaxMind.',
      ),
      'MaxMind Developer Site' => 
      array (
        0 => 'Strona developera MaxMind',
      ),
      'Visit the "My License Key" page under the "Services" section.' => 
      array (
        0 => 'Odwiedź stronę "Mój klucz licencyjny" w sekcji "Usługi".',
      ),
      'Click "Generate new license key".' => 
      array (
        0 => 'Kliknij "Generuj nowy klucz licencyjny".',
      ),
      'Paste the generated license key into the field on this page.' => 
      array (
        0 => 'Wklej wygenerowany klucz licencyjny do pola na tej stronie.',
      ),
      'Current Installed Version' => 
      array (
        0 => 'Obecnie zainstalowana wersja',
      ),
      'GeoLite is not currently installed on this installation.' => 
      array (
        0 => 'GeoLite nie jest obecnie zainstalowany w tej instalacji.',
      ),
      'MaxMind License Key' => 
      array (
        0 => 'Klucz licencyjny MaxMind',
      ),
      'Remove Key' => 
      array (
        0 => 'Usuń klucz',
      ),
      'Delete Station?' => 
      array (
        0 => 'Usunąć stację?',
      ),
      'Stations' => 
      array (
        0 => 'Stacje',
      ),
      'Clone' => 
      array (
        0 => 'Klonuj',
      ),
      'Field Name' => 
      array (
        0 => 'Nazwa pola',
      ),
      'This will be used as the label when editing individual songs, and will show in API results.' => 
      array (
        0 => 'Zostanie użyte jako nazwa pola podczas edytowania pojedynczych piosenek, i zostanie wyświetlone w wynikach API.',
      ),
      'Programmatic Name' => 
      array (
        0 => 'Nazwa programowa',
      ),
      'Optionally specify an API-friendly name, such as "field_name". Leave this field blank to automatically create one based on the name.' => 
      array (
        0 => 'Opcjonalnie zdefiniuj nazwę przyjazną dla API, jak na przykład "field_name". Pozostaw puste, aby automatycznie wygenerować nazwę w oparciu o podaną wcześniej.',
      ),
      'Automatically Set from ID3v2 Value' => 
      array (
        0 => 'Automatycznie ustaw z wartości ID3v2',
      ),
      'Optionally select an ID3v2 metadata field that, if present, will be used to set this field\'s value.' => 
      array (
        0 => 'Opcjonalnie wybierz pole metadanych ID3v2 (jeśli są), które zostanie użyte do ustawienia wartości tego pola.',
      ),
      'Edit Custom Field' => 
      array (
        0 => 'Edytuj pole niestandardowe',
      ),
      'Add Custom Field' => 
      array (
        0 => 'Dodaj pole niestandardowe',
      ),
      'Adapter' => 
      array (
        0 => 'Adapter',
      ),
      'Station(s)' => 
      array (
        0 => 'Stacja(e)',
      ),
      'Station Media' => 
      array (
        0 => 'Media stacji',
      ),
      'Station Recordings' => 
      array (
        0 => 'Nagrania stacji',
      ),
      'Station Podcasts' => 
      array (
        0 => 'Podcasty stacji',
      ),
      'Backups' => 
      array (
        0 => 'Kopie zapasowe',
      ),
      'Applying changes...' => 
      array (
        0 => 'Stosowanie zmian...',
      ),
      'Delete Storage Location?' => 
      array (
        0 => 'Usunąć miejsce przechowywania?',
      ),
      'Storage Locations' => 
      array (
        0 => 'Lokalizacje pamięci',
      ),
      'SHOUTcast version "%{ version }" is currently installed.' => 
      array (
        0 => 'Obecnie jest zainstalowany SHOUTcast w wersji "%{ version }".',
      ),
      'Install SHOUTcast 2 DNAS' => 
      array (
        0 => 'Zainstaluj DNAS SHOUTcast 2',
      ),
      'SHOUTcast 2 DNAS is not free software, and its restrictive license does not allow AzuraCast to distribute the SHOUTcast binary.' => 
      array (
        0 => 'SHOUTcast 2 DNAS nie jest wolnym oprogramowaniem, a jego restrykcyjna licencja nie pozwala AzuraCast na dystrybucję binarki SHOUTcast.',
      ),
      'In order to install SHOUTcast:' => 
      array (
        0 => 'Aby zainstalować SHOUTcast:',
      ),
      'Download the Linux x64 binary from the SHOUTcast Radio Manager:' => 
      array (
        0 => 'Pobierz plik binarny Linux x64 z SHOUTcast Radio Manager:',
      ),
      'SHOUTcast Radio Manager' => 
      array (
        0 => 'Menedżer radia SHOUTcast',
      ),
      'The file name should look like:' => 
      array (
        0 => 'Nazwa pliku powinna wyglądać tak:',
      ),
      'Upload the file on this page to automatically extract it into the proper directory.' => 
      array (
        0 => 'Prześlij plik na tej stronie, aby automatycznie rozpakować go do odpowiedniego katalogu.',
      ),
      'SHOUTcast 2 DNAS is not currently installed on this installation.' => 
      array (
        0 => 'SHOUTcast nie jest obecnie zainstalowany w tej instalacji.',
      ),
      'Services' => 
      array (
        0 => 'Usługi',
      ),
      'Stable' => 
      array (
        0 => 'Stabilny',
      ),
      'Rolling Release' => 
      array (
        0 => 'Wydanie Rolling Release',
      ),
      'AzuraCast Update Checks' => 
      array (
        0 => 'Sprawdzanie aktualizacji AzuraCast',
      ),
      'Current Release Channel' => 
      array (
        0 => 'Obecny Kanał Wydawniczy',
      ),
      'Learn more about release channels in the AzuraCast docs.' => 
      array (
        0 => 'Dowiedz się więcej o kanałach wydawniczych w dokumentacji AzuraCast.',
      ),
      'Show Update Announcements' => 
      array (
        0 => 'Pokaż ogłoszenia aktualizacji',
      ),
      'Show new releases within your update channel on the AzuraCast homepage.' => 
      array (
        0 => 'Pokaż nowe wydania na swoim kanale aktualizacji na stronie głównej AzuraCast.',
      ),
      'E-mail Delivery Service' => 
      array (
        0 => 'Usługa doręczania poczty elektronicznej',
      ),
      'Used for "Forgot Password" functionality, web hooks and other functions.' => 
      array (
        0 => 'Używane do funkcji "Zapomniałeś hasła", webhooków i innych funkcji.',
      ),
      'Enable Mail Delivery' => 
      array (
        0 => 'Włącz Wysyłanie Emaili',
      ),
      'Sender Name' => 
      array (
        0 => 'Nazwa nadawcy',
      ),
      'Sender E-mail Address' => 
      array (
        0 => 'Adres e-mail nadawcy',
      ),
      'SMTP Host' => 
      array (
        0 => 'Host SMTP',
      ),
      'SMTP Port' => 
      array (
        0 => 'Port SMTP',
      ),
      'Use Secure (TLS) SMTP Connection' => 
      array (
        0 => 'Użyj bezpiecznego połączenia SMTP (TLS)',
      ),
      'Usually enabled for port 465, disabled for ports 587 or 25.' => 
      array (
        0 => 'Zazwyczaj włączone dla portu 465, wyłączone dla portów 587 lub 25.',
      ),
      'SMTP Username' => 
      array (
        0 => 'Nazwa użytkownika SMTP',
      ),
      'SMTP Password' => 
      array (
        0 => 'Hasło SMTP',
      ),
      'Avatar Services' => 
      array (
        0 => 'Usługi awatarów',
      ),
      'Avatar Service' => 
      array (
        0 => 'Usługa awatarów',
      ),
      'Default Avatar URL' => 
      array (
        0 => 'Domyślny adres URL awatara',
      ),
      'Album Art Services' => 
      array (
        0 => 'Usługi dostarczania okładek albumów',
      ),
      'Check Web Services for Album Art for "Now Playing" Tracks' => 
      array (
        0 => 'Sprawdź usługi sieciowe w poszukiwaniu okładki albumu dla utworów z listy "Teraz Odtwarzane"',
      ),
      'Check Web Services for Album Art When Uploading Media' => 
      array (
        0 => 'Sprawdź usługi sieciowe w poszukiwaniu okładki albumu podczas przesyłania multimediów',
      ),
      'Last.fm API Key' => 
      array (
        0 => 'Klucz API Last.fm',
      ),
      'This service can provide album art for tracks where none is available locally.' => 
      array (
        0 => 'Ta usługa może dostarczać okładki albumów dla utworów, dla których lokalnie nie są dostępne żadne okładki.',
      ),
      'Apply for an API key at Last.fm' => 
      array (
        0 => 'Wyślij wniosek o klucz API w Last.fm',
      ),
      'Last 60 Days' => 
      array (
        0 => 'Ostatnie 60 dni',
      ),
      'Last Year' => 
      array (
        0 => 'Ostatni rok',
      ),
      'Last 2 Years' => 
      array (
        0 => 'Ostatnie 2 lata',
      ),
      'Indefinitely' => 
      array (
        0 => 'Nieokreślony',
      ),
      'Site Base URL' => 
      array (
        0 => 'Podstawowy adres URL witryny',
      ),
      'The base URL where this service is located. Use either the external IP address or fully-qualified domain name (if one exists) pointing to this server.' => 
      array (
        0 => 'Podstawowy adres URL, pod którym znajduje się ta usługa. Użyj zewnętrznego adresu IP lub pełnej nazwy domeny (jeśli istnieje) wskazującej na ten serwer.',
      ),
      'AzuraCast Instance Name' => 
      array (
        0 => 'Nazwa instancji AzuraCast',
      ),
      'This name will appear as a sub-header next to the AzuraCast logo, to help identify this server.' => 
      array (
        0 => 'Ta nazwa będzie wyświetlana jako nagłówek podrzędny obok loga AzuraCast, aby pomóc zidentyfikować ten serwer.',
      ),
      'Prefer Browser URL (If Available)' => 
      array (
        0 => 'Preferuj URL przeglądarki (jeśli dostępne)',
      ),
      'If this setting is set to "Yes", the browser URL will be used instead of the base URL when it\'s available. Set to "No" to always use the base URL.' => 
      array (
        0 => 'Jeśli ustawione na "Tak", tam gdzie to możliwe, będzie wykorzystywany URL przeglądarki zamiast podstawowego URL. Ustaw na "Nie", aby zawsze używać podstawowego URL.',
      ),
      'Use Web Proxy for Radio' => 
      array (
        0 => 'Użyj sieciowego serwera proxy dla radia',
      ),
      'By default, radio stations broadcast on their own ports (i.e. 8000). If you\'re using a service like CloudFlare or accessing your radio station by SSL, you should enable this feature, which routes all radio through the web ports (80 and 443).' => 
      array (
        0 => 'Domyślnie stacje radiowe nadają na swoje własne porty (czyli 8000). Jeśli używasz usługi takiej jak CloudFlare lub używasz dostępu do stacji radiowej przez SSL, należy włączyć tę funkcję, która przekierowuje wszystkie radia za pośrednictwem portów sieci web (80 i 443).',
      ),
      'Days of Playback History to Keep' => 
      array (
        0 => 'Ilość dni w historii odtwarzania',
      ),
      'Set longer to preserve more playback history and listener metadata for stations. Set shorter to save disk space.' => 
      array (
        0 => 'Ustaw dłuższe, aby zachować więcej historii odtwarzania i metadanych słuchacza dla stacji. Ustaw krótsze, aby zaoszczędzić miejsce na dysku.',
      ),
      'Use WebSockets for Now Playing Updates' => 
      array (
        0 => 'Użyj WebSocketów do aktualizacji aktualnie odtwarzanego utworu',
      ),
      'Enables or disables the use of the newer and faster WebSocket-based system for receiving live updates on public players. You may need to disable this if you encounter problems with it.' => 
      array (
        0 => 'Włącza lub wyłącza korzystanie z nowszych i szybszych systemów opartych na WebSocket, aby otrzymywać aktualizacje na żywo w publicznych odtwarzaczach. Wyłącz tą opcję, jeżeli napotkasz z nią problemy.',
      ),
      'Enable Advanced Features' => 
      array (
        0 => 'Włącz zaawansowane funkcje',
      ),
      'Enable certain advanced features in the web interface, including advanced playlist configuration, station port assignment, changing base media directories and other functionality that should only be used by users who are comfortable with advanced functionality.' => 
      array (
        0 => 'Włącz niektóre zaawansowane funkcje w interfejsie WWW, w tym zaawansowaną konfigurację playlisty, przydział portów stacji, zmianę podstawowych katalogów multimediów i inne funkcje, które powinny być używane tylko przez użytkowników, którzy są zaznajomieni z zaawansowaną funkcjonalnością.',
      ),
      'Security & Privacy' => 
      array (
        0 => 'Bezpieczeństwo i prywatność',
      ),
      'Privacy' => 
      array (
        0 => 'Prywatność',
      ),
      'Listener Analytics Collection' => 
      array (
        0 => 'Zbiór analiz danych o słuchaczach',
      ),
      'Aggregate listener statistics are used to show station reports across the system. IP-based listener statistics are used to view live listener tracking and may be required for royalty reports.' => 
      array (
        0 => 'Zbiorcze statystyki słuchalności są wykorzystywane do wyświetlania raportów o stacjach na przestrzeni całego systemu. Statystyki słuchalności w oparciu o IP są wykorzystywane do śledzenia aktualnie słuchających i mogą być wymagane w raportach dotyczących tantiem.',
      ),
      'Full:' => 
      array (
        0 => 'Pełne:',
      ),
      'Collect aggregate listener statistics and IP-based listener statistics' => 
      array (
        0 => 'Zbieraj zbiorcze statystyki słuchalności oraz statystyki słuchaczy w oparciu o IP',
      ),
      'Limited:' => 
      array (
        0 => 'Ograniczony:',
      ),
      'Only collect aggregate listener statistics' => 
      array (
        0 => 'Zbieraj tylko zbiorcze statystyki słuchalności',
      ),
      'None:' => 
      array (
        0 => 'Brak:',
      ),
      'Do not collect any listener analytics' => 
      array (
        0 => 'Nie zbieraj żadnych statystyk słuchalności',
      ),
      'Security' => 
      array (
        0 => 'Bezpieczeństwo',
      ),
      'Always Use HTTPS' => 
      array (
        0 => 'Zawsze wykorzystuj HTTPS',
      ),
      'Set to "Yes" to always use "https://" secure URLs, and to automatically redirect to the secure URL when an insecure URL is visited.' => 
      array (
        0 => 'Ustaw "Tak", aby zawsze używać szyfrowanego adresu URL "https://" i automatycznie przekierować do szyfrowanego adresu URL w przypadku odwiedzenia nieszyfrowanego URL.',
      ),
      'API "Access-Control-Allow-Origin" Header' => 
      array (
        0 => 'Nagłówek API "Access-Control-Allow-Origin"',
      ),
      'Set to * to allow all sources, or specify a list of origins separated by a comma (,).' => 
      array (
        0 => 'Ustaw * aby zezwolić na wszystkie źródła lub określić listę źródeł oddzielonych przecinkami (,).',
      ),
      'Learn more about this header.' => 
      array (
        0 => 'Dowiedz się więcej o tym nagłówku.',
      ),
      'Auto-Assign Value' => 
      array (
        0 => 'Automatyczne przypisywanie wartości',
      ),
      'None' => 
      array (
        0 => 'Brak',
      ),
      'Delete Custom Field?' => 
      array (
        0 => 'Usunąć pole niestandardowe?',
      ),
      'Create custom fields to store extra metadata about each media file uploaded to your station libraries.' => 
      array (
        0 => 'Utwórz pola niestandardowe, aby przechowywać dodatkowe metadane o każdym pliku multimedialnym przesłanym do bibliotek stacji.',
      ),
      'Changes saved.' => 
      array (
        0 => 'Zapisano zmiany.',
      ),
      'System Settings' => 
      array (
        0 => 'Ustawienia systemu',
      ),
      'Browser Icon' => 
      array (
        0 => 'Ikona przeglądarki',
      ),
      'Public Page Background' => 
      array (
        0 => 'Tło strony publicznej',
      ),
      'Default Album Art' => 
      array (
        0 => 'Domyślna okładka albumu',
      ),
      'Custom Branding' => 
      array (
        0 => 'Własny branding',
      ),
      'Upload Custom Assets' => 
      array (
        0 => 'Prześlij niestandardowe zasoby',
      ),
      'Clear Image' => 
      array (
        0 => 'Wyczyść obraz',
      ),
      'Prefer System Default' => 
      array (
        0 => 'Użyj domyślnych ustawień systemowych',
      ),
      'Branding Settings' => 
      array (
        0 => 'Ustawienia marki',
      ),
      'Base Theme for Public Pages' => 
      array (
        0 => 'Podstawowa skórka dla stron publicznych',
      ),
      'Select a theme to use as a base for station public pages and the login page.' => 
      array (
        0 => 'Wybierz skórkę do zastosowania dla publicznych stron stacji radiowych oraz na stronie logowania.',
      ),
      'Hide Album Art on Public Pages' => 
      array (
        0 => 'Ukryj okładki na stronach publicznych',
      ),
      'If selected, album art will not display on public-facing radio pages.' => 
      array (
        0 => 'Jeśli zaznaczone, okładki nie będą wyświetlane na publicznych stronach radiostacji.',
      ),
      'Hide AzuraCast Branding on Public Pages' => 
      array (
        0 => 'Ukryj branding AzuraCast na publicznych stronach',
      ),
      'If selected, this will remove the AzuraCast branding from public-facing pages.' => 
      array (
        0 => 'Jeśli zaznaczone, branding AzuraCast zostanie usunięty ze stron publicznych.',
      ),
      'Homepage Redirect URL' => 
      array (
        0 => 'URL przekierowania strony głównej',
      ),
      'If a visitor is not signed in and visits the AzuraCast homepage, you can automatically redirect them to the URL specified here. Leave blank to redirect them to the login screen by default.' => 
      array (
        0 => 'Jeśli odwiedzający nie jest zapisany i odwiedza stronę główną AzuraCast, możesz automatycznie przekierować go na podany tutaj URL. Pozostaw puste, aby domyślnie przekierować go do strony logowania.',
      ),
      'Custom CSS for Public Pages' => 
      array (
        0 => 'Własny CSS dla stron publicznych',
      ),
      'This CSS will be applied to the station public pages and login page.' => 
      array (
        0 => 'Ten CSS zostanie zastosowany na publicznych stronach stacji oraz na stronie logowania.',
      ),
      'Custom JS for Public Pages' => 
      array (
        0 => 'Własny JS dla stron publicznych',
      ),
      'This javascript code will be applied to the station public pages and login page.' => 
      array (
        0 => 'Niniejszy kod JavaScript zostanie zastosowany na publicznych stronach stacji oraz stronie logowania.',
      ),
      'Custom CSS for Internal Pages' => 
      array (
        0 => 'Własny CSS dla stron wewnętrznych',
      ),
      'This CSS will be applied to the main management pages, like this one.' => 
      array (
        0 => 'Niniejszy CSS zostanie zastosowany na głównych stronach panelu zarządzania, w tym na tej.',
      ),
      'Seek' => 
      array (
        0 => 'Szukaj',
      ),
      'Create Account' => 
      array (
        0 => 'Utwórz konto',
      ),
      'Create Station' => 
      array (
        0 => 'Utwórz stację',
      ),
      'AzuraCast First-Time Setup' => 
      array (
        0 => 'Ustawienia podczas pierwszego uruchomienia AzuraCast',
      ),
      'Welcome to AzuraCast!' => 
      array (
        0 => 'Witaj w AzuraCast!',
      ),
      'Let\'s get started by creating your Super Administrator account.' => 
      array (
        0 => 'Zacznijmy od utworzenia Twojego konta super administratora.',
      ),
      'This account will have full access to the system, and you\'ll automatically be logged in to it for the rest of setup.' => 
      array (
        0 => 'To konto będzie posiadało pełny dostęp do systemu, i zostaniesz na nie zalogowany automatycznie aby dokończyć instalację.',
      ),
      'E-mail Address' => 
      array (
        0 => 'Adres email',
      ),
      'Create a New Radio Station' => 
      array (
        0 => 'Utwórz nową radiostację',
      ),
      'Continue the setup process by creating your first radio station below. You can edit any of these details later.' => 
      array (
        0 => 'Kontynuuj proces instalacji, tworząc swoją pierwszą stację radiową. Każdą z tych informacji można edytować później.',
      ),
      'Create and Continue' => 
      array (
        0 => 'Utwórz i kontynuuj',
      ),
      'Customize AzuraCast Settings' => 
      array (
        0 => 'Dostosuj ustawienia AzuraCast',
      ),
      'Complete the setup process by providing some information about your broadcast environment. These settings can be changed later from the administration panel.' => 
      array (
        0 => 'Ukończ proces instalacji przez dostarczanie informacji o środowisku emisji. Te ustawienia można później zmienić z poziomu panelu administracyjnego.',
      ),
      'Save and Continue' => 
      array (
        0 => 'Zapisz i kontynuuj',
      ),
      'An error occurred and your request could not be completed.' => 
      array (
        0 => 'Wystąpił błąd i Twoje żądanie nie mogło zostać zakończone.',
      ),
      'Error' => 
      array (
        0 => '',
      ),
      'Success' => 
      array (
        0 => '',
      ),
      'Please wait...' => 
      array (
        0 => 'Proszę, czekaj...',
      ),
      'Delete Record?' => 
      array (
        0 => '',
      ),
      'The locale to use for CLI commands.' => 
      array (
        0 => 'Plik (locale) do użycia dla poleceń CLI.',
      ),
      'The application environment.' => 
      array (
        0 => 'Środowisko aplikacji.',
      ),
      'Manually modify the logging level.' => 
      array (
        0 => 'Ręczna modyfikacja poziomu zapisywania w dzienniku.',
      ),
      'This allows you to log debug-level errors temporarily (for problem-solving) or reduce the volume of logs that are produced by your installation, without needing to modify whether your installation is a production or development instance.' => 
      array (
        0 => 'Pozwala to na tymczasowe rejestrowanie błędów poziomu debugowania (dla rozwiązywania problemów) lub zmniejszenie ilości logów generowanych przez instalację, bez konieczności modyfikowania czy twoja instalacja działa w środowisku produkcyjnym czy rozwojowym.',
      ),
      'Composer Plugin Mode' => 
      array (
        0 => 'Tryb Wtyczki Composera',
      ),
      'Enable the composer "merge" functionality to combine the main application\'s composer.json file with any plugin composer files. This can have performance implications, so you should only use it if you use one or more plugins with their own Composer dependencies.' => 
      array (
        0 => 'Włącz funkcję "scalanie" composera aby połączyć plik composer.json głównej aplikacji z plikami wtyczek composera. Może to mieć wpływ na wydajność, więc powinieneś go używać tylko wtedy, gdy używasz jednej lub więcej wtyczek z ich własnymi zależnościami composera.',
      ),
      'Minimum Port for Station Port Assignment' => 
      array (
        0 => 'Minimalny Port dla Przypisania Portu Stacji',
      ),
      'Modify this if your stations are listening on nonstandard ports.' => 
      array (
        0 => 'Zmodyfikuj to, jeśli twoje stacje nasłuchują na niestandardowych portach.',
      ),
      'Maximum Port for Station Port Assignment' => 
      array (
        0 => 'Maksymalny Port dla Przypisania Portu Stacji',
      ),
      'MariaDB Host' => 
      array (
        0 => 'Host MariaDB',
      ),
      'Do not modify this after installation.' => 
      array (
        0 => 'Nie zmieniaj tego po instalacji.',
      ),
      'MariaDB Port' => 
      array (
        0 => 'Port MariaDB',
      ),
      'MariaDB Username' => 
      array (
        0 => 'Nazwa użytkownika MariaDB',
      ),
      'MariaDB Password' => 
      array (
        0 => 'Hasło MariaDB',
      ),
      'MariaDB Database Name' => 
      array (
        0 => 'Nazwa bazy danych MariaDB',
      ),
      'Auto-generate Random MariaDB Root Password' => 
      array (
        0 => 'Automatycznie generuj losowe hasło roota MariaDB',
      ),
      'MariaDB Root Password' => 
      array (
        0 => 'Hasło główne MariaDB',
      ),
      'Enable MariaDB Slow Query Log' => 
      array (
        0 => 'Włącz Rejestr Powolnych Zapytań w MariaDB',
      ),
      'Log slower queries to diagnose possible database issues. Only turn this on if needed.' => 
      array (
        0 => 'Rejestruj wolniejsze zapytania, aby zdiagnozować możliwe problemy z bazą danych. Włącz to tylko w razie potrzeby.',
      ),
      'MariaDB Maximum Connections' => 
      array (
        0 => 'Maksymalna liczba połączeń z MariaDB',
      ),
      'Set the amount of allowed connections to the database. This value should be increased if you are seeing the "Too many connections" error in the logs.' => 
      array (
        0 => 'Ustaw ilość dozwolonych połączeń do bazy danych. Ta wartość powinna zostać zwiększona, jeśli widzisz w logach błąd "Zbyt wiele połączeń".',
      ),
      'Enable Redis' => 
      array (
        0 => 'Włącz Redis',
      ),
      'Disable to use a flatfile cache instead of Redis.' => 
      array (
        0 => 'Wyłącz, aby używać pamięci podręcznej plików płaskich (flatfiles) zamiast Redis.',
      ),
      'Redis Host' => 
      array (
        0 => 'Host Redis',
      ),
      'Redis Port' => 
      array (
        0 => 'Port Redis',
      ),
      'Redis Database Index' => 
      array (
        0 => 'Indeks bazy danych Redis',
      ),
      'PHP Maximum POST File Size' => 
      array (
        0 => 'Maksymalny rozmiar pliku w żądaniu POST w PHP',
      ),
      'PHP Memory Limit' => 
      array (
        0 => 'Limit pamięci PHP',
      ),
      'PHP Script Maximum Execution Time' => 
      array (
        0 => 'Maksymalny czas wykonania skryptu PHP',
      ),
      '(in seconds)' => 
      array (
        0 => '(w sekundach)',
      ),
      'Short Sync Task Execution Time' => 
      array (
        0 => 'Krótki czas wykonania zadania synchronizacji',
      ),
      'The maximum execution time (and lock timeout) for the 15-second, 1-minute and 5-minute synchronization tasks.' => 
      array (
        0 => 'Maksymalny czas wykonania (i czas blokowania) dla 15-sekundowych, 1-minutowych i 5-minutowych zadań synchronizacji.',
      ),
      'Long Sync Task Execution Time' => 
      array (
        0 => 'Długi czas wykonywania zadania synchronizacji',
      ),
      'The maximum execution time (and lock timeout) for the 1-hour synchronization task.' => 
      array (
        0 => 'Maksymalny czas wykonania (i czas blokowania) dla zadania synchronizacji 1-godzinnej.',
      ),
      'Maximum PHP-FPM Worker Processes' => 
      array (
        0 => 'Maksymalna ilość procesów pracy PHP-FPM',
      ),
      'Enable Performance Profiling Extension' => 
      array (
        0 => 'Włącz Rozszerzenie Profilowania Wydajności',
      ),
      'Profiling data can be viewed by visiting %s.' => 
      array (
        0 => 'Dane profilowe można przeglądać odwiedzając %s.',
      ),
      'Profile Performance on All Requests' => 
      array (
        0 => 'Profiluj wydajność na wszystkich żądaniach',
      ),
      'This will have a significant performance impact on your installation.' => 
      array (
        0 => 'Będzie to miało znaczący wpływ na wydajność twojej instalacji.',
      ),
      'Profiling Extension HTTP Key' => 
      array (
        0 => 'Klucz HTTP Rozszerzenia Profilowania',
      ),
      'The value for the "SPX_KEY" parameter for viewing profiling pages.' => 
      array (
        0 => 'Wartość parametru "SPX_KEY" do przeglądania stron profilowania.',
      ),
      'Profiling Extension IP Allow List' => 
      array (
        0 => 'Lista dozwolonych adresów IP mających dostęp do rozszerzenia profilowania',
      ),
      '(Docker Compose) All Docker containers are prefixed by this name. Do not change this after installation.' => 
      array (
        0 => '(Docker Compose) Wszystkie kontenery Dockera są poprzedzone tą nazwą. Nie zmieniaj tego po zainstalowaniu.',
      ),
      '(Docker Compose) The amount of time to wait before a Docker Compose operation fails. Increase this on lower performance computers.' => 
      array (
        0 => '(Docker Compose) Czas oczekiwania przed operacją Docker Compose jest niewystarczający. Zwiększ tę wartość na komputerach o niższej wydajności.',
      ),
      'AzuraCast Release Channel' => 
      array (
        0 => 'Kanał Wydawniczy AzuraCast',
      ),
      'HTTP Port' => 
      array (
        0 => 'Port HTTP',
      ),
      'The main port AzuraCast listens to for insecure HTTP connections.' => 
      array (
        0 => 'Główny port, jakiego AzuraCast używa do nasłuchiwania niezabezpieczonych połączeń HTTP.',
      ),
      'HTTPS Port' => 
      array (
        0 => 'Port HTTPS',
      ),
      'The main port AzuraCast listens to for secure HTTPS connections.' => 
      array (
        0 => 'Główny port, jakiego AzuraCast używa do nasłuchiwania zabezpieczonych połączeń HTTPS.',
      ),
      'SFTP Port' => 
      array (
        0 => 'Port SFTP',
      ),
      'The port AzuraCast listens to for SFTP file management connections.' => 
      array (
        0 => 'Port, na jakim AzuraCast nasłuchuje połączeń zarządzania plikami poprzez SFTP.',
      ),
      'Station Ports' => 
      array (
        0 => 'Porty stacji',
      ),
      'The ports AzuraCast should listen to for station broadcasts and incoming DJ connections.' => 
      array (
        0 => 'Porty, na których AzuraCast powinien nasłuchiwać strumieni stacji oraz przychodzących połączeń prezenterów.',
      ),
      'Docker User UID' => 
      array (
        0 => 'Identyfikator (UID) Użytkownika Dockera',
      ),
      'Set the UID of the user running inside the Docker containers. Matching this with your host UID can fix permission issues.' => 
      array (
        0 => 'Ustaw UID użytkownika działającego wewnątrz kontenerów Dockera. Dopasowanie tego do UID hosta może rozwiązać problemy z uprawnieniami.',
      ),
      'Docker User GID' => 
      array (
        0 => 'Identyfikator GID Użytkownika Dockera',
      ),
      'Set the GID of the user running inside the Docker containers. Matching this with your host GID can fix permission issues.' => 
      array (
        0 => 'Ustaw GID użytkownika działającego wewnątrz kontenerów Dockera. Dopasowanie tego do GID hosta może rozwiązać problemy z uprawnieniami.',
      ),
      'Advanced: Use Privileged Docker Settings' => 
      array (
        0 => 'Zaawansowane: Użyj Uprzywilejowanych Ustawień Dockera',
      ),
      'LetsEncrypt Domain Name(s)' => 
      array (
        0 => 'Nazwa(y) domen(y) LetsEncrypt',
      ),
      'Domain name (example.com) or names (example.com,foo.bar) to use with LetsEncrypt.' => 
      array (
        0 => 'Nazwa domeny (example.com) lub nazwy (example.com,foo.bar) do użycia z LetsEncrypt.',
      ),
      'LetsEncrypt E-mail Address' => 
      array (
        0 => 'Adres E-mail LetsEncrypt',
      ),
      'Optionally provide an e-mail address for updates from LetsEncrypt.' => 
      array (
        0 => 'Opcjonalnie podaj adres e-mail do otrzymywania aktualizacji od LetsEncrypt.',
      ),
      'This file was automatically generated by AzuraCast.' => 
      array (
        0 => 'Ten plik został wygenerowany automatycznie przez AzuraCast.',
      ),
      'You can modify it as necessary. To apply changes, restart the Docker containers.' => 
      array (
        0 => 'Możesz zmodyfikować to w razie potrzeby. Aby zastosować zmiany, uruchom ponownie kontenery Dockera.',
      ),
      'Remove the leading "#" symbol from lines to uncomment them.' => 
      array (
        0 => 'Usuń poprzedzający symbol "#" z linii, aby je odkomentować.',
      ),
      'Valid options: %s' => 
      array (
        0 => 'Prawidłowe opcje: %s',
      ),
      'Default: %s' => 
      array (
        0 => 'Domyślnie: %s',
      ),
      'Additional Environment Variables' => 
      array (
        0 => 'Dodatkowe zmienne środowiskowe',
      ),
      'AzuraCast Installer' => 
      array (
        0 => 'Instalator AzuraCast',
      ),
      'Welcome to AzuraCast! Complete the initial server setup by answering a few questions.' => 
      array (
        0 => 'Witamy w AzuraCast! Ukończ konfigurację serwera odpowiadając na kilka pytań.',
      ),
      'AzuraCast Updater' => 
      array (
        0 => 'Narzędzie Aktualizacji AzuraCast',
      ),
      'Change installation settings?' => 
      array (
        0 => 'Zmienić ustawienia instalacji?',
      ),
      'AzuraCast is currently configured to listen on the following ports:' => 
      array (
        0 => 'AzuraCast jest obecnie skonfigurowany do nasłuchiwania na następujących portach:',
      ),
      'HTTP Port: %d' => 
      array (
        0 => 'Port HTTP: %d',
      ),
      'HTTPS Port: %d' => 
      array (
        0 => 'Port HTTPS: %d',
      ),
      'SFTP Port: %d' => 
      array (
        0 => 'Port SFTP: %d',
      ),
      'Radio Ports: %s' => 
      array (
        0 => 'Porty radiowe: %s',
      ),
      'Customize ports used for AzuraCast?' => 
      array (
        0 => 'Dostosować używane porty dla AzuraCast?',
      ),
      'Set up LetsEncrypt?' => 
      array (
        0 => 'Ustawić LetsEncrypt?',
      ),
      'Writing configuration files...' => 
      array (
        0 => 'Zapisywanie plików konfiguracyjnych...',
      ),
      'Server configuration complete!' => 
      array (
        0 => 'Konfiguracja serwera zakończona!',
      ),
      'This product includes GeoLite2 data created by MaxMind, available from %s.' => 
      array (
        0 => 'Ten produkt zawiera dane z GeoLite2 utworzone przez MaxMind, dostępne od %s.',
      ),
      'IP Geolocation by DB-IP' => 
      array (
        0 => 'Geolokalizacja IP przez DB-IP',
      ),
      'GeoLite database not configured for this installation. See System Administration for instructions.' => 
      array (
        0 => 'Baza danych GeoLite nie jest skonfigurowana dla tej instalacji. Zobacz instrukcje Administracji Systemu.',
      ),
      'Welcome to the AzuraCast Liquidsoap configuration editor.' => 
      array (
        0 => 'Witamy w edytorze konfiguracji AzuraCast Liquidsoap.',
      ),
      'Using this page, you can customize several sections of the Liquidsoap configuration.' => 
      array (
        0 => 'Korzystając z tej strony, możesz dostosować kilka sekcji konfiguracji Liquidsoap.',
      ),
      'The non-editable sections are automatically generated by AzuraCast.' => 
      array (
        0 => 'Sekcje nieedytowalne są generowane automatycznie przez AzuraCast.',
      ),
      '%s is not recognized as a service.' => 
      array (
        0 => '%s nie jest rozpoznany jako usługa.',
      ),
      'It may not be registered with Supervisor yet. Restarting broadcasting may help.' => 
      array (
        0 => 'Nie może być jeszcze zarejestrowana przez Inspektora. Ponowne uruchomienie nadawania może okazać się pomocne.',
      ),
      '%s cannot start' => 
      array (
        0 => '%s nie może się uruchomić',
      ),
      'It is already running.' => 
      array (
        0 => 'Wskazany element już został uruchomiony.',
      ),
      '%s cannot stop' => 
      array (
        0 => '%s nie może się zatrzymać',
      ),
      'It is not running.' => 
      array (
        0 => 'Wskazany element nie działa.',
      ),
      '%s encountered an error' => 
      array (
        0 => '%s napotkał błąd',
      ),
      'Check the log for details.' => 
      array (
        0 => 'Sprawdź dziennik, aby uzyskać szczegółowe informacje.',
      ),
      'Select...' => 
      array (
        0 => 'Wybierz...',
      ),
      'This feature is not currently supported on this station.' => 
      array (
        0 => 'Ta funkcja nie jest obecnie obsługiwana na tej stacji.',
      ),
      'Now Playing Data' => 
      array (
        0 => 'Teraz odtwarzane',
      ),
      '1-Minute Sync' => 
      array (
        0 => 'Synchronizacja co minutę',
      ),
      'Song Requests Queue' => 
      array (
        0 => 'Kolejka żądanych utworów',
      ),
      '5-Minute Sync' => 
      array (
        0 => 'Synchronizacja co 5 minut',
      ),
      'Check Media Folders' => 
      array (
        0 => 'Sprawdź foldery multimediów',
      ),
      '1-Hour Sync' => 
      array (
        0 => 'Synchronizacja co godzinę',
      ),
      'Analytics/Statistics' => 
      array (
        0 => 'Analiza/Statystyki',
      ),
      'Cleanup' => 
      array (
        0 => 'Wyczyść',
      ),
      'Installation Not Recently Backed Up' => 
      array (
        0 => 'Nie wykonano najnowszej kopii zapasowej tej instalacji',
      ),
      'This installation has not been backed up in the last two weeks.' => 
      array (
        0 => 'Ta instalacja w ciągu 2 tygodni nie utworzyła kopii zapasowej.',
      ),
      'Update Instructions' => 
      array (
        0 => 'Instrukcje aktualizacji',
      ),
      'AzuraCast <a href="%s" target="_blank">version %s</a> is now available.' => 
      array (
        0 => 'Dostępna jest <a href="%s" target="_blank">wersja %s</a> oprogramowania AzuraCast.',
      ),
      'You are currently running version %s. Updating is highly recommended.' => 
      array (
        0 => 'Obecnie wykorzystujesz wersję %s. Aktualizacja jest wysoce zalecana.',
      ),
      'New AzuraCast Release Version Available' => 
      array (
        0 => 'Dostępna jest nowa wersja oprogramowania AzuraCast',
      ),
      'Your installation is currently %d update(s) behind the latest version.' => 
      array (
        0 => 'Twoja instalacja jest obecnie %d aktualizacji za najnowszą wersją.',
      ),
      'View the changelog for full details.' => 
      array (
        0 => 'Zobacz listę zmian w celu uzyskania pełnych informacji.',
      ),
      'You should update to take advantage of bug and security fixes.' => 
      array (
        0 => 'Powinieneś dokonać aktualizacji, aby uzyskać poprawki błędów i bezpieczeństwa.',
      ),
      'New AzuraCast Updates Available' => 
      array (
        0 => 'Dostępne są nowe aktualizacje AzuraCast',
      ),
      'Synchronized Task Not Recently Run' => 
      array (
        0 => 'Zsynchronizowane zadanie nie zostało ostatnio uruchomione',
      ),
      'The "%s" synchronization task has not run recently. This may indicate an error with your installation.' => 
      array (
        0 => 'Zadanie synchronizacji "%s" nie zostało ostatnio uruchomione. Może to wskazywać na błąd instalacji.',
      ),
      'Manually Run Task' => 
      array (
        0 => 'Ręcznie uruchom zadanie',
      ),
      'The performance profiling extension is currently enabled on this installation.' => 
      array (
        0 => 'Rozszerzenie służące do profilowania wydajności jest obecnie włączone w tej instalacji.',
      ),
      'You can track the execution time and memory usage of any AzuraCast page or application from the profiler page.' => 
      array (
        0 => 'Możesz śledzić czas wykonania i użycie pamięci każdej strony AzuraCast lub aplikacji na stronie profilera.',
      ),
      'Profiler Control Panel' => 
      array (
        0 => 'Panel Sterowania Profilera',
      ),
      'Performance profiling is currently enabled for all requests.' => 
      array (
        0 => 'Profilowanie wydajności jest obecnie włączone dla wszystkich żądań.',
      ),
      'This can have an adverse impact on system performance. You should disable this when possible.' => 
      array (
        0 => 'Może to mieć niekorzystny wpływ na wydajność systemu. Powinieneś to wyłączyć, jeśli to możliwe.',
      ),
      'You should update your <code>docker-compose.yml</code> file to reflect the newest changes.' => 
      array (
        0 => 'Powinieneś zaktualizować plik <code>docker-compose.yml</code> , aby uwzględniał najnowsze zmiany.',
      ),
      'If you manually maintain this file, review the <a href="%s" target="_blank">latest version of the file</a> and make any changes needed.' => 
      array (
        0 => 'Jeśli ręcznie edytujesz ten plik, przejrzyj <a href="%s" target="_blank">najnowszą wersję pliku</a> i wprowadź potrzebne zmiany.',
      ),
      'Otherwise, update your installation and answer "Y" when prompted to update the file.' => 
      array (
        0 => 'W przeciwnym razie zaktualizuj swoją instalację i odpowiedz "Y", gdy zostaniesz poproszony o aktualizację pliku.',
      ),
      'Your <code>docker-compose.yml</code> file is out of date!' => 
      array (
        0 => 'Plik<code>docker-compose.yml </code>jest nieaktualny!',
      ),
      'You must be logged in to access this page.' => 
      array (
        0 => 'Musisz być zalogowany aby korzystać z tej strony.',
      ),
      'You do not have permission to access this portion of the site.' => 
      array (
        0 => 'Nie masz uprawnień do dostępu do tej części witryny.',
      ),
      'All Permissions' => 
      array (
        0 => 'Wszystkie uprawnienia',
      ),
      'View Administration Page' => 
      array (
        0 => 'Pokaż panel administracyjny',
      ),
      'View System Logs' => 
      array (
        0 => 'Przejrzyj dziennik systemowy',
      ),
      'Administer Settings' => 
      array (
        0 => 'Zarządzaj ustawieniami',
      ),
      'Administer API Keys' => 
      array (
        0 => 'Zarządzaj kluczami API',
      ),
      'Administer Stations' => 
      array (
        0 => 'Zarządzaj stacjami',
      ),
      'Administer Custom Fields' => 
      array (
        0 => 'Zarządzaj polami niestandardowymi',
      ),
      'Administer Backups' => 
      array (
        0 => 'Zarządzaj kopiami zapasowymi',
      ),
      'Administer Storage Locations' => 
      array (
        0 => 'Zarządzaj Lokalizacjami Przechowywania',
      ),
      'View Station Page' => 
      array (
        0 => 'Wyświetl stronę stacji',
      ),
      'View Station Reports' => 
      array (
        0 => 'Wyświetl raport słuchalności stacji',
      ),
      'View Station Logs' => 
      array (
        0 => 'Wyświetl logi stacji',
      ),
      'Manage Station Profile' => 
      array (
        0 => 'Edytuj profil stacji',
      ),
      'Manage Station Broadcasting' => 
      array (
        0 => 'Zarządzaj nadawaniem stacji',
      ),
      'Manage Station Streamers' => 
      array (
        0 => 'Zarządzaj streamerami stacji',
      ),
      'Manage Station Mount Points' => 
      array (
        0 => 'Zarządzaj punktami montowania stacji',
      ),
      'Manage Station Remote Relays' => 
      array (
        0 => 'Zarządzaj zdalnymi przekaźnikami stacji',
      ),
      'Manage Station Media' => 
      array (
        0 => 'Zarządzaj plikami dźwiękowymi stacji',
      ),
      'Manage Station Automation' => 
      array (
        0 => 'Zarządzaj automatyzacją stacji',
      ),
      'Manage Station Web Hooks' => 
      array (
        0 => 'Zarządzaj webhookami stacji',
      ),
      'Manage Station Podcasts' => 
      array (
        0 => 'Zarządzaj Podcastami Stacji',
      ),
      'Imported locale: %s' => 
      array (
        0 => 'Zaimportowano język: %s',
      ),
      'The account associated with e-mail address "%s" has been set as an administrator' => 
      array (
        0 => 'Konto połączone z adresem e-mail "%s" zostało ustawione jako administrator',
      ),
      'Account not found.' => 
      array (
        0 => 'Nie znaleziono konta.',
      ),
      'Fixtures loaded.' => 
      array (
        0 => 'Konfiguracje załadowane.',
      ),
      'Configuration successfully written.' => 
      array (
        0 => 'Konfiguracja została pomyślnie zapisana.',
      ),
      'AzuraCast Backup' => 
      array (
        0 => 'Kopia zapasowa AzuraCast',
      ),
      'Please wait while a backup is generated...' => 
      array (
        0 => 'Proszę czekać na wygenerowanie kopii zapasowej...',
      ),
      'Creating temporary directories...' => 
      array (
        0 => 'Tworzenie katalogów tymczasowych...',
      ),
      'Directory "%s" was not created' => 
      array (
        0 => 'Katalog "%s" nie został utworzony',
      ),
      'Backing up MariaDB...' => 
      array (
        0 => 'Tworzenie kopii zapasowej MariaDB...',
      ),
      'Creating backup archive...' => 
      array (
        0 => 'Tworzenie archiwum kopii zapasowej...',
      ),
      'Cleaning up temporary files...' => 
      array (
        0 => 'Czyszczenie plików tymczasowych...',
      ),
      'Backup complete in %.2f seconds.' => 
      array (
        0 => 'Do ukończenia kopii zapasowej pozostało %.2f sekund.',
      ),
      'Backup path %s not found!' => 
      array (
        0 => 'Nie znaleziono ścieżki kopii zapasowej %s!',
      ),
      'AzuraCast Setup' => 
      array (
        0 => 'Instalacja AzuraCast',
      ),
      'Welcome to AzuraCast. Please wait while some key dependencies of AzuraCast are set up...' => 
      array (
        0 => 'Witamy w AzuraCast. Poczekaj, aż niektóre kluczowe zależności AzuraCast zostaną skonfigurowane...',
      ),
      'Installing Data Fixtures' => 
      array (
        0 => 'Instalowanie Danych Konfiguracyjnych',
      ),
      'Refreshing All Stations' => 
      array (
        0 => 'Odświeżanie wszystkich stacji',
      ),
      'AzuraCast is now updated to the latest version!' => 
      array (
        0 => 'AzuraCast został zaktualizowany do najnowszej wersji!',
      ),
      'AzuraCast installation complete!' => 
      array (
        0 => 'Instalacja AzuraCast zakończona!',
      ),
      'Visit %s to complete setup.' => 
      array (
        0 => 'Odwiedź %s aby zakończyć konfigurację.',
      ),
      'Initialize AzuraCast' => 
      array (
        0 => 'Zainicjuj AzuraCast',
      ),
      'Initializing essential settings...' => 
      array (
        0 => 'Inicjowanie podstawowych ustawień...',
      ),
      'Environment: %s' => 
      array (
        0 => 'Środowisko: %s',
      ),
      'Installation Method: %s' => 
      array (
        0 => 'Metoda instalacji: %s',
      ),
      'Running Database Migrations' => 
      array (
        0 => 'Uruchamianie migracji bazy danych',
      ),
      'Generating Database Proxy Classes' => 
      array (
        0 => 'Generowanie klas proxy bazy danych',
      ),
      'Reload System Data' => 
      array (
        0 => 'Przeładuj dane systemowe',
      ),
      'AzuraCast is now initialized.' => 
      array (
        0 => 'AzuraCast jest teraz zainicjowany.',
      ),
      'AzuraCast Settings' => 
      array (
        0 => 'Ustawienia AzuraCast',
      ),
      'Setting Key' => 
      array (
        0 => 'Ustawianie klucza',
      ),
      'Setting Value' => 
      array (
        0 => 'Ustawianie wartości',
      ),
      'The port %s is in use by another station.' => 
      array (
        0 => 'Port %s jest już wykorzystywany przez inną stację.',
      ),
      'This value is already used.' => 
      array (
        0 => 'Ta wartość już jest używana.',
      ),
      'Storage location %s could not be validated: %s' => 
      array (
        0 => 'Lokalizacja przechowywania %s nie mogła zostać zweryfikowana: %s',
      ),
      'Storage location %s already exists.' => 
      array (
        0 => 'Lokalizacja przechowywania %s już istnieje.',
      ),
      'Search engine crawlers are not permitted to use this feature.' => 
      array (
        0 => 'Wyszukiwarki nie mogą używać tej funkcji.',
      ),
      'This station does not accept requests currently.' => 
      array (
        0 => 'Ta stacja obecnie nie akceptuje żądań.',
      ),
      'The song ID you specified could not be found in the station.' => 
      array (
        0 => 'Identyfikator utworu, który podałeś nie został znaleziony w stacji.',
      ),
      'The song ID you specified cannot be requested for this station.' => 
      array (
        0 => 'ID utworu, który podałeś nie może być żądany dla tej stacji.',
      ),
      'You have submitted a request too recently! Please wait before submitting another one.' => 
      array (
        0 => 'Zbyt szybko wysyłasz kolejne żądania! Poczekaj chwilę zanim wyślesz następne.',
      ),
      'Duplicate request: this song was already requested and will play soon.' => 
      array (
        0 => 'Zduplikowane żądanie: ta piosenka została już żądana i wkrótce zostanie odtworzona.',
      ),
      'This song or artist has been played too recently. Wait a while before requesting it again.' => 
      array (
        0 => 'Ta piosenka lub artysta została odtworzona niedawno. Poczekaj chwilę przed ponownym żądaniem.',
      ),
      'Changes saved successfully.' => 
      array (
        0 => 'Zmiany zostały pomyślnie zapisane.',
      ),
      'Record created successfully.' => 
      array (
        0 => 'Rekord utworzony pomyślnie.',
      ),
      'Record updated successfully.' => 
      array (
        0 => 'Rekord zaktualizowany pomyślnie.',
      ),
      'Record deleted successfully.' => 
      array (
        0 => 'Rekord został pomyślnie usunięty.',
      ),
      'Record not found' => 
      array (
        0 => 'Nie znaleziono wpisu',
      ),
      'The uploaded file exceeds the upload_max_filesize directive in php.ini.' => 
      array (
        0 => 'Wgrany plik przekracza limit określony przez dyrektywę upload_max_filesize w pliku php.ini.',
      ),
      'The uploaded file exceeds the MAX_FILE_SIZE directive from the HTML form.' => 
      array (
        0 => 'Przesłany plik przekracza imit określony przez dyrektywę MAX_FILE_SIZE z formularza HTML.',
      ),
      'The uploaded file was only partially uploaded.' => 
      array (
        0 => 'Wysyłany plik został przesłany tylko częściowo.',
      ),
      'No file was uploaded.' => 
      array (
        0 => 'Nie przesłano żadnego pliku.',
      ),
      'No temporary directory is available.' => 
      array (
        0 => 'Brak katalogu tymczasowego.',
      ),
      'Could not write to filesystem.' => 
      array (
        0 => 'Nie udało się zapisać do systemu plików.',
      ),
      'Upload halted by a PHP extension.' => 
      array (
        0 => 'Przesyłanie wstrzymane przez rozszerzenie PHP.',
      ),
      'Unspecified error.' => 
      array (
        0 => 'Nieokreślony błąd.',
      ),
      'Playlist: %s' => 
      array (
        0 => 'Playlista: %s',
      ),
      'Streamer: %s' => 
      array (
        0 => 'Streamer: %s',
      ),
      'Edit Liquidsoap Configuration' => 
      array (
        0 => 'Edytuj konfigurację Liquidsoap',
      ),
      'Streamers enabled!' => 
      array (
        0 => 'Streamery aktywowani!',
      ),
      'You can now set up streamer (DJ) accounts.' => 
      array (
        0 => 'Można teraz skonfigurować konta Streamera (DJ).',
      ),
      'Record not found.' => 
      array (
        0 => 'Nie znaleziono rekordu.',
      ),
      'Profile' => 
      array (
        0 => 'Profil',
      ),
      'Automated assignment complete!' => 
      array (
        0 => 'Automatyczne przypisanie kompletny!',
      ),
      'Automated assignment error' => 
      array (
        0 => 'Błąd automatycznego przypisania',
      ),
      'Statistics Overview' => 
      array (
        0 => 'Przegląd statystyk',
      ),
      'SoundExchange Report' => 
      array (
        0 => 'Raport SoundExchange',
      ),
      'No episodes found.' => 
      array (
        0 => 'Nie znaleziono odcinków.',
      ),
      'Episode not found.' => 
      array (
        0 => 'Odcinek nie znaleziony.',
      ),
      'Logged in successfully.' => 
      array (
        0 => 'Zalogowany pomyślnie.',
      ),
      'Login unsuccessful' => 
      array (
        0 => 'Logowanie nieudane',
      ),
      'Your credentials could not be verified.' => 
      array (
        0 => 'Nie można zweryfikować poświadczeń.',
      ),
      'Too many forgot password attempts' => 
      array (
        0 => 'Zbyt wiele prób użycia funkcji "Zapomniałem hasła"',
      ),
      'You have attempted to reset your password too many times. Please wait 30 seconds and try again.' => 
      array (
        0 => 'Próbowałeś zresetować hasło zbyt wiele razy. Proszę odczekać 30 sekund i spróbować ponownie.',
      ),
      'Account Recovery Link' => 
      array (
        0 => 'Link do odzyskiwania konta',
      ),
      'Account recovery e-mail sent.' => 
      array (
        0 => 'E-mail z odzyskiwaniem konta wysłany.',
      ),
      'If the e-mail address you provided is in the system, check your inbox for a password reset message.' => 
      array (
        0 => 'Jeśli podany adres e-mail jest w systemie, sprawdź swoją skrzynkę w poszukiwaniu wiadomości z informacją na temat resetowania hasła.',
      ),
      'Invalid token specified.' => 
      array (
        0 => 'Określono nieprawidłowy token.',
      ),
      'Logged in using account recovery token' => 
      array (
        0 => 'Zalogowany przy użyciu tokenu odzyskiwania konta',
      ),
      'Your password has been updated.' => 
      array (
        0 => 'Twoje hasło zostało zaktualizowane.',
      ),
      'Too many login attempts' => 
      array (
        0 => 'Zbyt wiele prób logowania',
      ),
      'You have attempted to log in too many times. Please wait 30 seconds and try again.' => 
      array (
        0 => 'Próbowano zalogować zbyt wiele razy. Odczekaj 30 sekund i spróbuj ponownie.',
      ),
      'Complete the setup process to get started.' => 
      array (
        0 => 'Ukończ proces instalacji, aby rozpocząć.',
      ),
      'API Key not found.' => 
      array (
        0 => 'Nie znaleziono klucza API.',
      ),
      'API Key updated.' => 
      array (
        0 => 'Klucz API zaktualizowany.',
      ),
      'Edit API Key' => 
      array (
        0 => 'Edytuj klucz API',
      ),
      'Add API Key' => 
      array (
        0 => 'Dodaj klucz API',
      ),
      'API Key deleted.' => 
      array (
        0 => 'Klucz API usunięty.',
      ),
      'Profile saved!' => 
      array (
        0 => 'Zapisano profil!',
      ),
      'The token you supplied is invalid. Please try again.' => 
      array (
        0 => 'Podany token jest nieprawidłowy. Spróbuj jeszcze raz.',
      ),
      'Two-factor authentication enabled.' => 
      array (
        0 => 'Włączono uwierzytelnianie dwuskładnikowe.',
      ),
      'Two-factor authentication disabled.' => 
      array (
        0 => 'Wyłączono uwierzytelnianie dwuskładnikowe.',
      ),
      'Set Up AzuraCast' => 
      array (
        0 => '',
      ),
      'Setup has already been completed!' => 
      array (
        0 => 'Instalacja została już ukończona!',
      ),
      'Dashboard' => 
      array (
        0 => 'Panel',
      ),
      'AzuraCast User' => 
      array (
        0 => 'Użytkownik AzuraCast',
      ),
      'This station does not support on-demand streaming.' => 
      array (
        0 => 'Ta stacja nie obsługuje streamingu na żądanie.',
      ),
      'Playlist successfully imported; %d of %d files were successfully matched.' => 
      array (
        0 => 'Lista odtwarzania pomyślnie zaimportowana; %d z %d plików zostało pomyślnie dopasowanych.',
      ),
      'This playlist is not a sequential playlist.' => 
      array (
        0 => 'Ta lista odtwarzania nie jest listą odtwarzania sekwencyjnego.',
      ),
      'Playlist reshuffled.' => 
      array (
        0 => 'Lista odtwarzania przetasowana.',
      ),
      'Playlist not found.' => 
      array (
        0 => 'Nie znaleziono listy odtwarzania.',
      ),
      'Playlist enabled.' => 
      array (
        0 => 'Playlista włączona.',
      ),
      'Playlist disabled.' => 
      array (
        0 => 'Playlista wyłączona.',
      ),
      'This station is out of available storage space.' => 
      array (
        0 => 'Przestrzeń dyskowa dla tej stacji jest zapełniona.',
      ),
      'No directory specified' => 
      array (
        0 => 'Nie określono katalogu',
      ),
      'File not specified.' => 
      array (
        0 => 'Plik nie został określony.',
      ),
      'New path not specified.' => 
      array (
        0 => 'Nie określono nowej ścieżki.',
      ),
      'File Not Processed: %s' => 
      array (
        0 => 'Plik nie został przetworzony: %s',
      ),
      'File Processing' => 
      array (
        0 => 'Przetwarzanie pliku',
      ),
      'Station restarted.' => 
      array (
        0 => 'Stacja uruchomiona ponownie.',
      ),
      'Frontend stopped.' => 
      array (
        0 => 'Frontend zatrzymany.',
      ),
      'Frontend started.' => 
      array (
        0 => 'Frontend uruchomiony.',
      ),
      'Frontend restarted.' => 
      array (
        0 => 'Frontend zrestartowany.',
      ),
      'Song skipped.' => 
      array (
        0 => 'Pominięty utwór.',
      ),
      'Streamer disconnected.' => 
      array (
        0 => 'Streamer odłączony.',
      ),
      'Backend stopped.' => 
      array (
        0 => 'Backend zatrzymany.',
      ),
      'Backend started.' => 
      array (
        0 => 'Backend uruchomiony.',
      ),
      'Backend restarted.' => 
      array (
        0 => 'Backend został ponownie uruchomiony.',
      ),
      'Web hook not found.' => 
      array (
        0 => 'Nie znaleziono webhooka.',
      ),
      'Web hook enabled.' => 
      array (
        0 => 'Włączono webhook.',
      ),
      'Web hook disabled.' => 
      array (
        0 => 'Webhook wyłączony.',
      ),
      'Podcast not found!' => 
      array (
        0 => 'Nie znaleziono podcastu!',
      ),
      'No recording available.' => 
      array (
        0 => 'Nagrywanie nie jest dostępne.',
      ),
      'All Stations' => 
      array (
        0 => 'Wszystkie stacje',
      ),
      'You cannot remove yourself.' => 
      array (
        0 => 'Nie możesz usunąć samego siebie.',
      ),
      'Create a new storage location based on the base directory.' => 
      array (
        0 => 'Utwórz nową lokalizację przechowywania na podstawie katalogu bazowego.',
      ),
      'Liquidsoap Log' => 
      array (
        0 => 'Dziennik Liquidsoap',
      ),
      'Liquidsoap Configuration' => 
      array (
        0 => 'Konfiguracja Liquidsoap',
      ),
      'Icecast Access Log' => 
      array (
        0 => 'Dziennik dostępu Icecast',
      ),
      'Icecast Error Log' => 
      array (
        0 => 'Dziennik błędów Icecast',
      ),
      'Icecast Configuration' => 
      array (
        0 => 'Konfiguracja Icecast',
      ),
      'SHOUTcast Log' => 
      array (
        0 => 'Dziennik SHOUTcast\'a',
      ),
      'SHOUTcast Configuration' => 
      array (
        0 => 'Konfiguracja SHOUTcast\'a',
      ),
      'User updated.' => 
      array (
        0 => 'Użytkownik zaktualizowany.',
      ),
      'User added.' => 
      array (
        0 => 'Użytkownik dodany.',
      ),
      'Another user already exists with this e-mail address. Please update the e-mail address.' => 
      array (
        0 => 'Inny użytkownik już istnieje z tym adresem e-mail. Proszę zaktualizować adres e-mail.',
      ),
      'Edit User' => 
      array (
        0 => 'Edytuj użytkownika',
      ),
      'Add User' => 
      array (
        0 => 'Dodaj użytkownika',
      ),
      'You cannot delete your own account.' => 
      array (
        0 => 'Nie możesz usunąć swojego konta.',
      ),
      'User deleted.' => 
      array (
        0 => 'Użytkownik usunięty.',
      ),
      'User not found.' => 
      array (
        0 => 'Nie znaleziono użytkownika.',
      ),
      'AzuraCast Application Log' => 
      array (
        0 => 'Dziennik aplikacji AzuraCast',
      ),
      'Nginx Access Log' => 
      array (
        0 => 'Dziennik dostępu Nginx',
      ),
      'Nginx Error Log' => 
      array (
        0 => 'Dziennik błędów Nginx',
      ),
      'PHP Application Log' => 
      array (
        0 => 'Dziennik aplikacji PHP',
      ),
      'Supervisord Log' => 
      array (
        0 => 'Supervisord dziennika',
      ),
      'Album Artist Sort Order' => 
      array (
        0 => 'Kolejność sortowania wykonawcy albumu',
      ),
      'Album Sort Order' => 
      array (
        0 => 'Kolejność sortowania albumów',
      ),
      'Band' => 
      array (
        0 => 'Zespół',
      ),
      'Bpm' => 
      array (
        0 => 'Bpm',
      ),
      'Comment' => 
      array (
        0 => 'Komentarz',
      ),
      'Commercial Information' => 
      array (
        0 => 'Informacje handlowe',
      ),
      'Composer' => 
      array (
        0 => 'Kompozytor',
      ),
      'Composer Sort Order' => 
      array (
        0 => 'Kolejność sortowania kompozytora',
      ),
      'Conductor' => 
      array (
        0 => 'Dyrygent',
      ),
      'Content Group Description' => 
      array (
        0 => 'Opis grupy treści',
      ),
      'Copyright' => 
      array (
        0 => 'Prawa autorskie',
      ),
      'Copyright Message' => 
      array (
        0 => 'Informacja o prawach autorskich',
      ),
      'Encoded By' => 
      array (
        0 => 'Kodowane przez',
      ),
      'Encoder Settings' => 
      array (
        0 => 'Ustawienia enkodera',
      ),
      'Encoding Time' => 
      array (
        0 => 'Czas kodowania',
      ),
      'File Owner' => 
      array (
        0 => 'Właściciel pliku',
      ),
      'File Type' => 
      array (
        0 => 'Typ pliku',
      ),
      'Initial Key' => 
      array (
        0 => 'Początkowy klucz',
      ),
      'Internet Radio Station Name' => 
      array (
        0 => 'Nazwa internetowej stacji radiowej',
      ),
      'Internet Radio Station Owner' => 
      array (
        0 => 'Właściciel internetowej stacji radiowej',
      ),
      'Involved People List' => 
      array (
        0 => 'Lista zaangażowanych osób',
      ),
      'Linked Information' => 
      array (
        0 => 'Powiązane informacje',
      ),
      'Lyricist' => 
      array (
        0 => 'Autor tekstu',
      ),
      'Media Type' => 
      array (
        0 => 'Typ multimediów',
      ),
      'Mood' => 
      array (
        0 => 'Nastrój',
      ),
      'Music CD Identifier' => 
      array (
        0 => 'Identyfikator płyty CD',
      ),
      'Musician Credits List' => 
      array (
        0 => 'Lista Muzyków',
      ),
      'Original Album' => 
      array (
        0 => 'Oryginalny album',
      ),
      'Original Artist' => 
      array (
        0 => 'Oryginalny Artysta',
      ),
      'Original Filename' => 
      array (
        0 => 'Oryginalna nazwa pliku',
      ),
      'Original Lyricist' => 
      array (
        0 => 'Oryginalny autor tekstu',
      ),
      'Original Release Time' => 
      array (
        0 => 'Oryginalny czas wydania',
      ),
      'Original Year' => 
      array (
        0 => 'Pierwotny rok',
      ),
      'Part Of A Compilation' => 
      array (
        0 => 'Część składanki',
      ),
      'Part Of A Set' => 
      array (
        0 => 'Część zestawu',
      ),
      'Performer Sort Order' => 
      array (
        0 => 'Kolejność sortowania wykonawców',
      ),
      'Playlist Delay' => 
      array (
        0 => 'Opóźnienie Playlisty',
      ),
      'Produced Notice' => 
      array (
        0 => 'Wydane Powiadomienie',
      ),
      'Publisher' => 
      array (
        0 => 'Wydawca',
      ),
      'Recording Time' => 
      array (
        0 => 'Czas nagrywania',
      ),
      'Release Time' => 
      array (
        0 => 'Czas wydania',
      ),
      'Remixer' => 
      array (
        0 => 'Remixer',
      ),
      'Set Subtitle' => 
      array (
        0 => 'Ustaw napisy',
      ),
      'Subtitle' => 
      array (
        0 => 'Podtytuł',
      ),
      'Tagging Time' => 
      array (
        0 => 'Czas tagowania',
      ),
      'Terms Of Use' => 
      array (
        0 => 'Warunki użytkowania',
      ),
      'Title Sort Order' => 
      array (
        0 => 'Kolejność sortowania tytułu',
      ),
      'Track Number' => 
      array (
        0 => 'Numer utworu',
      ),
      'Unsynchronised Lyric' => 
      array (
        0 => 'Niezsynchronizowany tekst',
      ),
      'URL Artist' => 
      array (
        0 => 'URL Artysty',
      ),
      'URL File' => 
      array (
        0 => 'URL Pliku',
      ),
      'URL Payment' => 
      array (
        0 => 'URL Płatności',
      ),
      'URL Publisher' => 
      array (
        0 => 'URL Wydawcy',
      ),
      'URL Source' => 
      array (
        0 => 'URL Źródła',
      ),
      'URL Station' => 
      array (
        0 => 'URL Stacji',
      ),
      'URL User' => 
      array (
        0 => 'URL Użytkownika',
      ),
      'Year' => 
      array (
        0 => 'Rok',
      ),
      'Run Synchronized Task' => 
      array (
        0 => 'Uruchom zsynchronizowane zadanie',
      ),
      'Debug Output' => 
      array (
        0 => 'Wynik Debugowania',
      ),
      'Configure Backups' => 
      array (
        0 => 'Skonfiguruj kopie zapasowe',
      ),
      'Run Manual Backup' => 
      array (
        0 => 'Uruchom ręczne tworzenie kopii zapasowej',
      ),
      'Backup deleted.' => 
      array (
        0 => 'Kopia zapasowa usunięta.',
      ),
      'Backup not found.' => 
      array (
        0 => 'Nie znaleziono kopii zapasowej.',
      ),
      'Are you sure?' => 
      array (
        0 => 'Jesteś pewien?',
      ),
      'Enter a password to continue.' => 
      array (
        0 => 'Wprowadź hasło, aby kontynuować.',
      ),
      'No problems detected.' => 
      array (
        0 => 'Nie wykryto żadnych problemów.',
      ),
      'Generate the translation locale file.' => 
      array (
        0 => 'Wygeneruj plik językowy tłumaczenia.',
      ),
      'Convert translated locale files into PHP arrays.' => 
      array (
        0 => 'Konwertuj przetłumaczone pliki językowe na tablice PHP arrays.',
      ),
      'Ensure key settings are initialized within AzuraCast.' => 
      array (
        0 => 'Upewnij się, że kluczowe ustawienia są zainicjowane w AzuraCast.',
      ),
      'Migrate existing configuration to new INI format if any exists.' => 
      array (
        0 => 'Migruj istniejącą konfigurację do nowego formatu INI, jeśli istnieje.',
      ),
      'Install fixtures for demo / local development.' => 
      array (
        0 => 'Zainstaluj dane konfiguracyjne w celu użycia demonstracyjnego / lokalnego.',
      ),
      'Run all general AzuraCast setup steps.' => 
      array (
        0 => 'Uruchom wszystkie ogólne kroki konfiguracji AzuraCast.',
      ),
      'Run one or more scheduled synchronization tasks.' => 
      array (
        0 => 'Uruchom jedno lub więcej zaplanowanych zadań synchronizacji.',
      ),
      'Process the message queue.' => 
      array (
        0 => 'Przetwarzaj kolejkę wiadomości.',
      ),
      'Clear the contents of the message queue.' => 
      array (
        0 => 'Wyczyść zawartość kolejki wiadomości.',
      ),
      'List all settings in the AzuraCast settings database.' => 
      array (
        0 => 'Wyświetl wszystkie ustawienia w bazie danych ustawień AzuraCast.',
      ),
      'Back up the AzuraCast database and statistics (and optionally media).' => 
      array (
        0 => 'Wykonaj kopię zapasową bazy danych AzuraCast i statystyk (i opcjonalnie mediów).',
      ),
      'System Maintenance' => 
      array (
        0 => 'Konserwacja systemu',
      ),
      'System Logs' => 
      array (
        0 => 'Dziennik systemowy',
      ),
      'System Debugger' => 
      array (
        0 => 'Debuger systemowy',
      ),
      'Users' => 
      array (
        0 => 'Użytkownicy',
      ),
      'User Accounts' => 
      array (
        0 => 'Konto użytkownika',
      ),
      'API Keys' => 
      array (
        0 => 'Klucze API',
      ),
      'Connected AzuraRelays' => 
      array (
        0 => 'Połączone AzuraRelays',
      ),
      'Install SHOUTcast' => 
      array (
        0 => 'Zainstaluj SHOUTcast',
      ),
      'Start Station' => 
      array (
        0 => 'Uruchom stację',
      ),
      'Ready to start broadcasting? Click to start your station.' => 
      array (
        0 => 'Gotów by rozpocząć nadawanie? Kliknij, aby uruchomić stację.',
      ),
      'Restart broadcasting? This will disconnect any current listeners.' => 
      array (
        0 => 'Zrestartować transmisję? Spowoduje to rozłączenie wszystkich obecnych słuchaczy.',
      ),
      'Restart to Apply Changes' => 
      array (
        0 => 'Zrestartuj, by zastosować zmiany',
      ),
      'Click to restart your station and apply configuration changes.' => 
      array (
        0 => 'Kliknij, aby zrestartować stację i zastosować zmiany w konfiguracji.',
      ),
      'Podcasts (Beta)' => 
      array (
        0 => 'Podcasty (Beta)',
      ),
      'Reports' => 
      array (
        0 => 'Zgłoszenia',
      ),
      'Duplicate Songs' => 
      array (
        0 => 'Zduplikowane utwory',
      ),
      'Unprocessable Files' => 
      array (
        0 => 'Pliki nieprzetwarzalne',
      ),
      'SoundExchange Royalties' => 
      array (
        0 => 'Tantiemy SoundExchange',
      ),
      'Utilities' => 
      array (
        0 => 'Narzędzia',
      ),
      'Automated Assignment' => 
      array (
        0 => 'Automatyczne przypisanie',
      ),
      'Log Viewer' => 
      array (
        0 => 'Podgląd dziennika',
      ),
      'Restart Broadcasting' => 
      array (
        0 => 'Ponowne uruchomienie nadawania',
      ),
      'Enable Automated Assignment' => 
      array (
        0 => 'Włącz automatyczne przydzielanie',
      ),
      'Allow the system to periodically automatically assign songs to playlists based on their performance. This process will run in the background, and will only run if this option is set to "Enabled" and at least one playlist is set to "Include in Automated Assignment".' => 
      array (
        0 => 'Okresowo pozwala systemowi na automatyczne przypisanie utworów do odtwarzania w oparciu o wydajność. Proces ten będzie działał w tle i będzie działać tylko wtedy, gdy opcja ta jest ustawiona na "Włączone" i co najmniej jedna lista jest ustawiony na "Dołącz do automatycznego przypisywania".',
      ),
      'Days Between Automated Assignments' => 
      array (
        0 => 'Dni pomiędzy automatycznymi przypisywaniami',
      ),
      'Based on this setting, the system will automatically reassign songs every (this) days using data from the previous (this) days.' => 
      array (
        0 => 'Na podstawie tego parametru, system automatycznie przypisze tytuły każda (X) dni, wykorzystując dane z ostatnich dni (X).',
      ),
      '%d days' => 
      array (
        0 => '%d dni',
      ),
      'Use Browser Default' => 
      array (
        0 => 'Użyj przeglądarki domyślnej',
      ),
      'Reset Password' => 
      array (
        0 => 'Resetuj hasło',
      ),
      'Leave these fields blank to continue using your current password.' => 
      array (
        0 => 'Pozostaw te pola puste, aby nadal używać obecnego hasła.',
      ),
      'Current Password' => 
      array (
        0 => 'Obecne hasło',
      ),
      'Confirm New Password' => 
      array (
        0 => 'Potwierdź Nowe Hasło',
      ),
      'Customization' => 
      array (
        0 => 'Dostosowywanie',
      ),
      'Site Theme' => 
      array (
        0 => 'Motyw witryny',
      ),
      'Describe the use-case for this API key for future reference.' => 
      array (
        0 => 'Opisz przypadek użycia tego klucza API w przyszłości.',
      ),
      'Storage Location' => 
      array (
        0 => 'Lokalizacja przechowywania',
      ),
      'Backup Filename' => 
      array (
        0 => 'Nazwa pliku kopii zapasowej',
      ),
      'This will be the file name for your backup, include the file type (.zip or .rar) you wish to use.' => 
      array (
        0 => 'Będzie to nazwa pliku kopii zapasowej, dołącz typ pliku (.zip lub .rar), którego chcesz użyć.',
      ),
      'Exclude Media from Backup' => 
      array (
        0 => 'Wyklucz multimedia z kopii zapasowych',
      ),
      'This will produce a significantly smaller backup, but you should make sure to back up your media elsewhere. Note that only locally stored media will be backed up.' => 
      array (
        0 => 'To spowoduje znacznie mniejszą kopię zapasową, ale powinieneś zrobić kopię zapasową swoich mediów gdzie indziej. Zauważ, że tylko lokalnie przechowywane media będą zapisywane w kopii zapasowej.',
      ),
      'Yes' => 
      array (
        0 => 'Tak',
      ),
      'No' => 
      array (
        0 => 'Nie',
      ),
      'Run Automatic Nightly Backups' => 
      array (
        0 => 'Uruchom automatyczne nocne tworzenie kopii zapasowych',
      ),
      'Enable to have AzuraCast automatically run nightly backups at the time specified.' => 
      array (
        0 => 'Pozwala AzuraCast na automatyczne tworzenie nocnych kopii zapasowych w podanym czasie.',
      ),
      'Scheduled Backup Time' => 
      array (
        0 => 'Zaplanowany czas tworzenia kopii zapasowych',
      ),
      'The time (in UTC) to run the automated backup, if enabled.' => 
      array (
        0 => 'Czas (w UTC) uruchomienia automatycznej kopii zapasowej, jeśli jest włączona.',
      ),
      'Exclude Media from Backups' => 
      array (
        0 => 'Wyklucz multimedia z kopii zapasowych',
      ),
      'Excluding media from automated backups will save space, but you should make sure to back up your media elsewhere. Note that only locally stored media will be backed up.' => 
      array (
        0 => 'Wykluczenie multimediów z automatycznych kopii zapasowych oszczędzi miejsce, ale powinieneś zrobić kopię zapasową swoich multimediów gdzie indziej. Miej na względzie, że zapisywane w kopii zapasowej będą tylko lokalnie przechowywane multimedia.',
      ),
      'Number of Backup Copies to Keep' => 
      array (
        0 => 'Liczba kopii zapasowych przechowywanych na dysku',
      ),
      'Copies older than the specified number of days will automatically be deleted. Set to zero to disable automatic deletion.' => 
      array (
        0 => 'Kopie starsze niż podana liczba dni będą automatycznie usuwane. Ustaw zero, aby wyłączyć automatyczne usuwanie.',
      ),
      'Attempt to Automatically Retrieve ISRC When Missing' => 
      array (
        0 => 'Próbuj Automatycznie Pobrać ISRC w Razie Braku',
      ),
      'If enabled, AzuraCast will connect to the MusicBrainz database to attempt to find an ISRC for any files where one is missing. Disabling this may improve performance.' => 
      array (
        0 => 'Jeśli włączone, AzuraCast połączy się z bazą danych MusicBrainz, aby spróbować znaleźć ISRC dla każdego pliku, w którym brakuje tej wartości. Wyłączenie tego może poprawić wydajność.',
      ),
      'Roles' => 
      array (
        0 => 'Role',
      ),
      'Code from Authenticator App' => 
      array (
        0 => 'Kod z aplikacji uwierzytelniającej',
      ),
      'Enter the current code provided by your authenticator app to verify that it\'s working correctly.' => 
      array (
        0 => 'Podaj kod obecnie wyświetlany przez aplikację uwierzytelniającą, aby zweryfikować, czy działa ona poprawnie.',
      ),
      'Verify Authenticator' => 
      array (
        0 => 'Zweryfikuj aplikację uwierzytelniającą',
      ),
      'Any time the currently playing song changes' => 
      array (
        0 => 'Za każdym razem, gdy zmienia się aktualnie odtwarzany utwór',
      ),
      'Any time the listener count increases' => 
      array (
        0 => 'Za każdym razem, gdy zwiększa się licznik słuchaczy',
      ),
      'Any time the listener count decreases' => 
      array (
        0 => 'Za każdym razem, gdy zmniejsza się licznik słuchaczy',
      ),
      'Any time a live streamer/DJ connects to the stream' => 
      array (
        0 => 'Za każdym razem, gdy nadający/DJ łączy się ze streamem',
      ),
      'Any time a live streamer/DJ disconnects from the stream' => 
      array (
        0 => 'Za każdym razem, gdy nadający/DJ rozłącza się ze streamem',
      ),
      'When the station broadcast goes offline.' => 
      array (
        0 => 'Kiedy transmisja się kończy.',
      ),
      'When the station broadcast comes online.' => 
      array (
        0 => 'Kiedy transmisja się rozpoczyna.',
      ),
      'Generic Web Hook' => 
      array (
        0 => 'Ogólny webhook',
      ),
      'Automatically send a message to any URL when your station data changes.' => 
      array (
        0 => 'Automatycznie wysyłaj wiadomość pod każdy URL, gdy dane Twojej stacji ulegną zmianie.',
      ),
      'Send E-mail' => 
      array (
        0 => 'Wyślij e-mail',
      ),
      'Send an e-mail to specified address(es).' => 
      array (
        0 => 'Wyślij e-mail na określony adres(y).',
      ),
      'TuneIn AIR' => 
      array (
        0 => 'TuneIn AIR',
      ),
      'Send song metadata changes to TuneIn.' => 
      array (
        0 => 'Wysyłaj aktualizacje metadanych utworu do TuneIn.',
      ),
      'Discord Webhook' => 
      array (
        0 => 'Webhook Discord\'a',
      ),
      'Automatically send a customized message to your Discord server.' => 
      array (
        0 => 'Automatycznie wysyłaj spersonalizowaną wiadomość na swój serwer Discord.',
      ),
      'Telegram Chat Message' => 
      array (
        0 => 'Wiadomość czatu w Telegram',
      ),
      'Use the Telegram Bot API to send a message to a channel.' => 
      array (
        0 => 'Wyślij wiadomość do kanału za pomocą interfejsu Telegram Bot API.',
      ),
      'Twitter Post' => 
      array (
        0 => 'Post na Twitterze',
      ),
      'Automatically send a tweet.' => 
      array (
        0 => 'Automatycznie wyślij tweeta.',
      ),
      'Google Analytics Integration' => 
      array (
        0 => 'Integracja Google Analytics',
      ),
      'Send stream listener details to Google Analytics.' => 
      array (
        0 => 'Wyślij szczegóły streamu do Google Analytics.',
      ),
      'Matomo Analytics Integration' => 
      array (
        0 => 'Integracja z Matomo Analytics',
      ),
      'Send stream listener details to Matomo Analytics.' => 
      array (
        0 => 'Wyślij szczegóły dotyczące słuchaczy strumienia do Matomo Analytics.',
      ),
      'Account Recovery' => 
      array (
        0 => 'Odzyskiwanie konta',
      ),
      'An account recovery link has been requested for your account on "%s".' => 
      array (
        0 => 'Poproszono o link odzyskiwania konta na "%s".',
      ),
      'Click the link below to log in to your account.' => 
      array (
        0 => 'Kliknij poniższy link, aby zalogować się do swojego konta.',
      ),
      'Skip to main content' => 
      array (
        0 => 'Skocz do treści głównej',
      ),
      'Toggle Sidebar' => 
      array (
        0 => 'Przełącz panel boczny',
      ),
      'Toggle Menu' => 
      array (
        0 => 'Przełącz menu',
      ),
      'System Administration' => 
      array (
        0 => 'Administracja systemem',
      ),
      'Switch Theme' => 
      array (
        0 => 'Przełącz motyw',
      ),
      'My API Keys' => 
      array (
        0 => 'Moje klucze API',
      ),
      'Help' => 
      array (
        0 => 'Pomoc',
      ),
      'End Session' => 
      array (
        0 => 'Zakończ sesję',
      ),
      'Sign Out' => 
      array (
        0 => 'Wyloguj się',
      ),
      'Powered by %s' => 
      array (
        0 => 'Powered by %s',
      ),
      'Like our software? <a href="%s" target="_blank">Donate to support AzuraCast!</a>' => 
      array (
        0 => 'Podoba Ci się nasze oprogramowanie? <a href="%s" target="_blank">Wesprzyj finansowo AzuraCast!</a>',
      ),
      'Errors were encountered when trying to save changes:' => 
      array (
        0 => 'Podczas zapisywania zmian wystąpiły następujące błędy:',
      ),
      'General' => 
      array (
        0 => 'Ogólne',
      ),
      'Details' => 
      array (
        0 => 'Szczegóły',
      ),
      'Server Status' => 
      array (
        0 => 'Status serwera',
      ),
      'CPU Load' => 
      array (
        0 => 'Obciążenie procesora',
      ),
      'Current' => 
      array (
        0 => 'Obecnie',
      ),
      '15-Minute Average' => 
      array (
        0 => 'Średnia 15-minutowa',
      ),
      'Memory' => 
      array (
        0 => 'Pamięć',
      ),
      '%s of %s Used' => 
      array (
        0 => '%s z %s używane',
      ),
      'Disk Space' => 
      array (
        0 => 'Miejsce na dysku',
      ),
      'Synchronization Tasks' => 
      array (
        0 => 'Zadania synchronizacji',
      ),
      'Last run: %s' => 
      array (
        0 => 'Ostatnie uruchomienie: %s',
      ),
      'Run Task' => 
      array (
        0 => 'Uruchom zadanie',
      ),
      'API Key' => 
      array (
        0 => 'Klucz API',
      ),
      'Owner' => 
      array (
        0 => 'Właściciel',
      ),
      'Revoke' => 
      array (
        0 => 'Wycofaj',
      ),
      'Clear Cache' => 
      array (
        0 => 'Wyczyść pamięć podręczną',
      ),
      'Clearing the application cache may log you out of your session.' => 
      array (
        0 => 'Wyczyszczenie pamięci podręcznej może wylogować Cię z Twojej sesji.',
      ),
      'Clear All Message Queues' => 
      array (
        0 => 'Wyczyść wszystkie kolejki wiadomości',
      ),
      'This will clear any pending unprocessed messages in all message queues.' => 
      array (
        0 => 'Spowoduje to wyczyszczenie oczekujących nieprzetworzonych wiadomości we wszystkich kolejkach wiadomości.',
      ),
      'Message Queues' => 
      array (
        0 => 'Kolejki wiadomości',
      ),
      '%d queued messages' => 
      array (
        0 => '%d wiadomości w kolejce',
      ),
      'Station-Specific Debugging' => 
      array (
        0 => 'Debugowanie Dla Poszczególnych Stacji',
      ),
      'Rebuild AutoDJ Queue' => 
      array (
        0 => 'Przebuduj kolejkę AutoDJ',
      ),
      'Run Test' => 
      array (
        0 => 'Uruchom Testowo',
      ),
      'Send Liquidsoap Telnet Command' => 
      array (
        0 => 'Wyślij polecenie Liquidsoap Telnet',
      ),
      'Command' => 
      array (
        0 => 'Polecenie',
      ),
      'Execute Command' => 
      array (
        0 => 'Wykonaj polecenie',
      ),
      'Run Synchronization Task' => 
      array (
        0 => 'Uruchom zadanie synchronizacji',
      ),
      'Debug Home' => 
      array (
        0 => 'Debugowanie - Strona Główna',
      ),
      'The synchronization task is running in the background. The log below will update automatically.' => 
      array (
        0 => 'Zadanie synchronizacji jest uruchomione w tle. Poniższy dziennik zostanie zaktualizowany automatycznie.',
      ),
      'Log In' => 
      array (
        0 => 'Zaloguj',
      ),
      'Delete user "%s"?' => 
      array (
        0 => 'Usunąć użytkownika "%s"?',
      ),
      '(You)' => 
      array (
        0 => '(Ty)',
      ),
      'Because you are running Docker, some system logs can only be accessed from a shell session on the host computer. You can run <code>%s</code> to access container logs from the terminal.' => 
      array (
        0 => 'Ponieważ używasz Dockera, niektóre dzienniki są dostępne tylko poprzez sesję powłoki na komputerze-hoście. Możesz uruchomić <code>%s</code> aby uzyskać dostęp do dzienników kontenera z poziomu terminala.',
      ),
      'Logs by Station' => 
      array (
        0 => 'Dzienniki według stacji',
      ),
      'Relay' => 
      array (
        0 => 'Relay',
      ),
      'Is Public' => 
      array (
        0 => 'Publiczny',
      ),
      'First Connected' => 
      array (
        0 => 'Połączony Jako Pierwszy',
      ),
      'Latest Update' => 
      array (
        0 => 'Najnowsza aktualizacja',
      ),
      'Backups Home' => 
      array (
        0 => 'Strona główna kopii zapasowych',
      ),
      'The backup process is running in the background. The log below will update automatically.' => 
      array (
        0 => 'Proces tworzenia kopii zapasowej jest uruchomiony w tle. Poniższy dziennik zostanie zaktualizowany automatycznie.',
      ),
      'Automatic Backups' => 
      array (
        0 => 'Automatyczne kopie zapasowe',
      ),
      'Never run' => 
      array (
        0 => 'Nigdy nie uruchamiane',
      ),
      'Configure' => 
      array (
        0 => 'Konfiguracja',
      ),
      'Most Recent Backup Log' => 
      array (
        0 => 'Najświeższy dziennik kopii zapasowej',
      ),
      'Restoring Backups' => 
      array (
        0 => 'Przywracanie kopii zapasowych',
      ),
      'To restore a backup from your host computer, run:' => 
      array (
        0 => 'Aby przywrócić kopię zapasową z własnego komputera, uruchom:',
      ),
      'Note that restoring a backup will clear your existing database. Never restore backup files from untrusted users.' => 
      array (
        0 => 'Miej na uwadze, że przywrócenie kopii zapasowej wyczyści Twoją obecną bazę danych. Nigdy nie przywracaj kopii zapasowych pochodzących od użytkowników, którym nie ufasz.',
      ),
      'Backup' => 
      array (
        0 => 'Kopia zapasowa',
      ),
      'Last Modified' => 
      array (
        0 => 'Ostatnio zmodyfikowane',
      ),
      'Delete backup "%s"?' => 
      array (
        0 => 'Usunąć kopię zapasową "%s"?',
      ),
      'Report Not Available' => 
      array (
        0 => 'Raport niedostępny',
      ),
      'This report is not available for this station, because the system administrator has chosen not to collect detailed IP-based listener information.' => 
      array (
        0 => 'Raport dla tej stacji nie jest dostępny, ponieważ administrator systemu postanowił nie zbierać szczegółowych informacji o słuchaczach w oparciu o IP.',
      ),
      'Station Broadcasting Disabled' => 
      array (
        0 => 'Nadawanie stacji wyłączone',
      ),
      'Your station is currently not enabled for broadcasting. You can still manage media, playlists, and other station settings. To re-enable broadcasting, <a href="%s">edit your station profile</a>.' => 
      array (
        0 => 'Dla Twojej stacji, nadawanie jest obecnie wyłączone. Nadal możesz zarządzać multimediami, playlistami i innymi ustawieniami stacji. Aby włączyć nadawanie ponownie, <a href="%s">wyedytuj profil swojej stacji</a>.',
      ),
      'Available Logs' => 
      array (
        0 => 'Dostępne dzienniki',
      ),
      'Station Time' => 
      array (
        0 => 'Czas stacji',
      ),
      'Automated Playlist Assignment' => 
      array (
        0 => 'Przypisanie automatycznych list odtwarzania',
      ),
      'Based on the previous performance of your station\'s songs, %s can automatically distribute songs evenly among your playlists, placing the highest performing songs in the highest-weighted playlists.' => 
      array (
        0 => 'Na podstawie dotychczasowych wyników piosenek w stacji %s może automatycznie rozprowadzać równomiernie utwory z listy odtwarzania, umieszczania poszczególnych zasobów w najczęstszych playlistach.',
      ),
      'Once you have configured automated assignment, click the button below to run the automated assignment process. This process will not run at all unless you have selected "Enable" below.' => 
      array (
        0 => 'Po skonfigurowaniu automatycznego przypisania, kliknij poniższy przycisk, aby uruchomić proces automatycznego przypisania. Ten proces nie będzie działać w ogóle, chyba że wybrano "Włącz" poniżej.',
      ),
      'Run Automated Assignment' => 
      array (
        0 => 'Uruchom zautomatyzowane przypisanie',
      ),
      'Configure Automated Assignment' => 
      array (
        0 => 'Konfigurowanie automatycznego przypisania',
      ),
      'Streamer accounts are currently disabled for this station. To enable streamer accounts, click the button below.' => 
      array (
        0 => 'Konta streamera są obecnie wyłączone dla tej stacji. Aby włączyć konta typu streamer, kliknij poniższy przycisk.',
      ),
      'Enable Streaming' => 
      array (
        0 => 'Włącz Streaming',
      ),
      'Two-Factor Authentication' => 
      array (
        0 => 'Uwierzytelnianie dwuskładnikowe',
      ),
      'Two-factor authentication improves the security of your account by requiring a second one-time access code in addition to your password when you log in.' => 
      array (
        0 => 'Uwierzytelnianie dwuskładnikowe poprawia bezpieczeństwo Twojego konta, ponieważ wymaga podania kodu jednorazowego dostępu oprócz hasła podczas logowania.',
      ),
      'Disable Two-Factor' => 
      array (
        0 => 'Wyłącz uwierzytelnianie dwuskładnikowe',
      ),
      'Enable Two-Factor' => 
      array (
        0 => 'Włącz uwierzytelnianie dwuskładnikowe',
      ),
      'Enable Two-Factor Authentication' => 
      array (
        0 => 'Włącz weryfikację dwuetapową',
      ),
      'Step 1: Scan QR Code' => 
      array (
        0 => 'Krok 1: Zeskanuj kod QR',
      ),
      'From your smartphone, scan the code to the right using an authentication app of your choice (FreeOTP, Authy, etc).' => 
      array (
        0 => 'Używając smartfona, zeskanuj kod po prawej stronie, używając wybranej przez siebie aplikacji uwierzytelniającej (FreeOTP, Authy, itp).',
      ),
      'Step 2: Verify Generated Code' => 
      array (
        0 => 'Krok 2: Zweryfikuj wygenerowany kod',
      ),
      'To verify that the code was set up correctly, enter the 6-digit code the app shows you.' => 
      array (
        0 => 'Aby sprawdzić, czy kod został ustawiony poprawnie, wpisz tutaj sześciocyfrowy kod wyświetlany przez aplikację.',
      ),
      'QR-Code' => 
      array (
        0 => 'Kod QR',
      ),
      'No entries found.' => 
      array (
        0 => 'Nie znaleziono wpisów.',
      ),
      'View Details' => 
      array (
        0 => 'Zobacz szczegóły',
      ),
      'New Key Generated' => 
      array (
        0 => 'Wygenerowano nowy klucz',
      ),
      '<b>Important: copy the key below before continuing!</b> You will not be able to retrieve it again.' => 
      array (
        0 => '<b>Ważne: Przed kontynuowaniem, skopiuj klucz!</b> Ponowne uzyskanie go nie będzie możliwe.',
      ),
      'Your full API key is below:' => 
      array (
        0 => 'Oto Twój pełny klucz API:',
      ),
      'When making API calls, you can pass this value in the "X-API-Key" header to authenticate as yourself. You can only perform the actions your user account is allowed to perform.' => 
      array (
        0 => 'Tworząc wywołania API, możesz przekazać tę wartość w nagłówku "X-API-Key", aby się uwierzytelnić. Możesz wykonywać tylko operacje dozwolone na Twoim koncie użytkownika.',
      ),
      'Continue' => 
      array (
        0 => 'Konynuuj',
      ),
      'API keys can be used to access some system functionality without needing to log in. All of the keys
            you create share your permissions in the system. For more information, see the <a href="%s">API documentation</a>.' => 
      array (
        0 => 'Klucze API mogą być używane do uzyskania dostępu do niektórych funkcji systemowych bez konieczności logowania się. Wszystkie klucze
            jakie tworzysz posiadają twoje uprawnienia w systemie. Aby uzyskać więcej informacji, zobacz <a href="%s">dokumentację API</a>.',
      ),
      'Key Identifier' => 
      array (
        0 => 'Identyfikator klucza',
      ),
      'Enter Two-Factor Code' => 
      array (
        0 => 'Wprowadź kod jednorazowy weryfikacji dwuetapowej',
      ),
      'Your account uses a two-factor security code. Enter the code your device is currently showing below.' => 
      array (
        0 => 'Twoje konto wykorzystuje jednorazowe kody weryfikacji dwuetapowej. Podaj poniżej kod aktualnie wyświetlony na Twoim urządzeniu.',
      ),
      'Security Code' => 
      array (
        0 => 'Kod bezpieczeństwa',
      ),
      'Sign in' => 
      array (
        0 => 'Zaloguj się',
      ),
      'Forgot Password' => 
      array (
        0 => 'Zapomniałem hasło',
      ),
      'name@example.com' => 
      array (
        0 => 'ktoś@domena.pl',
      ),
      'Send Recovery E-mail' => 
      array (
        0 => 'Wyślij e-mail odzyskiwania',
      ),
      'Welcome!' => 
      array (
        0 => 'Witaj!',
      ),
      'Welcome to %s!' => 
      array (
        0 => 'Witaj w %s!',
      ),
      'Enter your password' => 
      array (
        0 => 'Podaj swoje hasło',
      ),
      'Remember me' => 
      array (
        0 => 'Zapamiętaj mnie',
      ),
      'Please log in to continue.' => 
      array (
        0 => 'Proszę, zaloguj się, aby kontynuować.',
      ),
      'Forgot your password?' => 
      array (
        0 => 'Zapomniałeś hasła?',
      ),
      'This installation\'s administrator has not configured this functionality.' => 
      array (
        0 => 'Administrator tej instalacji nie skonfigurował tej funkcji.',
      ),
      'Contact an administrator to reset your password following the instructions in our documentation:' => 
      array (
        0 => 'Skontaktuj się z administratorem, aby zresetować hasło zgodnie z instrukcjami zawartymi w naszej dokumentacji:',
      ),
      'Password Reset Instructions' => 
      array (
        0 => 'Instrukcje resetowania hasła',
      ),
      'Recover Account' => 
      array (
        0 => 'Odzyskaj konto',
      ),
      'Choose a new password for your account.' => 
      array (
        0 => 'Wybierz nowe hasło dla swojego konta.',
      ),
      'Automatically scroll to the bottom of the log' => 
      array (
        0 => 'Automatycznie przewiń do końca dziennika',
      ),
      'Need Help?' => 
      array (
        0 => 'Potrzebujesz pomocy?',
      ),
      'You can find answers for many common questions in our <a href="%s" target="_blank">support documents</a>.' => 
      array (
        0 => 'Odpowiedzi na często zadawane pytania możesz znaleźć w naszej <a href="%s" target="_blank">dokumentacji</a>.',
      ),
      'If you\'re experiencing a bug or error, you can submit a GitHub issue using the link below.' => 
      array (
        0 => 'Jeśli napotkałeś usterkę lub błąd, możesz wysłać zgłoszenie na GitHubie, korzystając z poniższego linku.',
      ),
      'Your current installation type is <b>%s</b>. Be sure to include this when creating a new issue.' => 
      array (
        0 => 'Twój obecny typ instalacji to <b>%s</b>. Pamiętaj, aby zamieścić tę informację, tworząc nowe zgłoszenie.',
      ),
      'Add New GitHub Issue' => 
      array (
        0 => 'Dodaj Nowe Zgłoszenie Problemu na GitHubie',
      ),
    ),
  ),
);